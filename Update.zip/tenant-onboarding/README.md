# Tenant onboarding

A small standalone service for operators, with two tabs:

* **Onboard company** - type a company name and its collector details (step 1), optionally create
  its first user (step 2), and the company is set up.
* **Tenants** - see every registered company, search and sort, copy IDs, and **edit** a company's
  domain and collector details. Edits go to the `nhi_global.tenants` table only.

It is deployed on its own and shares no code with the API server or the frontend;
it only needs to reach the platform's Postgres.

## What one submit does (all or nothing, in one transaction)

1. **Company row.** Adds one row to `nhi_global.tenants`:

   | Column | Value |
   |---|---|
   | `db_name` | made from the company name: lowercase, `_` between words, at most 23 characters (`Acme Corp` -> `acme_corp`) |
   | `domain_name` | the same name with hyphens plus `DOMAIN_SUFFIX` (`acme-corp.nhi.local`) |
   | `tenant_id` | a new random UUID |
   | `created_at` | now |
   | `collector_aws_account_id`, `collector_external_id`, `collector_event_bridge_arn`, `collector_regions` | what you typed - all four are required |

2. **Company workspace.** Creates the schema named `db_name` with every tenant table
   (65 tables, the two time-partitioned posture tables with their first partitions, and the
   reference rows the posture engine needs: pillars, categories, rule weights, drift config).
   An existing schema is never altered.
3. **Customer account (optional field).** If you enter the customer's AWS account ID, a row is added
   to that schema's `accounts` table with `tenant_id`, `account_id`, `client_aws_account_id`,
   `regions` and **`external_id` = the collector External ID**, status `pending`. Leave the field empty
   and no row is added; the API creates it when the customer connects (it also copies the External
   ID then). The account is refused if another company already has it.
4. **First user (optional section).** Adds a row to `nhi_global.nhi_users`:
   `id` = next free number, `email` = `name@db_name` (what the sign-in page takes),
   `password` = **bcrypt hash** (the plain password is never stored or logged), `full_name`,
   `department`, `team`, `role` (default `admin`), `tenant_id` = the company's, `status` = `active`,
   `last_login_at` empty, `created_at` now. A CSV with the sign-in details downloads in the browser
   (the password lives only in the browser tab; it can't be fetched later).

`nhi_global.refresh_tokens` needs nothing here: the API writes a row each time someone signs in, and
removes them when the user is deleted.

## Editing a company (Tenants tab)

Select **Edit** on a row. You can change: domain, AWS account ID, External ID, event bus ARN, regions.
You cannot change the tenant ID, the workspace name (`db_name`) or the created date: every user,
account and table of the company is tied to them (users sign in as `name@db_name`), so the server
refuses any request that names them.

* Only the `nhi_global.tenants` row is written. Nothing in the company's workspace, its accounts or
  its users is touched. (An account already registered for the customer keeps the External ID it
  had until the API next verifies it.)
* **Same rules as onboarding**: 12-digit account, External ID 16-255 characters, a valid event bus
  ARN, valid regions, a dotted lowercase domain. A saved detail cannot be emptied.
* **Changing the External ID** shows a warning and needs "I understand": the customer's AWS role trusts
  the current value, so their connection stops until the role is updated.
* **No lost updates**: each save sends the values you were looking at; if someone changed the row
  meanwhile, nothing is written and the page offers to load the latest.
* **Old rows**: a company saved long ago in an old format (for example a domain without a dot, or an
  External ID under 16 characters) is marked "Needs update". The database refuses any change to such
  a row until the old values are fixed, so the page asks you to fix them in the same save.
* One company per domain and per External ID: a duplicate is refused.
* The server log records which fields changed (never their values).

## Deleting a company

At the bottom of a company's **Edit** window: **Delete...**. It opens a confirmation that shows what will be
removed (users, connected AWS accounts) and asks you to **type the workspace name**; the button stays
disabled until it matches, and the server checks the name again. In one transaction it:

1. deletes the company's users from `nhi_global.nhi_users` (and their rows in `refresh_tokens`),
2. drops the company's whole schema (`DROP SCHEMA ... CASCADE`: every table and all its data),
3. deletes the company's row from `nhi_global.tenants`.

If any step fails, nothing is deleted. It cannot be undone. It never deletes a protected schema (`public`,
`nhi_global`, `nhi_scanner`, `information_schema`, `pg_*`), even if a company row names one. Not touched:
ClickHouse data (a `<name>_clickhouse` database, if one exists) and anything in the customer's AWS account.
The audit log records `tenant_deleted` with who, the company and what was removed. The database user
therefore also needs `DELETE` on `nhi_global.tenants`, `nhi_global.nhi_users` and `nhi_global.refresh_tokens`,
and to own (or be allowed to drop) the company schemas it created.

## Submitting the same company twice

The company name decides the identity: `Acme Corp`, `acme corp`, `ACME-Corp.` all give `acme_corp`.
A second submit **adds no row**; it answers "already registered", shows any entries that differ from
what is saved (nothing is overwritten - an External ID must never change once a customer trusts it),
and still lets you add a user or fill a missing workspace. Two people submitting at once are
serialised by a database lock. If a row was added by hand earlier, submitting its company builds its
missing workspace without a second row.

Refused with a clear message, nothing saved: an External ID already used by another company, a
customer account already used by another company, a username already taken (`name@db_name`), a
company whose name is too close to a different registered one.

## Signing in

The page opens on a sign-in form (username and password). The administrator is set by environment
variables; nothing is stored in the database, and **the password is only ever kept as a bcrypt hash**.

1. **Make the password hash** (typed hidden, or piped in; the password itself is never stored):

   ```sh
   ./tenant-onboarding hash-password          # or: docker run -it --rm tenant-onboarding hash-password
   ```
   It prints `ADMIN_PASSWORD_HASH='$2a$12$...'`, and a `b64:...` form for docker compose / `.env`
   files where `$` is special. Use 12-72 characters; a long random one is best.
2. Set `ADMIN_USERNAME` (default `admin`), `ADMIN_PASSWORD_HASH`, and `SESSION_SECRET`
   (32+ characters; without it everyone is signed out whenever the service restarts).

How it behaves:

* A wrong username and a wrong password give the same message and take the same time.
* The session is a signed cookie: `HttpOnly` (page scripts can't read it), `SameSite=Strict`,
  `Secure` when `COOKIE_SECURE=true`, gone when the browser closes, and valid for 12 hours at most.
  **Sign out** (account menu, top right) clears it. Changing the password hash or `SESSION_SECRET`
  signs everyone out.
* Only the sign-in page and its stylesheet, logo and wave images are reachable without signing in.
* If the session ends while you are filling in a form, a banner says so and the form keeps what you
  typed; sign in again in a new tab and retry.
* Sign-ins, onboardings and edits write one JSON line each to the service's standard output (who and
  what; edits show old and new values, External IDs shortened). Never a password or a hash.

There is no lockout or second factor, to keep this simple, so use a long random password and keep the
service off the public internet (VPN, or an IP allow-list at the load balancer).

The look is light only: a deep-blue gradient sidebar with soft wave edges, white rounded cards, pill buttons.
Who is signed in and the sign-out icon are at the top right.

## Run

```sh
cp .env.example .env     # fill it in (use the b64: hash form in a .env file)
set -a; . ./.env; set +a
go run .                 # http://localhost:8090
```

Docker: `docker build -t tenant-onboarding .` then run with the same variables.

**Deploy behind https** and set `COOKIE_SECURE=true`. `GET /healthz` needs no sign-in and checks the
database.

API (behind the sign-in cookie): `GET /api/workspace?company=`, `POST /api/onboard`,
`GET /api/tenants`, `PATCH /api/tenants/{id}` (body `{"expected": {...}, "changes": {...}}`).
Public: `GET /api/session`, `POST /api/login`, `POST /api/logout`, `GET /healthz`.

The database user needs: `INSERT`/`SELECT`/`UPDATE`/`DELETE` on `nhi_global.tenants`, `INSERT`/`SELECT`/`DELETE` on
`nhi_global.nhi_users` and `DELETE` on `nhi_global.refresh_tokens`, and `CREATE` on the database (to create new schemas). Existing company
schemas are only read.

## Tests

```sh
go test ./...                                            # logic only
DB_HOST=localhost DB_USER=postgres DB_PASSWORD=... go test ./...   # plus Postgres tests (each makes and drops its own scratch database)
```

## Regenerating the table definitions

`sql/tenant_schema.sql` and `sql/tenant_seed.sql` are generated from a `pg_dump` of nhi_db:

```sh
python3 scripts/extract_tenant_schema.py nhi_db.sql <a_tenant_schema_name>
```

Run it after the tenant tables change, review the diff, run the tests (they expect 65 tables - update
the number in `TestTemplates` if the count changed on purpose).
