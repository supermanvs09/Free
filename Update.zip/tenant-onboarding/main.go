// Command tenant-onboarding is a small standalone service for operators: one
// page where a company is registered and its first user is created. It talks to
// the platform's Postgres directly and shares no code with the API server.
package main

import (
	"bufio"
	"context"
	"database/sql"
	"encoding/base64"
	"errors"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"

	_ "github.com/jackc/pgx/v5/stdlib"
	"golang.org/x/crypto/bcrypt"
	"golang.org/x/term"
)

func env(key, fallback string) string {
	if v := strings.TrimSpace(os.Getenv(key)); v != "" {
		return v
	}
	return fallback
}

// databaseURL is DATABASE_URL, or one built from the same DB_* variables the
// API server uses, so both services can share one env file.
func databaseURL() string {
	if v := strings.TrimSpace(os.Getenv("DATABASE_URL")); v != "" {
		return v
	}
	host := env("DB_HOST", "")
	if host == "" {
		return ""
	}
	u := url.URL{
		Scheme:   "postgres",
		User:     url.UserPassword(env("DB_USER", "postgres"), os.Getenv("DB_PASSWORD")),
		Host:     net.JoinHostPort(host, env("DB_PORT", "5432")),
		Path:     "/" + env("DB_NAME", "nhi_db"),
		RawQuery: "sslmode=" + env("DB_SSLMODE", "require"),
	}
	return u.String()
}

func envBool(key string) bool {
	switch strings.ToLower(strings.TrimSpace(os.Getenv(key))) {
	case "1", "true", "yes", "on":
		return true
	}
	return false
}

func main() {
	if len(os.Args) > 1 {
		switch os.Args[1] {
		case "hash-password":
			hashPassword()
		default:
			fmt.Fprintln(os.Stderr, "usage: tenant-onboarding [hash-password]\n(with no argument it starts the service)")
			os.Exit(2)
		}
		return
	}
	serve()
}

// hashPassword reads a password (hidden when typed, or one line from a pipe) and
// prints the bcrypt hash to put in ADMIN_PASSWORD_HASH. The password itself is
// never stored anywhere.
func hashPassword() {
	var pw []byte
	var err error
	fd := int(os.Stdin.Fd())
	if term.IsTerminal(fd) {
		fmt.Fprint(os.Stderr, "Password (12-72 characters): ")
		pw, err = term.ReadPassword(fd)
		fmt.Fprintln(os.Stderr)
		if err == nil {
			fmt.Fprint(os.Stderr, "Repeat it: ")
			var again []byte
			again, err = term.ReadPassword(fd)
			fmt.Fprintln(os.Stderr)
			if err == nil && string(again) != string(pw) {
				log.Fatal("The two entries differ. Nothing was created.")
			}
		}
	} else {
		var line string
		line, err = bufio.NewReader(os.Stdin).ReadString('\n')
		if err == io.EOF && line != "" {
			err = nil
		}
		pw = []byte(strings.TrimRight(line, "\r\n"))
	}
	if err != nil {
		log.Fatalf("could not read the password: %v", err)
	}
	if len(pw) < 12 || len(pw) > 72 {
		log.Fatal("Use a password of 12 to 72 characters. A long random one is best (openssl rand -base64 18).")
	}
	hash, err := bcrypt.GenerateFromPassword(pw, 12)
	if err != nil {
		log.Fatal(err)
	}
	fmt.Println("Set this as the ADMIN_PASSWORD_HASH environment variable (keep the quotes in a shell):")
	fmt.Printf("\n  ADMIN_PASSWORD_HASH='%s'\n\n", hash)
	fmt.Println("In a docker compose or .env file, where $ is special, use this form instead:")
	fmt.Printf("\n  ADMIN_PASSWORD_HASH=b64:%s\n", base64.StdEncoding.EncodeToString(hash))
}

func serve() {
	dsn := databaseURL()
	if dsn == "" {
		log.Fatal("set DATABASE_URL, or DB_HOST with DB_PORT, DB_NAME, DB_USER, DB_PASSWORD and DB_SSLMODE")
	}
	auth, notes, err := NewAuth(AuthConfig{
		User:         env("ADMIN_USERNAME", "admin"),
		PasswordHash: os.Getenv("ADMIN_PASSWORD_HASH"),
		Secret:       os.Getenv("SESSION_SECRET"),
		CookieSecure: envBool("COOKIE_SECURE"),
	})
	if err != nil {
		log.Fatal(err)
	}
	for _, n := range notes {
		log.Print("note: " + n)
	}
	if !auth.secure {
		log.Print("note: COOKIE_SECURE is not set. Behind https, set COOKIE_SECURE=true so the session cookie is marked Secure.")
	}

	db, err := sql.Open("pgx", dsn)
	if err != nil {
		log.Fatalf("database: %v", err)
	}
	db.SetMaxOpenConns(4)
	db.SetConnMaxLifetime(30 * time.Minute)
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	if err := db.PingContext(ctx); err != nil {
		log.Fatalf("database is not reachable: %v", err)
	}
	cancel()

	svc, err := NewService(db, env("GLOBAL_SCHEMA", "nhi_global"), env("DOMAIN_SUFFIX", "nhi.local"))
	if err != nil {
		log.Fatal(err)
	}
	srv := &http.Server{
		Addr:              ":" + env("PORT", "8090"),
		Handler:           NewHandler(svc, auth, db),
		ReadHeaderTimeout: 10 * time.Second,
		ReadTimeout:       30 * time.Second,
		WriteTimeout:      4 * time.Minute, // a first build of the tables takes seconds, never minutes
		IdleTimeout:       2 * time.Minute,
	}
	go func() {
		stop := make(chan os.Signal, 1)
		signal.Notify(stop, syscall.SIGINT, syscall.SIGTERM)
		<-stop
		shut, done := context.WithTimeout(context.Background(), 30*time.Second)
		defer done()
		_ = srv.Shutdown(shut)
	}()
	log.Printf("tenant onboarding listening on %s", srv.Addr)
	if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
		log.Fatal(err)
	}
}
