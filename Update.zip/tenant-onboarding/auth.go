package main

import (
	"context"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"net/http"
	"strings"
	"time"

	"golang.org/x/crypto/bcrypt"
)

const (
	cookieName    = "nhi_admin_session"
	sessionLength = 12 * time.Hour // signed out after this; the cookie also goes when the browser closes
	minBcryptCost = 10
)

// failDelay slows every wrong sign-in a little, so guessing is slow.
var failDelay = 400 * time.Millisecond

// AuthConfig is read from the environment. The password is never here, only its
// bcrypt hash.
type AuthConfig struct {
	User         string
	PasswordHash string // bcrypt, or "b64:" + base64 of it (for env files where "$" is special)
	Secret       string // signs the session cookie; random per start when empty
	CookieSecure bool   // mark the cookie Secure (set when served over https)
}

// Auth signs the one administrator in: a form, a bcrypt hash from the
// environment, and a signed cookie.
type Auth struct {
	user    string
	userSum [32]byte
	hash    []byte
	dummy   []byte
	key     []byte
	secure  bool
	now     func() time.Time
}

type session struct {
	User string `json:"u"`
	Exp  int64  `json:"exp"`
}

// NewAuth validates the configuration. The returned notes are warnings to log.
func NewAuth(c AuthConfig) (*Auth, []string, error) {
	var notes []string
	user := strings.TrimSpace(c.User)
	if len(user) < 3 || len(user) > 64 {
		return nil, nil, errors.New("ADMIN_USERNAME must be 3-64 characters")
	}
	raw := strings.TrimSpace(c.PasswordHash)
	if strings.HasPrefix(raw, "b64:") {
		b, err := base64.StdEncoding.DecodeString(strings.TrimPrefix(raw, "b64:"))
		if err != nil {
			return nil, nil, errors.New("ADMIN_PASSWORD_HASH starts with b64: but is not valid base64")
		}
		raw = string(b)
	}
	if raw == "" {
		return nil, nil, errors.New("set ADMIN_PASSWORD_HASH (create one with: tenant-onboarding hash-password)")
	}
	cost, err := bcrypt.Cost([]byte(raw))
	if err != nil {
		return nil, nil, errors.New("ADMIN_PASSWORD_HASH is not a bcrypt hash. Create one with: tenant-onboarding hash-password. In an env file or docker compose, where $ is special, use the b64: form it prints")
	}
	if cost < minBcryptCost {
		return nil, nil, fmt.Errorf("ADMIN_PASSWORD_HASH has bcrypt cost %d; use %d or more", cost, minBcryptCost)
	}
	secret := []byte(c.Secret)
	switch {
	case len(secret) == 0:
		secret = make([]byte, 32)
		if _, err := rand.Read(secret); err != nil {
			return nil, nil, err
		}
		notes = append(notes, "SESSION_SECRET is not set: everyone is signed out whenever this service restarts. Set a long random value to keep sessions.")
	case len(secret) < 32:
		return nil, nil, errors.New("SESSION_SECRET must be at least 32 characters (openssl rand -base64 32)")
	}
	// Changing the password hash also ends every open session.
	mac := hmac.New(sha256.New, secret)
	mac.Write([]byte("session|" + raw))
	dummy, err := bcrypt.GenerateFromPassword([]byte("no-such-administrator"), cost)
	if err != nil {
		return nil, nil, err
	}
	return &Auth{
		user: user, userSum: sha256.Sum256([]byte(user)), hash: []byte(raw), dummy: dummy, key: mac.Sum(nil),
		secure: c.CookieSecure, now: time.Now,
	}, notes, nil
}

/* ---------- the cookie ---------- */

func (a *Auth) sign(payload string) string {
	m := hmac.New(sha256.New, a.key)
	m.Write([]byte(payload))
	return base64.RawURLEncoding.EncodeToString(m.Sum(nil))
}

func (a *Auth) isSecure(r *http.Request) bool { return a.secure || r.TLS != nil }

func (a *Auth) setCookie(w http.ResponseWriter, r *http.Request) {
	b, _ := json.Marshal(session{User: a.user, Exp: a.now().Add(sessionLength).Unix()})
	p := base64.RawURLEncoding.EncodeToString(b)
	// No Expires/Max-Age: a session cookie, gone when the browser closes.
	http.SetCookie(w, &http.Cookie{
		Name: cookieName, Value: p + "." + a.sign(p), Path: "/", HttpOnly: true, Secure: a.isSecure(r), SameSite: http.SameSiteStrictMode,
	})
}

func (a *Auth) clearCookie(w http.ResponseWriter, r *http.Request) {
	http.SetCookie(w, &http.Cookie{
		Name: cookieName, Value: "", Path: "/", MaxAge: -1, HttpOnly: true, Secure: a.isSecure(r), SameSite: http.SameSiteStrictMode,
	})
}

// current says who is signed in: nobody for no cookie, a forged or altered one,
// someone else's, or one past its time.
func (a *Auth) current(r *http.Request) (string, bool) {
	c, err := r.Cookie(cookieName)
	if err != nil {
		return "", false
	}
	p, sig, ok := strings.Cut(c.Value, ".")
	if !ok || !hmac.Equal([]byte(sig), []byte(a.sign(p))) {
		return "", false
	}
	raw, err := base64.RawURLEncoding.DecodeString(p)
	var s session
	if err != nil || json.Unmarshal(raw, &s) != nil || s.User != a.user || a.now().Unix() > s.Exp {
		return "", false
	}
	return s.User, true
}

/* ---------- handlers ---------- */

type ctxKey struct{}

// Who is the signed-in administrator of a request that passed requireSession.
func Who(r *http.Request) string {
	u, _ := r.Context().Value(ctxKey{}).(string)
	return u
}

// requireSession lets only the signed-in administrator through. An API call that
// is refused gets a code so the page can say what happened.
func (a *Auth) requireSession(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		user, ok := a.current(r)
		if !ok {
			if strings.HasPrefix(r.URL.Path, "/api/") {
				writeJSON(w, http.StatusUnauthorized, errorBody{Error: "Your session has ended. Sign in again.", Code: "session"})
			} else {
				http.Error(w, "Sign in to continue.", http.StatusUnauthorized)
			}
			return
		}
		next(w, r.WithContext(context.WithValue(r.Context(), ctxKey{}, user)))
	}
}

type loginBody struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

func (a *Auth) login(w http.ResponseWriter, r *http.Request) {
	r.Body = http.MaxBytesReader(w, r.Body, 4<<10)
	var in loginBody
	if err := json.NewDecoder(r.Body).Decode(&in); err != nil {
		writeJSON(w, http.StatusBadRequest, errorBody{Error: "That request could not be read. Reload the page and try again."})
		return
	}
	sum := sha256.Sum256([]byte(strings.TrimSpace(in.Username)))
	userOK := subtle.ConstantTimeCompare(sum[:], a.userSum[:]) == 1
	// Always one bcrypt comparison, so a wrong username takes as long as a wrong password.
	hash := a.hash
	if !userOK {
		hash = a.dummy
	}
	if bcrypt.CompareHashAndPassword(hash, []byte(in.Password)) != nil || !userOK {
		time.Sleep(failDelay)
		audit(r, "login_failed", map[string]any{"username": clip(in.Username, 64)})
		writeJSON(w, http.StatusUnauthorized, errorBody{Error: "Incorrect username or password.", Code: "credentials"})
		return
	}
	a.setCookie(w, r)
	audit(r.WithContext(context.WithValue(r.Context(), ctxKey{}, a.user)), "login", nil)
	writeJSON(w, http.StatusOK, map[string]any{"ok": true, "user": a.user})
}

func (a *Auth) logout(w http.ResponseWriter, r *http.Request) {
	if user, ok := a.current(r); ok {
		audit(r.WithContext(context.WithValue(r.Context(), ctxKey{}, user)), "logout", nil)
	}
	a.clearCookie(w, r)
	writeJSON(w, http.StatusOK, map[string]any{"ok": true})
}

// state tells the page who is signed in.
func (a *Auth) state(w http.ResponseWriter, r *http.Request) {
	user, ok := a.current(r)
	out := map[string]any{"signed_in": ok}
	if ok {
		out["user"] = user
	}
	writeJSON(w, http.StatusOK, out)
}

/* ---------- audit log ---------- */

// audit writes one JSON line per event to the service log: who and what. Never
// a password, a hash or a full External ID.
func audit(r *http.Request, event string, detail map[string]any) {
	rec := map[string]any{"audit": event, "time": time.Now().UTC().Format(time.RFC3339)}
	if r != nil {
		if u := Who(r); u != "" {
			rec["user"] = u
		}
	}
	for k, v := range detail {
		rec[k] = v
	}
	b, _ := json.Marshal(rec)
	log.Print(string(b))
}

func clip(s string, n int) string {
	s = strings.Map(func(r rune) rune {
		if r < 32 || r == 127 {
			return -1 // no control characters in a log line
		}
		return r
	}, strings.TrimSpace(s))
	if len(s) > n {
		return s[:n]
	}
	return s
}
