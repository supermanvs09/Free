package main

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"io"
	"log"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"golang.org/x/crypto/bcrypt"
)

const testPassword = "correct horse battery"

func init() {
	failDelay = 0
	log.SetOutput(io.Discard) // the audit lines are checked where they matter
}

func testHash(t testing.TB) string {
	t.Helper()
	h, err := bcrypt.GenerateFromPassword([]byte(testPassword), minBcryptCost)
	if err != nil {
		t.Fatal(err)
	}
	return string(h)
}

func testAuth(t testing.TB, mutate ...func(*AuthConfig)) *Auth {
	t.Helper()
	cfg := AuthConfig{User: "superadmin", PasswordHash: testHash(t), Secret: strings.Repeat("s", 40)}
	for _, m := range mutate {
		m(&cfg)
	}
	a, _, err := NewAuth(cfg)
	if err != nil {
		t.Fatal(err)
	}
	return a
}

// client is a tiny browser: it keeps the session cookie between requests.
type client struct {
	t      testing.TB
	h      http.Handler
	cookie *http.Cookie
}

func (c *client) do(method, path string, body any, mutate ...func(*http.Request)) *httptest.ResponseRecorder {
	c.t.Helper()
	rd := bytes.NewReader(nil)
	if body != nil {
		b, _ := json.Marshal(body)
		rd = bytes.NewReader(b)
	}
	r := httptest.NewRequest(method, path, rd)
	if c.cookie != nil {
		r.AddCookie(c.cookie)
	}
	for _, m := range mutate {
		m(r)
	}
	w := httptest.NewRecorder()
	c.h.ServeHTTP(w, r)
	for _, ck := range w.Result().Cookies() {
		if ck.Name == cookieName {
			if ck.MaxAge < 0 || ck.Value == "" {
				c.cookie = nil
			} else {
				c.cookie = ck
			}
		}
	}
	return w
}

func (c *client) signIn(user, pass string) *httptest.ResponseRecorder {
	return c.do("POST", "/api/login", map[string]string{"username": user, "password": pass})
}

func authClient(t testing.TB, a *Auth) *client {
	return &client{t: t, h: NewHandler(&Service{suffix: "nhi.local"}, a, nil)}
}

func TestNewAuthValidation(t *testing.T) {
	good := testHash(t)
	for name, cfg := range map[string]AuthConfig{
		"no hash":      {User: "superadmin", Secret: strings.Repeat("s", 40)},
		"not a hash":   {User: "superadmin", PasswordHash: "plaintext-password", Secret: strings.Repeat("s", 40)},
		"bad b64":      {User: "superadmin", PasswordHash: "b64:!!!", Secret: strings.Repeat("s", 40)},
		"short secret": {User: "superadmin", PasswordHash: good, Secret: "short"},
		"short user":   {User: "ab", PasswordHash: good},
	} {
		if _, _, err := NewAuth(cfg); err == nil {
			t.Errorf("%s: should be refused", name)
		}
	}
	weak, _ := bcrypt.GenerateFromPassword([]byte(testPassword), 4)
	if _, _, err := NewAuth(AuthConfig{User: "superadmin", PasswordHash: string(weak)}); err == nil || !strings.Contains(err.Error(), "cost") {
		t.Errorf("a weak hash must be refused: %v", err)
	}
	// The b64: form, for env files where $ is special, is the same hash.
	a, notes, err := NewAuth(AuthConfig{User: "superadmin", PasswordHash: "b64:" + base64.StdEncoding.EncodeToString([]byte(good))})
	if err != nil || len(notes) == 0 {
		t.Fatalf("b64 form: %v notes=%v (no SESSION_SECRET should leave a note)", err, notes)
	}
	if bcrypt.CompareHashAndPassword(a.hash, []byte(testPassword)) != nil {
		t.Error("b64 form decoded to a different hash")
	}
}

func TestSignInPageAndProtectedFiles(t *testing.T) {
	c := authClient(t, testAuth(t))
	// Nobody signed in: the sign-in page at /, and only its own assets.
	if w := c.do("GET", "/", nil); w.Code != 200 || !strings.Contains(w.Body.String(), "Sign in") || strings.Contains(w.Body.String(), "view-tenants") {
		t.Errorf("/ before sign-in = %d", w.Code)
	}
	for _, p := range []string{"/app.css", "/login.js", "/brand/mark.png"} {
		if w := c.do("GET", p, nil); w.Code != 200 {
			t.Errorf("%s should be public, got %d", p, w.Code)
		}
	}
	for _, p := range []string{"/lib.js", "/tenants.js", "/onboard.js", "/app.js", "/index.html"} {
		if w := c.do("GET", p, nil); w.Code != 401 {
			t.Errorf("%s without a session = %d, want 401", p, w.Code)
		}
	}
	for _, p := range []string{"/api/workspace?company=x", "/api/tenants"} {
		w := c.do("GET", p, nil)
		if w.Code != 401 || !strings.Contains(w.Body.String(), `"session"`) {
			t.Errorf("%s = %d %s", p, w.Code, w.Body)
		}
	}
	if w := c.do("POST", "/api/onboard", valid()); w.Code != 401 {
		t.Errorf("onboard without a session = %d", w.Code)
	}
	if w := c.do("PATCH", "/api/tenants/3f7b2c14-8e9a-4d2b-b6c8-5e9f1a2b3c4d", map[string]any{}); w.Code != 401 {
		t.Errorf("edit without a session = %d", w.Code)
	}
	if w := c.do("GET", "/api/session", nil); !strings.Contains(w.Body.String(), `"signed_in":false`) {
		t.Errorf("session = %s", w.Body)
	}

	if w := c.signIn("superadmin", testPassword); w.Code != 200 {
		t.Fatalf("sign in = %d %s", w.Code, w.Body)
	}
	if w := c.do("GET", "/", nil); w.Code != 200 || !strings.Contains(w.Body.String(), "Onboard a company") {
		t.Errorf("/ after sign-in = %d", w.Code)
	}
	for _, p := range []string{"/lib.js", "/tenants.js", "/app.js"} {
		if w := c.do("GET", p, nil); w.Code != 200 {
			t.Errorf("%s after sign-in = %d", p, w.Code)
		}
	}
	if w := c.do("GET", "/api/session", nil); !strings.Contains(w.Body.String(), `"user":"superadmin"`) {
		t.Errorf("session = %s", w.Body)
	}
}

func TestWrongCredentials(t *testing.T) {
	c := authClient(t, testAuth(t))
	var msgs []string
	for _, in := range [][2]string{{"superadmin", "wrong password!"}, {"someone", testPassword}, {"", ""}, {"superadmin", ""}} {
		w := c.signIn(in[0], in[1])
		if w.Code != 401 || c.cookie != nil {
			t.Errorf("%v: %d", in, w.Code)
		}
		msgs = append(msgs, w.Body.String())
	}
	if msgs[0] != msgs[1] {
		t.Error("a wrong username and a wrong password must look identical")
	}
	// Username is trimmed, password is not.
	if w := c.signIn("  superadmin ", testPassword); w.Code != 200 {
		t.Errorf("padded username = %d", w.Code)
	}
	if w := authClient(t, testAuth(t)).signIn("superadmin", testPassword+" "); w.Code != 401 {
		t.Errorf("a trailing space in the password must matter: %d", w.Code)
	}
	if w := c.do("POST", "/api/login", nil); w.Code != 400 {
		t.Errorf("empty body = %d", w.Code)
	}
}

func TestCookie(t *testing.T) {
	c := authClient(t, testAuth(t))
	w := c.signIn("superadmin", testPassword)
	ck := c.cookie
	if ck == nil || !ck.HttpOnly || ck.SameSite != http.SameSiteStrictMode || ck.Path != "/" {
		t.Fatalf("cookie = %+v", ck)
	}
	if ck.MaxAge != 0 || !ck.Expires.IsZero() {
		t.Error("the cookie must be a session cookie, gone when the browser closes")
	}
	if ck.Secure || w.Header().Get("Strict-Transport-Security") != "" {
		t.Error("plain http must not claim Secure/HSTS")
	}
	sc := authClient(t, testAuth(t, func(c *AuthConfig) { c.CookieSecure = true }))
	w = sc.signIn("superadmin", testPassword)
	if sc.cookie == nil || !sc.cookie.Secure || w.Header().Get("Strict-Transport-Security") == "" {
		t.Error("COOKIE_SECURE must mark the cookie Secure and send HSTS")
	}
}

func TestSessionExpiryAndForgery(t *testing.T) {
	a := testAuth(t)
	clock := time.Date(2026, 10, 26, 9, 0, 0, 0, time.UTC)
	a.now = func() time.Time { return clock }
	c := authClient(t, a)
	c.signIn("superadmin", testPassword)
	clock = clock.Add(sessionLength - time.Minute)
	if w := c.do("GET", "/api/workspace?company=x", nil); w.Code != 200 {
		t.Errorf("still inside the session = %d", w.Code)
	}
	clock = clock.Add(2 * time.Minute)
	if w := c.do("GET", "/api/workspace?company=x", nil); w.Code != 401 {
		t.Errorf("past the session = %d", w.Code)
	}

	good := authClient(t, a)
	clock = time.Date(2026, 10, 26, 9, 0, 0, 0, time.UTC)
	good.signIn("superadmin", testPassword)
	payload, sig, _ := strings.Cut(good.cookie.Value, ".")
	for name, v := range map[string]string{
		"altered payload": payload[:len(payload)-2] + "AA." + sig,
		"no signature":    payload,
		"empty signature": payload + ".",
		"garbage":         "x.y",
		"other signature": payload + "." + strings.Repeat("A", 43),
	} {
		f := authClient(t, a)
		f.cookie = &http.Cookie{Name: cookieName, Value: v}
		if w := f.do("GET", "/api/workspace?company=x", nil); w.Code != 401 {
			t.Errorf("%s accepted: %d", name, w.Code)
		}
	}
	// A cookie from another deployment (other secret, or other password) is no good here.
	other := map[string]*Auth{
		"other secret": testAuth(t, func(c *AuthConfig) { c.Secret = strings.Repeat("z", 40) }),
		"other password": testAuth(t, func(c *AuthConfig) {
			h, _ := bcrypt.GenerateFromPassword([]byte("a different one 123"), minBcryptCost)
			c.PasswordHash = string(h)
		}),
	}
	for name, o := range other {
		oc := authClient(t, o)
		pass := testPassword
		if name == "other password" {
			pass = "a different one 123"
		}
		oc.signIn("superadmin", pass)
		cross := authClient(t, a)
		cross.cookie = oc.cookie
		if w := cross.do("GET", "/api/workspace?company=x", nil); w.Code != 401 {
			t.Errorf("%s: a foreign cookie was accepted (%d)", name, w.Code)
		}
	}
}

func TestLogout(t *testing.T) {
	c := authClient(t, testAuth(t))
	c.signIn("superadmin", testPassword)
	if w := c.do("POST", "/api/logout", nil); w.Code != 200 || c.cookie != nil {
		t.Fatalf("logout = %d, cookie kept = %v", w.Code, c.cookie != nil)
	}
	if w := c.do("GET", "/api/workspace?company=x", nil); w.Code != 401 {
		t.Errorf("after logout = %d", w.Code)
	}
	if w := authClient(t, testAuth(t)).do("POST", "/api/logout", nil); w.Code != 200 {
		t.Errorf("logout without a session = %d", w.Code)
	}
}

func TestLogNeverHoldsSecrets(t *testing.T) {
	var buf bytes.Buffer
	log.SetOutput(&buf)
	defer log.SetOutput(io.Discard)
	a := testAuth(t)
	c := authClient(t, a)
	c.signIn("superadmin", "my wrong password 1")
	c.signIn("evil\nuser", testPassword)
	c.signIn("superadmin", testPassword)
	c.do("POST", "/api/logout", nil)
	out := buf.String()
	for _, secret := range []string{testPassword, "my wrong password 1", string(a.hash)} {
		if strings.Contains(out, secret) {
			t.Fatalf("the log contains a secret: %q", secret)
		}
	}
	for _, want := range []string{`"audit":"login_failed"`, `"audit":"login"`, `"audit":"logout"`} {
		if !strings.Contains(out, want) {
			t.Errorf("log lacks %s:\n%s", want, out)
		}
	}
	if strings.Count(out, "\n") != strings.Count(out, `"audit"`) {
		t.Errorf("an entry spans lines (log forging): %q", out)
	}
}
