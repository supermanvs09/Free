# Product film

The film on the home page (`public/video/deep-algorithms-film.mp4`, 1:09). It is made from code so it can be re-cut when the products or the words change: live-action footage carries the world and the threat, and the site's own product pictures carry the answer.

**Structure** (modelled on enterprise security brand films): the stakes in the real world → the threat in one line → the brand → four times over, a **worst case on screen in silence** (a rogue AI agent at 02:14, the right password in the wrong hands, 18,204 bot logins in a minute, a 72-hour breach clock) followed by the product stopping it → proof (customers, certifications) → one ask. The cuts land on the words, and the type is large, left-aligned and kept to a few words.

| File | What it does |
| --- | --- |
| `script.json` | The narration, line by line. `text` is what appears on screen and in captions, `say` is what the voice reads (spellings that help pronunciation, such as "Adap-ID"), and `after` is the pause after each line. The long pauses after `brand`, `zenstra`, `adapid` and `botshield` are the silent worst-case beats. |
| `tts.py` | Synthesises the narration with [Kokoro](https://github.com/hexgrad/kokoro) (Apache-2.0), voice `af_heart`, one line at a time. Writes `vo.wav` and `timings.json`. |
| `footage.json` | The live-action shots: source URL, the window used (`in`, `dur`) and per-shot `lift`/`sat`. Every clip is free for commercial use without attribution (Pexels and Coverr licences). See `CREDITS.md`. |
| `footage.py` | Downloads each shot, cuts its window and gives all shots one grade (cool shadows, muted saturation, gentle film curve), so footage from different cameras cuts together. Writes 1920×1080 JPEG frames at 30 fps. |
| `mix.py` | Generates the score (soft pads, a pulse from the brand moment on, whooshes, a chime, a closing swell), plus an impact and riser into each worst-case beat on their own bus. Ducks the score under the voice and sets it 18 dB below speech. |
| `captions.py` | Writes the WebVTT captions from `timings.json`. |
| `render.mjs` | Opens `film.html` on the dev server, serves the footage frames as `/clips/…`, and captures every frame at 1920×1080. |
| `src/dev/film/Film.jsx` | The film: each scene is a pure function of time, cut to `timings.json`. Shots get a slow camera move, grain and lens falloff. The product scenes reuse the site's product pictures, with their steps driven by the film clock. |

## Remake it

```bash
# 1. voice (Python 3.11+): pip install kokoro-onnx soundfile
#    model files: kokoro-v1.0.onnx and voices-v1.0.bin from github.com/thewh1teagle/kokoro-onnx/releases
python tools/film/tts.py <model-dir> build/film            # vo.wav + timings.json
cp build/film/timings.json tools/film/timings.json

# 2. footage (ffmpeg, curl)
python tools/film/footage.py build/film/cache build/film/clips

# 3. sound
python tools/film/mix.py build/film/vo.wav tools/film/timings.json build/film/mix.wav 68.9

# 4. captions
python tools/film/captions.py tools/film/timings.json public/video/deep-algorithms-film.vtt

# 5. picture (Playwright with Chromium; set CHROMIUM=/path/to/chrome to use a system browser)
npm run dev &                                              # serves film.html
node tools/film/render.mjs http://localhost:5173 build/film/frames build/film/clips

# 6. encode (loudness to -16 LUFS, true peak -1.5 dB)
ffmpeg -framerate 30 -i build/film/frames/f%05d.jpg -i build/film/mix.wav -map 0:v -map 1:a \
  -af "loudnorm=I=-16:TP=-1.5:LRA=9" -ar 48000 -c:v libx264 -preset slow -crf 20 -pix_fmt yuv420p \
  -profile:v high -level 4.1 -g 60 -movflags +faststart -c:a aac -b:a 160k -shortest \
  public/video/deep-algorithms-film.mp4
ffmpeg -i public/video/deep-algorithms-film.mp4 -c:v libvpx-vp9 -b:v 0 -crf 34 -row-mt 1 -c:a libopus -b:a 128k \
  public/video/deep-algorithms-film.webm
ffmpeg -ss 30.5 -i public/video/deep-algorithms-film.mp4 -frames:v 1 -c:v libwebp -quality 86 public/video/film-poster.webp
```

Don't edit source files while `render.mjs` runs. The dev server reloads the page, and the renderer reopens it and redoes the frame, which costs time.

Check the narration by ear, or with a speech-to-text pass (for example faster-whisper `small.en`): every product name should come back spelled correctly. A professional voice recording can replace `vo.wav` one-for-one. If you do, re-time `timings.json` by hand so the scenes stay on the words. Swapping a shot means changing its `src`/`in` in `footage.json` and re-running steps 2 and 5.
