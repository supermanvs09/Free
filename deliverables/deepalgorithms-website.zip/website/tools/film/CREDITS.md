# Footage credits

Live-action shots in the product film. All are free for commercial use with no attribution required; credit is given here anyway.

- Pexels License: https://www.pexels.com/license/
- Coverr License: https://coverr.co/license

| Shot | Used for | Source page |
| --- | --- | --- |
| `city` | Opening city | [Coverr](https://coverr.co/s?q=houston-texas-at-night) |
| `desk` | Analyst at a screen, late | [Coverr](https://coverr.co/s?q=a-man-shutting-down-his-pc-and-walking-away) |
| `rack` | Service accounts | [Pexels](https://www.pexels.com/video/7140928/) |
| `cables` | Cloud keys | [Pexels](https://www.pexels.com/video/1085656/) |
| `terminal` | AI agents | [Pexels](https://www.pexels.com/video/6804117/) |
| `attacker` | Attackers have noticed | [Pexels](https://www.pexels.com/video/6962343/) |
| `typing` | They log in | [Pexels](https://www.pexels.com/video/5240956/) |
| `soc` | Every alert stays quiet | [Pexels](https://www.pexels.com/video/7255101/) |
| `nightroad` | Brand moment and closing card | [Pexels](https://www.pexels.com/video/16456493/) |
| `call` | Worst case: scam call | [Coverr](https://coverr.co/s?q=a+man+using+his+phone+at+home+late+at+night) |
| `towers` | Worst case: rogue AI agent | [Pexels](https://www.pexels.com/video/17499154/) |
| `code` | Zenstra background | [Pexels](https://www.pexels.com/video/853919/) |
| `intruder` | Worst case: wrong person | [Pexels](https://www.pexels.com/video/7534265/) |
| `banking` | adapID background | [Pexels](https://www.pexels.com/video/7821646/) |
| `junction` | Worst case: bot flood | [Coverr](https://coverr.co/s?q=busy-intersection-at-night) |
| `traffic` | BotShield background | [Coverr](https://coverr.co/s?q=cars-driving-at-night) |
| `corridor` | Worst case: breach clock | [Pexels](https://www.pexels.com/video/3192916/) |
| `ward` | ICMS background | [Coverr](https://coverr.co/s?q=iv-in-hospital-room) |
| `charminar` | Built in India (Charminar, Hyderabad) | [Pexels](https://www.pexels.com/video/14590277/) |
| `payment` | Trusted by banks | [Pexels](https://www.pexels.com/video/6602062/) |
| `delhi` | Government (Rashtrapati Bhavan, New Delhi) | [Pexels](https://www.pexels.com/video/20794145/) |
| `office` | Enterprises that cannot afford a breach | [Pexels](https://www.pexels.com/video/7581202/) |
| `morning` | 09:00, the morning after | [Coverr](https://coverr.co/s?q=office+building) |

Also by Deep Algorithms in the film: the product pictures (src/components/viz), logos, the narration (Kokoro, Apache-2.0, voice af_heart) and the score (tools/film/mix.py).
