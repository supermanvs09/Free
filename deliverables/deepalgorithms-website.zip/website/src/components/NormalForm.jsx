import { useEffect, useRef, useState } from 'react';
import { useInView, useReducedMotion, cx } from '../lib/motion.js';

/* The home hero: "the shape of normal". Thousands of points flow along the ridges
   of one living, fingerprint-like form, the behavioural baseline Deep Algorithms
   learns for every identity. Every few seconds a patch of it drifts off pattern
   and turns red, a ring locks on, it is held and dissolves, and the form heals.
   One idea, no product screens: the product pages carry those.

   Rendering: one WebGL2 draw call. Every point is computed in the vertex shader
   from (ridge, position along it, seed) and the clock, so the main thread only
   sets a few uniforms per frame. Without WebGL2, or under reduced motion, the
   still render underneath stays. The animation stops while off screen. */

const POSTER = '/img/hero/shape-of-normal.webp';
const RIDGES = 60;

/* the five worst cases of the film, in its order: what the ring says when it locks on */
const CAUGHT = [
  ['Scam payment', 'held in < 80 ms'],
  ['Agent outside its task', 'blocked in 4 ms'],
  ['Impossible sign-in', 'contained in 1.4 s'],
  ['Bot login wave', 'refused at the edge'],
  ['Read without consent', 'stopped, on record'],
];
const CYCLE = 6.2; // seconds between deviations
const SPAN = 2.6; // how long one deviation lasts, in seconds (phase 0 → 1.4)

const VS = `#version 300 es
precision highp float;
in vec3 a; // ridge 0..1, position along it 0..1, seed 0..1
uniform float uT, uAspect, uDpr, uPh, uAR, uAU, uScale;
uniform vec2 uMouse;
out vec4 vC;
float h(float x) { return fract(sin(x * 127.1) * 43758.5453); }
float n1(float x) { float i = floor(x), f = fract(x); f = f * f * (3. - 2. * f); return mix(h(i), h(i + 1.), f); }
vec3 form(float r, float th, float t) {
  float R = r * (1. + .20 * sin(th + r * 4.) + .11 * sin(2. * th + r * 7.) + .035 * sin(6. * th - t * .3 + r * 11.)) * (1. + .015 * sin(t * .9 + r * 6.));
  vec2 p = vec2(cos(th) * .80, sin(th) * 1.08) * R;
  p += vec2(.07 * sin(r * 9.), .15 * r * r - .05);
  return vec3(p, .28 * cos(min(R, 1.4) * 1.6) - .06);
}
void main() {
  float r = .07 + a.x;
  float flow = (.03 + .05 * a.z) * (a.x > .5 ? -1. : 1.);
  float th = a.y * 6.2831853 + uT * flow;
  vec3 p = form(r, th, uT);
  float gap = step(.22, n1(th * 3.6 + a.x * 61.)); // ridge endings and forks
  float dr = abs(a.x - uAR), du = abs(fract(a.y - uAU + .5) - .5);
  float inA = (1. - smoothstep(.06, .11, dr)) * (1. - smoothstep(.05, .1, du)) * step(0., uPh);
  float ph = uPh, live = step(ph, 1.);
  vec2 dir = normalize(p.xy + 1e-4);
  p.xy += dir * inA * live * (smoothstep(0., .35, ph) * .16 + (n1(a.z * 40. + uT * 2.) - .5) * .07 * ph);
  p.z += inA * live * smoothstep(0., .35, ph) * .12;
  p += inA * live * smoothstep(.72, 1., ph) * vec3(h(a.z * 9.) - .5, h(a.z * 13.) - .5, h(a.z * 17.) - .3) * .9;
  float ry = .24 * sin(uT * .11), rx = -.2 + .05 * sin(uT * .07);
  p = vec3(p.x * cos(ry) + p.z * sin(ry), p.y, -p.x * sin(ry) + p.z * cos(ry));
  p = vec3(p.x, p.y * cos(rx) - p.z * sin(rx), p.y * sin(rx) + p.z * cos(rx));
  float w = 2.6 - p.z;
  vec2 s = p.xy * uScale / w;
  s.x /= uAspect;
  vec2 dm = s - uMouse;
  float md = length(dm * vec2(uAspect, 1.));
  s += normalize(dm + 1e-5) * .05 * exp(-md * md * 40.);
  gl_Position = vec4(s, 0., 1.);
  float depth = clamp((1.4 - p.z) / 1.6, .3, 1.);
  gl_PointSize = (1.5 + 2.3 * a.z * a.z) * uDpr * (2.2 / w);
  vec3 c = mix(vec3(.30, .62, 1.), vec3(.68, .94, 1.), h(a.z * 7.));
  c = mix(c, vec3(1.6, .42, .34), inA * live * smoothstep(0., .25, ph));
  float fade = 1. - inA * (smoothstep(.75, 1., ph) - smoothstep(1.05, 1.4, ph));
  float edge = 1. - .65 * smoothstep(.55, 1., a.x); // outer ridges thin out, the core stays bright
  vC = vec4(c, gap * depth * edge * (.6 + .4 * h(a.z * 3.)) * fade * (1. + inA * live * .8));
}`;
const FS = `#version 300 es
precision mediump float;
in vec4 vC; out vec4 o;
void main() { float k = smoothstep(.5, 0., length(gl_PointCoord - .5)); o = vec4(vC.rgb * vC.a * k, vC.a * k); }`;

/* the same form on the CPU, for where the ring goes */
function project(ar, au, t, aspect, scale) {
  const r = 0.07 + ar, th = au * Math.PI * 2 + t * 0.055 * (ar > 0.5 ? -1 : 1);
  const R = r * (1 + 0.2 * Math.sin(th + r * 4) + 0.11 * Math.sin(2 * th + r * 7) + 0.035 * Math.sin(6 * th - t * 0.3 + r * 11)) * (1 + 0.015 * Math.sin(t * 0.9 + r * 6));
  let x = Math.cos(th) * 0.8 * R + 0.07 * Math.sin(r * 9), y = Math.sin(th) * 1.08 * R + 0.15 * r * r - 0.05, z = 0.28 * Math.cos(Math.min(R, 1.4) * 1.6) - 0.06;
  const ry = 0.24 * Math.sin(t * 0.11), rx = -0.2 + 0.05 * Math.sin(t * 0.07);
  [x, z] = [x * Math.cos(ry) + z * Math.sin(ry), -x * Math.sin(ry) + z * Math.cos(ry)];
  [y, z] = [y * Math.cos(rx) - z * Math.sin(rx), y * Math.sin(rx) + z * Math.cos(rx)];
  const w = 2.6 - z;
  return [((x * scale) / w / aspect + 1) / 2, (1 - (y * scale) / w) / 2];
}

export default function NormalForm() {
  const box = useRef(null), cv = useRef(null), ring = useRef(null);
  const reduce = useReducedMotion();
  const seen = useInView(box, { threshold: 0.05 });
  const [paused, setPaused] = useState(false);
  const [gl2, setGl2] = useState(true);
  const [state, setState] = useState({ phase: 'normal', i: 0 });
  const live = useRef({ paused: false, seen: false });
  live.current.paused = paused || reduce;
  live.current.seen = seen;

  useEffect(() => {
    const c = cv.current;
    const gl = c.getContext('webgl2', { premultipliedAlpha: true, antialias: false, alpha: true });
    if (!gl) { setGl2(false); return undefined; }
    const sh = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); return s; };
    const prog = gl.createProgram();
    gl.attachShader(prog, sh(gl.VERTEX_SHADER, VS)); gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, FS)); gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) { setGl2(false); return undefined; }
    gl.useProgram(prog);
    const small = c.clientWidth < 520;
    const n = small ? 12000 : 24000;
    // points spread over the ridges in proportion to each ridge's length
    const data = new Float32Array(n * 3);
    let seed = 11;
    const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
    for (let i = 0; i < n; i++) {
      const ridge = Math.floor(Math.sqrt(rnd()) * RIDGES) / RIDGES;
      data.set([ridge, rnd(), rnd()], i * 3);
    }
    gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer());
    gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);
    const loc = gl.getAttribLocation(prog, 'a');
    gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 3, gl.FLOAT, false, 0, 0);
    const U = Object.fromEntries(['uT', 'uAspect', 'uDpr', 'uPh', 'uAR', 'uAU', 'uScale', 'uMouse'].map((k) => [k, gl.getUniformLocation(prog, k)]));
    gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE);
    gl.clearColor(0, 0, 0, 0);

    const dpr = Math.min(2, window.devicePixelRatio || 1);
    let W = 0, H = 0;
    const size = () => { W = c.clientWidth; H = c.clientHeight; c.width = Math.round(W * dpr); c.height = Math.round(H * dpr); gl.viewport(0, 0, c.width, c.height); };
    size();
    const ro = new ResizeObserver(size); ro.observe(c);
    const mouse = [9, 9], target = [9, 9];
    const onMove = (e) => { const b = c.getBoundingClientRect(); target[0] = ((e.clientX - b.left) / b.width) * 2 - 1; target[1] = 1 - ((e.clientY - b.top) / b.height) * 2; };
    const onLeave = () => { target[0] = 9; target[1] = 9; };
    c.addEventListener('pointermove', onMove); c.addEventListener('pointerleave', onLeave);

    let t = 4, last = performance.now(), raf = 0, k = -1, phaseName = 'normal', ar = 0.5, au = 0;
    const frame = (now) => {
      raf = requestAnimationFrame(frame);
      const dt = Math.min(0.05, (now - last) / 1000); last = now;
      const { paused: p, seen: s } = live.current;
      if (!s || document.hidden) return;
      if (!p) t += dt;
      // which deviation, and how far through it
      const cyc = Math.floor(t / CYCLE), ct = t - cyc * CYCLE;
      if (cyc !== k) { k = cyc; ar = 0.42 + 0.4 * ((cyc * 0.618) % 1); au = (cyc * 0.381) % 1; }
      const ph = ct < SPAN ? (ct / SPAN) * 1.4 : -1;
      const name = ph < 0 ? 'normal' : ph < 0.35 ? 'deviation' : ph < 1 ? 'held' : 'healed';
      if (name !== phaseName) { phaseName = name; setState({ phase: name, i: ((cyc % CAUGHT.length) + CAUGHT.length) % CAUGHT.length }); }
      mouse[0] += (target[0] - mouse[0]) * 0.12; mouse[1] += (target[1] - mouse[1]) * 0.12;
      const aspect = W / H, scale = small ? 1.85 : 2.0;
      gl.uniform1f(U.uT, t); gl.uniform1f(U.uAspect, aspect); gl.uniform1f(U.uDpr, dpr); gl.uniform1f(U.uPh, ph);
      gl.uniform1f(U.uAR, ar); gl.uniform1f(U.uAU, au); gl.uniform1f(U.uScale, scale); gl.uniform2f(U.uMouse, mouse[0], mouse[1]);
      gl.clear(gl.COLOR_BUFFER_BIT); gl.drawArrays(gl.POINTS, 0, n);
      if (ring.current) {
        const [x, y] = project(ar, au, t, aspect, scale);
        ring.current.style.transform = `translate(${x * W}px, ${y * H}px)`;
        ring.current.classList.toggle('flip', x > 0.58); // keep the label inside the picture
      }
    };
    raf = requestAnimationFrame(frame);
    return () => { cancelAnimationFrame(raf); ro.disconnect(); c.removeEventListener('pointermove', onMove); c.removeEventListener('pointerleave', onLeave); };
  }, []);

  const [what, how] = CAUGHT[state.i];
  const showRing = gl2 && !reduce && (state.phase === 'deviation' || state.phase === 'held');
  return (
    <figure ref={box} className="sn relative mx-auto aspect-square w-full max-w-[640px]" data-phase={reduce || !gl2 ? 'still' : state.phase}
      aria-label="Illustration: thousands of points flow along the ridges of one living, fingerprint-like form, the behaviour Deep Algorithms learns for every identity. Every few seconds one patch drifts off pattern and turns red; a ring locks on, the patch is held and dissolves, and the form heals.">
      <img src={POSTER} alt="" aria-hidden="true" className={cx('absolute inset-0 h-full w-full object-contain transition-opacity duration-700', gl2 && !reduce && 'sn-under')} />
      <canvas ref={cv} aria-hidden="true" className={cx('absolute inset-0 h-full w-full', (!gl2 || reduce) && 'hidden')} />
      <div ref={ring} aria-hidden="true" className={cx('sn-ring pointer-events-none absolute left-0 top-0', showRing && 'on', state.phase === 'held' && 'held')}>
        <span className="sn-dot" />
        <span className="sn-tag"><b>{what}</b><span>{how}</span></span>
      </div>
      {!reduce && gl2 && (
        <button type="button" onClick={() => setPaused(!paused)} className="absolute right-0 top-0 inline-flex h-8 w-8 items-center justify-center rounded-full border border-white/20 bg-[#0b1d40] text-white/80 hover:text-white" aria-label={paused ? 'Play the animation' : 'Pause the animation'}>
          {paused ? <svg width="12" height="12" viewBox="0 0 12 12" aria-hidden="true"><path d="M3 1.5v9l7.5-4.5z" fill="currentColor" /></svg> : <svg width="12" height="12" viewBox="0 0 12 12" aria-hidden="true"><path d="M3 1.5h2v9H3zM7 1.5h2v9H7z" fill="currentColor" /></svg>}
        </button>
      )}
    </figure>
  );
}
