import { Link } from 'react-router';
import { CERTS } from '../data/site.js';
import { PRODUCT_MENU } from '../data/nav.js';
import { CountUp, Icon, cx } from './ui.jsx';
import ProductMark from './ProductMark.jsx';
import CertSeal from './CertSeal.jsx';
import { Logo, logoTitle } from './viz/kit.jsx';

/* Coloured story panels, the grammar enterprise sites use to make a claim
   concrete: a large card with what the product does beside a person whose
   identity it protects (what it knows about them, what they can reach), a
   card with a sourced figure, and a card of proof. Used by the home page's
   "Who we help" and by the figures on every product page. People in the
   photos are models (Pexels, free licence); chips and access are
   illustrations, and every page that shows them says so. */

const Tick = ({ on }) => (
  <span className={cx('absolute -right-1.5 -top-1.5 grid h-[18px] w-[18px] place-items-center rounded-full text-white ring-2 ring-white', on ? 'bg-[#1f9d63]' : 'bg-[#e5484d]')}>
    {on ? <svg width="9" height="9" viewBox="0 0 12 12" aria-hidden="true"><path d="m2.5 6.4 2.3 2.2L9.5 3.8" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
      : <svg width="8" height="8" viewBox="0 0 12 12" aria-hidden="true"><path d="M3 3l6 6M9 3l-6 6" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" /></svg>}
  </span>
);

export function Proof({ kind }) {
  if (kind === 'award') return (
    <div className="flex h-full flex-col">
      <img src="/img/events/dsci-excellence.webp" alt="" className="h-28 w-full rounded-[12px] object-cover" loading="lazy" decoding="async" />
      <p className="mt-4 text-[16px] font-semibold text-[var(--rc-ink)]">Cybersecurity Excellence, 2025</p>
      <p className="mt-1 text-[14px] text-[var(--rc-ink2)]">Awarded by the Data Security Council of India.</p>
      <Link to="/why-deep-algorithms#recognition" className="rc-link mt-auto pt-4">All recognition<Icon name="ArrowRight" size={13} weight="bold" /></Link>
    </div>
  );
  if (kind === 'customers') return (
    <div className="flex h-full flex-col">
      <p className="text-[13px] font-semibold uppercase tracking-[.1em] text-[var(--rc-ink2)]">Trusted by banks in India</p>
      <ul className="mt-5 space-y-4">
        {[['canara-bank', 'Canara Bank'], ['karnataka-bank', 'Karnataka Bank'], ['dcb-bank', 'DCB Bank']].map(([k, n]) => (
          <li key={k}>
            <img src={`/img/logos/${k}.webp`} alt={n} className="rc-on-light h-8 w-auto max-w-[150px] object-contain" loading="lazy" decoding="async" />
            <img src={`/img/logos/${k}-white.webp`} alt={n} className="rc-on-dark h-8 w-auto max-w-[150px] object-contain" loading="lazy" decoding="async" />
          </li>
        ))}
      </ul>
      <Link to="/solutions/bfsi" className="rc-link mt-auto pt-4">Banking and financial services<Icon name="ArrowRight" size={13} weight="bold" /></Link>
    </div>
  );
  if (kind === 'gov') return (
    <div className="flex h-full flex-col">
      <p className="text-[13px] font-semibold uppercase tracking-[.1em] text-[var(--rc-ink2)]">Trusted by government and public bodies</p>
      <ul className="mt-5 space-y-4">
        {[['meity', 'MeitY, Government of India'], ['ncrtc', 'NCRTC'], ['ccoe', 'Cybersecurity Centre of Excellence']].map(([k, n]) => (
          <li key={k}>
            <img src={`/img/logos/${k}.webp`} alt={n} className="rc-on-light h-9 w-auto max-w-[160px] object-contain" loading="lazy" decoding="async" />
            <img src={`/img/logos/${k}-white.webp`} alt={n} className="rc-on-dark h-9 w-auto max-w-[160px] object-contain" loading="lazy" decoding="async" />
          </li>
        ))}
      </ul>
      <Link to="/solutions/government" className="rc-link mt-auto pt-4">Government and public sector<Icon name="ArrowRight" size={13} weight="bold" /></Link>
    </div>
  );
  if (kind === 'deploy') return (
    <div className="flex h-full flex-col">
      <span className="grid h-11 w-11 place-items-center rounded-[12px] bg-white text-[#12171f] shadow-sm"><Logo k="aws" size="62%" /></span>
      <p className="mt-4 text-[16px] font-semibold text-[var(--rc-ink)]">Read-only, from the first day.</p>
      <p className="mt-1 text-[14px] leading-snug text-[var(--rc-ink2)]">One read-only role per AWS account. Nothing installed on your workloads.</p>
      <Link to="/adapid-ai/nhi-security" className="rc-link mt-auto pt-4">How it connects<Icon name="ArrowRight" size={13} weight="bold" /></Link>
    </div>
  );
  if (kind === 'regs') return (
    <div className="flex h-full flex-col">
      <p className="text-[13px] font-semibold uppercase tracking-[.1em] text-[var(--rc-ink2)]">Evidence mapped to</p>
      <ul className="mt-4 flex flex-wrap gap-2">
        {['DPDP Act 2023', 'DPDP Rules 2025', 'RBI', 'SEBI', 'ISO 27701'].map((x) => <li key={x} className="rounded-full bg-white/80 px-3 py-1.5 text-[13.5px] font-medium text-[#151b24]">{x}</li>)}
      </ul>
      <Link to="/dpdpa-compliance" className="rc-link mt-auto pt-4">DPDPA compliance<Icon name="ArrowRight" size={13} weight="bold" /></Link>
    </div>
  );
  return (
    <div className="flex h-full flex-col">
      <p className="text-[13px] font-semibold uppercase tracking-[.1em] text-[var(--rc-ink2)]">Certified</p>
      <ul className="mt-4 space-y-3">
        {CERTS.map((c) => <li key={c.code} className="flex items-center gap-3 text-[14.5px] font-medium text-[var(--rc-ink)]"><CertSeal code={c.code} size={36} /><span>{c.name}<span className="block text-[12px] font-normal text-[var(--rc-ink2)]">{c.desc}</span></span></li>)}
      </ul>
    </div>
  );
}


const CHIP_ICONS = ['User', 'MapPin', 'DeviceMobile'];

export function StoryCard({ story: R }) {
  const products = PRODUCT_MENU.filter((m) => (R.products || []).includes(m.key));
  return (
    <div className="rc-main grid overflow-hidden rounded-[22px] md:grid-cols-[1.05fr_.95fr]">
      <div className="flex flex-col p-7 md:p-9">
        {R.kicker && <p className="mb-4 text-[13px] font-semibold uppercase tracking-[.1em] text-[var(--rc-ink2)]">{R.kicker}</p>}
        <h3 className="text-[clamp(22px,2vw,27px)] font-semibold leading-tight tracking-[-0.02em] text-[var(--rc-ink)]">{R.h}</h3>
        <ul className="mt-6 space-y-3">
          {R.points.map((x) => (
            <li key={x} className="flex gap-3 text-[15.5px] leading-snug text-[var(--rc-ink2)]">
              <Icon name="CheckCircle" size={20} weight="fill" className="mt-px shrink-0 text-[#2f6fe4]" />{x}
            </li>
          ))}
        </ul>
        {products.length > 0 && (
          <div className="mt-7 flex flex-wrap items-center gap-2">
            {products.map((p) => <Link key={p.key} to={p.path} className="rc-pill inline-flex items-center gap-2 rounded-full py-1.5 pl-1.5 pr-3.5 text-[14px] font-medium"><ProductMark p={p.key} size={24} />{p.name}</Link>)}
          </div>
        )}
        {R.to && <Link to={R.to} className="rc-link mt-auto pt-7">{R.cta}<Icon name="ArrowRight" size={14} weight="bold" /></Link>}
      </div>
      <div className="relative min-h-[320px] md:min-h-[400px]">
        <img src={R.photo} alt="" className="absolute inset-0 h-full w-full object-cover" style={{ objectPosition: R.pos || '50% 30%' }} loading="lazy" decoding="async" />
        <div aria-hidden="true" className="absolute inset-0" style={{ background: 'linear-gradient(90deg, rgb(195 220 255 / .35), transparent 30%)' }} />
        {/* what we know about this identity, and what it can reach */}
        <ul aria-hidden="true" className="absolute bottom-[22%] left-4 space-y-2 md:left-[-22px]">
          {R.chips.map((c, i) => (
            <li key={c} className="rc-chip flex items-center gap-2 rounded-[10px] bg-white/95 px-3 py-2 text-[13.5px] font-medium text-[#0e1116] shadow-[0_12px_28px_-12px_rgba(10,40,90,.45)]" style={{ animationDelay: `${150 + i * 120}ms` }}>
              <span className={cx('grid h-5 w-5 shrink-0 place-items-center rounded-full text-white', R.alert === i ? 'bg-[#e5484d]' : 'bg-[#2f6fe4]')}><Icon name={(R.icons || CHIP_ICONS)[i]} size={11} weight="bold" /></span>{c}
            </li>
          ))}
        </ul>
        {R.apps?.length > 0 && (
          <ul aria-hidden="true" className="absolute bottom-4 left-4 flex gap-2.5 md:left-[-22px]">
            {R.apps.map(([k, ok], i) => (
              <li key={k} title={logoTitle(k)} className="rc-chip relative grid h-11 w-11 place-items-center rounded-[11px] bg-white text-[#12171f] shadow-[0_12px_28px_-12px_rgba(10,40,90,.45)]" style={{ animationDelay: `${500 + i * 90}ms` }}>
                <Logo k={k} size="56%" /><Tick on={ok} />
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

/* One sourced figure, large; any others listed under it. */
export function StatCard({ items, className }) {
  const [a, ...rest] = items;
  return (
    <div className={cx('rc-stat rounded-[22px] p-7', className)}>
      <p className="rc-num font-semibold tracking-[-0.04em]" style={{ fontSize: 'clamp(40px, 3.6vw, 54px)', lineHeight: 1 }}><CountUp value={a.v} /></p>
      <p className="mt-3 text-[15px] leading-snug text-[var(--rc-ink)]">{a.l}</p>
      {a.s && <p className="mt-3 text-[12.5px] text-[var(--rc-ink2)]">Source: {a.s}</p>}
      {rest.length > 0 && (
        <ul className="mt-5 space-y-4 border-t border-[#151b24]/10 pt-5">
          {rest.map((x) => (
            <li key={x.l}>
              <p className="text-[15px] leading-snug text-[var(--rc-ink)]"><span className="mr-1.5 text-[22px] font-semibold tracking-[-0.02em]">{x.v}</span>{x.l}</p>
              {x.s && <p className="mt-1 text-[12px] text-[var(--rc-ink2)]">Source: {x.s}</p>}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
