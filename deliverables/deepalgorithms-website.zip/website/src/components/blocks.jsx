import { useRef, useState } from 'react';
import { Link } from 'react-router';
import { CUSTOMERS, CERTS } from '../data/site.js';
import { POSTS, formatDate } from '../data/posts.js';
import { Button, Icon, Reveal, cx } from './ui.jsx';
import Cover from './Cover.jsx';
import CertSeal from './CertSeal.jsx';

/* Customer logos on a slow marquee that pauses on hover/focus: white on dark,
   one quiet ink tone on a light sheet (.logo-mono). */
export function LogoMarquee({ title = 'Trusted by banks, government and enterprises across India', className }) {
  const [paused, setPaused] = useState(false);
  const items = [...CUSTOMERS, ...CUSTOMERS];
  return (
    <section aria-label="Customers" className={cx('py-10', className)}>
      <div className="wrap">
        <div className="flex items-center justify-center gap-3">
          <p className="text-center text-[14px] text-ink-3">{title}</p>
          <button type="button" onClick={() => setPaused(!paused)} className="inline-flex h-7 w-7 items-center justify-center rounded-full text-ink-3 hover:text-ink" aria-label={paused ? 'Play logo row' : 'Pause logo row'}>
            <Icon name={paused ? 'Play' : 'Pause'} size={13} weight="fill" />
          </button>
        </div>
        <div className={cx('marquee-wrap relative mt-7 overflow-hidden', paused && 'paused')} style={{ maskImage: 'linear-gradient(90deg, transparent, #000 10%, #000 90%, transparent)', WebkitMaskImage: 'linear-gradient(90deg, transparent, #000 10%, #000 90%, transparent)' }}>
          <ul className="marquee flex w-max items-center gap-16 pr-16">
            {items.map(([k, n], i) => (
              <li key={i} aria-hidden={i >= CUSTOMERS.length} className="shrink-0">
                <img src={`/img/logos/${k}-white.webp`} alt={i < CUSTOMERS.length ? n : ''} loading="eager" decoding="async" className="logo-mono h-8 w-auto max-w-[140px] object-contain md:h-9" />
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}

/* "Trusted by" under a hero: every customer rolling past at a reading pace,
   with a pause control (WCAG 2.2.2). Stops for reduced motion (global rule). */
export function TrustedRow({ keys = CUSTOMERS.map(([k]) => k), label = 'Trusted by banks, government and enterprises across India' }) {
  const [paused, setPaused] = useState(false);
  return (
    <div className="border-t border-line">
      <div className="wrap flex flex-col gap-4 py-6 lg:flex-row lg:items-center lg:gap-10">
        <p className="shrink-0 text-[14px] leading-snug text-ink-3 max-lg:text-center lg:w-[210px]">{label}</p>
        <div className="flex min-w-0 flex-1 items-center gap-3">
          <LogoRoll keys={keys} paused={paused} className="min-w-0 flex-1" />
          <button type="button" onClick={() => setPaused(!paused)} className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-line-2 text-ink-3 transition-colors hover:text-ink" aria-label={paused ? 'Play customer logos' : 'Pause customer logos'}>
            <Icon name={paused ? 'Play' : 'Pause'} size={12} weight="fill" />
          </button>
        </div>
      </div>
    </div>
  );
}

/* Customer logos rolling past; the pace is set by the count so every row reads
   at the same speed. Hover or focus pauses it. */
export function LogoRoll({ keys, className, paused }) {
  const names = Object.fromEntries(CUSTOMERS);
  const items = [...keys, ...keys];
  return (
    <div className={cx('marquee-wrap relative overflow-hidden', paused && 'paused', className)} style={{ maskImage: 'linear-gradient(90deg, transparent, #000 8%, #000 92%, transparent)', WebkitMaskImage: 'linear-gradient(90deg, transparent, #000 8%, #000 92%, transparent)' }}>
      <ul className="marquee flex w-max items-center gap-14 pr-14" style={{ animationDuration: `${keys.length * 3.4}s` }}>
        {items.map((k, i) => <li key={i} aria-hidden={i >= keys.length || undefined} className="shrink-0"><img src={`/img/logos/${k}-white.webp`} alt={i < keys.length ? names[k] : ''} loading="eager" decoding="async" className="h-8 w-auto max-w-[124px] object-contain opacity-85 md:h-9" /></li>)}
      </ul>
    </div>
  );
}

/* Closing call to action on a band of light. */
export function CtaBand({ title = 'Find your riskiest identity before attackers do.', body = 'A 30-minute session with a Deep Algorithms engineer, on your own environment, with your own questions.', primary = { label: 'Book a demo', to: '/request-demo' } }) {
  return (
    <section data-cta className="noprint stage relative overflow-hidden py-24 md:py-36">
      {/* a quiet engineering grid, not a light show: the words carry this band */}
      <div aria-hidden="true" className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(rgb(255 255 255 / .1) 1px, transparent 1px)', backgroundSize: '24px 24px', maskImage: 'radial-gradient(55% 65% at 50% 50%, #000, transparent)', WebkitMaskImage: 'radial-gradient(55% 65% at 50% 50%, #000, transparent)' }} />
      <div aria-hidden="true" className="absolute inset-x-0 top-0 h-px" style={{ background: 'linear-gradient(90deg, transparent, rgb(255 255 255 / .12), transparent)' }} />
      <Reveal className="wrap relative text-center">
        <h2 className="t-h1 mx-auto max-w-[18ch]">{title}</h2>
        <p className="t-lead mx-auto mt-6 max-w-[600px]">{body}</p>
        <div className="mt-10 flex flex-wrap justify-center gap-3">
          <Button to={primary.to} size="lg" arrow>{primary.label}</Button>
          <Button to="/contact" variant="ghost" size="lg">Talk to us</Button>
        </div>
      </Reveal>
    </section>
  );
}

/* The product film: poster first, the real player only once asked for. */
export function FilmPlayer({ src = '/video/deep-algorithms-film', poster = '/video/film-poster.webp', captions = '/video/deep-algorithms-film.vtt', title = 'One bank, one night, five attacks', duration = '1:22' }) {
  const [play, setPlay] = useState(false);
  const v = useRef(null);
  const meta = <span className="inline-flex items-center gap-2 rounded-full bg-black/40 px-3 py-1.5 text-[13.5px] font-medium text-white/90 backdrop-blur"><Icon name="ClosedCaptioning" size={16} />Captions · {duration}</span>;
  return (
    <div>
      <div className="relative aspect-video w-full overflow-hidden rounded-[18px] border border-line-2 bg-black shadow-[0_60px_120px_-50px_rgba(0,0,0,.85)] md:rounded-[28px]">
        {play ? (
          <video ref={v} className="absolute inset-0 h-full w-full" poster={poster} controls autoPlay playsInline preload="auto">
            <source src={`${src}.webm`} type="video/webm" />
            <source src={`${src}.mp4`} type="video/mp4" />
            <track kind="captions" src={captions} srcLang="en" label="English" />
          </video>
        ) : (
          <button type="button" onClick={() => setPlay(true)} className="group absolute inset-0 block h-full w-full text-left" aria-label={`Play the film: ${title}, ${duration}`}>
            <img src={poster} alt="" className="absolute inset-0 h-full w-full object-cover transition-transform duration-[1.2s] group-hover:scale-[1.02]" loading="lazy" decoding="async" />
            <span aria-hidden="true" className="absolute inset-0" style={{ background: 'radial-gradient(60% 60% at 50% 50%, rgb(5 21 48 / .15), rgb(5 21 48 / .55)), linear-gradient(180deg, transparent 55%, rgb(5 21 48 / .85))' }} />
            <span className="absolute left-1/2 top-1/2 flex h-14 w-14 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-white text-[#081c39] shadow-[0_0_0_10px_rgba(255,255,255,.12),0_30px_60px_-20px_rgba(0,0,0,.8)] transition-transform duration-500 group-hover:scale-[1.07] md:h-[104px] md:w-[104px]">
              <svg viewBox="0 0 24 24" className="ml-1 h-6 w-6 md:h-9 md:w-9" aria-hidden="true"><path d="M7 4.5v15l13-7.5z" fill="currentColor" /></svg>
            </span>
            <span className="absolute inset-x-9 bottom-8 hidden items-end justify-between gap-2 md:flex">
              <span className="text-[26px] font-semibold tracking-[-0.02em] text-white">{title}</span>{meta}
            </span>
          </button>
        )}
      </div>
      <div className="mt-4 flex flex-wrap items-center justify-between gap-3 md:hidden"><span className="text-[17px] font-semibold tracking-[-0.015em]">{title}</span>{meta}</div>
    </div>
  );
}

export function PostCard({ post, big }) {
  return (
    <Link to={`/blogs/${post.slug}`} className="group block">
      <Cover post={post} className={cx('aspect-[16/10] rounded-[18px] border border-line transition-all duration-500 group-hover:border-line-2', big && 'md:aspect-[16/9]')} />
      <p className="mt-5 text-[13px] font-semibold uppercase tracking-[.08em] text-cyan-2">{post.category}</p>
      <h3 className={cx('mt-2 font-semibold tracking-[-0.02em] text-ink transition-colors group-hover:text-fg', big ? 'text-[26px] leading-[1.2] md:text-[32px]' : 'text-[19px] leading-snug')}>{post.title}</h3>
      <p className="mt-2 line-clamp-2 text-[15px] leading-relaxed text-ink-3">{post.excerpt}</p>
      <p className="mt-3 text-[13.5px] text-ink-3">{formatDate(post)} · {post.read} min read</p>
    </Link>
  );
}

export function ResearchRow({ slugs, title = 'Related blogs' }) {
  const posts = slugs.map((s) => POSTS.find((p) => p.slug === s)).filter(Boolean);
  if (!posts.length) return null;
  return (
    <section data-rr className="sec">
      <div className="wrap">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <Reveal><p className="eyebrow mb-5">Blogs</p><h2 className="t-h2">{title}</h2></Reveal>
          <Link to="/blogs" className="link">All blogs<Icon name="ArrowRight" size={14} weight="bold" /></Link>
        </div>
        <div className="m-rail mt-12 grid gap-10 md:grid-cols-3">{posts.map((p, i) => <Reveal key={p.slug} delay={i * 80}><PostCard post={p} /></Reveal>)}</div>
      </div>
    </section>
  );
}

export function CertStrip({ className }) {
  return (
    <ul className={cx('grid grid-cols-2 gap-3 md:grid-cols-4', className)}>
      {CERTS.map((c) => (
        <li key={c.code} className="card flex items-center gap-4 p-4">
          <CertSeal code={c.code} size={48} />
          <span><span className="block text-[15px] font-semibold">{c.name}</span><span className="block text-[13px] text-ink-3">{c.desc}</span></span>
        </li>
      ))}
    </ul>
  );
}
