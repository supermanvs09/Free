import { useRef } from 'react';
import ProductMark from '../ProductMark.jsx';
import { Icon } from '../ui.jsx';
import { useOnView } from '../../lib/nullmotion.jsx';
import { Viz, Win, Chip, Gl, Logo, cx } from './kit.jsx';

const BOT = '#34e0c3';

/* B1. The CTEM loop: three agents narrow thousands of assets to the few that matter. */
const STAGES = [
  { k: 'Recon agent', v: '1,284', l: 'assets mapped', g: 'search', c: 'var(--vz-blue)' },
  { k: 'Red team agent', v: '37 → 6', l: 'exposures proven exploitable', g: 'bolt', c: '#ff8b7e' },
  { k: 'Blue team agent', v: '6', l: 'virtual patches live', g: 'shield', c: BOT },
];
export function CtemLoop({ k: fk } = {}) {
  return (
    <Viz k={fk} steps={[500, 900, 900, 900, 1000]} hold={4000} label="Illustration: a reconnaissance agent maps 1,284 assets, a red team agent proves 6 of 37 exposures exploitable and a blue team agent deploys 6 virtual patches while fixes are routed to owners.">
      {(k) => (
        <Win title="BotShield · Exposure loop" right={<Chip tone="ok">Continuous</Chip>} glow="rgb(52 224 195 / .4)">
          <div className="relative grid grid-cols-3 gap-[.7em]">
            <svg viewBox="0 0 300 40" preserveAspectRatio="none" className="pointer-events-none absolute left-0 right-0 top-[2.2em] h-[1.2em] w-full" aria-hidden="true">
              <line x1="50" y1="20" x2="250" y2="20" stroke="rgb(52 224 195 / .45)" strokeWidth="1.5" vectorEffect="non-scaling-stroke" className="flowline" />
            </svg>
            {STAGES.map((s, i) => (
              <div key={s.k} className={cx(`s${i + 1}`, 'relative z-[1] flex flex-col items-center text-center')}>
                <span className="vz-ic" style={{ width: '3em', height: '3em', borderRadius: '50%', color: s.c, background: 'var(--vz-solid)', borderColor: `${s.c}66` }}><Gl g={s.g} /></span>
                <span className="mt-[.6em] vz-h" style={{ color: s.c }}>{s.k}</span>
                <span className="mt-[.3em] block text-[1.7em] font-semibold tracking-[-0.03em] num">{s.v}</span>
                <span className="block vz-m">{s.l}</span>
              </div>
            ))}
          </div>
          <div className="s4 mt-[1.1em] vz-rows vz-panel">
            <div className="hd" style={{ gridTemplateColumns: '1.5fr 1fr .9fr' }}><span>Proven exposure</span><span>Where</span><span>Status</span></div>
            {[['OTP endpoint lacks rate limit', 'api.bank.in', 'Patched', 'nginx'], ['Session token in URL', 'm.bank.in', 'Patched', 'android'], ['Debug route exposed', 'pay.bank.in', 'Fix in Jira', 'nginx']].map((r, i) => (
              <div key={r[0]} style={{ gridTemplateColumns: '1.5fr 1fr .9fr' }}>
                <span className="truncate vz-t">{r[0]}</span><span className="flex min-w-0 items-center gap-[.4em]"><Logo k={r[3]} size="1.05em" /><span className="truncate vz-mono">{r[1]}</span></span><span>{i < 2 ? <Chip tone="ok">{r[2]}</Chip> : <span className="vz-chip c-info plain"><Logo k="jira" size="1em" />{r[2]}</span>}</span>
              </div>
            ))}
          </div>
          <div className="s5 mt-[.8em] flex items-center gap-[.5em] vz-m"><Gl g="clock" className="h-[1.1em] w-[1.1em]" style={{ color: BOT }} />Next cycle in 6 h. Nothing waits for a quarterly test.</div>
        </Win>
      )}
    </Viz>
  );
}

/* The same scan, a different queue. Left: the scanner's 37 maybes. A red-team
   agent sweeps through them, replaying each; 31 cannot be exploited and fall
   away, 6 are proven. Right: those six, each with its proof, patched at the edge
   one after another. Loops; finished state on the server and for reduced
   motion. Findings are illustrations. */
const PROVEN = [4, 10, 17, 23, 29, 34];
const QUEUE = [
  ['F-04', 'SQL injection', 'POST /api/login', 'Data returned with a crafted payload'],
  ['F-10', 'Broken access control', 'GET /accounts/{id}', 'Read another customer’s account'],
  ['F-17', 'Admin panel exposed', '/internal/admin', 'Reached without VPN'],
  ['F-23', 'Server-side request forgery', 'POST /media/fetch', 'Cloud metadata reachable'],
  ['F-29', 'Token not verified', 'Authorization header', 'Forged token accepted'],
  ['F-34', 'No rate limit', 'POST /otp/verify', 'OTP guessed in 4 minutes'],
];
export function ProofQueue() {
  const ref = useRef(null);
  useOnView(ref, (g, el) => {
    const drop = el.querySelectorAll('.pq-f:not(.pq-p)'), keep = el.querySelectorAll('.pq-p'), cnt = el.querySelector('.pq-n'), o = { v: 37 };
    return g.timeline({ repeat: -1, repeatDelay: 3 })
      .from(el.querySelectorAll('.pq-f'), { opacity: 0, scale: 0.6, duration: 0.3, stagger: { each: 0.015, from: 'random' }, ease: 'back.out(2)' })
      .fromTo(el.querySelector('.pq-sweep'), { yPercent: -10, opacity: 0 }, { yPercent: 1000, opacity: 1, duration: 2.2, ease: 'none' }, 0.7)
      .fromTo(drop, { opacity: 1, filter: 'grayscale(0)' }, { opacity: 0.22, filter: 'grayscale(1)', duration: 0.3, stagger: 0.055 }, 0.8)
      .fromTo(keep, { boxShadow: '0 0 0 0 rgb(229 72 77 / 0)' }, { boxShadow: '0 0 0 3px rgb(229 72 77 / .25)', background: '#fdecec', color: '#c4352a', borderColor: 'rgb(229 72 77 / .5)', duration: 0.3, stagger: 0.36 }, 0.9)
      .fromTo(o, { v: 37 }, { v: 6, duration: 2.2, ease: 'power1.inOut', onUpdate: () => { cnt.textContent = Math.round(o.v); } }, 0.8)
      .from(el.querySelectorAll('.pq-q'), { x: -24, opacity: 0, duration: 0.5, stagger: 0.18, ease: 'power3.out' }, 3.0)
      .fromTo(el.querySelectorAll('.pq-st'), { opacity: 0, scale: 0.6 }, { opacity: 1, scale: 1, duration: 0.4, stagger: 0.35, ease: 'back.out(2.4)' }, 4.0)
      .to(el.querySelector('.pq-sweep'), { opacity: 0, duration: 0.4 }, 2.9)
      .from(el.querySelector('.pq-done'), { y: 14, opacity: 0, duration: 0.5, ease: 'back.out(1.8)' }, 6.3);
  });
  return (
    <div ref={ref} className="grid items-start gap-5 lg:grid-cols-[.9fr_1.1fr]" role="img"
      aria-label="37 findings from a scanner. BotShield's red-team agent replays each one: 31 cannot be exploited, 6 are proven. The six are patched at the edge, each with its proof, and no developer ticket is needed to stop the risk.">
      <div className="relative overflow-hidden rounded-[22px] border border-line bg-white p-6 shadow-[0_30px_60px_-40px_rgb(11_42_82/.35)]">
        <div className="flex items-baseline justify-between">
          <p className="text-[12.5px] font-semibold uppercase tracking-[.1em] text-ink-3">From the scanner</p>
          <p className="text-[13px] text-ink-3"><b className="pq-n text-[26px] font-semibold tracking-[-0.03em] text-ink num">6</b> left to triage</p>
        </div>
        <div className="relative mt-5 grid grid-cols-[repeat(auto-fill,minmax(52px,1fr))] gap-2">
          {Array.from({ length: 37 }, (_, i) => {
            const p = PROVEN.includes(i + 1);
            return <span key={i} className={cx('pq-f mono grid h-9 place-items-center rounded-[9px] border text-[11.5px]', p ? 'pq-p border-[#e5484d]/50 bg-[#fdecec] font-semibold text-[#c4352a]' : 'border-line bg-[#f6f8fb] text-ink-3 opacity-25 grayscale')}>F-{String(i + 1).padStart(2, '0')}</span>;
          })}
          <span aria-hidden="true" className="pq-sweep pointer-events-none absolute inset-x-[-8px] top-0 h-[10%] opacity-0" style={{ background: 'linear-gradient(180deg, transparent, rgb(229 72 77 / .18) 70%, rgb(229 72 77 / .7))', borderBottom: '2px solid #e5484d' }} />
        </div>
        <p className="mt-5 flex items-center gap-2 text-[13px] text-ink-2"><span className="h-2 w-2 rounded-full bg-[#e5484d]" />Red-team agent replays every finding against the live app</p>
      </div>
      <div className="relative overflow-hidden rounded-[22px] border border-[#0a5ea3]/15 bg-white shadow-[0_40px_80px_-40px_rgb(10_94_163/.5)]">
        <div className="flex items-center justify-between border-b border-line bg-[#f6f9fd] px-6 py-4">
          <span className="flex items-center gap-2.5 text-[14px] font-semibold text-ink"><ProductMark p="botshield" size={22} />BotShield queue</span>
          <span className="text-[13px] text-ink-3"><b className="text-ink">6</b> proven of 37</span>
        </div>
        <ol>
          {QUEUE.map(([id, n, where, proof]) => (
            <li key={id} className="pq-q grid grid-cols-[52px_1fr_auto] items-center gap-3 border-b border-line px-6 py-3 last:border-0">
              <span className="mono text-[12px] font-semibold text-[#c4352a]">{id}</span>
              <span className="min-w-0"><span className="block text-[14.5px] font-semibold text-ink">{n} <span className="mono text-[12px] font-normal text-ink-3 max-sm:hidden">{where}</span></span><span className="block truncate text-[12.5px] text-ink-2">Proof: {proof}</span></span>
              <span className="pq-st inline-flex items-center gap-1 rounded-full bg-[#e8f6ef] px-2.5 py-1 text-[11.5px] font-semibold text-[#0c7546]"><Icon name="CheckCircle" size={13} weight="fill" />Patched at edge</span>
            </li>
          ))}
        </ol>
        <div className="pq-done m-4 mt-1 flex items-center gap-3 rounded-[14px] bg-gradient-to-r from-[#0a5ea3] to-[#1e88d8] px-4 py-3 text-white shadow-[0_16px_30px_-14px_rgb(10_94_163/.8)]">
          <Icon name="ShieldCheck" size={22} weight="fill" />
          <span><span className="block text-[14.5px] font-semibold">Six real risks closed today</span><span className="block text-[12.5px] text-white/80">31 maybes off the developers’ plate · code fixes tracked with the proof</span></span>
        </div>
      </div>
    </div>
  );
}
