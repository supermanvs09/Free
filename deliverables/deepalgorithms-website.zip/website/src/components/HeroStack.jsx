import { useEffect, useRef, useState } from 'react';
import { useInView, useReducedMotion, cx } from '../lib/motion.js';

/* The home hero: three planes, the way identity platforms draw themselves.
   Every identity at the bottom (people, service accounts, keys, AI agents),
   every resource on top (payments, customer data, email, cloud), and between
   them the plane where every access is checked, with Deep Algorithms at its
   core. Light flows up through the core. Every few seconds an attacker card
   floats up from one identity, is stopped at the checked plane, says how, and
   vanishes. Plain SVG and HTML, so the server render is already the picture. */

const W = 640, H = 600;
const CX = 252, PW = 190, PH = 95, T = 14; // centre, half-width, half-height and thickness of a plate
const LIFT = 182; // distance between plates
const PLANES = [
  { y: 118, label: ['Every', 'resource'], sub: 'Apps, data, payments', n: '03', id: 'res' },
  { y: 300, label: ['Every access,', 'checked'], sub: 'Decided in < 80 ms', n: '02', id: 'gate' },
  { y: 482, label: ['Every', 'identity'], sub: 'People, machines, AI', n: '01', id: 'ids' },
];
const diamond = (y, w = PW, h = PH) => `${CX},${y - h} ${CX + w},${y} ${CX},${y + h} ${CX - w},${y}`;
const sideL = (y) => `${CX - PW},${y} ${CX},${y + PH} ${CX},${y + PH + T} ${CX - PW},${y + T}`;
const sideR = (y) => `${CX + PW},${y} ${CX},${y + PH} ${CX},${y + PH + T} ${CX + PW},${y + T}`;
/* fine iso grid etched into a plate's top face */
const grid = (y, n = 6) => {
  const L = [CX - PW, y], Tp = [CX, y - PH], B = [CX, y + PH];
  let d = '';
  for (let k = 1; k < n; k++) {
    const u = k / n;
    const a = [L[0] + u * (Tp[0] - L[0]), L[1] + u * (Tp[1] - L[1])];
    d += `M${a[0]} ${a[1]}l${B[0] - L[0]} ${B[1] - L[1]}`;
    const b = [L[0] + u * (B[0] - L[0]), L[1] + u * (B[1] - L[1])];
    d += `M${b[0]} ${b[1]}l${Tp[0] - L[0]} ${Tp[1] - L[1]}`;
  }
  return d;
};
/* what sits on each plane, as offsets from its centre (iso: x right, y down) */
const IDS = [
  { id: 'person', label: 'Customer', dx: -114, dy: 0 },
  { id: 'staff', label: 'Employee', dx: -48, dy: 42 },
  { id: 'machine', label: 'Service account', dx: 50, dy: 42 },
  { id: 'key', label: 'Cloud key', dx: 114, dy: 0 },
  { id: 'agent', label: 'AI agent', dx: 0, dy: -20 },
];
const RES = [
  { id: 'pay', label: 'Payments', dx: -108, dy: 0 },
  { id: 'data', label: 'Customer data', dx: 0, dy: 44 },
  { id: 'mail', label: 'Email', dx: 108, dy: 0 },
  { id: 'cloud', label: 'Cloud', dx: 0, dy: -44 },
];
/* the attacks, in the film's order where they fit */
const ATTACKS = [
  { from: 'person', what: 'Scam call · ₹2,40,000 to a new payee', done: 'Payment held · < 80 ms' },
  { from: 'agent', what: 'AI agent exporting 40,000 records', done: 'Action blocked · 4 ms' },
  { from: 'staff', what: 'Right password · new device, Lagos', done: 'Sessions revoked · 1.4 s' },
  { from: 'key', what: 'Cloud key used from an unknown network', done: 'Key disabled · owner told' },
];
const CYCLE = 6400;

function Ico({ id }) {
  const p = {
    person: 'M12 12a3.6 3.6 0 1 0 0-7.2 3.6 3.6 0 0 0 0 7.2zM5 20c.8-3.6 3.6-5.6 7-5.6s6.2 2 7 5.6',
    staff: 'M12 11.4a3.3 3.3 0 1 0 0-6.6 3.3 3.3 0 0 0 0 6.6zM5 20c.8-3.4 3.6-5.4 7-5.4s6.2 2 7 5.4M10 15l2 2 2-2',
    machine: 'M4 5h16v6H4zM4 13h16v6H4zM8 8h.01M8 16h.01',
    key: 'M8 15.6a3.6 3.6 0 1 0 0-7.2 3.6 3.6 0 0 0 0 7.2zM11.6 12H20m-3 0v3m-2.4-3v2.2',
    agent: 'M5 7h14v11H5zM12 4v3M9.5 12h.01M14.5 12h.01',
    pay: 'M4 7h16v10H4zM4 10.5h16M8 14.5h3',
    data: 'M5 6c0-1.5 3-2.5 7-2.5s7 1 7 2.5v12c0 1.5-3 2.5-7 2.5S5 19.5 5 18zM5 6c0 1.5 3 2.5 7 2.5s7-1 7-2.5M5 12c0 1.5 3 2.5 7 2.5s7-1 7-2.5',
    mail: 'M4 6h16v12H4zM4 7l8 6 8-6',
    cloud: 'M7 18h10a4 4 0 0 0 .6-8 6 6 0 0 0-11.4 1.6A3.3 3.3 0 0 0 7 18z',
  }[id];
  return <path d={p} fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />;
}

/* a token standing on a plate: an upright icon tile with its shadow */
function Token({ x, y, id, hot }) {
  return (
    <g className={cx('hs-tok', hot && 'hot')} transform={`translate(${x} ${y})`}>
      <ellipse cx="0" cy="2" rx="19" ry="8" className="hs-tok-sh" />
      <rect x="-18" y="-40" width="36" height="36" rx="10" className="hs-tile" />
      <rect x="-18" y="-40" width="36" height="36" rx="10" fill="url(#hs-tile-hi)" />
      <g transform="translate(-10 -32) scale(.84)" className="hs-ic"><Ico id={id} /></g>
    </g>
  );
}

/* a solid plate: white top with an etched grid, two shaded edges, a soft shadow */
function Plate({ y }) {
  return (
    <g className="hs-plane">
      <ellipse cx={CX} cy={y + 40} rx="200" ry="70" fill="#0b2a52" opacity=".12" filter="url(#hs-soft)" />
      <polygon points={sideL(y)} className="hs-side-l" />
      <polygon points={sideR(y)} className="hs-side-r" />
      <polygon points={diamond(y)} fill="url(#hs-top)" className="hs-top" />
      <path d={grid(y)} className="hs-grid" />
      <polygon points={diamond(y)} className="hs-edge" />
    </g>
  );
}

/* a thin beam of light between two plates, with a pulse running up it */
function Beam({ x, y0, y1, i, reduce, off }) {
  return (
    <g className={cx('hs-beam', off && 'off')}>
      <path d={`M${x} ${y0}V${y1}`} stroke="url(#hs-beam)" />
      {!reduce && <circle cx={x} cy={y0} r="2.6" className="hs-pulse" style={{ '--len': `${y1 - y0}px`, animationDelay: `${(i * -0.53) % 2.6}s` }} />}
    </g>
  );
}

export default function HeroStack() {
  const box = useRef(null);
  const reduce = useReducedMotion();
  const seen = useInView(box, { threshold: 0.1 });
  const [paused, setPaused] = useState(false);
  const [st, setSt] = useState({ i: 0, phase: 'calm' });

  useEffect(() => {
    if (reduce || paused || !seen) return undefined;
    let t0 = performance.now() - (st.i * CYCLE), raf = 0, prev = '';
    const tick = (now) => {
      raf = requestAnimationFrame(tick);
      // rAF's frame time can sit just before t0 on a slow first frame; never go negative
      const t = Math.max(0, now - t0), k = Math.floor(t / CYCLE), ct = t - k * CYCLE;
      // 0.3 s the attacker appears; climbs to the checked plane by 1.9 s; stopped; 4.1 s floats away; calm
      const phase = ct < 300 ? 'calm' : ct < 1900 ? 'climb' : ct < 4100 ? 'stopped' : ct < 4800 ? 'gone' : 'calm';
      const key = `${k}:${phase}`;
      if (key !== prev) { prev = key; setSt({ i: k % ATTACKS.length, phase }); }
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [reduce, paused, seen]); // eslint-disable-line react-hooks/exhaustive-deps

  const A = ATTACKS[st.i];
  const src = IDS.find((d) => d.id === A.from);
  const sx = CX + src.dx, sy = PLANES[2].y + src.dy;
  const live = !reduce && st.phase !== 'calm';
  const at = st.phase === 'climb' ? [sx, sy - LIFT + 40] : st.phase === 'calm' ? [sx, sy - 44] : [sx, sy - LIFT + T + 4];
  const pct = (v, of) => `${(v / of) * 100}%`;
  const done = st.phase === 'stopped' || st.phase === 'gone';

  return (
    <figure ref={box} className="hs relative mx-auto aspect-[640/600] w-full max-w-[600px] select-none" data-phase={reduce ? 'still' : st.phase}
      aria-label="Illustration: three planes. People, service accounts, cloud keys and AI agents on the bottom plane; payments, customer data, email and cloud on the top plane; between them the plane where every access is checked, with Deep Algorithms at its core. An attacker card floats up from one identity, is stopped at the checked plane, and vanishes.">
      <svg viewBox={`0 0 ${W} ${H}`} className="h-full w-full overflow-visible" aria-hidden="true">
        <defs>
          <linearGradient id="hs-core" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#6fd0ff" /><stop offset="1" stopColor="#0a6dbb" /></linearGradient>
          <linearGradient id="hs-top" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#ffffff" /><stop offset="1" stopColor="#e9f0f8" /></linearGradient>
          <linearGradient id="hs-glass" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#dff1ff" stopOpacity=".62" /><stop offset=".55" stopColor="#bfe2fb" stopOpacity=".55" /><stop offset="1" stopColor="#8fc8f2" stopOpacity=".66" /></linearGradient>
          <linearGradient id="hs-tile-hi" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#fff" stopOpacity=".9" /><stop offset=".5" stopColor="#fff" stopOpacity="0" /></linearGradient>
          <linearGradient id="hs-beam" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stopColor="#0a6dbb" stopOpacity="0" /><stop offset=".5" stopColor="#0a6dbb" stopOpacity=".5" /><stop offset="1" stopColor="#00aeef" stopOpacity=".9" /></linearGradient>
          <radialGradient id="hs-glow"><stop offset="0" stopColor="#00aeef" stopOpacity=".28" /><stop offset="1" stopColor="#00aeef" stopOpacity="0" /></radialGradient>
          <radialGradient id="hs-floor-m"><stop offset="0" stopColor="#fff" /><stop offset="1" stopColor="#fff" stopOpacity="0" /></radialGradient>
          <mask id="hs-floor"><rect x="0" y="0" width={W} height={H} fill="url(#hs-floor-m)" /></mask>
          <pattern id="hs-dots" width="16" height="16" patternUnits="userSpaceOnUse"><circle cx="2" cy="2" r="1" fill="#0a3a6b" fillOpacity=".16" /></pattern>
          <filter id="hs-soft" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="14" /></filter>
        </defs>

        {/* the field: a dotted floor and a soft light behind the checked plate */}
        <rect x="0" y="0" width={W} height={H} fill="url(#hs-dots)" mask="url(#hs-floor)" />
        <ellipse cx={CX} cy={PLANES[1].y} rx="270" ry="200" fill="url(#hs-glow)" />

        {/* the rail and its annotations, as in a spec drawing */}
        <path d={`M${CX + PW + 28} ${PLANES[0].y} V${PLANES[2].y}`} className="hs-rail" />
        {PLANES.map((p) => (
          <g key={p.id} className={cx('hs-note', p.id === 'gate' && 'gate')}>
            <path d={`M${CX + PW + 6} ${p.y} H${CX + PW + 40}`} className="hs-rail" />
            <circle cx={CX + PW + 28} cy={p.y} r="3.5" className="hs-note-dot" />
            <text x={CX + PW + 48} y={p.y - 22} className="hs-num">{p.n}</text>
            <text x={CX + PW + 48} y={p.y} className="hs-label">{p.label[0]}<tspan x={CX + PW + 48} dy="19">{p.label[1]}</tspan></text>
            <text x={CX + PW + 48} y={p.y + 38} className="hs-sub">{p.sub}</text>
          </g>
        ))}

        {/* the identity plate */}
        <Plate y={PLANES[2].y} />
        {IDS.map((d) => <Token key={d.id} id={d.id} x={CX + d.dx} y={PLANES[2].y + d.dy} hot={live && d.id === A.from} />)}
        {/* light rising from every identity to the checked plate */}
        {IDS.map((d, i) => <Beam key={d.id} x={CX + d.dx} y0={PLANES[2].y + d.dy - 42} y1={PLANES[2].y + d.dy - LIFT + T} i={i} reduce={reduce} off={live && d.id === A.from} />)}

        {/* the checked plate: glass, with Deep Algorithms at its core */}
        <g className={cx('hs-plane gate', live && done && 'hit')}>
          <ellipse cx={CX} cy={PLANES[1].y + 30} rx="190" ry="70" fill="#0a6dbb" opacity=".16" filter="url(#hs-soft)" />
          <polygon points={sideL(PLANES[1].y)} className="hs-gside-l" />
          <polygon points={sideR(PLANES[1].y)} className="hs-gside-r" />
          <polygon points={diamond(PLANES[1].y)} fill="url(#hs-glass)" className="hs-gtop" />
          <path d={grid(PLANES[1].y, 8)} className="hs-ggrid" />
          {!reduce && [0, 1, 2].map((k) => <polygon key={k} points={diamond(PLANES[1].y, 60, 30)} className="hs-wave" style={{ animationDelay: `${k * -1.6}s` }} />)}
          <polygon points={diamond(PLANES[1].y)} className="hs-gedge" />
          <path d={`M${CX} ${PLANES[1].y}L${CX - PW + 20} ${PLANES[1].y}M${CX} ${PLANES[1].y}L${CX + PW - 20} ${PLANES[1].y}M${CX} ${PLANES[1].y}L${CX} ${PLANES[1].y - PH + 10}M${CX} ${PLANES[1].y}L${CX} ${PLANES[1].y + PH - 10}`} className="hs-trace" />
        </g>
        <g transform={`translate(${CX} ${PLANES[1].y})`} className="hs-badge">
          <ellipse cx="0" cy="16" rx="64" ry="26" fill="#00aeef" opacity=".35" filter="url(#hs-soft)" />
          <polygon points="-48,-4 0,20 0,34 -48,10" fill="#0a4f8f" />
          <polygon points="48,-4 0,20 0,34 48,10" fill="#0862a6" />
          <polygon points="0,-28 48,-4 0,20 -48,-4" fill="url(#hs-core)" />
          <polygon points="0,-28 48,-4 0,20 -48,-4" fill="none" stroke="#fff" strokeOpacity=".55" strokeWidth="1" />
          <image href="/brand/mark.webp" x="-12" y="-16" width="24" height="24" />
        </g>

        {/* checked access rising on to every resource */}
        {RES.map((r, i) => <Beam key={r.id} x={CX + r.dx} y0={PLANES[0].y + r.dy + LIFT - 6} y1={PLANES[0].y + r.dy + T + 2} i={i + 5} reduce={reduce} />)}

        {/* the resource plate */}
        <Plate y={PLANES[0].y} />
        {RES.map((r) => <Token key={r.id} id={r.id} x={CX + r.dx} y={PLANES[0].y + r.dy} />)}

        {/* the attacker's path up to the checked plane, and where it is stopped */}
        {live && <path d={`M${sx} ${sy - 44} V${sy - LIFT + T + 4}`} className={cx('hs-attack', st.phase === 'climb' && 'on', done && 'cut')} />}
        {live && done && (
          <g transform={`translate(${sx} ${sy - LIFT + T + 4})`} className="hs-stop">
            <circle r="13" /><path d="M-5 -5 5 5M5 -5 -5 5" />
          </g>
        )}
      </svg>

      {/* names under the tokens */}
      {IDS.map((d) => <span key={d.id} aria-hidden="true" className="hs-name" style={{ left: pct(CX + d.dx, W), top: pct(PLANES[2].y + d.dy + 8, H) }}>{d.label}</span>)}
      {RES.map((r) => <span key={r.id} aria-hidden="true" className="hs-name" style={{ left: pct(CX + r.dx, W), top: pct(PLANES[0].y + r.dy + 8, H) }}>{r.label}</span>)}

      {/* the attacker card */}
      <div aria-hidden="true" className={cx('hs-pop', live && 'on', done && 'done', st.phase === 'gone' && 'away')} style={{ left: pct(at[0], W), top: pct(at[1], H) }}>
        <span className="hs-pop-ic">
          {done ? <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12.5l4.2 4.2L19 7" /></svg>
            : <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M12 3c-4 0-7 3-7 7v4l-1.5 3h17L19 14v-4c0-4-3-7-7-7zm-3 9.5c1.6-1 4.4-1 6 0-.4 1-1.6 1.6-3 1.6s-2.6-.6-3-1.6z" /></svg>}
        </span>
        <span>{done ? A.done : A.what}</span>
      </div>

      {!reduce && (
        <button type="button" onClick={() => setPaused(!paused)} className="absolute right-0 top-0 inline-flex h-8 w-8 items-center justify-center rounded-full border border-line-2 bg-bg-1 text-ink-3 hover:text-ink" aria-label={paused ? 'Play the animation' : 'Pause the animation'}>
          {paused ? <svg width="12" height="12" viewBox="0 0 12 12" aria-hidden="true"><path d="M3 1.5v9l7.5-4.5z" fill="currentColor" /></svg> : <svg width="12" height="12" viewBox="0 0 12 12" aria-hidden="true"><path d="M3 1.5h2v9H3zM7 1.5h2v9H7z" fill="currentColor" /></svg>}
        </button>
      )}
    </figure>
  );
}
