import { useMemo } from 'react';
import TIM from '../../../tools/film/timings.json';
import FOOTAGE from '../../../tools/film/footage.json';
import { ZenGateway } from '../../components/viz/zenstra.jsx';
import { AdapRiskTimeline } from '../../components/viz/adapid.jsx';
import { CtemLoop } from '../../components/viz/botshield.jsx';
import { IcmsEvidence } from '../../components/viz/icms.jsx';
import { ScamCatch } from '../../components/viz/fraud.jsx';
import ProductMark from '../../components/ProductMark.jsx';
import { CUSTOMERS, CERTS } from '../../data/site.js';

/* The product film. Live-action shots (tools/film/footage.json, graded and cut to
   frames by footage.py) carry the world and the threat; the site's own product
   pictures carry the answer. Every frame is a pure function of time `t` (seconds):
   tools/film/render.mjs sets t, waits for the frame's images and captures 1920x1080.

   Structure, after the enterprise brand films it is measured against: the stakes
   in the real world, the threat in one line, the brand, then four times over a
   worst case on screen in silence followed by the product stopping it, proof, call
   to action. Hard cuts on the words; type is large, left-aligned and few. */

export const W = 1920, H = 1080, FPS = 30;
const C = Object.fromEntries(TIM.lines.map((l) => [l.id, l]));
export const LENGTH = Math.ceil((TIM.duration + 0.1) * 10) / 10;
const FRAMES = Object.fromEntries(FOOTAGE.clips.map((c) => [c.id, Math.floor(c.dur * FPS) - 1]));

const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const seg = (t, a, b) => clamp((t - a) / (b - a));
const ease = (x) => 1 - Math.pow(1 - x, 3);
const inout = (x) => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2);
const lerp = (a, b, x) => a + (b - a) * x;
const wordAt = (line, i) => line.start + (i / line.text.split(' ').length) * (line.end - line.start) * 0.92;
const MONO = 'JetBrains Mono Variable, ui-monospace, monospace';

/* ---------- footage ---------- */

/* one shot: the frame for time t, with a slow camera move (scale and drift) */
function Shot({ id, t, a, b, kb = [1.02, 1.1], pan = [0, 0, 0, 0], blur = 0, dim = 0, speed = 1, offset = 0, origin = '50% 50%' }) {
  const n = FRAMES[id];
  const f = clamp(Math.floor((t - a) * FPS * speed) + 1 + offset, 1, n);
  const x = (t - a) / Math.max(0.01, b - a);
  const s = lerp(kb[0], kb[1], x);
  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', background: '#05070a' }}>
      <img src={`/clips/${id}/${String(f).padStart(4, '0')}.jpg`} alt="" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', transformOrigin: origin, transform: `translate(${lerp(pan[0], pan[2], x)}px, ${lerp(pan[1], pan[3], x)}px) scale(${s + blur * 0.004})`, filter: blur ? `blur(${blur}px)` : undefined }} />
      {dim > 0 && <div style={{ position: 'absolute', inset: 0, background: `rgb(4 6 9 / ${dim})` }} />}
    </div>
  );
}

/* film grain and lens falloff over everything, so stock from many cameras reads as one film */
function useGrain() {
  return useMemo(() => {
    if (typeof document === 'undefined') return [];
    let seed = 7;
    const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
    return Array.from({ length: 6 }, () => {
      const c = document.createElement('canvas'); c.width = c.height = 384;
      const g = c.getContext('2d'), im = g.createImageData(384, 384);
      for (let i = 0; i < im.data.length; i += 4) { const v = 128 + (rnd() - 0.5) * 120; im.data[i] = im.data[i + 1] = im.data[i + 2] = v; im.data[i + 3] = 255; }
      g.putImageData(im, 0, 0);
      return c.toDataURL('image/png');
    });
  }, []);
}
function Finish({ t }) {
  const grain = useGrain();
  const g = grain[Math.floor(t * FPS) % (grain.length || 1)];
  return (
    <>
      <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(120% 95% at 50% 45%, transparent 60%, rgb(0 0 0 / .38) 100%)' }} />
      {g && <div style={{ position: 'absolute', inset: 0, backgroundImage: `url(${g})`, backgroundSize: '384px 384px', mixBlendMode: 'overlay', opacity: 0.11 }} />}
    </>
  );
}

/* ---------- type ---------- */

/* words light up as they are spoken */
function Spoken({ line, t, size = 84, color = '#fff', dim = 0.22, width = 1400, align = 'left', weight = 600, words: override, part = [0, 1], style }) {
  const words = (override || line.text).split(' ');
  const span = (line.end - line.start) * (part[1] - part[0]);
  const t0 = line.start + (line.end - line.start) * part[0];
  return (
    <p style={{ fontSize: size, fontWeight: weight, letterSpacing: '-0.045em', lineHeight: 1.04, maxWidth: width, textAlign: align, color, margin: align === 'center' ? '0 auto' : 0, textShadow: '0 4px 40px rgb(0 0 0 / .45)', ...style }}>
      {words.map((w, i) => {
        const at = t0 + (i / words.length) * span * 0.92;
        const on = ease(seg(t, at - 0.05, at + 0.25));
        return <span key={i} style={{ opacity: dim + (1 - dim) * on, filter: `blur(${(1 - on) * 3}px)` }}>{w}{i < words.length - 1 ? ' ' : ''}</span>;
      })}
    </p>
  );
}

/* bottom-left scrim so type always sits on dark, whatever the shot */
const Scrim = ({ side = 'bl', o = 0.72 }) => (
  <div style={{ position: 'absolute', inset: 0, background: side === 'bl'
    ? `linear-gradient(20deg, rgb(3 5 8 / ${o}) 0%, rgb(3 5 8 / ${o * 0.55}) 35%, transparent 65%)`
    : side === 'l' ? `linear-gradient(90deg, rgb(3 5 8 / ${o}) 0%, rgb(3 5 8 / ${o * 0.5}) 40%, transparent 70%)`
    : `linear-gradient(180deg, rgb(3 5 8 / ${o}) 0%, transparent 45%)` }} />
);


/* ---------- the four worst cases, in silence ---------- */

/* a real incident: the shot, the date and organisation, one line, and the source.
   Red edge light, nothing else. */
function Incident({ t, a, b, clip, kb, pan, clock, where, line, sub, counter, ch, src, children }) {
  const e = ease(seg(t, a + 0.1, a + 0.5));
  const blink = Math.floor(t * 2.4) % 2 === 0;
  const k = seg(t, a + 0.15, b - 0.2);
  return (
    <>
      <Shot id={clip} t={t} a={a} b={b} kb={kb} pan={pan} />
      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(0deg, rgb(3 5 8 / .86) 0%, rgb(3 5 8 / .18) 52%, rgb(3 5 8 / .38) 100%)' }} />
      <div style={{ position: 'absolute', inset: 0, boxShadow: `inset 0 0 ${180 + 60 * Math.sin(t * 7)}px rgb(255 60 50 / ${0.2 * e})` }} />
      <div style={{ position: 'absolute', left: 120, top: 96, display: 'flex', alignItems: 'center', gap: 18, opacity: e, fontFamily: MONO, fontSize: 26, letterSpacing: '.08em', color: '#ffb3ab' }}>
        <span style={{ width: 14, height: 14, borderRadius: 14, background: '#ff4d40', opacity: blink ? 1 : 0.25, boxShadow: '0 0 20px #ff4d40' }} />
        <span style={{ color: '#fff' }}>{clock}</span><span style={{ opacity: 0.85 }}>· {where}</span>
      </div>
      {children}
      <div style={{ position: 'absolute', left: 120, bottom: 175, width: 1640, opacity: e, transform: `translateY(${(1 - e) * 24}px)` }}>
        {counter && <p style={{ fontFamily: MONO, fontSize: 132, fontWeight: 600, letterSpacing: '-0.04em', color: '#ff6b5d', lineHeight: 1, marginBottom: 18, textShadow: '0 0 60px rgb(255 80 60 / .45)' }}>{counter(k)}</p>}
        <p style={{ fontSize: 76, fontWeight: 600, letterSpacing: '-0.045em', lineHeight: 1.06, color: '#fff' }}>{line}</p>
        {sub && <p style={{ marginTop: 18, fontSize: 32, color: 'rgb(255 255 255 / .66)', letterSpacing: '-0.01em' }}>{sub}</p>}
      </div>
      {src && <p style={{ position: 'absolute', left: 120, bottom: 70, fontSize: 20, color: 'rgb(255 255 255 / .5)', opacity: e }}>Source: {src}</p>}
      {ch && <Chapter t={t} a={a} {...ch} />}
    </>
  );
}

/* where we are in the night: attack n of 5, and the surface it hits */
function Chapter({ t, a, n, of = 5, what, acc = '#ff8b7e', side = 'r' }) {
  const e = ease(seg(t, a + 0.1, a + 0.5));
  return (
    <div style={{ position: 'absolute', zIndex: 4, ...(side === 'r' ? { right: 120 } : { left: 110 }), top: 88, display: 'flex', alignItems: 'center', gap: 14, opacity: e, padding: '12px 20px', borderRadius: 99, background: 'rgb(8 11 16 / .55)', border: '1px solid rgb(255 255 255 / .14)', backdropFilter: 'blur(10px)' }}>
      <span style={{ fontFamily: MONO, fontSize: 22, color: '#fff' }}>{String(n).padStart(2, '0')}<span style={{ color: 'rgb(255 255 255 / .4)' }}> / {String(of).padStart(2, '0')}</span></span>
      <span style={{ display: 'flex', gap: 5 }}>{Array.from({ length: of }, (_, j) => j + 1).map((i) => <i key={i} style={{ width: 20, height: 4, borderRadius: 4, background: i <= n ? acc : 'rgb(255 255 255 / .18)' }} />)}</span>
      <span style={{ fontSize: 21, fontWeight: 600, letterSpacing: '.08em', textTransform: 'uppercase', color: acc }}>{what}</span>
    </div>
  );
}

/* ---------- the products ---------- */

function Stage({ lt, d, children, from = [6, -6, -90], to = [2, -2, 0], width = 1440 }) {
  const x = inout(seg(lt, 0, d));
  return (
    <div style={{ perspective: 2600, perspectiveOrigin: '50% 40%' }}>
      <div style={{ width, transformStyle: 'preserve-3d', transform: `translateZ(${lerp(from[2], to[2], x)}px) rotateX(${lerp(from[0], to[0], x)}deg) rotateY(${lerp(from[1], to[1], x)}deg)` }}>{children}</div>
    </div>
  );
}
const stepAt = (t, steps) => steps.filter((s) => t >= s).length;

function Pop({ t, at, style, children }) {
  const x = ease(seg(t, at, at + 0.6));
  return <div style={{ position: 'absolute', transform: `translateZ(${110 * x}px) translateY(${(1 - x) * 30}px) scale(${0.9 + 0.1 * x})`, opacity: x, ...style }}>{children}</div>;
}
const Verdict = ({ tone = 'bad', head, body, sub }) => (
  <div className="vz-pop" style={{ padding: '20px 26px', '--glow': tone === 'bad' ? 'rgb(255 107 93 / .55)' : 'rgb(63 217 143 / .5)' }}>
    <p style={{ fontSize: 17, fontWeight: 700, letterSpacing: '.1em', color: tone === 'bad' ? '#ff7d70' : '#3fd98f' }}>{head}</p>
    <p style={{ marginTop: 6, fontSize: 23, fontWeight: 600 }}>{body}</p>
    {sub && <p style={{ fontSize: 18, color: '#9ea0a4' }}>{sub}</p>}
  </div>
);

/* frosted glass: the one surface every caption sits on */
const glass = (acc) => ({ background: 'rgb(9 12 18 / .72)', border: '1px solid rgb(190 210 240 / .16)', backdropFilter: 'blur(22px) saturate(1.2)', boxShadow: `0 40px 90px -30px rgb(0 0 0 / .85), inset 0 1px 0 rgb(255 255 255 / .06)${acc ? `, 0 0 80px -40px ${acc}` : ''}` });

/* a product answering its worst case. The product is the hero: large, centred, true to
   the real app. The world sits behind it, out of focus. The name, the promise and the
   result float on glass beside it, never inside it. */
function Product({ t, a, b, bg, bgOffset = 0, acc, mark, name, short, role, head, steps, Pic, pic, pop, focus, outcome, ch, width = 1440, top = 152 }) {
  const lt = t - a, d = b - a;
  const e = ease(seg(t, a + 0.15, a + 0.75));
  const u = ease(seg(t, a - 0.05, a + 0.35));
  return (
    <>
      <Shot id={bg} t={t} a={a} b={b} kb={[1.12, 1.18]} blur={14} dim={0.38} offset={bgOffset} />
      <div style={{ position: 'absolute', inset: 0, background: `radial-gradient(70% 70% at 50% 45%, ${acc}26, transparent 72%)` }} />
      <div className="film-light" style={{ position: 'absolute', left: (W - width) / 2, top, opacity: u, transform: `translateY(${(1 - u) * 40}px) scale(${0.97 + 0.03 * u})` }}>
        <Stage lt={lt} d={d} width={width}>
          <Focus t={t} b={b} f={focus} acc={acc}>
            <Pic k={stepAt(t, steps)} {...pic} />
            {pop && <Pop t={t} at={pop.at} style={pop.style}>{pop.el}</Pop>}
            <Guard t={t} a={a} at={outcome?.at ?? b} acc={acc} />
          </Focus>
        </Stage>
      </div>
      <Status t={t} a={a} at={outcome?.at ?? b} acc={acc} n={ch?.n} short={short || name} />
      <div style={{ position: 'absolute', zIndex: 3, left: 90, top: 56, display: 'flex', alignItems: 'center', gap: 16, padding: '12px 22px 12px 12px', borderRadius: 22, opacity: e, ...glass(acc) }}>
        <span style={{ width: 58, height: 58, borderRadius: 16, display: 'grid', placeItems: 'center', background: 'rgb(255 255 255 / .08)' }}><ProductMark p={mark} size={44} loading="eager" /></span>
        <span><span style={{ display: 'block', fontSize: 27, fontWeight: 600, letterSpacing: '-0.02em' }}>{name}</span><span style={{ display: 'block', marginTop: 2, fontSize: 18, color: '#b9bcc2' }}>{role}</span></span>
      </div>
      <div style={{ position: 'absolute', zIndex: 3, left: 90, bottom: 52, maxWidth: 900, padding: '24px 34px', borderRadius: 28, opacity: e, transform: `translateY(${(1 - e) * 30}px)`, ...glass(acc) }}>
        <h2 style={{ fontSize: 50, fontWeight: 600, letterSpacing: '-0.04em', lineHeight: 1.06 }}>{head}</h2>
      </div>
      {outcome && <Outcome t={t} acc={acc} {...outcome} />}
    </>
  );
}

const Lock = ({ size = 28, color = '#fff', open }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" style={{ flexShrink: 0 }}>
    <rect x="4.5" y="10.5" width="15" height="10" rx="2.5" /><path d={open ? 'M8 10.5V7a4 4 0 0 1 7.6-1.7' : 'M8 10.5V7a4 4 0 0 1 8 0v3.5'} /><circle cx="12" cy="15.5" r="1.4" fill={color} />
  </svg>
);
const Shield = ({ size = 26, color = '#fff' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinejoin="round" aria-hidden="true" style={{ flexShrink: 0 }}><path d="M12 3l7.5 3v5.5c0 4.6-3.2 8.2-7.5 9.5-4.3-1.3-7.5-4.9-7.5-9.5V6z" /><path d="M8.5 12l2.4 2.4 4.6-4.8" /></svg>
);
/* the product under protection: a scan sweeps it as it arrives, its edge glows in the
   product colour, and when the threat is contained the edge settles green */
function Guard({ t, a, at, acc }) {
  const sweep = seg(t, a + 0.25, a + 1.45), done = ease(seg(t, at, at + 0.5));
  const c = done > 0.5 ? '#3fd98f' : acc;
  return (
    <>
      <div style={{ position: 'absolute', inset: -10, borderRadius: 30, border: `2px solid ${c}`, opacity: 0.35 + 0.35 * done, boxShadow: `0 0 ${50 + 40 * done}px -6px ${c}`, pointerEvents: 'none' }} />
      {sweep > 0 && sweep < 1 && <div style={{ position: 'absolute', left: -10, right: -10, top: `${sweep * 100}%`, height: 120, marginTop: -120, background: `linear-gradient(180deg, transparent, ${acc}33 70%, ${acc}aa)`, borderBottom: `2px solid ${acc}`, boxShadow: `0 6px 30px ${acc}`, pointerEvents: 'none' }} />}
    </>
  );
}
/* top right: which chapter, and whether the threat is still live or contained */
function Status({ t, a, at, acc, n, short }) {
  const e = ease(seg(t, a + 0.2, a + 0.6)), done = seg(t, at, at + 0.01);
  const c = done ? '#3fd98f' : acc;
  return (
    <div style={{ position: 'absolute', zIndex: 4, right: 90, top: 56, display: 'flex', alignItems: 'center', gap: 14, padding: '14px 22px', borderRadius: 22, opacity: e, ...glass(c), border: `1px solid ${c}77` }}>
      {n && <span style={{ fontFamily: MONO, fontSize: 21, color: 'rgb(255 255 255 / .6)' }}>{String(n).padStart(2, '0')} / 05</span>}
      {done ? <Lock size={26} color={c} /> : <Shield size={26} color={c} />}
      <span style={{ fontSize: 22, fontWeight: 600, color: c }}>{done ? 'Contained' : 'Protected'}</span>
      <span style={{ fontSize: 20, color: 'rgb(255 255 255 / .7)' }}>{done ? 'before damage' : `by ${short}`}</span>
    </div>
  );
}

/* the camera leans into the one row that matters and the rest of the screen dims.
   f = { at, x, y, s, ring: [left, top, width, height] in % of the picture, measured from the DOM } */
function Focus({ t, b, f, acc, children }) {
  const z = f ? inout(seg(t, f.at, f.at + 0.9)) * (1 - inout(seg(t, b - 0.55, b))) : 0;
  return (
    <div style={{ position: 'relative', transformOrigin: f ? `${f.x}% ${f.y}%` : undefined, transform: `scale(${1 + ((f?.s || 1) - 1) * z})` }}>
      {children}
      {f && z > 0 && (
        <div style={{ position: 'absolute', left: `${f.ring[0]}%`, top: `${f.ring[1]}%`, width: `${f.ring[2]}%`, height: `${f.ring[3]}%`, borderRadius: 14, border: `2.5px solid ${acc}`, boxShadow: `0 0 0 4000px rgb(4 6 10 / ${0.4 * z}), 0 0 40px ${acc}`, opacity: z, pointerEvents: 'none' }} />
      )}
    </div>
  );
}

/* the result, as one number, on glass, bottom right */
function Outcome({ t, at, value, label, acc }) {
  const e = ease(seg(t, at, at + 0.6));
  return (
    <div style={{ position: 'absolute', zIndex: 3, right: 90, bottom: 52, width: 500, padding: '22px 30px', borderRadius: 28, opacity: e, transform: `translateY(${(1 - e) * 30}px) scale(${0.96 + 0.04 * e})`, ...glass(acc), border: `1px solid ${acc}66` }}>
      <p style={{ display: 'flex', alignItems: 'center', gap: 18, fontSize: 80, fontWeight: 600, letterSpacing: '-0.05em', lineHeight: 1, color: acc, textShadow: `0 0 50px ${acc}55` }}><Lock size={52} color={acc} />{value}</p>
      <p style={{ marginTop: 10, fontSize: 22, lineHeight: 1.3, color: 'rgb(255 255 255 / .82)' }}>{label}</p>
    </div>
  );
}

/* ---------- the timeline ---------- */

const Lg = C.login, Tr = C.trust, Br = C.brand, Rc = C.recap;
const T = {
  inc1: C.hook.start - 0.3, inc2: C.hook2.start - 0.2, mgm: C.mgm.start - 0.25, snow: C.snow.start - 0.2, drift: C.drift.start - 0.2, india: C.india.start - 0.2,
  login: Lg.start - 0.2,
  brand: Br.start - 0.55, ch1: C.cirm.start - 0.5,
  recap: Rc.start - 0.35, mumbai: Tr.start - 0.15, skyline: wordAt(Tr, 3) - 0.1, gov: wordAt(Tr, 5) + 0.05, team: wordAt(Tr, 8) - 0.1,
  cta: C.cta.start - 0.3,
};

/* the five answers. Each product protects one kind of attack from the incidents
   above; its picture plays the attack and the product stopping it, under a visible
   protection layer. Focus rings were measured from the rendered DOM. */
const CHAPTERS = [
  { id: 'cirm', n: 1, acc: '#3cc8f6',
    prod: { bg: 'soc', mark: 'adapid', name: 'adapID Identity Risk Management', short: 'adapID', role: 'For stolen-password logins', Pic: AdapRiskTimeline, width: 1150,
      head: <>A valid password. The wrong behaviour.<br /><span style={{ color: '#7fdcff' }}>Held before anything moves.</span></>,
      steps: [0.0, 0.1, 0.24, 0.38, 0.52, 0.62, 0.72], focus: { at: 0.6, x: 90, y: 18, s: 1.12, ring: [81.5, 9, 16.5, 18] },
      outcome: { at: 0.68, value: '1.4 s', label: 'from an impossible sign-in to every session revoked' } } },
  { id: 'fraud', n: 2, acc: '#3cc8f6',
    prod: { bg: 'banking', mark: 'adapid', name: 'adapID Fraud Prevention', short: 'adapID', role: 'For coached payments and scams', Pic: ScamCatch, pic: { time: '21:41' }, width: 885,
      head: <>The real customer, being coached.<br /><span style={{ color: '#7fdcff' }}>Held before the money moves.</span></>,
      steps: [0.1, 0.22, 0.34, 0.46, 0.58, 0.68], focus: { at: 0.7, x: 65, y: 88, s: 1.12, ring: [36, 81, 63.5, 12] },
      outcome: { at: 0.74, value: '< 80 ms', label: 'to a risk decision on every event, with the reason in plain words' } } },
  { id: 'zenstra', n: 3, acc: '#93a2ff',
    prod: { bg: 'code', mark: 'zenstra', name: 'Zenstra AI', short: 'Zenstra', role: 'For AI agents and their tokens', Pic: ZenGateway, width: 1050,
      head: <>Every agent action checked.<br /><span style={{ color: '#aab6ff' }}>Before it runs.</span></>,
      steps: [0.0, 0.12, 0.26, 0.4, 0.55, 0.7], focus: { at: 0.56, x: 50, y: 66, s: 1.12, ring: [1.5, 56, 96, 20.5] },
      outcome: { at: 0.62, value: '4 ms', label: 'to block an agent action outside its declared task' },
      pop: { at: 0.5, style: { left: -60, bottom: -40, width: 460 }, el: <Verdict head="BLOCKED · 4 MS" body="chat-agent → salesforce.export" sub="Outside its declared task" /> } } },
  { id: 'botshield', n: 4, acc: '#34e0c3',
    prod: { bg: 'traffic', mark: 'botshield', name: 'BotShield AI', short: 'BotShield', role: 'For stolen passwords at machine speed', Pic: CtemLoop, width: 1315,
      head: <>18,204 bot logins in a minute.<br /><span style={{ color: '#7ff0dc' }}>Refused at the edge.</span></>,
      steps: [0.0, 0.12, 0.3, 0.48, 0.66], focus: { at: 0.6, x: 47, y: 30, s: 1.12, ring: [35, 14, 26.5, 33] },
      outcome: { at: 0.66, value: '0', label: 'accounts taken over; real customers sign in as usual' },
      pop: { at: 0.2, style: { right: -60, top: 150, width: 400 }, el: <Verdict tone="ok" head="AT THE EDGE" body="18,204 bot logins refused" sub="No traffic diversion" /> } } },
  { id: 'icms', n: 5, acc: '#f4c76c',
    prod: { bg: 'ward', mark: 'icms', name: 'ICMS Compliance Suite', short: 'ICMS', role: 'For the regulator’s questions', Pic: IcmsEvidence, width: 1400,
      head: <>Who touched personal data, and why.<br /><span style={{ color: '#ffd98f' }}>Evidence in one click.</span></>,
      steps: [0.0, 0.08, 0.2, 0.3, 0.42, 0.54, 0.66], focus: { at: 0.44, x: 50, y: 55, s: 1.12, ring: [1.5, 46.5, 96, 18.5] },
      outcome: { at: 0.7, value: '< 5 min', label: 'to an audit-ready evidence package, inside the 72-hour window' } } },
];
const CHAPTER_SCENES = CHAPTERS.map((c, i) => {
  const line = C[c.id];
  const pa = i ? line.start - 0.4 : T.ch1;
  const pb = i < CHAPTERS.length - 1 ? C[CHAPTERS[i + 1].id].start - 0.4 : T.recap;
  const at = (f) => pa + (pb - pa) * f; // a fraction of the product scene
  const P = c.prod;
  return [pa, pb, (t) => <Product t={t} a={pa} b={pb} acc={c.acc} ch={{ n: c.n }} {...P}
    steps={P.steps.map((f, k) => (k === 0 ? pa - 0.6 : at(f)))}
    focus={P.focus && { ...P.focus, at: at(P.focus.at) }}
    outcome={P.outcome && { ...P.outcome, at: at(P.outcome.at) }}
    pop={P.pop && { ...P.pop, at: at(P.pop.at) }} />];
});

/* each scene: [start, end, render] */
const SCENES = [
  [0, T.inc1, (t) => <ColdOpen t={t} b={T.inc1} />],
  [T.inc1, T.inc2, (t) => (
    <Incident t={t} a={T.inc1} b={T.inc2} clip="typing" kb={[1.03, 1.12]} clock="FEB 2024" where="CHANGE HEALTHCARE"
      line={<>One stolen password.<br />A remote-access portal.</>} src="UnitedHealth Group testimony to the US Senate, May 2024">
      <PortalCard t={t} at={T.inc1 + 0.9} />
    </Incident>
  )],
  [T.inc2, T.mgm, (t) => (
    <Incident t={t} a={T.inc2} b={T.mgm} clip="rack" kb={[1.04, 1.12]} clock="FEB 2024" where="CHANGE HEALTHCARE"
      counter={(k) => Math.round(190000000 * ease(clamp(k * 1.25))).toLocaleString('en-US')}
      line="people affected." sub="No MFA. Ransomware nine days later." src="US Department of Health and Human Services, January 2025" />
  )],
  [T.mgm, T.snow, (t) => <Incident t={t} a={T.mgm} b={T.snow} clip="call" kb={[1.03, 1.1]} clock="SEP 2023" where="MGM RESORTS" line="One call to the help desk." sub="Credentials reset for an attacker. About $100 million." src="MGM Resorts International, Form 8-K, October 2023" />],
  [T.snow, T.drift, (t) => <Incident t={t} a={T.snow} b={T.drift} clip="terminal" kb={[1.04, 1.12]} clock="APR–JUN 2024" where="SNOWFLAKE CUSTOMERS" line="Passwords stolen by malware." sub="About 165 organisations notified." src="Mandiant (Google Cloud), June 2024" />],
  [T.drift, T.india, (t) => <Incident t={t} a={T.drift} b={T.india} clip="code" kb={[1.03, 1.1]} clock="AUG 2025" where="SALESLOFT DRIFT" line={<>An AI chat agent’s tokens,<br />used to export customer data.</>} src="Google Threat Intelligence Group, August 2025" />],
  [T.india, T.login, (t) => <Incident t={t} a={T.india} b={T.login} clip="mumbai" kb={[1.03, 1.1]} clock="JAN–APR 2024" where="INDIA" counter={(k) => `₹${Math.round(120 * ease(clamp(k * 1.3)))} crore`} line="lost to “digital arrest” scams." sub="Paid by the victims themselves, through their own banking apps." src="Indian Cyber Crime Coordination Centre (I4C), Ministry of Home Affairs, 2024" />],
  [T.login, T.brand, (t) => (
    <>
      <Shot id="soc" t={t} a={T.login} b={T.brand} kb={[1.03, 1.1]} />
      <Scrim />
      <div style={{ position: 'absolute', left: 120, bottom: 130 }}><Spoken line={Lg} t={t} size={92} width={1500} /></div>
      <div style={{ position: 'absolute', right: 120, top: 110, display: 'grid', gap: 14, opacity: ease(seg(t, T.login + 0.5, T.login + 0.9)) }}>
        {['Password correct', 'Session valid', 'No alert raised'].map((x, i) => (
          <span key={x} style={{ display: 'inline-flex', alignItems: 'center', gap: 14, padding: '14px 24px', borderRadius: 99, border: '1px solid rgb(63 217 143 / .35)', background: 'rgb(10 14 20 / .6)', backdropFilter: 'blur(12px)', fontSize: 28, color: '#d9f7e8', opacity: ease(seg(t, T.login + 0.6 + i * 0.35, T.login + 1.0 + i * 0.35)) }}>
            <span style={{ color: '#3fd98f', fontWeight: 700 }}>✓</span>{x}
          </span>
        ))}
      </div>
    </>
  )],
  [T.brand, T.ch1, (t) => <Brand t={t} a={T.brand} b={T.ch1} />],

  ...CHAPTER_SCENES,
  [T.recap, T.mumbai, (t) => <Recap t={t} a={T.recap} b={T.mumbai} />],
  [T.mumbai, T.skyline, (t) => (
    <>
      <Shot id="charminar" t={t} a={T.mumbai} b={T.skyline} kb={[1.02, 1.1]} origin="50% 70%" />
      <Scrim o={0.95} />
      <div style={{ position: 'absolute', left: 120, bottom: 130 }}><Spoken line={Tr} t={t} size={104} words="Built in India." part={[0, 3 / 14]} /></div>
    </>
  )],
  [T.skyline, T.gov, (t) => (
    <>
      <Shot id="payment" t={t} a={T.skyline} b={T.gov} kb={[1.04, 1.12]} offset={40} />
      <Scrim o={0.85} />
      <div style={{ position: 'absolute', left: 120, bottom: 130 }}><Spoken line={Tr} t={t} size={88} words="Trusted by banks, government" part={[3 / 14, 7 / 14]} /></div>
    </>
  )],
  [T.gov, T.team, (t) => (
    <>
      <Shot id="delhi" t={t} a={T.gov} b={T.team} kb={[1.03, 1.1]} origin="50% 55%" />
      <Scrim o={0.95} />
      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(0deg, rgb(3 5 8 / .55), transparent 40%)' }} />
      <div style={{ position: 'absolute', left: 120, bottom: 130 }}><Spoken line={Tr} t={t} size={88} words="Trusted by banks, government" part={[3 / 14, 7 / 14]} /></div>
    </>
  )],
  [T.team, T.cta, (t) => <Proof t={t} a={T.team} b={T.cta} />],
  [T.cta, LENGTH, (t) => <Cta t={t} a={T.cta} />],
];

/* ---------- scenes with more than a shot and a line ---------- */


/* cold open, in silence: a remote-access login screen, one password typed, no second factor */
function ColdOpen({ t, b }) {
  const e = ease(seg(t, 0.35, 0.9)), out = 1 - seg(t, b - 0.25, b);
  const typed = Math.round(clamp((t - 0.9) / 1.2) * 12);
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: out }}>
      <Shot id="typing" t={t} a={0} b={b} kb={[1.16, 1.1]} blur={6} dim={0.55} offset={40} />
      <div style={{ position: 'absolute', left: '50%', top: '50%', width: 620, transform: `translate(-50%, -50%) translateY(${(1 - e) * 20}px)`, opacity: e, padding: '34px 38px', borderRadius: 26, ...glass('#7fd6ff') }}>
        <p style={{ fontFamily: MONO, fontSize: 20, letterSpacing: '.12em', color: 'rgb(255 255 255 / .55)' }}>REMOTE ACCESS · SIGN IN</p>
        <div style={{ marginTop: 22, padding: '14px 18px', borderRadius: 14, background: 'rgb(255 255 255 / .06)', border: '1px solid rgb(255 255 255 / .12)', fontSize: 26, color: '#e6eaf0' }}>j.smith</div>
        <div style={{ marginTop: 12, padding: '14px 18px', borderRadius: 14, background: 'rgb(255 255 255 / .06)', border: '1px solid rgb(127 214 255 / .5)', fontFamily: MONO, fontSize: 26, color: '#e6eaf0', letterSpacing: '.2em' }}>{'•'.repeat(typed)}<span style={{ opacity: Math.floor(t * 3) % 2 ? 1 : 0 }}>|</span></div>
        <p style={{ marginTop: 18, fontSize: 21, color: '#ffb3ab', opacity: ease(seg(t, 2.1, 2.4)) }}>Second factor: not required</p>
      </div>
    </div>
  );
}

/* the portal login, signed in */
function PortalCard({ t, at }) {
  const x = ease(seg(t, at, at + 0.5));
  return (
    <div style={{ position: 'absolute', right: 120, top: 120, width: 560, padding: '26px 30px', borderRadius: 26, opacity: x, transform: `translateY(${(1 - x) * 26}px)`, ...glass('#ff6b5d') }}>
      <p style={{ fontFamily: MONO, fontSize: 19, letterSpacing: '.1em', color: 'rgb(255 255 255 / .55)' }}>REMOTE ACCESS PORTAL</p>
      <div style={{ display: 'flex', gap: 12, marginTop: 18, flexWrap: 'wrap' }}>
        {[['✓ Password correct', '#4be29a', 'rgb(63 217 143 / .14)'], ['✕ No MFA', '#ff8b7e', 'rgb(255 107 93 / .14)'], ['✓ Signed in', '#4be29a', 'rgb(63 217 143 / .14)']].map(([s2, c, bg], i) => (
          <span key={s2} style={{ padding: '9px 18px', borderRadius: 99, background: bg, color: c, fontSize: 22, fontWeight: 600, opacity: ease(seg(t, at + 0.3 + i * 0.3, at + 0.6 + i * 0.3)) }}>{s2}</span>
        ))}
      </div>
    </div>
  );
}

/* same attacks, a different ending: each incident above with the control that answers it */
function Recap({ t, a, b }) {
  const e = ease(seg(t, a + 0.1, a + 0.6));
  const done = [['adapid', 'Stolen-password login', 'held', '#3cc8f6'], ['adapid', 'Help-desk reset', 'held', '#3cc8f6'], ['adapid', 'Malware-stolen keys', 'revoked', '#3cc8f6'], ['zenstra', 'Agent tokens', 'scoped', '#93a2ff'], ['adapid', 'Coached payment', 'held', '#3cc8f6']];
  return (
    <>
      <Shot id="morning" t={t} a={a} b={b} kb={[1.04, 1.12]} />
      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(0deg, rgb(3 5 8 / .88) 0%, rgb(3 5 8 / .35) 50%, rgb(3 5 8 / .35) 80%, rgb(3 5 8 / .7) 100%)' }} />
      <div style={{ position: 'absolute', left: 120, bottom: 300 }}><Spoken line={Rc} t={t} size={108} width={1600} /></div>
      <div style={{ position: 'absolute', left: 120, right: 120, bottom: 130, display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 16, opacity: e }}>
        {done.map(([k, s2, v, c], i) => {
          const x = ease(seg(t, a + 0.3 + i * 0.12, a + 0.8 + i * 0.12));
          return (
            <div key={s2} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '16px 18px', borderRadius: 20, background: 'rgb(8 12 18 / .62)', border: `1px solid ${c}66`, backdropFilter: 'blur(12px)', opacity: x, transform: `translateY(${(1 - x) * 20}px)` }}>
              <ProductMark p={k} size={42} loading="eager" />
              <span style={{ lineHeight: 1.15 }}><span style={{ display: 'block', fontSize: 20, fontWeight: 600, color: '#fff' }}>{s2}</span><span style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 4, fontSize: 18, fontWeight: 600, color: '#3fd98f' }}><Lock size={18} color="#3fd98f" />{v}</span></span>
            </div>
          );
        })}
      </div>
    </>
  );
}

const Mark = ({ size = 64, style }) => (
  <span style={{ display: 'inline-flex', width: size, height: size, borderRadius: size * 0.26, background: '#fff', padding: size * 0.16, boxShadow: '0 20px 50px -15px rgba(0,0,0,.6)', ...style }}><img src="/brand/mark.webp" alt="" style={{ width: '100%', height: '100%' }} /></span>
);

const LINE = [['adapid', 'adapID AI', 'Fraud and identity risk'], ['zenstra', 'Zenstra AI', 'AI agents'], ['botshield', 'BotShield AI', 'Apps, APIs, the edge'], ['icms', 'ICMS Suite', 'Personal data']];

/* the brand: a blue plate opens over the city, says the line, shows the four products and closes back to the mark */
function Brand({ t, a, b }) {
  const L = Br;
  const app = ease(seg(t, a, a + 0.45)), open = inout(seg(t, L.start - 0.15, L.start + 0.6)), close = inout(seg(t, b - 0.5, b - 0.05));
  const w = lerp(lerp(120, 1560, open), 120, close), h = lerp(lerp(120, 720, open), 120, close);
  return (
    <>
      <Shot id="nightroad" t={t} a={a} b={b} kb={[1.15, 1.2]} blur={10} dim={0.35} offset={120} />
      <div style={{ position: 'absolute', left: W / 2 - w / 2, top: H / 2 - h / 2 + (1 - app) * 160, width: w, height: h, borderRadius: 36, overflow: 'hidden', opacity: app * (1 - seg(t, b - 0.12, b)), background: 'linear-gradient(135deg, #0068ac 0%, #0a7fcf 55%, #169fe6 100%)', boxShadow: `0 0 ${80 + 120 * open}px rgb(0 140 220 / .35)` }}>
        <div style={{ position: 'absolute', inset: 0, opacity: 0.16, backgroundImage: 'radial-gradient(rgb(255 255 255 / .55) 1.5px, transparent 1.5px)', backgroundSize: '30px 30px' }} />
        <div style={{ position: 'absolute', left: '50%', top: lerp(h / 2, 92, open * (1 - close)), transform: 'translate(-50%, -50%)' }}><Mark size={lerp(70, 84, open)} /></div>
        <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', paddingTop: 170, opacity: open * (1 - seg(t, b - 0.75, b - 0.45)) }}>
          <p style={{ fontSize: 44, fontWeight: 600, letterSpacing: '-0.03em', color: 'rgb(255 255 255 / .88)' }}>Deep Algorithms</p>
          <div style={{ marginTop: 14 }}><Spoken line={L} t={t} size={80} width={1360} align="center" words="secures every identity, and stops the one being misused." dim={0.28} part={[2 / 11, 1]} /></div>
          <div style={{ position: 'absolute', left: 40, right: 40, bottom: 40, display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
            {LINE.map(([k, n, r], i) => {
              const x = ease(seg(t, wordAt(L, 2) + i * 0.12, wordAt(L, 2) + 0.5 + i * 0.12));
              return (
                <div key={k} style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '18px 20px', borderRadius: 20, background: 'rgb(4 22 48 / .42)', border: '1px solid rgb(255 255 255 / .2)', opacity: x, transform: `translateY(${(1 - x) * 24}px)` }}>
                  <span style={{ width: 62, height: 62, flexShrink: 0, borderRadius: 16, display: 'grid', placeItems: 'center', background: '#fff' }}><ProductMark p={k} size={46} loading="eager" /></span>
                  <span style={{ textAlign: 'left' }}><span style={{ display: 'block', fontSize: 25, fontWeight: 600, letterSpacing: '-0.02em', color: '#fff' }}>{n}</span><span style={{ display: 'block', marginTop: 3, fontSize: 18, color: 'rgb(255 255 255 / .75)' }}>{r}</span></span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
}

/* proof: the team at work, then the logos of the institutions that run on it */
function Proof({ t, a, b }) {
  const logos = ease(seg(t, a + 0.5, a + 1.1));
  return (
    <>
      <Shot id="office" t={t} a={a} b={b} kb={[1.03, 1.12]} dim={0.15 + 0.35 * logos} />
      <Scrim side="t" o={0.7} />
      <div style={{ position: 'absolute', left: 120, top: 110 }}><Spoken line={Tr} t={t} size={76} width={1700} words="and enterprises that cannot afford a breach." part={[7 / 14, 1]} /></div>
      <div style={{ position: 'absolute', left: 120, right: 120, bottom: 170, display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 20, perspective: 1600 }}>
        {CUSTOMERS.filter(([k]) => !/^ii?t-|^iiit-/.test(k)).slice(0, 12).map(([k, n], i) => {
          const x = ease(seg(t, a + 0.5 + i * 0.07, a + 1.0 + i * 0.07));
          return (
            <div key={k} style={{ height: 118, borderRadius: 20, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgb(10 14 20 / .55)', border: '1px solid rgb(160 190 230 / .16)', backdropFilter: 'blur(10px)', opacity: x, transform: `rotateX(${(1 - x) * -50}deg) translateY(${(1 - x) * 30}px)` }}>
              <img src={`/img/logos/${k}-white.webp`} alt={n} style={{ maxHeight: 52, maxWidth: 180, objectFit: 'contain', opacity: 0.9 }} />
            </div>
          );
        })}
      </div>
      <div style={{ position: 'absolute', left: 0, right: 0, bottom: 90, display: 'flex', justifyContent: 'center', gap: 14, opacity: ease(seg(t, a + 1.6, a + 2.1)) }}>
        {CERTS.map((c) => <span key={c.code} style={{ padding: '10px 20px', borderRadius: 99, border: '1px solid rgb(160 190 230 / .28)', background: 'rgb(10 14 20 / .5)', fontSize: 21, color: '#d5d7db' }}>{c.name}</span>)}
      </div>
    </>
  );
}

/* the close, in two moves: the ask over the city, then the lockup with the four
   products and where to go. Something new arrives every couple of seconds. */
function Cta({ t, a }) {
  const L = C.cta;
  const x = ease(seg(t, a, a + 0.7));
  const L2 = C.cta2;
  const lock = ease(seg(t, L2.start - 0.35, L2.start + 0.45)); // "The future is decided today.", after a beat
  const out = 1 - seg(t, LENGTH - 0.9, LENGTH - 0.05);
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: out }}>
      <Shot id="nightroad" t={t} a={a} b={LENGTH} kb={[1.0, 1.12]} dim={0.3 + 0.25 * lock} blur={lock * 8} offset={60} />
      <Scrim o={0.7 * (1 - lock)} />
      <div style={{ position: 'absolute', left: 120, bottom: 130, opacity: x * (1 - lock), transform: `translateY(${(1 - x) * 26 - lock * 40}px)` }}>
        <Spoken line={L} t={t} size={108} width={1500} dim={0.2} />
      </div>
      <div style={{ position: 'absolute', left: 0, right: 0, top: 150, textAlign: 'center', opacity: lock, transform: `translateY(${(1 - lock) * 30}px)` }}>
        <img src="/brand/logo-lockup-inverse.webp" alt="Deep Algorithms" style={{ height: 110, margin: '0 auto' }} />
        <p style={{ marginTop: 50, fontSize: 80, fontWeight: 600, letterSpacing: '-0.045em', color: '#fff' }}>The future is decided today.</p>
        <div style={{ marginTop: 50, display: 'flex', justifyContent: 'center', gap: 18 }}>
          {LINE.map(([k, n], i) => {
            const y = ease(seg(t, wordAt(L2, 2) + i * 0.12, wordAt(L2, 2) + 0.5 + i * 0.12));
            return <span key={k} style={{ display: 'inline-flex', alignItems: 'center', gap: 12, padding: '12px 20px 12px 14px', borderRadius: 18, background: 'rgb(10 14 20 / .55)', border: '1px solid rgb(180 200 230 / .2)', opacity: y, transform: `translateY(${(1 - y) * 16}px)` }}><ProductMark p={k} size={48} loading="eager" /><span style={{ fontSize: 28, fontWeight: 600 }}>{n}</span></span>;
          })}
        </div>
        <div style={{ marginTop: 56, display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 24, opacity: ease(seg(t, wordAt(L2, 5) - 0.4, wordAt(L2, 5) + 0.2)) }}>
          <span style={{ height: 96, padding: '0 52px', display: 'inline-flex', alignItems: 'center', borderRadius: 99, background: '#0a6dbb', color: '#fff', fontSize: 36, fontWeight: 600, boxShadow: '0 20px 60px -15px rgb(10 109 187 / .8)' }}>Book a demo</span>
          <span style={{ fontSize: 44, color: '#fff', fontWeight: 500, letterSpacing: '-0.01em' }}>deepalgorithms.io</span>
        </div>
      </div>
    </div>
  );
}

export default function Film({ t }) {
  const first = 1 - seg(t, 0, 0.6); // fade up from black
  return (
    <div className="film" style={{ position: 'relative', width: W, height: H, overflow: 'hidden', background: '#05070a', color: '#f2f3f5', fontFamily: 'Inter Variable, sans-serif' }}>
      {SCENES.map(([a, b, render], i) => (t >= a && t < b ? <div key={i} style={{ position: 'absolute', inset: 0 }}>{render(t)}</div> : null))}
      <Finish t={t} />
      {first > 0 && <div style={{ position: 'absolute', inset: 0, background: '#000', opacity: first }} />}
    </div>
  );
}
