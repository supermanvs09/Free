import { useMemo } from 'react';
import TIM from '../../../tools/film/timings.json';
import FOOTAGE from '../../../tools/film/footage.json';
import { ZenGateway } from '../../components/viz/zenstra.jsx';
import { AdapRiskTimeline } from '../../components/viz/adapid.jsx';
import { CtemLoop } from '../../components/viz/botshield.jsx';
import { IcmsEvidence } from '../../components/viz/icms.jsx';
import ProductMark from '../../components/ProductMark.jsx';
import { CUSTOMERS, CERTS } from '../../data/site.js';

/* The product film. Live-action shots (tools/film/footage.json, graded and cut to
   frames by footage.py) carry the world and the threat; the site's own product
   pictures carry the answer. Every frame is a pure function of time `t` (seconds):
   tools/film/render.mjs sets t, waits for the frame's images and captures 1920x1080.

   Structure, after the enterprise brand films it is measured against: the stakes
   in the real world, the threat in one line, the brand, then four times over a
   worst case on screen in silence followed by the product stopping it, proof, call
   to action. Hard cuts on the words; type is large, left-aligned and few. */

export const W = 1920, H = 1080, FPS = 30;
const C = Object.fromEntries(TIM.lines.map((l) => [l.id, l]));
export const LENGTH = Math.ceil((TIM.duration + 0.1) * 10) / 10;
const FRAMES = Object.fromEntries(FOOTAGE.clips.map((c) => [c.id, Math.floor(c.dur * FPS) - 1]));

const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const seg = (t, a, b) => clamp((t - a) / (b - a));
const ease = (x) => 1 - Math.pow(1 - x, 3);
const inout = (x) => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2);
const lerp = (a, b, x) => a + (b - a) * x;
const wordAt = (line, i) => line.start + (i / line.text.split(' ').length) * (line.end - line.start) * 0.92;
const MONO = 'JetBrains Mono Variable, ui-monospace, monospace';

/* ---------- footage ---------- */

/* one shot: the frame for time t, with a slow camera move (scale and drift) */
function Shot({ id, t, a, b, kb = [1.02, 1.1], pan = [0, 0, 0, 0], blur = 0, dim = 0, speed = 1, offset = 0, origin = '50% 50%' }) {
  const n = FRAMES[id];
  const f = clamp(Math.floor((t - a) * FPS * speed) + 1 + offset, 1, n);
  const x = (t - a) / Math.max(0.01, b - a);
  const s = lerp(kb[0], kb[1], x);
  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', background: '#05070a' }}>
      <img src={`/clips/${id}/${String(f).padStart(4, '0')}.jpg`} alt="" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', transformOrigin: origin, transform: `translate(${lerp(pan[0], pan[2], x)}px, ${lerp(pan[1], pan[3], x)}px) scale(${s + blur * 0.004})`, filter: blur ? `blur(${blur}px)` : undefined }} />
      {dim > 0 && <div style={{ position: 'absolute', inset: 0, background: `rgb(4 6 9 / ${dim})` }} />}
    </div>
  );
}

/* film grain and lens falloff over everything, so stock from many cameras reads as one film */
function useGrain() {
  return useMemo(() => {
    if (typeof document === 'undefined') return [];
    let seed = 7;
    const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
    return Array.from({ length: 6 }, () => {
      const c = document.createElement('canvas'); c.width = c.height = 384;
      const g = c.getContext('2d'), im = g.createImageData(384, 384);
      for (let i = 0; i < im.data.length; i += 4) { const v = 128 + (rnd() - 0.5) * 120; im.data[i] = im.data[i + 1] = im.data[i + 2] = v; im.data[i + 3] = 255; }
      g.putImageData(im, 0, 0);
      return c.toDataURL('image/png');
    });
  }, []);
}
function Finish({ t }) {
  const grain = useGrain();
  const g = grain[Math.floor(t * FPS) % (grain.length || 1)];
  return (
    <>
      <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(120% 95% at 50% 45%, transparent 55%, rgb(0 0 0 / .55) 100%)' }} />
      {g && <div style={{ position: 'absolute', inset: 0, backgroundImage: `url(${g})`, backgroundSize: '384px 384px', mixBlendMode: 'overlay', opacity: 0.11 }} />}
    </>
  );
}

/* ---------- type ---------- */

/* words light up as they are spoken */
function Spoken({ line, t, size = 84, color = '#fff', dim = 0.22, width = 1400, align = 'left', weight = 600, words: override, part = [0, 1], style }) {
  const words = (override || line.text).split(' ');
  const span = (line.end - line.start) * (part[1] - part[0]);
  const t0 = line.start + (line.end - line.start) * part[0];
  return (
    <p style={{ fontSize: size, fontWeight: weight, letterSpacing: '-0.045em', lineHeight: 1.04, maxWidth: width, textAlign: align, color, margin: align === 'center' ? '0 auto' : 0, textShadow: '0 4px 40px rgb(0 0 0 / .45)', ...style }}>
      {words.map((w, i) => {
        const at = t0 + (i / words.length) * span * 0.92;
        const on = ease(seg(t, at - 0.05, at + 0.25));
        return <span key={i} style={{ opacity: dim + (1 - dim) * on, filter: `blur(${(1 - on) * 3}px)` }}>{w}{i < words.length - 1 ? ' ' : ''}</span>;
      })}
    </p>
  );
}

/* bottom-left scrim so type always sits on dark, whatever the shot */
const Scrim = ({ side = 'bl', o = 0.85 }) => (
  <div style={{ position: 'absolute', inset: 0, background: side === 'bl'
    ? `linear-gradient(20deg, rgb(3 5 8 / ${o}) 0%, rgb(3 5 8 / ${o * 0.55}) 35%, transparent 65%)`
    : side === 'l' ? `linear-gradient(90deg, rgb(3 5 8 / ${o}) 0%, rgb(3 5 8 / ${o * 0.5}) 40%, transparent 70%)`
    : `linear-gradient(180deg, rgb(3 5 8 / ${o}) 0%, transparent 45%)` }} />
);

/* a machine identity named on screen: a glass tag pinned into the shot */
function Tag({ t, at, x, y, kind, name, color }) {
  const e = ease(seg(t, at, at + 0.45));
  return (
    <div style={{ position: 'absolute', left: x, top: y, opacity: e, transform: `translateY(${(1 - e) * 16}px)` }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '16px 24px 16px 18px', borderRadius: 18, background: 'rgb(10 14 20 / .62)', border: `1px solid ${color}55`, backdropFilter: 'blur(14px)', boxShadow: `0 0 60px -20px ${color}` }}>
        <span style={{ width: 14, height: 14, borderRadius: 14, background: color, boxShadow: `0 0 18px ${color}` }} />
        <span>
          <span style={{ display: 'block', fontSize: 19, fontWeight: 600, letterSpacing: '.12em', textTransform: 'uppercase', color }}>{kind}</span>
          <span style={{ display: 'block', marginTop: 4, fontFamily: MONO, fontSize: 27, color: '#f2f4f7' }}>{name}</span>
        </span>
      </div>
      <div style={{ position: 'absolute', left: 25, top: '100%', width: 1, height: 90 * e, background: `linear-gradient(${color}, transparent)` }} />
    </div>
  );
}

/* ---------- the four worst cases, in silence ---------- */

/* a worst case: the shot, a live clock and one line; red edge light, nothing else */
function Incident({ t, a, b, clip, kb, pan, clock, where, line, sub, counter }) {
  const e = ease(seg(t, a + 0.1, a + 0.5));
  const blink = Math.floor(t * 2.4) % 2 === 0;
  const k = seg(t, a + 0.15, b - 0.2);
  return (
    <>
      <Shot id={clip} t={t} a={a} b={b} kb={kb} pan={pan} />
      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(0deg, rgb(3 5 8 / .9) 0%, rgb(3 5 8 / .3) 50%, rgb(3 5 8 / .45) 100%)' }} />
      <div style={{ position: 'absolute', inset: 0, boxShadow: `inset 0 0 ${180 + 60 * Math.sin(t * 7)}px rgb(255 60 50 / ${0.22 * e})` }} />
      <div style={{ position: 'absolute', left: 120, top: 96, display: 'flex', alignItems: 'center', gap: 18, opacity: e, fontFamily: MONO, fontSize: 26, letterSpacing: '.06em', color: '#ffb3ab' }}>
        <span style={{ width: 14, height: 14, borderRadius: 14, background: '#ff4d40', opacity: blink ? 1 : 0.25, boxShadow: '0 0 20px #ff4d40' }} />
        <span style={{ color: '#fff' }}>{clock}</span><span style={{ opacity: 0.7 }}>· {where}</span>
      </div>
      <div style={{ position: 'absolute', left: 120, bottom: 120, width: 1640, opacity: e, transform: `translateY(${(1 - e) * 24}px)` }}>
        {counter && <p style={{ fontFamily: MONO, fontSize: 132, fontWeight: 600, letterSpacing: '-0.04em', color: '#ff6b5d', lineHeight: 1, marginBottom: 18, textShadow: '0 0 60px rgb(255 80 60 / .45)' }}>{counter(k)}</p>}
        <p style={{ fontSize: 78, fontWeight: 600, letterSpacing: '-0.045em', lineHeight: 1.05, color: '#fff' }}>{line}</p>
        {sub && <p style={{ marginTop: 18, fontSize: 32, color: 'rgb(255 255 255 / .62)', letterSpacing: '-0.01em' }}>{sub}</p>}
      </div>
    </>
  );
}

/* ---------- the products ---------- */

function Stage({ lt, d, children, from = [7, -14, -100], to = [3, -5, 0], width = 1270 }) {
  const x = inout(seg(lt, 0, d));
  return (
    <div style={{ perspective: 2200, perspectiveOrigin: '50% 45%' }}>
      <div style={{ width, transformStyle: 'preserve-3d', transform: `translateZ(${lerp(from[2], to[2], x)}px) rotateX(${lerp(from[0], to[0], x)}deg) rotateY(${lerp(from[1], to[1], x)}deg)` }}>{children}</div>
    </div>
  );
}
const stepAt = (t, steps) => steps.filter((s) => t >= s).length;

function Pop({ t, at, style, children }) {
  const x = ease(seg(t, at, at + 0.6));
  return <div style={{ position: 'absolute', transform: `translateZ(${110 * x}px) translateY(${(1 - x) * 30}px) scale(${0.9 + 0.1 * x})`, opacity: x, ...style }}>{children}</div>;
}
const Verdict = ({ tone = 'bad', head, body, sub }) => (
  <div className="vz-pop" style={{ padding: '20px 26px', '--glow': tone === 'bad' ? 'rgb(255 107 93 / .55)' : 'rgb(63 217 143 / .5)' }}>
    <p style={{ fontSize: 17, fontWeight: 700, letterSpacing: '.1em', color: tone === 'bad' ? '#ff7d70' : '#3fd98f' }}>{head}</p>
    <p style={{ marginTop: 6, fontSize: 23, fontWeight: 600 }}>{body}</p>
    {sub && <p style={{ fontSize: 18, color: '#9ea0a4' }}>{sub}</p>}
  </div>
);

/* a product answering its worst case: the world behind, out of focus; the product in front */
function Product({ t, a, b, bg, bgOffset = 0, acc, mark, name, role, head, steps, Pic, pop }) {
  const lt = t - a, d = b - a;
  const e = ease(seg(t, a, a + 0.6));
  return (
    <>
      <Shot id={bg} t={t} a={a} b={b} kb={[1.12, 1.18]} blur={16} dim={0.5} offset={bgOffset} />
      <div style={{ position: 'absolute', inset: 0, background: `radial-gradient(60% 70% at 72% 50%, ${acc}22, transparent 70%)` }} />
      <Scrim side="l" o={0.8} />
      <div style={{ position: 'absolute', left: 110, top: 0, bottom: 0, width: 540, display: 'flex', flexDirection: 'column', justifyContent: 'center', opacity: e, transform: `translateY(${(1 - e) * 26}px)` }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 22 }}>
          <span style={{ width: 100, height: 100, borderRadius: 28, display: 'grid', placeItems: 'center', background: 'rgb(255 255 255 / .07)', border: '1px solid rgb(180 200 230 / .22)', backdropFilter: 'blur(10px)', boxShadow: `0 0 70px -14px ${acc}` }}><ProductMark p={mark} size={70} loading="eager" /></span>
          <span><span style={{ display: 'block', fontSize: 36, fontWeight: 600, letterSpacing: '-0.02em' }}>{name}</span><span style={{ display: 'block', marginTop: 4, fontSize: 23, color: '#b9bcc2' }}>{role}</span></span>
        </div>
        <h2 style={{ marginTop: 40, fontSize: 58, fontWeight: 600, letterSpacing: '-0.045em', lineHeight: 1.04 }}>{head}</h2>
      </div>
      <div className="film-light" style={{ position: 'absolute', right: 56, top: 0, bottom: 0, display: 'flex', alignItems: 'center' }}>
        <Stage lt={lt} d={d}>
          <div style={{ position: 'relative' }}>
            <Pic k={stepAt(t, steps)} />
            {pop && <Pop t={t} at={pop.at} style={pop.style}>{pop.el}</Pop>}
          </div>
        </Stage>
      </div>
    </>
  );
}

/* ---------- the timeline ---------- */

const Lg = C.login, Sh = C.shift, Tr = C.trust, Br = C.brand;
const T = {
  hook2: 2.5,
  rack: Sh.start - 0.05, cables: wordAt(Sh, 2) + 0.2, terminal: wordAt(Sh, 5) + 0.05, attacker: wordAt(Sh, 9) - 0.15,
  typing: Lg.start - 0.1, soc: wordAt(Lg, 8) - 0.1,
  brand: Br.start - 0.55,
  inc1: Br.end + 0.35, zen: C.zenstra.start + 0.6,
  inc2: C.zenstra.end + 0.25, adap: C.adapid.start + 0.6,
  inc3: C.adapid.end + 0.25, bot: C.botshield.start + 0.6,
  inc4: C.botshield.end + 0.25, icms: C.icms.start + 0.6,
  mumbai: Tr.start - 0.15, skyline: wordAt(Tr, 3) - 0.1, team: wordAt(Tr, 8) - 0.1,
  cta: C.cta.start - 0.3,
};
const beat = (line, next, frac) => line.start + (next - line.start) * frac;

/* each scene: [start, end, render] */
const SCENES = [
  [0, T.hook2, (t) => (
    <>
      <Shot id="city" t={t} a={0} b={T.hook2} kb={[1.12, 1.03]} />
      <Scrim />
      <div style={{ position: 'absolute', left: 120, bottom: 130, opacity: 1 - seg(t, T.hook2 - 0.15, T.hook2) }}>
        <Spoken line={C.hook} t={t} size={92} width={1250} words="Most access in your company" part={[0, 5 / 11]} />
      </div>
    </>
  )],
  [T.hook2, T.rack, (t) => (
    <>
      <Shot id="desk" t={t} a={T.hook2} b={T.rack} kb={[1.04, 1.12]} origin="40% 40%" />
      <Scrim />
      <div style={{ position: 'absolute', left: 120, bottom: 130 }}>
        <Spoken line={C.hook} t={t} size={92} width={1300} words="no longer belongs to a person." part={[5 / 11, 1]} />
      </div>
      <div style={{ position: 'absolute', right: 120, top: 110, textAlign: 'right', opacity: ease(seg(t, T.hook2 + 0.5, T.hook2 + 1.0)) }}>
        <p style={{ fontSize: 120, fontWeight: 600, letterSpacing: '-0.05em', lineHeight: 1, color: '#fff' }}>82<span style={{ color: '#7fd3ff' }}>:</span>1</p>
        <p style={{ marginTop: 10, fontSize: 25, color: 'rgb(255 255 255 / .75)' }}>machine identities for every human</p>
        <p style={{ marginTop: 6, fontSize: 17, color: 'rgb(255 255 255 / .45)' }}>CyberArk Identity Security Landscape, 2025</p>
      </div>
    </>
  )],
  [T.rack, T.cables, (t) => (
    <>
      <Shot id="rack" t={t} a={T.rack} b={T.cables} kb={[1.05, 1.13]} />
      <Scrim side="l" o={0.7} />
      <Tag t={t} at={T.rack + 0.15} x={1060} y={250} kind="Service account" name="svc-payments-prod" color="#a9c1de" />
      <div style={{ position: 'absolute', left: 120, bottom: 130 }}><Spoken line={Sh} t={t} size={84} words="Service accounts," part={[0, 2 / 14]} /></div>
    </>
  )],
  [T.cables, T.terminal, (t) => (
    <>
      <Shot id="cables" t={t} a={T.cables} b={T.terminal} kb={[1.1, 1.02]} />
      <Scrim side="l" o={0.7} />
      <Tag t={t} at={T.cables + 0.1} x={1120} y={300} kind="Cloud key" name="AKIA••••••7Q2F" color="#ffd27a" />
      <div style={{ position: 'absolute', left: 120, bottom: 130 }}><Spoken line={Sh} t={t} size={84} words="cloud keys" part={[2 / 14, 4 / 14]} /></div>
    </>
  )],
  [T.terminal, T.attacker, (t) => (
    <>
      <Shot id="terminal" t={t} a={T.terminal} b={T.attacker} kb={[1.04, 1.12]} />
      <Scrim side="l" o={0.75} />
      <Tag t={t} at={T.terminal + 0.1} x={1080} y={260} kind="AI agent" name="invoice-agent" color="#b4bfff" />
      <div style={{ position: 'absolute', left: 120, bottom: 130 }}><Spoken line={Sh} t={t} size={84} words="and AI agents hold it now." part={[4 / 14, 9 / 14]} /></div>
    </>
  )],
  [T.attacker, T.typing, (t) => (
    <>
      <Shot id="attacker" t={t} a={T.attacker} b={T.typing} kb={[1.02, 1.12]} origin="70% 40%" />
      <div style={{ position: 'absolute', inset: 0, background: 'rgb(120 10 0 / .14)', mixBlendMode: 'multiply' }} />
      <Scrim />
      <div style={{ position: 'absolute', left: 120, bottom: 130 }}><Spoken line={Sh} t={t} size={96} color="#ffd1cb" words="And attackers have noticed." part={[9 / 14, 1]} /></div>
    </>
  )],
  [T.typing, T.soc, (t) => (
    <>
      <Shot id="typing" t={t} a={T.typing} b={T.soc} kb={[1.03, 1.1]} />
      <Scrim />
      <div style={{ position: 'absolute', left: 120, bottom: 130 }}><Spoken line={Lg} t={t} size={88} words="They don’t break in anymore. They log in," part={[0, 8 / 13]} width={1500} /></div>
      <LoginCard t={t} at={wordAt(Lg, 5) - 0.15} />
    </>
  )],
  [T.soc, T.brand, (t) => (
    <>
      <Shot id="soc" t={t} a={T.soc} b={T.brand} kb={[1.03, 1.1]} />
      <Scrim />
      <div style={{ position: 'absolute', left: 120, bottom: 130 }}><Spoken line={Lg} t={t} size={88} words="and every alert stays quiet." part={[8 / 13, 1]} /></div>
      <div style={{ position: 'absolute', right: 120, top: 110, opacity: ease(seg(t, T.soc + 0.4, T.soc + 0.8)) }}>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 16, padding: '18px 30px', borderRadius: 99, border: '1px solid rgb(160 190 230 / .3)', background: 'rgb(10 14 20 / .6)', backdropFilter: 'blur(12px)', fontSize: 30, color: '#d5d7db' }}>
          <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="#94969a" strokeWidth="1.8" aria-hidden="true"><path d="M6 8a6 6 0 1 1 12 0c0 7 3 8 3 8H3s3-1 3-8M10 20a2 2 0 0 0 4 0" /><path d="M3 3l18 18" /></svg>
          Alerts raised <b style={{ color: '#fff', fontSize: 40, marginLeft: 6 }}>0</b>
        </span>
      </div>
    </>
  )],
  [T.brand, T.inc1, (t) => <Brand t={t} a={T.brand} b={T.inc1} />],

  [T.inc1, T.zen, (t) => <Incident t={t} a={T.inc1} b={T.zen} clip="towers" kb={[1.06, 1.14]} clock="02:14:07 IST" where="payments cloud" line={<>An AI agent starts exporting<br />your customer records.</>} sub="Valid token. No alert." />],
  [T.zen, T.inc2, (t) => {
    const b = (f) => beat(C.zenstra, T.inc2, f);
    return <Product t={t} a={T.zen} b={T.inc2} bg="code" acc="#93a2ff" mark="zenstra" name="Zenstra AI" role="Security for AI agents"
      head={<>Every action checked.<br /><span style={{ color: '#aab6ff' }}>Before it runs.</span></>} Pic={ZenGateway}
      steps={[T.zen - 0.1, b(0.12), b(0.26), b(0.4), b(0.55), b(0.7)]}
      pop={{ at: b(0.5), style: { left: -90, bottom: -60, width: 460 }, el: <Verdict head="BLOCKED · 4 MS" body="invoice-agent → salesforce.export" sub="Outside its declared task" /> }} />;
  }],
  [T.inc2, T.adap, (t) => <Incident t={t} a={T.inc2} b={T.adap} clip="intruder" kb={[1.04, 1.12]} clock="02:14:52 IST" where="sign-in · new phone" line="Right password. Right OTP. Wrong person." sub="Every check passes." />],
  [T.adap, T.inc3, (t) => {
    const b = (f) => beat(C.adapid, T.inc3, f);
    return <Product t={t} a={T.adap} b={T.inc3} bg="banking" acc="#3cc8f6" mark="adapid" name="adapID AI" role="People and machine identities"
      head={<>A valid login. <span style={{ color: '#7fdcff' }}>Stopped anyway.</span></>} Pic={AdapRiskTimeline}
      steps={[T.adap - 0.1, b(0.1), b(0.24), b(0.38), b(0.52), b(0.66), b(0.8)]} />;
  }],
  [T.inc3, T.bot, (t) => <Incident t={t} a={T.inc3} b={T.bot} clip="junction" kb={[1.03, 1.1]} clock="02:15:30 IST" where="login API" line="bot logins in sixty seconds." counter={(k) => Math.round(18204 * ease(k)).toLocaleString('en-US')} />],
  [T.bot, T.inc4, (t) => {
    const b = (f) => beat(C.botshield, T.inc4, f);
    return <Product t={t} a={T.bot} b={T.inc4} bg="traffic" acc="#34e0c3" mark="botshield" name="BotShield AI" role="Apps, APIs and the edge"
      head={<>37 findings. <span style={{ color: '#7ff0dc' }}>Six real holes. All closed.</span></>} Pic={CtemLoop}
      steps={[T.bot - 0.1, b(0.12), b(0.3), b(0.48), b(0.66)]}
      pop={{ at: b(0.2), style: { right: -70, top: -70, width: 400 }, el: <Verdict tone="ok" head="AT THE EDGE" body="18,204 bot logins refused" sub="No traffic diversion" /> }} />;
  }],
  [T.inc4, T.icms, (t) => <Incident t={t} a={T.inc4} b={T.icms} clip="corridor" kb={[1.02, 1.1]} clock="09:00:00 IST" where="Data Protection Board" line="A breach report, due in full." counter={(k) => { const s = 72 * 3600 - Math.round(k * 4); const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), ss = s % 60; return `${h}:${String(m).padStart(2, '0')}:${String(ss).padStart(2, '0')}`; }} />],
  [T.icms, T.mumbai, (t) => {
    const b = (f) => beat(C.icms, T.mumbai, f);
    return <Product t={t} a={T.icms} b={T.mumbai} bg="ward" acc="#f4c76c" mark="icms" name="ICMS Compliance Suite" role="DPDPA compliance"
      head={<>Evidence in one click.<br /><span style={{ color: '#ffd98f' }}>Not one quarter.</span></>} Pic={IcmsEvidence}
      steps={[T.icms - 0.1, b(0.08), b(0.2), b(0.33), b(0.48), b(0.6), b(0.72)]} />;
  }],

  [T.mumbai, T.skyline, (t) => (
    <>
      <Shot id="mumbai" t={t} a={T.mumbai} b={T.skyline} kb={[1.03, 1.11]} origin="55% 60%" />
      <Scrim />
      <div style={{ position: 'absolute', left: 120, bottom: 130 }}><Spoken line={Tr} t={t} size={104} words="Built in India." part={[0, 3 / 14]} /></div>
    </>
  )],
  [T.skyline, T.team, (t) => (
    <>
      <Shot id="skyline" t={t} a={T.skyline} b={T.team} kb={[1.02, 1.09]} />
      <Scrim />
      <div style={{ position: 'absolute', left: 120, bottom: 130 }}><Spoken line={Tr} t={t} size={88} words="Trusted by banks, government" part={[3 / 14, 7 / 14]} /></div>
    </>
  )],
  [T.team, T.cta, (t) => <Proof t={t} a={T.team} b={T.cta} />],
  [T.cta, LENGTH, (t) => <Cta t={t} a={T.cta} />],
];

/* ---------- scenes with more than a shot and a line ---------- */

function LoginCard({ t, at }) {
  const x = ease(seg(t, at, at + 0.5));
  return (
    <div style={{ position: 'absolute', right: 120, top: 120, width: 600, padding: '28px 32px', borderRadius: 26, background: 'rgb(12 15 20 / .72)', border: '1px solid rgb(160 190 230 / .2)', backdropFilter: 'blur(16px)', boxShadow: '0 50px 100px -40px rgba(0,0,0,.9)', opacity: x, transform: `translateY(${(1 - x) * 30}px)` }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
        <img src="/img/photos/hero-person.webp" alt="" style={{ width: 72, height: 72, borderRadius: 72, objectFit: 'cover', objectPosition: '38% 12%', border: '2px solid rgb(255 255 255 / .2)' }} />
        <span><span style={{ display: 'block', fontSize: 32, fontWeight: 600 }}>Finance analyst</span><span style={{ display: 'block', fontSize: 24, color: '#9ea0a4' }}>Lagos · A new phone</span></span>
        <span style={{ marginLeft: 'auto', fontFamily: MONO, fontSize: 24, color: '#b2b4b8' }}>02:14</span>
      </div>
      <div style={{ display: 'flex', gap: 12, marginTop: 22 }}>
        {['✓ MFA passed', '✓ Signed in'].map((s, i) => <span key={s} style={{ padding: '9px 18px', borderRadius: 99, background: 'rgb(63 217 143 / .14)', color: '#4be29a', fontSize: 22, fontWeight: 600, opacity: ease(seg(t, at + 0.3 + i * 0.25, at + 0.6 + i * 0.25)) }}>{s}</span>)}
      </div>
    </div>
  );
}

const Mark = ({ size = 64, style }) => (
  <span style={{ display: 'inline-flex', width: size, height: size, borderRadius: size * 0.26, background: '#fff', padding: size * 0.16, boxShadow: '0 20px 50px -15px rgba(0,0,0,.6)', ...style }}><img src="/brand/mark.webp" alt="" style={{ width: '100%', height: '100%' }} /></span>
);

/* the brand: a blue plate opens over the city, says the line, and closes back to the mark */
function Brand({ t, a, b }) {
  const L = Br;
  const app = ease(seg(t, a, a + 0.45)), open = inout(seg(t, L.start - 0.15, L.start + 0.6)), close = inout(seg(t, L.end + 0.05, b - 0.05));
  const w = lerp(lerp(120, 1500, open), 120, close), h = lerp(lerp(120, 620, open), 120, close);
  return (
    <>
      <Shot id="nightroad" t={t} a={a} b={b} kb={[1.15, 1.2]} blur={10} dim={0.55} />
      <div style={{ position: 'absolute', left: W / 2 - w / 2, top: H / 2 - h / 2 + (1 - app) * 160, width: w, height: h, borderRadius: 36, overflow: 'hidden', opacity: app * (1 - seg(t, b - 0.12, b)), background: 'linear-gradient(135deg, #0068ac 0%, #0a7fcf 55%, #169fe6 100%)', boxShadow: `0 0 ${80 + 120 * open}px rgb(0 140 220 / .35)` }}>
        <div style={{ position: 'absolute', inset: 0, opacity: 0.16, backgroundImage: 'radial-gradient(rgb(255 255 255 / .55) 1.5px, transparent 1.5px)', backgroundSize: '30px 30px' }} />
        <div style={{ position: 'absolute', left: '50%', top: lerp(h / 2, 92, open * (1 - close)), transform: 'translate(-50%, -50%)' }}><Mark size={lerp(70, 84, open)} /></div>
        <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', paddingTop: 70, opacity: open * (1 - seg(t, L.end - 0.05, L.end + 0.2)) }}>
          <p style={{ fontSize: 44, fontWeight: 600, letterSpacing: '-0.03em', color: 'rgb(255 255 255 / .88)' }}>Deep Algorithms</p>
          <div style={{ marginTop: 14 }}><Spoken line={L} t={t} size={96} width={1300} align="center" words="catches them before they act." dim={0.28} part={[2 / 7, 1]} /></div>
        </div>
      </div>
    </>
  );
}

/* proof: the team at work, then the logos of the institutions that run on it */
function Proof({ t, a, b }) {
  const logos = ease(seg(t, a + 0.5, a + 1.1));
  return (
    <>
      <Shot id="team" t={t} a={a} b={b} kb={[1.03, 1.12]} dim={0.25 + 0.4 * logos} />
      <Scrim side="t" o={0.7} />
      <div style={{ position: 'absolute', left: 120, top: 110 }}><Spoken line={Tr} t={t} size={76} width={1700} words="and enterprises that cannot afford a breach." part={[7 / 14, 1]} /></div>
      <div style={{ position: 'absolute', left: 120, right: 120, bottom: 170, display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 20, perspective: 1600 }}>
        {CUSTOMERS.filter(([k]) => !/^ii?t-|^iiit-/.test(k)).slice(0, 12).map(([k, n], i) => {
          const x = ease(seg(t, a + 0.5 + i * 0.07, a + 1.0 + i * 0.07));
          return (
            <div key={k} style={{ height: 118, borderRadius: 20, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgb(10 14 20 / .55)', border: '1px solid rgb(160 190 230 / .16)', backdropFilter: 'blur(10px)', opacity: x, transform: `rotateX(${(1 - x) * -50}deg) translateY(${(1 - x) * 30}px)` }}>
              <img src={`/img/logos/${k}-white.webp`} alt={n} style={{ maxHeight: 52, maxWidth: 180, objectFit: 'contain', opacity: 0.9 }} />
            </div>
          );
        })}
      </div>
      <div style={{ position: 'absolute', left: 0, right: 0, bottom: 90, display: 'flex', justifyContent: 'center', gap: 14, opacity: ease(seg(t, a + 1.6, a + 2.1)) }}>
        {CERTS.map((c) => <span key={c.code} style={{ padding: '10px 20px', borderRadius: 99, border: '1px solid rgb(160 190 230 / .28)', background: 'rgb(10 14 20 / .5)', fontSize: 21, color: '#d5d7db' }}>{c.name}</span>)}
      </div>
    </>
  );
}

/* the close: the city at night, the lockup and one ask */
function Cta({ t, a }) {
  const L = C.cta;
  const x = ease(seg(t, a, a + 0.8));
  const out = 1 - seg(t, LENGTH - 1.5, LENGTH - 0.15);
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: out }}>
      <Shot id="nightroad" t={t} a={a} b={LENGTH} kb={[1.0, 1.1]} dim={0.62} offset={60} />
      <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(55% 60% at 50% 50%, rgb(3 5 8 / .55), transparent 80%)' }} />
      <div style={{ position: 'absolute', left: 0, right: 0, top: 245, textAlign: 'center', opacity: x, transform: `translateY(${(1 - x) * 30}px)` }}>
        <img src="/brand/logo-lockup-inverse.webp" alt="Deep Algorithms" style={{ height: 72, margin: '0 auto' }} />
        <div style={{ marginTop: 70 }}><Spoken line={L} t={t} size={100} width={1400} align="center" words="Find your riskiest identity before attackers do." dim={0.2} part={[0, 7 / 17]} /></div>
        <p style={{ marginTop: 34, fontSize: 40, fontWeight: 500, letterSpacing: '-0.02em', color: '#8fd2ff', opacity: ease(seg(t, wordAt(L, 7) - 0.15, wordAt(L, 7) + 0.45)) }}>The future is decided today.</p>
        <div style={{ marginTop: 52, display: 'inline-flex', alignItems: 'center', gap: 22, opacity: ease(seg(t, wordAt(L, 12) - 0.4, wordAt(L, 12) + 0.2)) }}>
          <span style={{ height: 76, padding: '0 38px', display: 'inline-flex', alignItems: 'center', borderRadius: 99, background: '#0a6dbb', color: '#fff', fontSize: 30, fontWeight: 600 }}>Book a demo</span>
          <span style={{ fontSize: 34, color: '#e2e4e8', fontWeight: 500 }}>deepalgorithms.io</span>
        </div>
      </div>
    </div>
  );
}

export default function Film({ t }) {
  const first = 1 - seg(t, 0, 0.6); // fade up from black
  return (
    <div className="film" style={{ position: 'relative', width: W, height: H, overflow: 'hidden', background: '#05070a', color: '#f2f3f5', fontFamily: 'Inter Variable, sans-serif' }}>
      {SCENES.map(([a, b, render], i) => (t >= a && t < b ? <div key={i} style={{ position: 'absolute', inset: 0 }}>{render(t)}</div> : null))}
      <Finish t={t} />
      {first > 0 && <div style={{ position: 'absolute', inset: 0, background: '#000', opacity: first }} />}
    </div>
  );
}
