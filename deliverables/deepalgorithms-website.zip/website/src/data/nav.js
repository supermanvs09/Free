/* Menu content. Text only, as enterprise security sites do it: a name and one
   line per item, grouped by product line. adapID AI is a family of four
   products; Zenstra AI, BotShield AI and ICMS are single platforms, so their
   columns list what the platform covers. */
export const PRODUCT_MENU = [
  {
    key: 'adapid', name: 'adapID AI', acc: 'var(--color-adap)', tag: '4 products', path: '/adapid-ai',
    blurb: 'Security for human and machine identities',
    kind: 'products',
    items: [
      { name: 'Identity Risk Management', desc: 'A live risk score for every person', path: '/adapid-ai' },
      { name: 'NHI Security for AWS', desc: 'Every role, key and workload identity', path: '/adapid-ai/nhi-security' },
      { name: 'Identity Fraud Prevention', desc: 'Mobile and internet banking, login to payment', path: '/adapid-ai/fraud-prevention' },
      { name: 'Active Directory Security', desc: 'Attack paths to Domain Admins', path: '/ad-security' },
    ],
  },
  {
    key: 'zenstra', name: 'Zenstra AI', acc: 'var(--color-zen)', tag: 'Platform', path: '/agentic-ai/agentic-identity',
    blurb: 'Security for AI agents, in one platform',
    kind: 'platform',
    covers: 'For copilots, cloud agents, workflow automations, coding agents and MCP servers.',
    items: [
      { name: 'Agent discovery', path: '/agentic-ai/agent-discovery' },
      { name: 'Agent identity and access', path: '/agentic-ai/agent-access' },
      { name: 'Runtime enforcement', path: '/agentic-ai/runtime-enforcement' },
      { name: 'MCP security', path: '/agentic-ai/mcp-security' },
      { name: 'Detection and response', path: '/agentic-ai/detection-response' },
      { name: 'Decision record', path: '/agentic-ai/decision-record' },
    ],
  },
  {
    key: 'botshield', name: 'BotShield AI', acc: 'var(--color-bot)', tag: 'Platform', path: '/botshield-ai',
    blurb: 'Exposure, bots and DDoS, in one platform',
    kind: 'platform',
    covers: 'For web apps, APIs, login flows and payment journeys.',
    items: [
      { name: 'Threat exposure management', path: '/botshield-ai#loop' },
      { name: 'Bot defence', path: '/botshield-ai#bots' },
      { name: 'DDoS protection, L3 to L7', path: '/botshield-ai/ddos-protection' },
      { name: 'Virtual patching', path: '/botshield-ai#loop' },
    ],
  },
  {
    key: 'icms', name: 'ICMS Compliance Suite', acc: 'var(--color-icms)', tag: 'Platform', path: '/dpdpa-compliance',
    blurb: 'DPDPA compliance, in one platform',
    kind: 'platform',
    covers: 'For customer data, patient records and employee data.',
    items: [
      { name: 'Personal data discovery', path: '/dpdpa-compliance#discover' },
      { name: 'Purpose and consent checks', path: '/dpdpa-compliance#consent' },
      { name: 'Breach response in 72 hours', path: '/dpdpa-compliance#breach' },
      { name: 'Audit evidence for DPDPA, RBI and SEBI', path: '/dpdpa-compliance#evidence' },
    ],
  },
];

export const CHALLENGES = [
  { name: 'Govern AI agents', desc: 'Owners, scoped access and checks before every action', path: '/agentic-ai/agentic-identity' },
  { name: 'Stop account takeover and mule accounts', desc: 'Score every login, payee and payment', path: '/adapid-ai/fraud-prevention' },
  { name: 'Secure machine identities in AWS', desc: 'Find unused access and leaked keys', path: '/adapid-ai/nhi-security' },
  { name: 'Close Active Directory attack paths', desc: 'Cut the routes to Domain Admins', path: '/ad-security' },
  { name: 'Stop bots and DDoS', desc: 'Keep portals and APIs online', path: '/botshield-ai' },
  { name: 'Prove DPDPA compliance', desc: 'Evidence generated as data is used', path: '/dpdpa-compliance' },
];
