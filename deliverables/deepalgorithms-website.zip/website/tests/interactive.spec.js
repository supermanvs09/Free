import { test, expect } from '@playwright/test';
import { hydrated } from './helpers.js';

test('home: the platform explorer shows each of the four products, each with its own page', async ({ page, isMobile }) => {
  test.skip(isMobile, 'phones get the accordion');
  await page.goto('/');
  await hydrated(page);
  const section = page.locator('#platform');
  await section.scrollIntoViewIfNeeded();
  for (const name of ['adapID AI', 'Zenstra AI', 'BotShield AI', 'ICMS Compliance Suite']) {
    await section.getByRole('tab', { name: new RegExp(`^${name}`) }).click();
    await expect(section.getByRole('link', { name: `Explore ${name}` })).toHaveAttribute('href', /\//);
  }
  await section.getByRole('tab', { name: /^Zenstra AI/ }).focus();
  await page.keyboard.press('ArrowDown');
  await expect(section.getByRole('tab', { name: /^BotShield AI/ })).toHaveAttribute('aria-selected', 'true');
});

test('home: the role tabs switch by click and by arrow keys', async ({ page }) => {
  await page.goto('/');
  await hydrated(page);
  const tab = page.getByRole('tab', { name: 'Compliance and DPO' });
  await tab.scrollIntoViewIfNeeded();
  await tab.click();
  await expect(tab).toHaveAttribute('aria-selected', 'true');
  await expect(page.locator('#role-panel')).toContainText('DPDPA');
  await page.keyboard.press('ArrowRight');
  await expect(page.getByRole('tab', { name: 'Fraud and digital banking' })).toHaveAttribute('aria-selected', 'true');
});

test('reduced motion still shows every product card and figure', async ({ page }) => {
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.goto('/');
  await hydrated(page);
  await expect(page.locator('#platform').getByRole('tab')).toHaveCount(4);
  await expect(page.getByText('₹25.5 Cr').first()).toBeVisible();
});

test('zenstra: before and after sit side by side, five moments each', async ({ page }) => {
  await page.goto('/agentic-ai/agentic-identity');
  const sec = page.locator('section:has(#chg-h)');
  await expect(sec.getByText('Without Zenstra', { exact: true })).toBeVisible();
  await expect(sec.getByText('With Zenstra', { exact: true })).toBeVisible();
  await expect(sec.locator('.chg-with li')).toHaveCount(5);
  await expect(sec.locator('.chg-without li')).toHaveCount(5);
});

test('botshield: the red-team scene plays and names the six proven findings', async ({ page }) => {
  await page.goto('/botshield-ai');
  await hydrated(page);
  const scene = page.getByRole('img', { name: /37 possible findings/ });
  await scene.scrollIntoViewIfNeeded();
  await expect(scene.locator('canvas')).toBeVisible();
  // the names arrive as the blue-team agent patches each one
  await expect(scene.getByText('Old TLS on a partner gateway')).toBeVisible({ timeout: 12000 });
});

test('a hero takes the reader into the page instead of repeating Book a demo', async ({ page }) => {
  await page.goto('/adapid-ai/nhi-security');
  await hydrated(page);
  await expect(page.locator('main section').first().getByRole('link', { name: 'Book a demo' })).toHaveCount(0);
  await page.getByRole('button', { name: 'See how it works' }).click();
  await expect.poll(() => page.evaluate(() => window.scrollY)).toBeGreaterThan(300);
});

test('home: the pinned picture follows the story as you scroll', async ({ page, isMobile }) => {
  test.skip(isMobile, 'on a phone each step carries its own picture');
  await page.goto('/');
  await hydrated(page);
  const tab = (name) => page.getByRole('tab', { name, exact: true });
  await page.locator('[data-i="1"]').evaluate((el) => el.scrollIntoView({ block: 'center', behavior: 'instant' }));
  await expect(tab('Machine identities')).toHaveAttribute('aria-selected', 'true');
  await page.locator('[data-i="2"]').evaluate((el) => el.scrollIntoView({ block: 'center', behavior: 'instant' }));
  await expect(tab('People')).toHaveAttribute('aria-selected', 'true');
  await expect(page.getByRole('link', { name: 'How adapID catches it' }).first()).toBeVisible();
});

test('home: the hero scene plays, can be paused, and tells the whole story to screen readers', async ({ page }) => {
  await page.goto('/');
  const hero = page.locator('figure.th');
  await expect(hero).toHaveAttribute('aria-label', /attacker.*AI agent.*blown away as dust.*next attempt/);
  await expect(hero).toHaveAttribute('data-phase', /alert|claim|scan|verdict|dust/, { timeout: 8000 });
  // no product names in the hero
  await expect(page.locator('section[aria-labelledby="hero-h"]')).not.toContainText(/adapID|Zenstra|BotShield|ICMS/);
  await hero.getByRole('button', { name: 'Pause the animation' }).click();
  await expect(hero.getByRole('button', { name: 'Play the animation' })).toBeVisible();
});

test('every hero rolls the customer logos, with a pause control', async ({ page }) => {
  for (const path of ['/', '/adapid-ai']) {
    await page.goto(path);
    const roll = page.locator('.marquee').first();
    await expect(roll).toBeAttached();
    expect(await roll.locator('img[alt]:not([alt=""])').count()).toBeGreaterThanOrEqual(17);
    await page.getByRole('button', { name: 'Pause customer logos' }).first().click();
    await expect(page.getByRole('button', { name: 'Play customer logos' }).first()).toBeVisible();
  }
});

test('product tour: steps by button, keyboard and link, and ends on a demo', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('link', { name: 'Take the product tour' }).first().click();
  await expect(page).toHaveURL(/\/product-tour/);
  const frame = page.locator('.tour-frame');
  await expect(frame).toContainText('Step 1 of 11');
  await frame.getByRole('button', { name: 'Next' }).click();
  await expect(frame).toContainText('Step 2 of 11');
  await page.keyboard.press('ArrowRight');
  await expect(page).toHaveURL(/#step-3$/);
  await page.goto('/product-tour#step-12');
  await expect(frame.getByRole('link', { name: 'Book a demo' })).toBeVisible();
});

test('product pictures keep their smallest text readable, phone or desktop', async ({ page }) => {
  for (const path of ['/adapid-ai', '/ad-security', '/dpdpa-compliance']) {
    await page.goto(path);
    await hydrated(page);
    const smallest = await page.evaluate(() => {
      let min = 99;
      for (const v of document.querySelectorAll('.vz')) for (const e of v.querySelectorAll('*')) {
        if (!e.getBoundingClientRect().width || ![...e.childNodes].some((c) => c.nodeType === 3 && c.textContent.trim().length > 1)) continue;
        min = Math.min(min, parseFloat(getComputedStyle(e).fontSize));
      }
      return min;
    });
    expect(smallest, path).toBeGreaterThanOrEqual(9.5);
  }
});

test('on a phone the attack path reads as a chain, one step under the other', async ({ page, isMobile }) => {
  test.skip(!isMobile, 'phone layout');
  await page.goto('/ad-security');
  await hydrated(page);
  const bench = page.locator('figure:has([role=tablist])').first();
  await bench.scrollIntoViewIfNeeded();
  await bench.getByRole('tab', { name: 'Attack paths' }).click();
  const chain = bench.locator('.wb-chain');
  await expect(chain).toBeVisible();
  for (const n of ['j.mehta', 'WKS-0412', 'svc-sql', 'Server Admins', 'Domain Admins']) await expect(chain.getByText(n, { exact: true })).toBeVisible();
  await bench.getByRole('tab', { name: 'Remediation' }).click();
  await expect(bench.getByText('Remediated, and checked again')).toBeVisible({ timeout: 8000 });
});

test('fraud: three checks on one dial, each session with its own decision', async ({ page }) => {
  await page.goto('/adapid-ai/fraud-prevention');
  await hydrated(page);
  const gate = page.locator('figure.fg');
  await gate.scrollIntoViewIfNeeded();
  await expect(page.getByRole('heading', { name: 'Three checks. One decision.' })).toBeVisible();
  await expect(gate.locator('.fg-dial')).toBeVisible();
  for (const [tab, verdict, found] of [['Genuine customer', 'Allow', 'Her typing, her phone'], ['Mule payment', 'Block', 'Payee is a known mule account'], ['Account takeover', 'Step up', 'Right password, wrong hands']]) {
    await gate.getByRole('tab', { name: tab }).click();
    await expect(gate.locator('.fg-verdict')).toHaveText(verdict);
    await expect(gate.getByText(found)).toBeVisible();
  }
  // the three checks are named, and nothing is wrapped in a card
  for (const n of ['Identity', 'Protection', 'Payment']) await expect(gate.locator('.fg-name', { hasText: n })).toBeVisible();
  await expect(gate.locator('.card')).toHaveCount(0);
});

test('home goes from the numbers straight to the platform, with no empty logo moment', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#orbit')).toHaveCount(0);
  await hydrated(page);
  await page.getByRole('button', { name: /See the platform/ }).first().click();
  await expect(page.locator('#platform-h')).toBeInViewport({ timeout: 5000 });
  // the blogs section is gone from home; blogs stay one click away in the menu
  await expect(page.locator('#res-h')).toHaveCount(0);
  await expect(page.getByRole('navigation', { name: 'Primary' }).getByRole('link', { name: 'Blogs' })).toHaveAttribute('href', '/blogs');
});
