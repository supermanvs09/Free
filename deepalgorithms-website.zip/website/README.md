# deepalgorithms.io

React 19 + Vite 8 + Tailwind 4, prerendered to static HTML (41 pages, a 404, sitemap.xml and robots.txt).

```bash
npm ci
cp .env.example .env
npm run dev          # http://localhost:5173
npm run build        # dist/, static, deploy anywhere
npm run preview      # serves dist/ the way Vercel or Netlify do
npm run test:e2e     # 145 Playwright checks against the build (npx playwright install chromium once)
```

Deploy `dist/` to any host that serves `about-us/index.html` for `/about-us` (Vercel and Netlify do; `vercel.json` and `public/_redirects` are included). Do not use a single-page-app fallback that answers every URL with the home page: React would hydrate the wrong page.

## Where things are

| Path | What |
| --- | --- |
| `src/styles.css` | Design tokens and base styles. One type family (Inter 4 with its optical-size axis); JetBrains Mono only for machine values inside product pictures. Dark canvas in the logo blues; each product line keeps one accent. |
| `src/components/FlowRibbons.jsx` | The glowing fibre ribbons behind heroes and calls to action (canvas, pauses off screen, static under reduced motion). |
| `src/components/Backdrop.jsx` | The slow, blurred aurora behind every page. Dense reading sits on `.calm`, which blurs it further. |
| `src/components/BrandMoment.jsx` | Home page scroll sequence: the logo opens into the statement, closes and becomes the hub of the product map. |
| `src/components/Stage3D.jsx` | 3D frame for key pictures; `<Pop>` lifts the important part out of the frame. |
| `src/components/viz/` | Every product picture, as code with sample data, one file per product line. Steps play while on screen; server HTML shows the final step. |
| `src/components/Header.jsx`, `src/data/nav.js` | Text-only mega menus. adapID AI lists its four products; Zenstra AI, BotShield AI and ICMS list what each platform covers. |
| `src/pages/products/` | One page per product, each with its own structure; the six Zenstra capabilities share `Capability.jsx`. |
| `src/data/` | Products, solutions, company, legal, posts and site facts. Article bodies are in `src/content/posts/`. |
| `tools/film/` | The one-minute product film: script, voice, music, captions, frame renderer. See its README. |
| `tests/` | Playwright end-to-end checks: every page, menus, film, interactions, phone layouts. |

Dev-only pages (not part of the build): `gallery.html` shows every product picture side by side; `film.html` renders the film frame by frame.

Product figures are attributed to Deep Algorithms; third-party figures carry their source. All product UI in the pictures is illustrative.
