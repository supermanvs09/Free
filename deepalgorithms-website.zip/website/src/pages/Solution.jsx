import { useParams } from 'react-router';
import { Seo } from '../lib/head.jsx';
import { SOLUTION_PAGES } from '../data/solutions.js';
import { Reveal, SectionHead } from '../components/ui.jsx';
import { CtaBand, ResearchRow } from '../components/blocks.jsx';
import Stage3D from '../components/Stage3D.jsx';
import { Hero, Stats, Related, LINKS } from '../components/ProductKit.jsx';
import { FraudDecision } from '../components/viz/adapid.jsx';
import { PatientAccess } from '../components/viz/icms.jsx';
import { DdosEdge, BotIntent } from '../components/viz/botshield.jsx';
import NotFound from './NotFound.jsx';

/* Each industry opens on the scene that matters most to it. */
const SCENE = { bfsi: () => <FraudDecision scenario="mule" />, healthcare: PatientAccess, government: DdosEdge, 'digital-platforms': BotIntent };
const KEY = { fraud: 'fraud', nhi: 'nhi', zenstra: 'zenstra', icms: 'icms', adapid: 'cirm', ad: 'ad', ddos: 'ddos', botshield: 'botshield' };

export default function Solution() {
  const { slug } = useParams();
  const s = SOLUTION_PAGES[slug];
  if (!s) return <NotFound />;
  const V = SCENE[slug];
  const path = `/solutions/${slug}`;
  const products = s.products.map((k) => LINKS[KEY[k]]).filter(Boolean);
  return (
    <>
      <Seo title={s.seoTitle} description={s.description} path={path} crumbs={[{ name: s.name, path }]} />
      <Hero crumbs={[{ name: 'Solutions' }, { name: s.name }]} eyebrow={`Solutions · ${s.name}`} title={s.title} lead={s.sub}>
        <Stage3D tilt={[6, -13]}><V /></Stage3D>
      </Hero>

      <Stats items={s.stats} title="Why it matters now" />

      <section className="sec" aria-labelledby="help-h">
        <div className="wrap">
          <SectionHead align="left" id="help-h" eyebrow="How we help" title={`How Deep Algorithms helps ${s.who} teams.`} />
          <ol className="mt-12 grid gap-4 md:grid-cols-2">
            {s.help.map((h, i) => (
              <Reveal as="li" key={h.title} delay={i * 70} className="card flex gap-5 p-6 md:p-8">
                <span className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-line-2 text-[15px] font-semibold text-cyan-2 num">{i + 1}</span>
                <span><span className="block text-[20px] font-semibold tracking-[-0.02em]">{h.title}</span><span className="mt-2 block text-[15.5px] leading-relaxed text-ink-2">{h.body}</span></span>
              </Reveal>
            ))}
          </ol>
        </div>
      </section>

      <Related items={products.slice(0, 3)} title="Products to start with" />
      <ResearchRow slugs={s.research} />
      <CtaBand title={s.cta.title} body={s.cta.body} />
    </>
  );
}
