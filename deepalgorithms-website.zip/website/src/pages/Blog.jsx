import { useMemo } from 'react';
import { Link, useSearchParams } from 'react-router';
import { Seo } from '../lib/head.jsx';
import { SITE } from '../data/site.js';
import { POSTS, formatDate, authorOf } from '../data/posts.js';
import { Icon, Reveal, Breadcrumb, cx } from '../components/ui.jsx';
import { PostCard, CtaBand } from '../components/blocks.jsx';
import Cover, { TOPIC } from '../components/Cover.jsx';
import FlowRibbons from '../components/FlowRibbons.jsx';
import { topicSlug } from '../components/Header.jsx';

const TOPICS = [...new Set(POSTS.map((p) => p.category))];
const PRODUCTS = [...new Set(POSTS.map((p) => p.product.name.split(' ')[0]))];
const hueOf = (c) => `hsl(${(TOPIC[c] || { hue: 200 }).hue} 100% var(--hl))`;

function Featured({ post }) {
  return (
    <Link to={`/blogs/${post.slug}`} className="group grid overflow-hidden rounded-[26px] border border-line bg-fg/[.025] transition-colors hover:border-line-2 lg:grid-cols-[1.25fr_1fr]">
      <Cover post={post} className="aspect-[16/10] lg:aspect-auto lg:min-h-[420px]" />
      <div className="flex flex-col justify-center p-7 md:p-10">
        <p className="flex items-center gap-2 text-[13px] font-semibold uppercase tracking-[.08em]" style={{ color: hueOf(post.category) }}>Latest · {post.category}</p>
        <h2 className="mt-4 text-[28px] font-semibold leading-[1.12] tracking-[-0.03em] text-ink transition-colors group-hover:text-fg md:text-[38px]">{post.title}</h2>
        <p className="mt-4 text-[16.5px] leading-relaxed text-ink-2">{post.excerpt}</p>
        <p className="mt-6 flex items-center gap-3 text-[14px] text-ink-3">
          <span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-white p-1.5"><img src="/brand/mark.webp" alt="" className="h-full w-full" /></span>
          {authorOf(post)} · {formatDate(post)} · {post.read} min read
        </p>
        <span className="link mt-7">Read the research<Icon name="ArrowRight" size={14} weight="bold" /></span>
      </div>
    </Link>
  );
}

function Mini({ post }) {
  return (
    <Link to={`/blogs/${post.slug}`} className="group grid grid-cols-[120px_1fr] gap-5 rounded-[18px] p-2 transition-colors hover:bg-fg/[.03] md:grid-cols-[160px_1fr]">
      <Cover post={post} showHook={false} className="aspect-[4/3] rounded-[12px] border border-line" />
      <span className="self-center">
        <span className="block text-[12px] font-semibold uppercase tracking-[.08em]" style={{ color: hueOf(post.category) }}>{post.category}</span>
        <span className="mt-1.5 block text-[16.5px] font-semibold leading-snug tracking-[-0.015em] text-ink group-hover:text-fg">{post.title}</span>
        <span className="mt-1.5 block text-[13px] text-ink-3">{post.read} min read</span>
      </span>
    </Link>
  );
}

export default function Blog() {
  const [params, setParams] = useSearchParams();
  const topic = params.get('topic') || '';
  const product = params.get('product') || '';
  const q = params.get('q') || '';
  const set = (k, v) => { const n = new URLSearchParams(params); if (v) n.set(k, v); else n.delete(k); setParams(n, { replace: true, preventScrollReset: true }); };

  const list = useMemo(() => POSTS.filter((p) => (!topic || topicSlug(p.category) === topic)
    && (!product || p.product.name.startsWith(product))
    && (!q || `${p.title} ${p.excerpt} ${p.category}`.toLowerCase().includes(q.toLowerCase()))), [topic, product, q]);
  const filtering = topic || product || q;
  const [lead, ...rest] = POSTS;

  return (
    <>
      <Seo title="Research: Identity, AI Agent, Fraud and Bot Security" path="/blogs" description="Field notes and analysis from Deep Algorithms Research on identity attacks, AI agent security, financial crime, bot defence, DDoS and DPDPA compliance." crumbs={[{ name: 'Research', path: '/blogs' }]} />

      <section className="stage band-brand hero-under relative overflow-hidden">
        <FlowRibbons preset="band" intensity={0.55} />
        <div className="wrap relative pb-14 pt-12 md:pt-16">
          <Breadcrumb items={[{ name: 'Research' }]} className="rise" />
          <div className="mt-10 grid items-end gap-10 lg:grid-cols-[1.3fr_1fr]">
            <div>
              <p className="eyebrow rise">Deep Algorithms Research</p>
              <h1 className="t-h1 rise mt-6" style={{ '--d': '80ms' }}>How identities get attacked, and how to stop it.</h1>
              <p className="t-lead rise mt-6 max-w-[620px]" style={{ '--d': '160ms' }}>Field notes and analysis on identity attacks, AI agents, financial crime, bots and the regulation that shapes them. {POSTS.length} reports across {TOPICS.length} topics.</p>
            </div>
            <div className="rise" style={{ '--d': '240ms' }}>
              <label htmlFor="rs" className="mb-2 block text-[14px] text-ink-3">Search the research</label>
              <div className="flex h-14 items-center gap-3 rounded-full border border-line-2 bg-[#090b0f]/80 px-5 backdrop-blur focus-within:border-cyan/60">
                <Icon name="MagnifyingGlass" size={20} className="text-ink-3" />
                <input id="rs" type="search" value={q} onChange={(e) => set('q', e.target.value)} placeholder="Mule accounts, MCP, DDoS…" className="h-full w-full bg-transparent text-[16px] text-ink outline-none placeholder:text-ink-3" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {!filtering && (
        <section className="pb-8" aria-label="Featured research">
          <div className="wrap grid gap-6 xl:grid-cols-[1.9fr_1fr]">
            <Reveal><Featured post={lead} /></Reveal>
            <Reveal delay={100} className="flex flex-col justify-center gap-2">
              <p className="mb-2 px-2 text-[12.5px] font-semibold uppercase tracking-[.1em] text-ink-3">Also new</p>
              {rest.slice(0, 3).map((p) => <Mini key={p.slug} post={p} />)}
            </Reveal>
          </div>
        </section>
      )}

      <section className="sec pt-10" aria-labelledby="all-h">
        <div className="wrap">
          <div className="flex flex-col gap-5 border-b border-line pb-6">
            <div className="flex flex-wrap items-baseline justify-between gap-3">
              <h2 id="all-h" className="text-[24px] font-semibold tracking-[-0.02em]">{filtering ? `${list.length} ${list.length === 1 ? 'result' : 'results'}` : 'All research'}</h2>
              {filtering && <button type="button" onClick={() => setParams(new URLSearchParams(), { replace: true, preventScrollReset: true })} className="text-[14px] text-cyan-2 hover:text-fg">Clear filters</button>}
            </div>
            <div className="flex flex-wrap items-center gap-2" role="group" aria-label="Filter by topic">
              <span className="mr-1 text-[13px] text-ink-3">Topic</span>
              {[['', 'All'], ...TOPICS.map((t) => [topicSlug(t), t])].map(([v, label]) => (
                <button key={label} type="button" aria-pressed={topic === v} onClick={() => set('topic', v)}
                  className={cx('h-9 rounded-full border px-3.5 text-[14px] transition-colors', topic === v ? 'border-transparent bg-fg font-medium text-bg' : 'border-line-2 text-ink-2 hover:text-ink')}>
                  {label}{v && <span className="ml-1.5 text-[12px] opacity-60 num">{POSTS.filter((p) => p.category === label).length}</span>}
                </button>
              ))}
            </div>
            <div className="flex flex-wrap items-center gap-2" role="group" aria-label="Filter by product">
              <span className="mr-1 text-[13px] text-ink-3">Product</span>
              {['', ...PRODUCTS].map((v) => (
                <button key={v || 'all'} type="button" aria-pressed={product === v} onClick={() => set('product', v)}
                  className={cx('h-9 rounded-full border px-3.5 text-[14px] transition-colors', product === v ? 'border-transparent bg-fg font-medium text-bg' : 'border-line-2 text-ink-2 hover:text-ink')}>{v || 'All'}</button>
              ))}
            </div>
          </div>
          <p className="sr-only" aria-live="polite">{list.length} articles shown</p>
          {list.length ? (
            <div className="mt-12 grid gap-x-8 gap-y-14 md:grid-cols-2 lg:grid-cols-3">
              {list.map((p) => <div key={p.slug} className="fadein"><PostCard post={p} /></div>)}
            </div>
          ) : (
            <div className="mt-16 rounded-[22px] border border-dashed border-line-2 p-12 text-center">
              <p className="text-[20px] font-semibold">Nothing matches that yet.</p>
              <p className="mt-2 text-ink-2">Try another word, or clear the filters to see all {POSTS.length} reports.</p>
            </div>
          )}
        </div>
      </section>

      <section className="sec-tight" aria-labelledby="topics-h">
        <div className="wrap">
          <h2 id="topics-h" className="kicker mb-6">Browse by topic</h2>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {TOPICS.map((t) => (
              <button key={t} type="button" onClick={() => { set('topic', topicSlug(t)); document.getElementById('all-h')?.scrollIntoView({ behavior: 'smooth' }); }} className="card card-hover flex items-center justify-between p-5 text-left">
                <span><span className="block text-[16px] font-semibold" style={{ color: hueOf(t) }}>{t}</span><span className="mt-1 block text-[13.5px] text-ink-3">{POSTS.filter((p) => p.category === t).length} {POSTS.filter((p) => p.category === t).length === 1 ? 'report' : 'reports'}</span></span>
                <Icon name="ArrowRight" size={16} className="text-ink-3" />
              </button>
            ))}
            <a href={SITE.linkedin} target="_blank" rel="noreferrer" className="card card-hover flex items-center justify-between p-5">
              <span><span className="block text-[16px] font-semibold">New research first</span><span className="mt-1 block text-[13.5px] text-ink-3">Follow us on LinkedIn</span></span>
              <Icon name="LinkedinLogo" size={20} className="text-ink-3" />
            </a>
          </div>
        </div>
      </section>

      <CtaBand title="Put the research to work." body="See how what we write about looks in your own environment, with a Deep Algorithms engineer." />
    </>
  );
}
