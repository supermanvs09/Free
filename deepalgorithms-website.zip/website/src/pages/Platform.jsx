import { Seo } from '../lib/head.jsx';
import { BELIEFS, RECOGNITION } from '../data/company.js';
import { Icon, Reveal, SectionHead } from '../components/ui.jsx';
import { CtaBand, CertStrip, LogoMarquee } from '../components/blocks.jsx';
import { Hero, Points, Compare } from '../components/ProductKit.jsx';
import { ProductMapStatic } from '../components/BrandMoment.jsx';

const DEPLOY = [
  ['Zenstra AI', 'var(--color-zen)', 'A gateway inside your VPC, plus read-only connections to agent platforms'],
  ['adapID AI', 'var(--color-adap)', 'Read-only connectors to your IdP, IAM, HR and SaaS; one read-only role per AWS account'],
  ['BotShield AI', 'var(--color-bot)', 'Inline at the edge, inside ISP and near-edge networks, with no traffic diversion'],
  ['ICMS Compliance Suite', 'var(--color-icms)', 'Connected to the stores that hold personal data and to your identity sources'],
];

export default function Platform() {
  return (
    <>
      <Seo title="Why Deep Algorithms: Security for Every Identity Attackers Use" path="/platform" description="Why banks, government and enterprises choose Deep Algorithms: four focused products for AI agents, human and machine identities, bots and DDoS, and DPDPA compliance, each acting before damage is done." crumbs={[{ name: 'Why Deep Algorithms', path: '/platform' }]} />
      <Hero layout="stack" ribbons="band" crumbs={[{ name: 'Why Deep Algorithms' }]} eyebrow="Why Deep Algorithms"
        title="The defence has to be as intelligent as the attack."
        lead="Attackers adopted AI, automation and stolen identities. We build products that learn your environment, decide in the moment and explain every decision, for organisations that cannot afford a breach." />

      <section className="stage sec pt-0" aria-label="How the products fit together"><div className="wrap"><ProductMapStatic /></div></section>

      <section className="sec" aria-labelledby="share-h">
        <div className="wrap">
          <SectionHead id="share-h" eyebrow="What every product shares" title="Four products, built on the same convictions." />
          <div className="mt-12"><Points cols={4} items={[
            { icon: 'Lightning', h: 'Decide before damage', p: 'Inline decisions before the action, login, payment or request completes.' },
            { icon: 'ChatCircleText', h: 'Explain every decision', p: 'Scores and blocks come with their reasons, in language analysts and auditors can follow.' },
            { icon: 'Cloud', h: 'Respect your environment', p: 'Read-only connectors, agentless roles and gateways that run where your data already is.' },
            { icon: 'Scales', h: 'Built for Indian regulation', p: 'Evidence mapped to DPDPA 2023, RBI and SEBI expectations from the start.' },
          ]} /></div>
        </div>
      </section>

      <section className="sec" aria-labelledby="dep-h">
        <div className="wrap grid gap-12 lg:grid-cols-[.8fr_1.2fr] lg:gap-16">
          <Reveal>
            <p className="eyebrow">Deployment</p>
            <h2 id="dep-h" className="t-h2 mt-6">Each product deploys the way its problem needs.</h2>
            <p className="t-lead mt-5">No product asks you to move your data or rewrite your applications.</p>
          </Reveal>
          <Reveal delay={100}>
            <ul className="divide-y divide-line overflow-hidden rounded-[22px] border border-line">
              {DEPLOY.map(([n, c, t]) => (
                <li key={n} className="grid gap-2 p-6 md:grid-cols-[220px_1fr] md:gap-6">
                  <span className="flex items-center gap-2 text-[16px] font-semibold"><span className="h-2 w-2 rounded-full" style={{ background: c, boxShadow: `0 0 10px ${c}` }} />{n}</span>
                  <span className="text-[15.5px] leading-relaxed text-ink-2">{t}</span>
                </li>
              ))}
            </ul>
          </Reveal>
        </div>
      </section>

      <section className="sec" aria-labelledby="cmp-h">
        <div className="wrap">
          <SectionHead id="cmp-h" eyebrow="The difference" title="Built for the attack that looks legitimate." />
          <Reveal className="mt-12">
            <Compare caption="Deep Algorithms compared with rule-based and periodic security tools" cols={['Rule-based tools', 'Periodic reviews', 'Deep Algorithms']} rows={[
              ['Catches valid logins used by the wrong person', false, false, true],
              ['Covers machine identities and AI agents', 'Rarely', 'Partly', true],
              ['Acts before the action completes', 'Sometimes', false, true],
              ['Explains each decision', false, 'In a report', 'In plain language'],
              ['Evidence for regulators', 'Raw logs', 'Point in time', 'Continuous'],
            ]} />
          </Reveal>
        </div>
      </section>

      <section className="sec" aria-labelledby="bel-h">
        <div className="wrap">
          <SectionHead align="left" id="bel-h" eyebrow="What we believe" title="Not values on a wall. Constraints on every line of code." />
          <div className="mt-12"><Points items={BELIEFS.map((b) => ({ icon: b.icon, h: b.title, p: b.body }))} /></div>
        </div>
      </section>

      <section className="sec" aria-labelledby="trust-h">
        <div className="wrap">
          <SectionHead id="trust-h" eyebrow="Trust" title="Certified, recognised and in production." lead="ISO 27001, SOC 2 Type II, ISO 42001 and ISO 27701. Compliance documentation is available on request." />
          <Reveal className="mt-12"><CertStrip /></Reveal>
          <ul className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {RECOGNITION.slice(0, 4).map((r, i) => (
              <Reveal as="li" key={r.title} delay={i * 60} className="card flex items-center gap-4 p-4">
                <Icon name="Medal" size={22} className="shrink-0 text-icms" />
                <span><span className="block text-[15px] font-semibold">{r.title}</span><span className="block text-[13px] text-ink-3">{r.where} · {r.year}</span></span>
              </Reveal>
            ))}
          </ul>
        </div>
      </section>

      <LogoMarquee />
      <CtaBand />
    </>
  );
}
