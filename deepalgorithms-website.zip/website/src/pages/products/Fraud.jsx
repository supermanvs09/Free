import { useState } from 'react';
import { Link } from 'react-router';
import { Seo } from '../../lib/head.jsx';
import { PRODUCTS } from '../../data/products.js';
import { Icon, Reveal, SectionHead, Tabs } from '../../components/ui.jsx';
import { CtaBand, ResearchRow } from '../../components/blocks.jsx';
import Stage3D from '../../components/Stage3D.jsx';
import { Hero, Stats, Faq, Related, Points, LINKS, ACC } from '../../components/ProductKit.jsx';
import { FraudDecision, FRAUD_CASES, MuleNetwork } from '../../components/viz/adapid.jsx';

const p = PRODUCTS.fraud;
const A = ACC.adap;
const KEYS = ['mule', 'ato', 'sim', 'synthetic', 'good'];
const STORY = {
  mule: 'A customer adds a payee and sends ₹2,40,000. The payee’s device has been seen on 22 other accounts. The transfer is stopped before it clears.',
  ato: 'A password reset, then a login from a new device. The typing rhythm does not match Rohit’s. adapID asks for a stronger check instead of letting the session through.',
  sim: 'An OTP goes to a SIM that changed three hours ago, just before the first payment. The payment is held for four hours while the bank confirms with the customer.',
  synthetic: 'A new application uses a PAN and phone number seen together on nine other applications. It goes to review instead of becoming an account.',
  good: 'Kiran pays a known payee the usual amount from the usual phone. Nothing about it is unusual, so nothing gets in the way.',
};

function Simulator() {
  const [i, setI] = useState(0);
  const k = KEYS[i];
  return (
    <div>
      <Tabs items={KEYS.map((x) => FRAUD_CASES[x].label)} value={i} onChange={setI} acc={A} label="Fraud scenarios" />
      <div className="mt-10 grid items-center gap-10 lg:grid-cols-[.8fr_1.2fr] lg:gap-16">
        <div key={k} className="fadein">
          <p className="text-[13px] font-semibold uppercase tracking-[.08em] text-adap">{FRAUD_CASES[k].label}</p>
          <h3 className="mt-3 text-[28px] font-semibold leading-tight tracking-[-0.03em] md:text-[34px]">{FRAUD_CASES[k].event}</h3>
          <p className="mt-4 text-[17px] leading-relaxed text-ink-2">{STORY[k]}</p>
          <p className="mt-6 inline-flex items-center gap-2 rounded-full border border-line-2 px-4 py-2 text-[14px] text-ink-2"><Icon name="Clock" size={16} className="text-adap" />Decided in {FRAUD_CASES[k].ms} ms, before the money moves</p>
        </div>
        <FraudDecision scenario={k} />
      </div>
    </div>
  );
}

const SIGNALS = [
  { icon: 'DeviceMobile', h: 'Device intelligence', p: 'First-seen devices, emulators, SIM changes and a device shared across many accounts.' },
  { icon: 'CursorClick', h: 'Behavioural biometrics', p: 'Typing rhythm, navigation and hesitation that belong to the account owner, or do not.' },
  { icon: 'Graph', h: 'Identity graph', p: 'Links between accounts, payees, phones and documents that reveal mule rings and synthetic identities.' },
  { icon: 'Globe', h: 'Network', p: 'Proxies, hosting ranges, impossible travel and addresses already tied to fraud.' },
  { icon: 'Wallet', h: 'Transaction context', p: 'Amount, payee age, time and velocity against what this customer usually does.' },
  { icon: 'ChatCircleText', h: 'One explained decision', p: 'Approve, step-up, hold or block, with every contributing signal kept for review and audit.' },
];

const FAQ = [
  { title: 'Where does adapID sit in the payment flow?', body: 'It scores logins, payee additions and payments as they happen, and returns a decision your channel applies: approve, step-up, hold or block.' },
  { title: 'Will good customers feel it?', body: 'Good customers pass silently. Step-up appears only where risk rises, so friction lands on the sessions that deserve it.' },
  { title: 'How do you catch mule accounts?', body: 'Payees are scored the moment they are added, against registries and cross-account device and identity links, so mule activity is stopped at the payee.' },
  { title: 'Is it aligned with RBI expectations?', body: 'It supports RBI digital payment security and authentication expectations, and every decision is explainable and logged for audit.' },
];

export default function Fraud() {
  return (
    <>
      <Seo title={p.seoTitle} description={p.description} path={p.path} crumbs={[{ name: 'adapID AI', path: '/adapid-ai' }, { name: 'Identity Fraud Prevention', path: p.path }]} />
      <Hero acc="adap" crumbs={[{ name: 'adapID AI', path: '/adapid-ai' }, { name: 'Identity Fraud Prevention' }]} eyebrow="adapID AI · Identity Fraud Prevention"
        title={<>Catch the takeover and the mule <span style={{ color: '#7fdcff' }}>before the money moves.</span></>}
        lead="One decision engine across device, behaviour, identity graph, network and transaction context. Every login, payee and payment scored before it clears."
        note="Built for net banking, UPI and mobile apps.">
        <Stage3D tilt={[6, -12]}><FraudDecision scenario="mule" /></Stage3D>
      </Hero>

      <section className="stage sec" aria-labelledby="sim-h">
        <div className="wrap">
          <SectionHead align="left" id="sim-h" acc={A} eyebrow="Try it" title="Five kinds of fraud. Five different decisions." lead="Pick a scenario to see which signals rise, what adapID decides and why." />
          <div className="mt-12"><Simulator /></div>
        </div>
      </section>

      <section className="sec" aria-labelledby="mule-h">
        <div className="wrap grid items-center gap-12 lg:grid-cols-2 lg:gap-20">
          <Reveal>
            <p className="eyebrow" style={{ '--acc': A }}>India’s mule account crisis</p>
            <h2 id="mule-h" className="t-h2 mt-6">Stop the mule at the payee, not after the money is gone.</h2>
            <div className="mt-8 grid grid-cols-2 gap-4">
              {p.stats.slice(0, 2).map((s) => (
                <div key={s.v} className="card p-5">
                  <p className="text-[32px] font-semibold tracking-[-0.04em] text-adap num">{s.v}</p>
                  <p className="mt-2 text-[14px] leading-snug text-ink-2">{s.l}</p>
                  <p className="mt-3 text-[12px] text-ink-3">Source: {s.s}</p>
                </div>
              ))}
            </div>
            <Link to="/blogs/india-mule-account-crisis" className="link mt-8" style={{ '--acc': A }}>Read the research<Icon name="ArrowRight" size={14} weight="bold" /></Link>
          </Reveal>
          <Reveal delay={120} className="card p-3 md:p-5"><div className="screen tone-d p-2 md:p-4"><MuleNetwork /></div></Reveal>
        </div>
      </section>

      <section className="sec" aria-labelledby="sig-h">
        <div className="wrap">
          <SectionHead id="sig-h" acc={A} eyebrow="How it decides" title="Five signals. One decision." />
          <div className="mt-12"><Points items={SIGNALS} acc="adap" /></div>
        </div>
      </section>

      <Stats acc="adap" items={p.stats} />
      <Faq items={FAQ} />
      <Related items={[LINKS.cirm, LINKS.botshield, LINKS.icms]} />
      <ResearchRow slugs={p.research} />
      <CtaBand accent="adap" title={p.cta.title} body={p.cta.body} />
    </>
  );
}
