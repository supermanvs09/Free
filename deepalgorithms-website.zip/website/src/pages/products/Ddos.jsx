import { Link } from 'react-router';
import { Seo } from '../../lib/head.jsx';
import { PRODUCTS } from '../../data/products.js';
import { Icon, Reveal, SectionHead } from '../../components/ui.jsx';
import { CtaBand, ResearchRow } from '../../components/blocks.jsx';
import Stage3D from '../../components/Stage3D.jsx';
import { Hero, Stats, Faq, Related, Points, LINKS, ACC } from '../../components/ProductKit.jsx';
import { DdosEdge } from '../../components/viz/botshield.jsx';
import { Gl } from '../../components/viz/kit.jsx';

const p = PRODUCTS.ddos;
const A = ACC.bot;

/* The five 2026 patterns, from our research article on DDoS strategy. */
const PATTERNS = [
  { icon: 'Hourglass', h: 'Low-and-slow connections', p: 'A trickle, not a flood: connections held open with requests that never finish, until the server has no threads left.' },
  { icon: 'Code', h: 'Expensive API endpoints', p: 'A few thousand requests a minute to search or pricing APIs, each costing the server a hundred times a static page.' },
  { icon: 'Lock', h: 'TLS handshake exhaustion', p: 'Thousands of handshakes a second, before any application code runs, so application monitoring sees nothing.' },
  { icon: 'Globe', h: 'Residential-proxy floods', p: 'Hundreds of thousands of real home addresses making one or two requests each. Geo-blocks and IP lists catch nothing.' },
  { icon: 'Users', h: 'Fraud that doubles as DDoS', p: 'Paced credential stuffing that locks out real customers, drains the login service and commits fraud at the same time.' },
];

function Lanes() {
  const lane = (title, steps, bad) => (
    <div className="card p-6 md:p-8" style={bad ? undefined : { borderColor: 'rgb(52 224 195 / .4)' }}>
      <p className="text-[13px] font-semibold uppercase tracking-[.08em]" style={{ color: bad ? 'var(--color-ink-3)' : A }}>{title}</p>
      <div className="mt-6 flex items-center gap-2 overflow-x-auto pb-1">
        {steps.map(([g, t], i) => (
          <span key={t} className="flex items-center gap-2">
            <span className="flex min-w-[92px] flex-col items-center rounded-[14px] border border-line bg-fg/[.03] px-3 py-3 text-center">
              <Gl g={g} className="h-5 w-5" style={{ color: bad && t.includes('Scrubbing') ? 'var(--color-warn)' : bad ? 'var(--color-ink-3)' : A }} />
              <span className="mt-2 text-[12.5px] leading-tight text-ink-2">{t}</span>
            </span>
            {i < steps.length - 1 && <Icon name="ArrowRight" size={14} className="shrink-0 text-ink-3" />}
          </span>
        ))}
      </div>
      <ul className="mt-6 space-y-2 text-[14.5px] text-ink-2">
        {(bad ? ['Extra round trip while you are under attack', 'Diversion has to be detected and switched on', 'Built for volume, blind to floods that look human'] : ['No diversion, no extra hops', 'Always on, adapts without manual tuning', 'Behavioural detection for floods that look like users']).map((t) => (
          <li key={t} className="flex gap-2"><Icon name={bad ? 'X' : 'Check'} size={16} weight="bold" className="mt-[3px] shrink-0" style={{ color: bad ? 'var(--color-crit)' : A }} />{t}</li>
        ))}
      </ul>
    </div>
  );
  return (
    <div className="grid gap-5 lg:grid-cols-2">
      {lane('Scrubbing centre', [['globe', 'Users'], ['cloud', 'Divert'], ['shield', 'Scrubbing centre'], ['cloud', 'Return'], ['server', 'Origin']], true)}
      {lane('BotShield at the edge', [['globe', 'Users'], ['shield', 'Edge, near users'], ['server', 'Origin']], false)}
    </div>
  );
}

const FAQ = [
  { title: 'Where is BotShield deployed?', body: 'Inside ISP and near-edge networks, close to your users, so mitigation happens inline without diverting traffic.' },
  { title: 'Which layers are covered?', body: 'Layer 3 volumetric, layer 4 protocol and layer 7 application attacks, including floods built to look like real users.' },
  { title: 'Do we have to tune it during an attack?', body: 'No. Rate limiting, shaping and blocking adapt to traffic automatically, and both SOC and NOC teams see the same control plane.' },
];

export default function Ddos() {
  return (
    <>
      <Seo title={p.seoTitle} description={p.description} path={p.path} crumbs={[{ name: 'BotShield AI', path: '/botshield-ai' }, { name: 'DDoS Protection', path: p.path }]} />
      <Hero acc="bot" crumbs={[{ name: 'BotShield AI', path: '/botshield-ai' }, { name: 'DDoS Protection' }]} eyebrow="BotShield AI · DDoS Protection"
        title={<>Stay online when the flood <span style={{ color: '#7ff0dc' }}>looks like your customers.</span></>}
        lead="Inline, edge-ready protection against volumetric, protocol and application-layer attacks, close to your users, without added latency or user friction."
        note="For web apps, APIs, citizen services and checkout.">
        <Stage3D tilt={[6, -12]}><DdosEdge /></Stage3D>
      </Hero>

      <section className="sec" aria-labelledby="ln-h">
        <div className="wrap">
          <SectionHead id="ln-h" acc={A} eyebrow="Why inline" title="Don’t send your traffic away to clean it." lead="The scrubbing-centre model was built for floods of volume. Today’s attacks are built to look like users, and every detour costs you while you are under attack." />
          <Reveal className="mt-12"><Lanes /></Reveal>
        </div>
      </section>

      <section className="stage sec" aria-labelledby="pt-h">
        <div className="wrap">
          <SectionHead align="left" id="pt-h" acc={A} eyebrow="What takes platforms down in 2026" title="Five patterns, and none of them look like a flood." />
          <div className="mt-12 grid gap-4 md:grid-cols-2 lg:grid-cols-5">
            {PATTERNS.map((x, i) => (
              <Reveal key={x.h} delay={i * 60} className="card p-6">
                <span className="inline-flex h-10 w-10 items-center justify-center rounded-[12px] bg-bot/10 text-bot"><Icon name={x.icon} size={20} /></span>
                <h3 className="mt-5 text-[17px] font-semibold leading-snug tracking-[-0.015em]">{x.h}</h3>
                <p className="mt-2 text-[14px] leading-relaxed text-ink-2">{x.p}</p>
              </Reveal>
            ))}
          </div>
          <Reveal className="mt-8"><Link to="/blogs/ddos-mitigation-strategy-2026" className="link" style={{ '--acc': A }}>Read the full analysis<Icon name="ArrowRight" size={14} weight="bold" /></Link></Reveal>
        </div>
      </section>

      <section className="sec" aria-labelledby="ops-h">
        <div className="wrap">
          <SectionHead id="ops-h" acc={A} eyebrow="Operations" title="One control plane for SOC and NOC." />
          <div className="mt-12"><Points acc="bot" items={[
            { icon: 'Globe', h: 'Close to your users', p: 'Deployed inside ISP and near-edge networks.' },
            { icon: 'Lightning', h: 'No manual tuning', p: 'Mitigation adapts to traffic automatically.' },
            { icon: 'Gauge', h: 'Clear visibility', p: 'Every attack, response and outcome in one place.' },
          ]} /></div>
        </div>
      </section>

      <Stats acc="bot" items={p.stats} />
      <Faq items={FAQ} />
      <Related items={[LINKS.botshield, LINKS.fraud, LINKS.zenstra]} />
      <ResearchRow slugs={p.research} />
      <CtaBand accent="bot" title={p.cta.title} body={p.cta.body} />
    </>
  );
}
