import { Seo } from '../../lib/head.jsx';
import { PRODUCTS } from '../../data/products.js';
import { Button, Icon, Reveal, SectionHead } from '../../components/ui.jsx';
import { CtaBand, ResearchRow } from '../../components/blocks.jsx';
import Stage3D, { Pop } from '../../components/Stage3D.jsx';
import { Hero, Stats, Faq, Compare, Related, Explorer, LINKS } from '../../components/ProductKit.jsx';
import { ZenGateway, ZenInventory, ZenGrant, ZenMcp, ZenDetect, ZenRecord, ZenSurfaces } from '../../components/viz/zenstra.jsx';
import { Gl } from '../../components/viz/kit.jsx';
import { ZenToggle } from '../../components/Changes.jsx';

const p = PRODUCTS.zenstra;

const CAPS = [
  { tab: 'Discover', icon: 'MagnifyingGlass', h: 'Every agent, including the shadow ones', p: 'Custom, third-party and employee-built agents across workflows, cloud and staff devices, in one inventory with an owner, a platform and what each one can reach.', points: ['Copilot Studio, Claude, Cursor, n8n, LangGraph and more', 'Agents with no owner flagged for assignment', 'Ranked by what they can reach'], to: '/agentic-ai/agent-discovery', cta: 'Agent discovery', V: ZenInventory },
  { tab: 'Scope', icon: 'Fingerprint', h: 'An owner, a job and access that expires', p: 'Each agent gets the narrowest grant for its declared task. When the task ends, so does the access. Renewal needs a person.', points: ['Wildcard roles replaced with task-sized grants', 'Standing keys removed', 'Risk explained in plain language'], to: '/agentic-ai/agent-access', cta: 'Agent identity and access', V: ZenGrant },
  { tab: 'Enforce', icon: 'ShieldCheck', h: 'Allow, hold or block, before the call runs', p: 'A gateway inside your VPC compares each tool call with the agent’s task, grant and your policy, in milliseconds. High-impact actions wait for a named approver.', points: ['No agent rewrite', 'Payloads never leave your cloud', 'Human approval where it counts'], to: '/agentic-ai/runtime-enforcement', cta: 'Runtime enforcement', V: ZenGateway, props: { compact: true } },
  { tab: 'MCP', icon: 'PlugsConnected', h: 'Trust MCP servers on purpose', p: 'Allow-list servers and tools per agent, mark unofficial servers, and hold any tool whose definition changes after you approved it.', points: ['Per-agent tool scope', 'Changed tools held with the difference shown', 'Unofficial servers kept out by default'], to: '/agentic-ai/mcp-security', cta: 'MCP security', V: ZenMcp },
  { tab: 'Detect', icon: 'Pulse', h: 'Misuse of legitimate access, caught', p: 'A baseline per agent for tools, volumes, destinations and timing. When an agent steps outside its task, even with valid credentials, it is contained and its owner gets the evidence.', points: ['Beyond what an access check allows', 'Containment by policy', 'Evidence attached'], to: '/agentic-ai/detection-response', cta: 'Detection and response', V: ZenDetect },
  { tab: 'Prove', icon: 'ClipboardText', h: 'A record an auditor can read', p: 'Agent, task, policy and outcome on one line, chained so that any edit or gap shows. Export evidence for SOC 2, ISO/IEC 42001 and DPDPA reviews.', points: ['Tamper-evident chain', 'Policy version on every decision', 'PDF and CSV export'], to: '/agentic-ai/decision-record', cta: 'Decision record', V: ZenRecord },
];

const FAQ = [
  { title: 'Do we have to rewrite our agents?', body: 'No. Tool calls pass through the Zenstra gateway, and discovery uses read-only connections to the platforms your teams already build on. Agents keep working as they are.' },
  { title: 'Where does Zenstra run?', body: 'The gateway runs inside your own VPC. Prompts and payloads stay in your cloud; Zenstra decides on the call and records the decision.' },
  { title: 'Which agents and platforms does it cover?', body: 'Copilots, cloud agents, workflow automations such as n8n and Zapier, coding agents such as Cursor and Claude, and the MCP servers they connect to.' },
  { title: 'Will it slow our agents down?', body: 'Decisions are made inline in milliseconds. Only the actions your policy marks as high-impact wait for a person.' },
  { title: 'What do auditors get?', body: 'A tamper-evident decision record with the agent, its task, the policy version and the outcome for every action, exported as PDF or CSV.' },
];

/* Where the gateway sits: agents on the left, your systems on the right, all inside your cloud. */
function Deployment() {
  const L = [['agent', 'Copilots and agents'], ['flow', 'Workflow automations'], ['laptop', 'Coding agents']];
  const R = [['bank', 'Core banking'], ['db', 'CRM and data'], ['mail', 'Email and documents']];
  return (
    <div className="card relative overflow-hidden p-6 md:p-10">
      <div className="absolute inset-3 rounded-[18px] border border-dashed" style={{ borderColor: 'rgb(147 162 255 / .35)' }} aria-hidden="true" />
      <p className="relative text-[12.5px] font-semibold uppercase tracking-[.1em]" style={{ color: 'var(--color-zen)' }}>Your VPC</p>
      <div className="relative mt-6 grid items-center gap-8 md:grid-cols-[1fr_auto_1fr]">
        <ul className="space-y-3">{L.map(([g, t]) => <li key={t} className="flex items-center gap-3 rounded-[14px] border border-line bg-fg/[.03] p-3.5 text-[15px]"><Gl g={g} className="h-5 w-5 text-zen" />{t}</li>)}</ul>
        <div className="flex flex-col items-center text-center">
          <span className="relative inline-flex h-24 w-24 items-center justify-center rounded-[26px] text-[#101216]" style={{ background: 'linear-gradient(135deg, #b8c2ff, #7d8dff)', boxShadow: '0 0 60px rgb(147 162 255 / .5)' }}><Gl g="shield" className="h-11 w-11" /></span>
          <p className="mt-4 text-[16px] font-semibold">Zenstra gateway</p>
          <p className="mt-1 max-w-[200px] text-[13.5px] text-ink-3">Every call checked against task, grant and policy</p>
        </div>
        <ul className="space-y-3">{R.map(([g, t]) => <li key={t} className="flex items-center gap-3 rounded-[14px] border border-line bg-fg/[.03] p-3.5 text-[15px]"><Gl g={g} className="h-5 w-5 text-ink-2" />{t}</li>)}</ul>
      </div>
      <div className="relative mt-8 grid gap-3 border-t border-line pt-6 text-[14.5px] text-ink-2 md:grid-cols-3">
        <p className="flex gap-2"><Icon name="Lock" size={18} className="shrink-0 text-zen" />Prompts and payloads stay in your cloud</p>
        <p className="flex gap-2"><Icon name="Lightning" size={18} className="shrink-0 text-zen" />Decisions inline, in milliseconds</p>
        <p className="flex gap-2"><Icon name="ClipboardText" size={18} className="shrink-0 text-zen" />Every decision written to the record</p>
      </div>
    </div>
  );
}

export default function Zenstra() {
  return (
    <>
      <Seo title={p.seoTitle} description={p.description} path={p.path} crumbs={[{ name: 'Zenstra AI', path: p.path }]} />
      <Hero acc="zen" crumbs={[{ name: 'Products', path: '/products' }, { name: 'Zenstra AI' }]} eyebrow="Zenstra AI · Security for AI agents"
        title={<>Let AI agents act. <span style={{ color: '#aab6ff' }}>Check every action first.</span></>}
        lead="Zenstra finds every AI agent and MCP server in your enterprise, gives each one an owner and access sized to its task, and decides every tool call before it runs."
        ctas={<><Button to="/request-demo" size="lg" arrow>Book a demo</Button><Button href="https://www.zenstra.ai" target="_blank" rel="noopener" variant="ghost" size="lg">Visit zenstra.ai<Icon name="ArrowUpRight" size={16} /></Button></>}
        note="One platform for copilots, cloud agents, workflow automations, coding agents and MCP servers.">
        <Stage3D tilt={[6, -15]}>
          <ZenGateway />
          <Pop z={90} className="absolute -left-[6%] bottom-[8%] hidden w-[46%] md:block" delay={900}>
            <div className="vz-pop vzw" style={{ padding: '14px 16px', '--glow': 'rgb(255 107 93 / .5)' }}>
              <p className="text-[12px] font-semibold uppercase tracking-[.08em] text-crit">Blocked · 4 ms</p>
              <p className="mt-1 text-[14px] font-medium">invoice-agent → crm.export</p>
              <p className="text-[12.5px] text-ink-3">Not part of “summarise the Q3 contract”</p>
            </div>
          </Pop>
        </Stage3D>
      </Hero>

      <section className="sec" aria-labelledby="where-h">
        <div className="wrap">
          <SectionHead id="where-h" acc="var(--color-zen)" eyebrow="Where your agents live" title="One platform for every place agents run." lead="Agents are built by business teams, developers and vendors, on platforms IT never provisioned. Zenstra covers all of them with one inventory, one policy and one record." />
          <Reveal className="mt-14"><ZenSurfaces /></Reveal>
        </div>
      </section>

      <section className="stage sec" aria-labelledby="caps-h">
        <div className="wrap">
          <SectionHead align="left" id="caps-h" acc="var(--color-zen)" eyebrow="What Zenstra does" title="From the first agent to the last audit." lead="Six capabilities that work on their own and get stronger together. Pick one to see it work." />
          <div className="mt-12"><Explorer items={CAPS} acc="zen" label="Zenstra capabilities" /></div>
        </div>
      </section>

      <section className="sec" aria-labelledby="chg-h">
        <div className="wrap">
          <SectionHead id="chg-h" acc="var(--color-zen)" eyebrow="What changes" title="What changes with Zenstra." lead="Five moments in every agent’s life, before and after. Flip the switch to compare." />
          <Reveal className="mx-auto mt-12 max-w-[980px]"><ZenToggle /></Reveal>
        </div>
      </section>

      <section className="sec" aria-labelledby="dep-h">
        <div className="wrap grid items-center gap-12 lg:grid-cols-[.8fr_1.2fr] lg:gap-16">
          <Reveal>
            <p className="eyebrow" style={{ '--acc': 'var(--color-zen)' }}>Deployment</p>
            <h2 id="dep-h" className="t-h2 mt-6">Inside your cloud, in the path of every call.</h2>
            <p className="t-lead mt-5">Most tools see an agent after it acts. Zenstra sits between your agents and your systems, so the decision happens before the action does.</p>
          </Reveal>
          <Reveal delay={120}><Deployment /></Reveal>
        </div>
      </section>

      <section className="sec" aria-labelledby="cmp-h">
        <div className="wrap">
          <SectionHead id="cmp-h" acc="var(--color-zen)" eyebrow="Why it is different" title="Built to decide, not only to watch." />
          <Reveal className="mt-12">
            <Compare acc="zen" caption="How Zenstra compares with logging and identity tools for AI agents" cols={['Logs and SIEM', 'Identity tools', 'Zenstra AI']} rows={[
              ['Finds agents nobody registered', false, 'Some', true],
              ['Knows each agent’s task', false, false, true],
              ['Decides before the tool runs', false, 'At sign-in only', true],
              ['Catches misuse of valid access', 'After the fact', false, true],
              ['Evidence an auditor can verify', 'Raw logs', 'Access reviews', 'Tamper-evident record'],
            ]} />
          </Reveal>
        </div>
      </section>

      <Stats acc="zen" items={p.stats} title="Why it matters now" />
      <Faq items={FAQ} />
      <Related items={[LINKS.cirm, LINKS.nhi, LINKS.icms]} />
      <ResearchRow slugs={p.research} title="Research on AI agent security" />
      <CtaBand accent="zen" title={p.cta.title} body={p.cta.body} />
    </>
  );
}
