import { Link } from 'react-router';
import { Seo } from '../../lib/head.jsx';
import { PRODUCTS } from '../../data/products.js';
import { Icon, Reveal, SectionHead } from '../../components/ui.jsx';
import { CtaBand, ResearchRow } from '../../components/blocks.jsx';
import Stage3D from '../../components/Stage3D.jsx';
import { Hero, Stats, Faq, Related, Steps, LINKS, ACC } from '../../components/ProductKit.jsx';
import { CtemLoop, BotIntent, DdosEdge } from '../../components/viz/botshield.jsx';

const p = PRODUCTS.botshield;
const A = ACC.bot;

const BOTS = [
  ['Credential stuffing', 'Stolen passwords tried at scale, from rotating addresses.'],
  ['Scraping', 'Prices, catalogues and content copied by automation that looks like browsing.'],
  ['OTP abuse', 'SMS and OTP endpoints flooded to run up costs or lock customers out.'],
  ['Fake sign-ups', 'Accounts created in bulk for promotions, mules or later attacks.'],
];

const FAQ = [
  { title: 'How is this different from a vulnerability scanner?', body: 'A scanner lists what might be wrong. BotShield’s red team agent replays each finding to prove it is exploitable, so your teams only see what is real.' },
  { title: 'What is a virtual patch?', body: 'A protection rule deployed in front of the vulnerable route, so the exposure is closed while the code fix is built and released.' },
  { title: 'How do you tell bots from people?', body: 'By intent and behaviour, such as typing cadence, header order, retry timing and credential reuse, rather than by signatures or IP lists that bots rotate past.' },
  { title: 'How often does the loop run?', body: 'Continuously. New assets and changes are mapped as they appear, instead of waiting for a quarterly test.' },
];

export default function BotShield() {
  return (
    <>
      <Seo title={p.seoTitle} description={p.description} path={p.path} crumbs={[{ name: 'BotShield AI', path: p.path }]} />
      <Hero layout="stack" acc="bot" ribbons="band" crumbs={[{ name: 'Products', path: '/products' }, { name: 'BotShield AI' }]} eyebrow="BotShield AI · Exposure, bots and DDoS"
        title={<>The attack is autonomous. <span style={{ color: '#7ff0dc' }}>Your defence has to be too.</span></>}
        lead="Agents map your attack surface, prove which exposures are exploitable and deploy protection while the fix reaches its owner. Bot defence stops automation by intent, and DDoS protection keeps you online."
        note="One platform for web apps, APIs, login flows and payment journeys.">
        <Stage3D tilt={[12, 0]} range={[3, 5]} className="mx-auto max-w-[900px]"><CtemLoop /></Stage3D>
      </Hero>

      <section id="loop" className="sec scroll-mt-20" aria-labelledby="loop-h">
        <div className="wrap">
          <SectionHead id="loop-h" acc={A} eyebrow="Continuous threat exposure management" title="Discover, simulate, validate, fix. Then again." lead="Only exploitable findings reach your teams, and protection is live before the release." />
          <div className="mt-12"><Steps acc="bot" loop items={[
            { h: 'Discover', p: 'A reconnaissance agent maps every domain, API and login flow as it appears.' },
            { h: 'Simulate', p: 'A red team agent attacks what it finds, the way a real adversary would.' },
            { h: 'Validate', p: 'Every finding is replayed before it is raised. No guesses in your queue.' },
            { h: 'Fix', p: 'A blue team agent deploys a virtual patch and routes the fix to the owning team.' },
          ]} /></div>
        </div>
      </section>

      <section id="bots" className="stage sec scroll-mt-20" aria-labelledby="bots-h">
        <div className="wrap grid items-center gap-12 lg:grid-cols-[.85fr_1.15fr] lg:gap-16">
          <Reveal>
            <p className="eyebrow" style={{ '--acc': A }}>Bot defence</p>
            <h2 id="bots-h" className="t-h2 mt-6">Intent, not signatures.</h2>
            <p className="t-lead mt-5">Bots adapt in hours; signature updates take weeks. BotShield identifies automation by what it is trying to do, even when it rotates identities and addresses.</p>
            <ul className="mt-8 grid gap-3 sm:grid-cols-2">
              {BOTS.map(([h, t]) => <li key={h} className="card p-5"><p className="text-[16px] font-semibold">{h}</p><p className="mt-1.5 text-[14px] leading-relaxed text-ink-2">{t}</p></li>)}
            </ul>
          </Reveal>
          <Reveal delay={120}><BotIntent /></Reveal>
        </div>
      </section>

      <section className="sec" aria-labelledby="upi-h">
        <div className="wrap">
          <Reveal className="card overflow-hidden p-8 md:p-14" style={{ background: 'radial-gradient(80% 120% at 100% 0%, rgb(52 224 195 / .14), transparent 60%), linear-gradient(180deg, color-mix(in oklab, var(--color-fg) 4%, transparent), color-mix(in oklab, var(--color-fg) 1%, transparent))' }}>
            <div className="grid items-center gap-10 lg:grid-cols-[1.1fr_.9fr]">
              <div>
                <p className="eyebrow" style={{ '--acc': A }}>Built for UPI-scale fintech</p>
                <h2 id="upi-h" className="t-h2 mt-6">When money moves in seconds, so do the bots.</h2>
                <p className="t-lead mt-5">Login, OTP, payee and payment endpoints are where adversarial bots go first. BotShield watches each one continuously.</p>
                <Link to="/blogs/ctem-bot-defence-fintech" className="link mt-7" style={{ '--acc': A }}>CTEM for bot defence in Indian fintech<Icon name="ArrowRight" size={14} weight="bold" /></Link>
              </div>
              <div className="lg:text-right">
                <p className="font-semibold tracking-[-0.05em] text-bot num" style={{ fontSize: 'clamp(48px, 6vw, 88px)', lineHeight: 1 }}>{p.stats[0].v}</p>
                <p className="mt-3 text-[16px] text-ink-2 lg:ml-auto lg:max-w-[320px]">{p.stats[0].l}</p>
                <p className="mt-2 text-[12.5px] text-ink-3">Source: {p.stats[0].s}</p>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="sec" aria-labelledby="dd-h">
        <div className="wrap grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
          <Reveal className="lg:order-2">
            <p className="eyebrow" style={{ '--acc': A }}>Availability</p>
            <h2 id="dd-h" className="t-h2 mt-6">When the flood comes, you stay online.</h2>
            <p className="t-lead mt-5">Volumetric, protocol and application-layer attacks mitigated close to your users, inline, with no traffic detour.</p>
            <Link to="/botshield-ai/ddos-protection" className="link mt-7" style={{ '--acc': A }}>DDoS Protection<Icon name="ArrowRight" size={14} weight="bold" /></Link>
          </Reveal>
          <Reveal delay={100} className="lg:order-1"><DdosEdge /></Reveal>
        </div>
      </section>

      <Stats acc="bot" items={p.stats} />
      <Faq items={FAQ} />
      <Related items={[LINKS.fraud, LINKS.zenstra, LINKS.icms]} />
      <ResearchRow slugs={p.research} />
      <CtaBand accent="bot" title="Fix what is actually exploitable." body={p.cta.body} />
    </>
  );
}
