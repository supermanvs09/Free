import { Seo } from '../../lib/head.jsx';
import { PRODUCTS } from '../../data/products.js';
import { Icon, Reveal, SectionHead, cx } from '../../components/ui.jsx';
import { CtaBand, ResearchRow } from '../../components/blocks.jsx';
import Stage3D, { Pop } from '../../components/Stage3D.jsx';
import { Hero, Stats, Faq, Related, LINKS, ACC } from '../../components/ProductKit.jsx';
import { NhiGraph } from '../../components/viz/adapid.jsx';

const p = PRODUCTS.nhi;
const A = ACC.adap;

const TRUST = `{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Principal": { "AWS": "arn:aws:iam::<adapid-account>:root" },
    "Action": "sts:AssumeRole",
    "Condition": { "StringEquals": { "sts:ExternalId": "<your-external-id>" } }
  }]
}`;

const GENOME = [
  ['lambda-kyc-sync', 'GetSecretValue from eu-west-1', '30 days', 'Needs review', 'warn'],
  ['ecs-notify-svc', 'New S3 bucket read, 2:14 am', 'Established', 'Malicious', 'crit'],
  ['glue-ledger-etl', 'Job ran 3x usual volume', 'Established', 'Legitimate', 'ok'],
  ['sm-fraud-train', 'Called iam:PassRole', 'Learning', 'Needs review', 'warn'],
  ['stepfn-payouts', 'Within baseline', 'Established', 'Healthy', 'ok'],
];
const SECRETS = [
  ['AKIA••••7Q2F', 'payments-api/config.yml', '2 days ago', 'Real secret', 'crit'],
  ['ghp_••••x91', 'infra/deploy.sh', 'Today', 'Real secret', 'crit'],
  ['AKIA••••EXAMPLE', 'docs/setup.md', '1 week ago', 'Known harmless', 'ok'],
  ['db_password', '3 places in one commit', 'Yesterday', 'Repeated value', 'warn'],
];
const TONE = { ok: 'c-ok', warn: 'c-warn', crit: 'c-crit' };

function Table({ cols, rows, caption }) {
  return (
    <div className="overflow-x-auto rounded-[20px] border border-line bg-bg-1" role="region" tabIndex={0} aria-label={caption}>
      <table className="w-full min-w-[640px] text-left text-[14.5px]">
        <caption className="sr-only">{caption}</caption>
        <thead><tr className="border-b border-line">{cols.map((c) => <th key={c} scope="col" className="px-5 py-4 text-[12px] font-semibold uppercase tracking-[.08em] text-ink-3">{c}</th>)}</tr></thead>
        <tbody>{rows.map((r) => (
          <tr key={r[0]} className="border-b border-line last:border-0">
            <td className="px-5 py-4 font-mono text-[13.5px] text-ink">{r[0]}</td><td className="px-5 py-4 text-ink-2">{r[1]}</td><td className="px-5 py-4 text-ink-3">{r[2]}</td>
            <td className="px-5 py-4"><span className={cx('vz-chip', TONE[r[4]])} style={{ fontSize: 12.5 }}>{r[3]}</span></td>
          </tr>
        ))}</tbody>
      </table>
    </div>
  );
}

const FAQ = [
  { title: 'What access does adapID need?', body: 'One read-only IAM role per AWS account, assumed with an external ID. Nothing is installed on workloads and nothing is written to your accounts.' },
  { title: 'Which identities are covered?', body: 'IAM roles, users, service-linked roles and workload identities across accounts and regions, with their credentials and trust relationships.' },
  { title: 'How do you know what is used?', body: 'Granted permissions are compared with 90 days of CloudTrail activity, so unused access stands out for removal.' },
  { title: 'Where do you look for leaked secrets?', body: 'GitHub and AWS CodeCommit, with model-based triage so analysts see real exposures first, and full-history deep scans on demand.' },
];

export default function Nhi() {
  return (
    <>
      <Seo title={p.seoTitle} description={p.description} path={p.path} crumbs={[{ name: 'adapID AI', path: '/adapid-ai' }, { name: 'NHI Security for AWS', path: p.path }]} />
      <Hero acc="adap" crumbs={[{ name: 'adapID AI', path: '/adapid-ai' }, { name: 'NHI Security for AWS' }]} eyebrow="adapID AI · NHI Security for AWS"
        title={<>Every machine identity in your AWS accounts. <span style={{ color: '#7fdcff' }}>Found, scored, watched.</span></>}
        lead="Fifteen machine identities for every person, and most were created by a deploy, not by a decision. adapID finds each role, key and workload identity, shows what it can reach and what it actually uses, and catches the one that starts behaving differently."
        note="Agentless. One read-only role per account.">
        <Stage3D tilt={[6, -13]}>
          <NhiGraph />
          <Pop z={80} delay={1000} className="absolute -right-[3%] -top-[8%] hidden w-[40%] sm:block">
            <div className="vz-pop" style={{ padding: '14px 16px', '--glow': 'rgb(60 200 246 / .5)' }}>
              <p className="text-[12px] font-semibold uppercase tracking-[.08em] text-adap">Unused for 90 days</p>
              <p className="mt-1 text-[14px] font-medium">205 permissions safe to remove</p>
            </div>
          </Pop>
        </Stage3D>
      </Hero>

      <section className="sec" aria-labelledby="on-h">
        <div className="wrap grid gap-12 lg:grid-cols-[1fr_1fr] lg:gap-16">
          <Reveal>
            <p className="eyebrow" style={{ '--acc': A }}>Connect an account</p>
            <h2 id="on-h" className="t-h2 mt-6">From one read-only role to a full inventory, in minutes.</h2>
            <ol className="mt-10 space-y-7">
              {[['Create the role', 'Deploy one read-only IAM role with the trust policy on the right. No agents, no write access.'], ['Pass three checks', 'adapID verifies it can assume the role, read IAM and read CloudTrail before the first sync is queued.'], ['See every identity', 'Roles, users, keys and workload identities appear with owner, exposure and posture score, and every change since the last sync.']].map(([h, t], i) => (
                <li key={h} className="flex gap-5">
                  <span className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-[14px] font-bold text-on-acc" style={{ background: A }}>{i + 1}</span>
                  <span><span className="block text-[19px] font-semibold tracking-[-0.015em]">{h}</span><span className="mt-1 block text-[15.5px] leading-relaxed text-ink-2">{t}</span></span>
                </li>
              ))}
            </ol>
          </Reveal>
          <Reveal delay={120} className="self-center">
            <div className="tone-d overflow-hidden rounded-[20px] border border-line bg-[#080a0e]">
              <div className="flex items-center justify-between border-b border-line px-5 py-3"><span className="font-mono text-[13px] text-ink-2">adapid-readonly · trust policy</span><span className="vz-chip c-ok" style={{ fontSize: 12 }}>Read-only</span></div>
              <pre className="overflow-x-auto p-5 font-mono text-[13px] leading-[1.75] text-[#bcd6f2]"><code>{TRUST}</code></pre>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="sec" aria-labelledby="gu-h">
        <div className="wrap">
          <SectionHead id="gu-h" acc={A} eyebrow="Posture and access" title="Granted is not the same as used." lead="Each identity is scored from 100 down by the checks it fails. The access graph shows who can assume what, and 90 days of CloudTrail show what is actually used." />
          <Reveal className="mx-auto mt-14 max-w-[900px] card p-6 md:p-9">
            {[['lambda-kyc-sync', 214, 9], ['ecs-notify-svc', 88, 31], ['glue-ledger-etl', 61, 44]].map(([n, g, u]) => (
              <div key={n} className="border-b border-line py-5 first:pt-0 last:border-0 last:pb-0">
                <div className="flex flex-wrap items-baseline justify-between gap-2"><span className="font-mono text-[14px] text-ink">{n}</span><span className="text-[14px] text-ink-3"><b className="text-ink num">{u}</b> used of <b className="text-ink num">{g}</b> granted</span></div>
                <div className="relative mt-3 h-3 overflow-hidden rounded-full bg-fg/[.06]">
                  <span className="absolute inset-y-0 left-0 rounded-full bg-fg/15" style={{ width: '100%' }} />
                  <span className="absolute inset-y-0 left-0 rounded-full" style={{ width: `${(u / g) * 100}%`, background: A }} />
                </div>
              </div>
            ))}
            <p className="mt-6 text-[13.5px] text-ink-3">Illustrative identities. Unused permissions are listed for removal with the CloudTrail evidence behind each one.</p>
          </Reveal>
        </div>
      </section>

      <section className="stage sec" aria-labelledby="gen-h">
        <div className="wrap grid gap-12 lg:grid-cols-[.75fr_1.25fr] lg:gap-16">
          <Reveal>
            <p className="eyebrow" style={{ '--acc': A }}>NHI Genome</p>
            <h2 id="gen-h" className="t-h2 mt-6">Every workload has a normal. We notice when it changes.</h2>
            <p className="t-lead mt-5">Each workload identity learns its normal calls, resources and schedule. Departures are graded, explained and sent for review.</p>
          </Reveal>
          <Reveal delay={100}><Table caption="Workload identities and their departures from baseline" cols={['Identity', 'Departure from baseline', 'Baseline', 'Verdict']} rows={GENOME} /></Reveal>
        </div>
      </section>

      <section className="sec" aria-labelledby="sec-h">
        <div className="wrap grid gap-12 lg:grid-cols-[.75fr_1.25fr] lg:gap-16">
          <Reveal>
            <p className="eyebrow" style={{ '--acc': A }}>Exposed secrets</p>
            <h2 id="sec-h" className="t-h2 mt-6">Keys leaked into code, found and ranked by real risk.</h2>
            <p className="t-lead mt-5">Secrets found in GitHub and AWS CodeCommit are sorted by models, so analysts see real exposures before false alarms.</p>
            <p className="mt-6 flex items-center gap-2 text-[15px] text-ink-2"><Icon name="Code" size={18} className="text-adap" />Full-history deep scans on demand</p>
          </Reveal>
          <Reveal delay={100}><Table caption="Secrets found in code and their verdicts" cols={['Secret', 'Where', 'Found', 'Verdict']} rows={SECRETS} /></Reveal>
        </div>
      </section>

      <Stats acc="adap" items={p.stats} />
      <Faq items={FAQ} />
      <Related items={[LINKS.cirm, LINKS.zenstra, LINKS.ad]} />
      <ResearchRow slugs={p.research} />
      <CtaBand accent="adap" title={p.cta.title} body={p.cta.body} />
    </>
  );
}
