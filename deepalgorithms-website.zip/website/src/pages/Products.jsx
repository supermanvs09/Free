import { useState } from 'react';
import { Link } from 'react-router';
import { Seo } from '../lib/head.jsx';
import { Icon, Reveal, SectionHead, cx } from '../components/ui.jsx';
import { CtaBand } from '../components/blocks.jsx';
import { Hero, ACC } from '../components/ProductKit.jsx';

const NEEDS = ['Everything', 'AI agents', 'People', 'Machine identities', 'Payments', 'Active Directory', 'Apps and APIs', 'Personal data'];

const ALL = [
  { line: 'Zenstra AI', acc: ACC.zen, name: 'Zenstra AI', kind: 'Platform', body: 'Discover every AI agent and MCP server, give each one an owner and scoped access, and decide every tool call before it runs.', needs: ['AI agents'], to: '/agentic-ai/agentic-identity', points: ['Agent discovery', 'Runtime enforcement', 'Decision record'] },
  { line: 'adapID AI', acc: ACC.adap, name: 'Identity Risk Management', kind: 'Product', body: 'A live, explainable risk score for every person, acted on the moment behaviour changes.', needs: ['People'], to: '/adapid-ai', points: ['Behaviour baselines', 'Step-up, hold or block', 'Day-one detection'] },
  { line: 'adapID AI', acc: ACC.adap, name: 'NHI Security for AWS', kind: 'Product', body: 'Every IAM role, key and workload identity found, scored for posture and watched for new behaviour.', needs: ['Machine identities'], to: '/adapid-ai/nhi-security', points: ['Agentless, one read-only role', 'Granted vs used', 'Leaked secrets'] },
  { line: 'adapID AI', acc: ACC.adap, name: 'Identity Fraud Prevention', kind: 'Product', body: 'Logins, payees and payments scored on five signals before money moves.', needs: ['Payments', 'People'], to: '/adapid-ai/fraud-prevention', points: ['Mule accounts at the payee', 'Account takeover', 'Under 80 ms'] },
  { line: 'adapID AI', acc: ACC.adap, name: 'Active Directory Security', kind: 'Product', body: 'Paths to Domain Admins mapped and cut, and live abuse contained in seconds.', needs: ['Active Directory'], to: '/ad-security', points: ['Attack path ranking', 'Kerberoasting to DCSync', 'Automatic containment'] },
  { line: 'BotShield AI', acc: ACC.bot, name: 'BotShield AI', kind: 'Platform', body: 'Agents prove which exposures are exploitable and patch them virtually; bot defence stops automation by intent.', needs: ['Apps and APIs', 'Payments'], to: '/botshield-ai', points: ['Continuous exposure management', 'Bot defence', 'Virtual patching'] },
  { line: 'BotShield AI', acc: ACC.bot, name: 'DDoS Protection', kind: 'Part of BotShield', body: 'Volumetric, protocol and application-layer attacks mitigated at the edge, inline, with no diversion.', needs: ['Apps and APIs'], to: '/botshield-ai/ddos-protection', points: ['L3 to L7', 'No diversion', 'One control plane'] },
  { line: 'ICMS Compliance Suite', acc: ACC.icms, name: 'ICMS Compliance Suite', kind: 'Platform', body: 'Personal data discovered, every access checked against purpose and consent, and audit evidence generated as it happens.', needs: ['Personal data'], to: '/dpdpa-compliance', points: ['DPDPA, RBI and SEBI', 'Consent ledger', '72-hour breach response'] },
];

export default function Products() {
  const [n, setN] = useState(0);
  const need = NEEDS[n];
  const list = n === 0 ? ALL : ALL.filter((x) => x.needs.includes(need));
  return (
    <>
      <Seo title="Products: AI Agent, Identity, Fraud, Bot and Compliance Security" path="/products" description="Every Deep Algorithms product: Zenstra AI for AI agents, the four adapID AI products for human and machine identities, BotShield AI for exposure, bots and DDoS, and the ICMS Compliance Suite for DPDPA." crumbs={[{ name: 'Products', path: '/products' }]} />
      <Hero layout="stack" ribbons="band" crumbs={[{ name: 'Products' }]} eyebrow="Products"
        title="Four product lines. A product for each way in."
        lead="Each product solves one problem and runs on its own. Start with the identity your attackers are most likely to use." />

      <section className="pb-24" aria-labelledby="dir-h">
        <div className="wrap">
          <h2 id="dir-h" className="sr-only">Find a product</h2>
          <Reveal className="flex flex-col items-start gap-4 md:flex-row md:items-center">
            <p className="shrink-0 text-[15px] text-ink-2">What do you need to protect?</p>
            <div role="group" aria-label="What do you need to protect?" className="flex flex-wrap gap-2">
              {NEEDS.map((x, i) => (
                <button key={x} type="button" aria-pressed={n === i} onClick={() => setN(i)}
                  className={cx('h-10 rounded-full border px-4 text-[14.5px] font-medium transition-colors', n === i ? 'border-transparent bg-white text-[#04121f]' : 'border-line-2 text-ink-2 hover:border-white/30 hover:text-ink')}>{x}</button>
              ))}
            </div>
          </Reveal>
          <p className="sr-only" aria-live="polite">{list.length} products</p>
          <div className="mt-10 grid gap-5 md:grid-cols-2 xl:grid-cols-4">
            {list.map((x) => (
              <Link key={x.to} to={x.to} className="card card-hover fadein group flex flex-col p-6 md:p-7" style={{ '--acc': x.acc }}>
                <span className="flex items-center justify-between gap-3">
                  <span className="flex items-center gap-2 text-[12.5px] font-semibold uppercase tracking-[.08em]" style={{ color: x.acc }}><span className="h-1.5 w-1.5 rounded-full" style={{ background: x.acc, boxShadow: `0 0 10px ${x.acc}` }} />{x.line}</span>
                  <span className="rounded-full border border-line-2 px-2 py-0.5 text-[11.5px] text-ink-3">{x.kind}</span>
                </span>
                <h3 className="mt-5 text-[22px] font-semibold leading-tight tracking-[-0.025em]">{x.name}</h3>
                <p className="mt-3 flex-1 text-[15px] leading-relaxed text-ink-2">{x.body}</p>
                <ul className="mt-6 space-y-2 border-t border-line pt-5">
                  {x.points.map((t) => <li key={t} className="flex items-center gap-2 text-[14px] text-ink-2"><Icon name="Check" size={14} weight="bold" style={{ color: x.acc }} />{t}</li>)}
                </ul>
                <span className="link mt-6 text-[14.5px]">Explore<Icon name="ArrowRight" size={14} weight="bold" /></span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="sec" aria-labelledby="tog-h">
        <div className="wrap">
          <SectionHead id="tog-h" eyebrow="Better together" title="Use one. Or combine them where the risk is." lead="Products run independently. These are the combinations teams start with most often." />
          <div className="mt-12 grid gap-4 md:grid-cols-3">
            {[
              ['Banks and fintechs', ['Identity Fraud Prevention', 'BotShield AI', 'ICMS Compliance Suite'], 'Stop mules at the payee and bots at login, and keep DPDPA and RBI evidence ready.', '/solutions/bfsi'],
              ['An AI rollout', ['Zenstra AI', 'NHI Security for AWS'], 'Govern the agents you deploy and the cloud keys they run on.', '/agentic-ai/agentic-identity'],
              ['A public service', ['DDoS Protection', 'Active Directory Security'], 'Keep the portal online and the domain behind it closed to attackers.', '/solutions/government'],
            ].map(([h, prods, t, to], i) => (
              <Reveal key={h} delay={i * 80}>
                <Link to={to} className="card card-hover block h-full p-7">
                  <p className="text-[19px] font-semibold tracking-[-0.015em]">{h}</p>
                  <ul className="mt-4 flex flex-wrap gap-2">{prods.map((x) => <li key={x} className="rounded-full border border-line-2 px-3 py-1 text-[13px] text-ink-2">{x}</li>)}</ul>
                  <p className="mt-4 text-[15px] leading-relaxed text-ink-2">{t}</p>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <CtaBand title="Not sure where to start?" body="Tell us which identities worry you most, and an engineer will show you the product that fits, on your own environment." primary={{ label: 'Talk to an engineer', to: '/request-demo' }} />
    </>
  );
}
