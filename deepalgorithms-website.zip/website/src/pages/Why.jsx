import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router';
import { useInView, useReducedMotion } from '../lib/motion.js';
import { Seo } from '../lib/head.jsx';
import { SITE, CERTS } from '../data/site.js';
import { LEADERS, ADVISORS, RECOGNITION, TEAM_PHOTOS, BELIEFS } from '../data/company.js';
import { Breadcrumb, Button, Icon, Reveal, SectionHead, cx } from '../components/ui.jsx';
import { CertStrip, CtaBand, LogoMarquee } from '../components/blocks.jsx';
import { Compare } from '../components/ProductKit.jsx';
import FlowRibbons from '../components/FlowRibbons.jsx';
import ProductMark from '../components/ProductMark.jsx';

/* Why Deep Algorithms: the company and the case for it, on one page.
   What enterprise "why us" and company pages carry, in this order: the claim,
   how the platform works, the story, the difference, the people, the proof,
   then careers and offices. */

const img = (k) => `/img/events/${k}.webp`;
const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));

/* how far the reader is through an element, 0 at its top entering the lower
   part of the screen, 1 at its bottom leaving the upper part */
function useScrollProgress(ref, { start = 0.85, end = 0.25 } = {}) {
  const [p, setP] = useState(1);
  const reduce = useReducedMotion();
  useEffect(() => {
    if (reduce) { setP(1); return undefined; }
    let raf = 0;
    const read = () => {
      raf = 0;
      const el = ref.current;
      if (!el) return;
      const r = el.getBoundingClientRect(), vh = window.innerHeight;
      setP(clamp((vh * start - r.top) / (r.height + vh * (start - end))));
    };
    const on = () => { if (!raf) raf = requestAnimationFrame(read); };
    read();
    window.addEventListener('scroll', on, { passive: true });
    window.addEventListener('resize', on);
    return () => { cancelAnimationFrame(raf); window.removeEventListener('scroll', on); window.removeEventListener('resize', on); };
  }, [ref, reduce, start, end]);
  return p;
}

const LINEUP = [
  ['zenstra', 'Zenstra AI', 'AI agents', '#93a2ff', 'Agent’s CRM export blocked', '4 ms', '/agentic-ai/agentic-identity', 'Security for AI agents: every action checked against its task before it runs.'],
  ['adapid', 'adapID AI', 'People and machine identities', '#3cc8f6', 'Lagos sign-in held at risk 94', '1.4 s', '/adapid-ai', 'Security for people and machine identities: the one that starts behaving differently is stopped.'],
  ['botshield', 'BotShield AI', 'Apps, APIs and the edge', '#34e0c3', '18,204 bot logins refused', '60 s', '/botshield-ai', 'Exposure, bot and DDoS defence: real risks proven and patched, bots and floods stopped at the edge.'],
  ['icms', 'ICMS Compliance Suite', 'Personal data and DPDPA', '#f4c76c', 'Read without consent refused', 'now', '/dpdpa-compliance', 'DPDPA compliance: every access to personal data becomes evidence, ready before the auditor asks.'],
];

/* The four products, one at a time: the mark large, with its name and one line
   on what it does. Each holds for a few seconds, then gives way to the next;
   the bars below show how many there are, not which comes next. */
const HOLD = 3600;
function ProductPanel() {
  const ref = useRef(null);
  const seen = useInView(ref, { threshold: 0.3 });
  const reduce = useReducedMotion();
  const [on, setOn] = useState(0);
  const [held, setHeld] = useState(false);
  useEffect(() => {
    if (!seen || reduce || held) return undefined;
    const t = setTimeout(() => setOn((n) => (n + 1) % LINEUP.length), HOLD);
    return () => clearTimeout(t);
  }, [seen, reduce, held, on]);
  const P = LINEUP[on];
  return (
    <div ref={ref} className="relative mx-auto grid w-full max-w-[540px] place-items-center py-6 text-center">
      <div aria-hidden="true" className="absolute left-1/2 top-[99px] h-[360px] w-[360px] -translate-x-1/2 -translate-y-1/2 rounded-full blur-2xl transition-[background] duration-1000 max-sm:top-[82px] max-sm:h-[260px] max-sm:w-[260px]" style={{ background: `radial-gradient(closest-side, color-mix(in oklab, ${P[3]} 38%, transparent), transparent 72%)` }} />
      <div aria-hidden="true" className="ps-ring absolute left-1/2 top-[99px] h-[250px] w-[250px] -translate-x-1/2 -translate-y-1/2 rounded-full max-sm:top-[82px] max-sm:h-[190px] max-sm:w-[190px]" style={{ background: `conic-gradient(from 0deg, transparent 0 62%, color-mix(in oklab, ${P[3]} 80%, transparent) 78%, transparent 92%)`, WebkitMask: 'radial-gradient(closest-side, transparent 96%, #000 97%)', mask: 'radial-gradient(closest-side, transparent 96%, #000 97%)', transition: 'background 1s' }} />
      <Link key={on} to={P[6]} className="ps-in relative grid place-items-center" aria-label={`${P[1]}: ${P[7]}`}>
        <span className="ps-bob grid h-[150px] w-[150px] place-items-center max-sm:h-[116px] max-sm:w-[116px]"><ProductMark p={P[0]} size={128} className="max-sm:!h-[98px] max-sm:!w-[98px]" style={{ filter: `drop-shadow(0 18px 40px color-mix(in oklab, ${P[3]} 55%, transparent))` }} /></span>
        <span className="mt-10 block text-[clamp(30px,3vw,42px)] font-semibold tracking-[-0.03em] text-white">{P[1]}</span>
        <span className="mt-3 block max-w-[30ch] text-[17px] leading-relaxed text-white/75">{P[7]}</span>
      </Link>
      <div className="relative mt-10 flex gap-2" role="group" aria-label="Products">
        {LINEUP.map(([k, name], i) => (
          <button key={k} type="button" onClick={() => { setHeld(true); setOn(i); }} aria-label={name} aria-current={i === on || undefined} className="group py-2">
            <span className="block h-[3px] w-10 overflow-hidden rounded-full bg-white/15">
              <span className={cx('block h-full rounded-full bg-white/85', i === on && !held && !reduce ? 'ps-fill' : '')} style={{ width: i === on && (held || reduce) ? '100%' : i === on ? undefined : '0%', animationDuration: `${HOLD}ms` }} />
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}

/* ---------- inside the platform: one picture that changes as you read ---------- */
const STEPS = [
  { k: 'See', h: 'See every identity', p: 'People, service accounts, cloud keys and AI agents, found across your identity provider, cloud and SaaS, each with an owner.' },
  { k: 'Learn', h: 'Learn what normal looks like', p: 'Every identity gets its own baseline: where it signs in from, what it reaches, when it works and how much it moves.' },
  { k: 'Decide', h: 'Decide before the action runs', p: 'When an identity steps outside its normal, the login, payment, API call or agent action is held before it completes.' },
  { k: 'Explain', h: 'Explain every decision', p: 'Each hold comes with its reasons in plain language, so an analyst can act in seconds and a customer is not left guessing.' },
  { k: 'Prove', h: 'Prove it to the regulator', p: 'Every decision is kept on a tamper-evident record, mapped to DPDPA, RBI and SEBI, ready before the auditor asks.' },
];
const RINGS = [
  { r: 104, label: 'People', nodes: [[-60, 'User'], [60, 'User'], [180, 'User'], [250, 'User']] },
  { r: 168, label: 'Machine identities', nodes: [[-20, 'Key'], [40, 'Cloud'], [110, 'Database'], [160, 'HardDrives'], [215, 'Key'], [300, 'Cloud']] },
  { r: 232, label: 'AI agents', nodes: [[10, 'Robot'], [75, 'Sparkle'], [135, 'Robot'], [195, 'Cpu'], [270, 'Robot'], [325, 'Sparkle']] },
];
const HOT = [1, 0]; // the identity that steps outside its normal: ring 1, node 0 (a cloud key)

function CorePicture({ step }) {
  const pos = (r, a) => [50 + (r / 5.2) * Math.cos((a * Math.PI) / 180), 50 + (r / 5.2) * Math.sin((a * Math.PI) / 180)];
  const [hx, hy] = pos(RINGS[HOT[0]].r, RINGS[HOT[0]].nodes[HOT[1]][0]);
  return (
    <div className="relative mx-auto aspect-square w-full max-w-[520px]" aria-hidden="true">
      <svg viewBox="0 0 100 100" className="absolute inset-0 h-full w-full">
        <defs><radialGradient id="core-halo"><stop offset="0" stopColor="#3cc8f6" stopOpacity=".35" /><stop offset="1" stopColor="#3cc8f6" stopOpacity="0" /></radialGradient></defs>
        <circle cx="50" cy="50" r="22" fill="url(#core-halo)" />
        {RINGS.map((g) => <circle key={g.r} cx="50" cy="50" r={g.r / 5.2} fill="none" stroke="var(--color-line-2)" strokeWidth=".25" strokeDasharray={step >= 1 ? '0.8 1.2' : 'none'} />)}
        {step >= 2 && <line x1="50" y1="50" x2={hx} y2={hy} stroke="#f0644d" strokeWidth=".5" strokeDasharray="1.4 1" className="core-line" />}
      </svg>
      {RINGS.map((g, i) => g.nodes.map(([a, ic], j) => {
        const [x, y] = pos(g.r, a);
        const hot = step >= 2 && i === HOT[0] && j === HOT[1];
        return (
          <span key={`${i}-${j}`} className={cx('core-node absolute flex h-[9%] w-[9%] -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border bg-bg-1 text-ink-2', hot && 'is-hot')}
            style={{ left: `${x}%`, top: `${y}%`, transitionDelay: `${(i * 6 + j) * 30}ms` }}>
            <Icon name={ic} size={16} />
            {step >= 1 && !hot && <span className="core-base" />}
          </span>
        );
      }))}
      <span className="absolute left-1/2 top-1/2 flex h-[19%] w-[19%] -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-[24%] border border-[#e3e8ee] bg-white shadow-[0_18px_40px_-16px_rgb(6_47_87/.5)]">
        <img src="/brand/mark.webp" alt="" className="h-[58%] w-[58%]" />
      </span>
      {/* what the step adds, beside the picture */}
      <div className={cx('core-card absolute left-[56%] top-[6%] w-[52%] max-w-[250px]', step === 2 && 'on')}>
        <p className="text-[12px] font-semibold uppercase tracking-[.08em] text-[#f0644d]">Held before it ran</p>
        <p className="mt-1 text-[14px] font-semibold text-ink">svc-payments key</p>
        <p className="mt-1 text-[13px] leading-snug text-ink-3">Tried to read a customer table it has never touched.</p>
      </div>
      <div className={cx('core-card absolute left-[56%] top-[6%] w-[52%] max-w-[250px]', step === 3 && 'on')}>
        <p className="text-[12px] font-semibold uppercase tracking-[.08em] text-cyan-2">Why it was held</p>
        <ul className="mt-2 space-y-1.5 text-[13px] text-ink-2">
          {['First read of this table in 90 days', 'Called from a new network', 'Outside its usual hours'].map((t) => <li key={t} className="flex gap-2"><Icon name="CheckCircle" size={15} weight="fill" className="mt-px shrink-0 text-cyan-2" />{t}</li>)}
        </ul>
      </div>
      <div className={cx('core-card absolute bottom-[2%] left-1/2 w-[86%] max-w-[380px] -translate-x-1/2', step === 4 && 'on')}>
        <p className="flex items-center justify-between text-[12px] font-semibold uppercase tracking-[.08em] text-ink-3"><span>Decision record</span><span className="text-[#4be29a]">Sealed</span></p>
        <ul className="mt-2 divide-y divide-line text-[13px]">
          {[['#4821', 'svc-payments key held', 'DPDPA §8'], ['#4820', 'Agent export refused', 'RBI'], ['#4819', 'Login stepped up', 'SEBI']].map(([n, t, m]) => (
            <li key={n} className="flex items-center gap-3 py-1.5"><span className="num text-ink-3">{n}</span><span className="flex-1 text-ink-2">{t}</span><span className="text-[12px] text-ink-3">{m}</span></li>
          ))}
        </ul>
      </div>
    </div>
  );
}

function InsideCore() {
  const ref = useRef(null);
  const p = useScrollProgress(ref, { start: 0.45, end: 0.55 });
  const reduce = useReducedMotion();
  const [step, setStep] = useState(4);
  const [wide, setWide] = useState(false);
  useEffect(() => {
    const m = window.matchMedia('(min-width: 1024px)');
    const on = () => setWide(m.matches);
    on(); m.addEventListener('change', on);
    return () => m.removeEventListener('change', on);
  }, []);
  useEffect(() => { if (wide && !reduce) setStep(Math.min(STEPS.length - 1, Math.floor(p * STEPS.length))); else setStep(4); }, [p, wide, reduce]);
  return (
    <section ref={ref} className="sec relative" aria-labelledby="core-h" style={wide && !reduce ? { height: `${STEPS.length * 70 + 40}vh` } : undefined}>
      <div className={cx('wrap', wide && !reduce && 'sticky top-[calc(var(--hdr)+24px)]')}>
        <div className="grid items-center gap-12 lg:grid-cols-[minmax(0,.9fr)_minmax(0,1.1fr)] lg:gap-16">
          <div>
            <p className="eyebrow">Inside the platform</p>
            <h2 id="core-h" className="t-h2 mt-6">One intelligence behind every product.</h2>
            <ol className="mt-10 space-y-1">
              {STEPS.map((s, i) => (
                <li key={s.k} className={cx('core-step border-l-2 py-3 pl-5 transition-colors duration-300', i === step ? 'border-cyan-2' : 'border-line')}>
                  <p className={cx('flex items-baseline gap-3 text-[19px] font-semibold tracking-[-0.015em] transition-colors', i === step ? 'text-ink' : 'text-ink-3')}><span className="num text-[13px] text-cyan-2">{String(i + 1).padStart(2, '0')}</span>{s.h}</p>
                  <p className={cx('core-p text-[15.5px] leading-relaxed text-ink-2', (i === step || !wide || reduce) && 'on')}>{s.p}</p>
                </li>
              ))}
            </ol>
          </div>
          <CorePicture step={step} />
        </div>
      </div>
    </section>
  );
}

/* ---------- our story: the statement lights up as you read, then the years ---------- */
const STATEMENT = 'Attackers adopted AI. Bots that pass for people, stolen identities that drift unseen for months, data access that looks exactly like legitimate work. Tools built for a world of rules could not keep up. So we built defence that learns what normal looks like, and acts before the deviation becomes a breach.';

function Statement() {
  const ref = useRef(null);
  const p = useScrollProgress(ref, { start: 0.9, end: 0.45 });
  const words = STATEMENT.split(' ');
  return (
    <p ref={ref} className="text-[clamp(26px,3.1vw,42px)] font-semibold leading-[1.2] tracking-[-0.025em]">
      {words.map((w, i) => {
        const on = clamp(p * words.length * 1.15 - i);
        return <span key={i} style={{ opacity: 0.18 + 0.82 * on, transition: 'opacity .2s linear' }}>{w}{i < words.length - 1 ? ' ' : ''}</span>;
      })}
    </p>
  );
}

const YEARS = [
  { y: '2022', h: 'Founded in Hyderabad', p: 'Deep Algorithms starts from one observation: attackers had adopted AI, and the tools defending against them had not.', items: [['Company founded', 'Hyderabad, India']], photo: null },
  { y: '2024', h: 'On the national stage', p: 'Our work on identity and data security reaches government and industry forums across India.', items: [['Bharat Mandapam', 'Delhi'], ['CCoE DSCI Chapter Meet', 'Hyderabad'], ['Cybersecurity and Privacy conference', 'Telangana']], photo: 'bharat-mandapam' },
  { y: '2025', h: 'Recognised for the work', p: 'Awards from the Data Security Council of India and industry bodies, and an international stage in Dubai.', items: [['Cybersecurity Excellence', 'Data Security Council of India'], ['Business Excellence Award', 'Best Cybersecurity Solutions Provider'], ['GITEX GLOBAL × Expand North Star', 'Dubai']], photo: 'dsci-excellence' },
  { y: '2026', h: 'Growing the team', p: 'A new office, training with the Cyber Bureau in Hyderabad and the AI Summit in Delhi.', items: [['New office inauguration', 'Hyderabad'], ['Cyber Security Training', 'Cyber Bureau Hyderabad'], ['AI Summit', 'Delhi']], photo: 'office-inauguration' },
];

function Years() {
  const ref = useRef(null);
  const p = useScrollProgress(ref, { start: 0.7, end: 0.6 });
  return (
    <ol ref={ref} className="relative mt-16 space-y-14 md:space-y-20">
      <span aria-hidden="true" className="absolute bottom-2 left-[15px] top-2 w-px bg-line-2 md:left-1/2" />
      <span aria-hidden="true" className="absolute left-[15px] top-2 w-px origin-top bg-cyan-2 md:left-1/2" style={{ height: 'calc(100% - 16px)', transform: `scaleY(${p})` }} />
      {YEARS.map((y, i) => {
        const lit = p >= (i + 0.2) / YEARS.length;
        return (
          <li key={y.y} className="relative grid gap-6 pl-12 md:grid-cols-2 md:gap-16 md:pl-0">
            <span aria-hidden="true" className={cx('absolute left-[7px] top-1 h-[17px] w-[17px] rounded-full border-2 transition-colors duration-500 md:left-1/2 md:-translate-x-1/2', lit ? 'border-cyan-2 bg-cyan-2' : 'border-line-2 bg-bg')} />
            <Reveal className={cx(i % 2 ? 'md:order-2 md:pl-4' : 'md:pr-4 md:text-right')}>
              <p className="text-[56px] font-semibold leading-none tracking-[-0.05em] text-cyan-2 num md:text-[72px]">{y.y}</p>
              <h3 className="mt-3 text-[24px] font-semibold tracking-[-0.025em]">{y.h}</h3>
              <p className="mt-2 text-[16.5px] leading-relaxed text-ink-2">{y.p}</p>
              <ul className={cx('mt-4 flex flex-wrap gap-2', !(i % 2) && 'md:justify-end')}>
                {y.items.map(([t, w]) => <li key={t} className="rounded-full border border-line-2 px-3 py-1.5 text-[13px] text-ink-2"><span className="font-medium text-ink">{t}</span> · {w}</li>)}
              </ul>
            </Reveal>
            <Reveal delay={100} className={cx(i % 2 && 'md:order-1')}>
              <div className="relative aspect-[16/10] overflow-hidden rounded-[20px] border border-line bg-bg-1">
                {y.photo ? <img src={img(y.photo)} alt={y.items[0][0]} className="h-full w-full object-cover" loading="lazy" decoding="async" />
                  : <div className="flex h-full items-center justify-center" style={{ background: 'linear-gradient(140deg, #062a5c, #04193a)' }}><span className="flex h-24 w-24 items-center justify-center rounded-[26px] bg-white p-5"><img src="/brand/mark.webp" alt="" className="h-full w-full" /></span></div>}
              </div>
            </Reveal>
          </li>
        );
      })}
    </ol>
  );
}

/* Leaders: a portrait, the role in one line and a short record. */
function Leader({ p }) {
  return (
    <div className="card card-hover group relative flex h-full flex-col p-6">
      <div className="flex items-center gap-4">
        <span className="relative block h-[68px] w-[68px] shrink-0 rounded-full p-[2px]" style={{ background: 'linear-gradient(140deg, #3cc8f6, #0068ac 60%, rgb(148 170 200 / .25))' }}>
          <img src={`/img/people/${p.img}.webp`} alt="" width="64" height="64" className="h-full w-full rounded-full bg-[#0f1115] object-cover" loading="lazy" decoding="async" />
        </span>
        <span className="min-w-0 pr-7">
          <span className="block text-[17px] font-semibold leading-tight tracking-[-0.015em]">{p.name}</span>
          <span className="mt-1 block text-[13.5px] font-medium text-cyan-2">{p.role}</span>
        </span>
      </div>
      <p className="mt-5 flex-1 border-t border-line pt-4 text-[14px] leading-relaxed text-ink-2">{p.bio}</p>
      <a href={p.linkedin} target="_blank" rel="noreferrer" className="absolute right-4 top-4 inline-flex h-9 w-9 items-center justify-center rounded-full text-ink-3 transition-colors hover:bg-fg/[.06] hover:text-ink" aria-label={`${p.name} on LinkedIn`}><Icon name="LinkedinLogo" size={18} /></a>
    </div>
  );
}

function Advisor({ p }) {
  return (
    <a href={p.linkedin} target="_blank" rel="noreferrer" className="group flex h-full items-start gap-3.5 rounded-[16px] border border-line p-4 transition-colors hover:border-line-2 hover:bg-fg/[.025]" aria-label={`${p.name}, ${p.role}, on LinkedIn`}>
      <img src={`/img/people/${p.img}.webp`} alt="" width="48" height="48" className="h-12 w-12 shrink-0 rounded-full bg-[#0f1115] object-cover" loading="lazy" decoding="async" />
      <span className="min-w-0 flex-1">
        <span className="flex items-center gap-1.5 text-[15px] font-semibold leading-tight">{p.name}<Icon name="LinkedinLogo" size={14} className="text-ink-3 opacity-0 transition-opacity group-hover:opacity-100" /></span>
        <span className="mt-0.5 block text-[12.5px] font-medium text-cyan-2">{p.role}</span>
        <span className="mt-1.5 block text-[13px] leading-snug text-ink-3">{p.bio}</span>
      </span>
    </a>
  );
}

/* The team, rolling past: two rows in opposite directions, paused on hover. */
function TeamRoll() {
  const [paused, setPaused] = useState(false);
  const rowA = TEAM_PHOTOS.concat(RECOGNITION.slice(4).map((r) => ({ title: `${r.title}, ${r.where}`, img: r.img })));
  const rowB = [...rowA.slice(3), ...rowA.slice(0, 3)];
  // each row is its photos twice over, moved by exactly one set, so the loop has no seam
  const Row = ({ items, reverse }) => (
    <ul className={cx('marquee roll-team flex w-max', reverse && 'rev')}>
      {[...items, ...items].map((t, i) => {
        const copy = i >= items.length;
        return (
          <li key={t.img + i} className="w-[316px] shrink-0 pr-4 md:w-[396px]" aria-hidden={copy || undefined}>
            <figure>
              <img src={img(t.img)} alt={copy ? '' : t.title} className="aspect-[4/3] w-full rounded-[18px] border border-line object-cover" loading="lazy" decoding="async" />
              <figcaption className="mt-2.5 text-[13.5px] text-ink-3">{t.title}</figcaption>
            </figure>
          </li>
        );
      })}
    </ul>
  );
  return (
    <div className={cx('marquee-wrap relative mt-12 space-y-6 overflow-hidden', paused && 'paused')} onFocus={() => setPaused(true)} onBlur={() => setPaused(false)}>
      <Row items={rowA} />
      <Row items={rowB} reverse />
      <button type="button" onClick={() => setPaused(!paused)} aria-pressed={paused} className="absolute bottom-0 right-5 inline-flex h-9 items-center gap-2 rounded-full border border-line-2 bg-bg/80 px-3.5 text-[13px] text-ink-2 backdrop-blur md:right-10">
        <Icon name={paused ? 'Play' : 'Pause'} size={13} weight="fill" />{paused ? 'Play' : 'Pause'}
      </button>
    </div>
  );
}

const TEAMS = [
  { name: 'AI engineering', icon: 'Cpu', work: 'Behaviour models that score people, machine identities and AI agents in milliseconds, and explain every score in plain language.' },
  { name: 'Security research', icon: 'Detective', work: 'Attack paths, mule networks and new identity attacks, studied in the field and written up as the reports on this site.' },
  { name: 'Product engineering', icon: 'Code', work: 'Gateways, connectors and consoles that run inside customers’ own clouds, built for banks, hospitals and government.' },
];

export default function Why() {
  return (
    <>
      <Seo title="Why Deep Algorithms: The Company and the Case for It" path="/why-deep-algorithms" description="Why banks, government and enterprises choose Deep Algorithms: one intelligence that sees every identity, learns what normal looks like and acts before damage is done. Founded in Hyderabad in 2022. Meet the team." crumbs={[{ name: 'Why Deep Algorithms', path: '/why-deep-algorithms' }]} />

      <section className="stage band-brand hero-under relative overflow-hidden" data-page-name="Why Deep Algorithms">
        <FlowRibbons preset="hero" mobilePreset="heroMobile" intensity={0.7} />
        <div className="wrap relative grid items-center gap-14 pb-20 pt-10 lg:min-h-[min(84svh,820px)] lg:grid-cols-[1.05fr_1fr] lg:gap-10">
          <div className="max-md:text-center">
            <Breadcrumb items={[{ name: 'Why Deep Algorithms' }]} className="rise mb-8 max-md:justify-center" />
            <p className="eyebrow rise">Why Deep Algorithms</p>
            <h1 className="t-hero rise mt-7" style={{ '--d': '80ms' }}>The defence has to be as intelligent as the attack.</h1>
            <p className="t-lead rise mt-7 max-w-[560px] max-md:mx-auto" style={{ '--d': '160ms' }}>Attackers adopted AI, automation and stolen identities. We build products that learn your environment, decide in the moment and explain every decision, for organisations that cannot afford a breach.</p>
            <dl className="rise mt-10 grid max-w-[480px] grid-cols-3 gap-x-8 max-md:mx-auto" style={{ '--d': '240ms' }}>
              {[['Founded', SITE.founded], ['Headquarters', 'Hyderabad'], ['Certifications', CERTS.length]].map(([k, v]) => (
                <div key={k}><dt className="text-[13px] text-ink-3">{k}</dt><dd className="mt-1 text-[24px] font-semibold tracking-[-0.03em] num">{v}</dd></div>
              ))}
            </dl>
          </div>
          <ProductPanel />
        </div>
      </section>

      <InsideCore />

      <section className="sec" aria-labelledby="story-h">
        <div className="wrap">
          <p className="eyebrow">Our story</p>
          <h2 id="story-h" className="t-h2 mt-6 max-w-[760px]">We don’t sell security products. We build defence that thinks.</h2>
          <div className="mt-12 max-w-[1040px]"><Statement /></div>
          <Years />
        </div>
      </section>

      <section className="sec" aria-labelledby="cmp-h">
        <div className="wrap">
          <SectionHead id="cmp-h" eyebrow="The difference" title="Built for the attack that looks legitimate." />
          <Reveal className="mt-12">
            <Compare caption="Deep Algorithms compared with rule-based and periodic security tools" cols={['Rule-based tools', 'Periodic reviews', 'Deep Algorithms']} rows={[
              ['Catches valid logins used by the wrong person', false, false, true],
              ['Covers machine identities and AI agents', 'Rarely', 'Partly', true],
              ['Acts before the action completes', 'Sometimes', false, true],
              ['Explains each decision', false, 'In a report', 'In plain language'],
              ['Evidence for regulators', 'Raw logs', 'Point in time', 'Continuous'],
            ]} />
          </Reveal>
        </div>
      </section>

      <section className="sec" aria-labelledby="bel-h">
        <div className="wrap">
          <SectionHead align="left" id="bel-h" eyebrow="What we believe" title="Not values on a wall. Constraints on every line of code." />
          <ol className="mt-12 grid gap-x-12 md:grid-cols-2 lg:grid-cols-3">
            {BELIEFS.map((b, i) => (
              <Reveal as="li" key={b.title} delay={(i % 3) * 70} className="border-t border-line py-7">
                <Icon name={b.icon} size={24} className="text-cyan-2" />
                <span className="mt-4 block text-[19px] font-semibold tracking-[-0.02em]">{b.title}</span>
                <span className="mt-2 block text-[15.5px] leading-relaxed text-ink-2">{b.body}</span>
              </Reveal>
            ))}
          </ol>
        </div>
      </section>

      <section id="leadership" className="sec scroll-mt-20" aria-labelledby="lead-h">
        <div className="wrap">
          <SectionHead align="left" id="lead-h" eyebrow="Leadership" title="Decades in AI, banking and security, in one team." lead="Founders, operators and researchers from IIT, IIM, IIIT and Imperial College London." />
          <div className="m-rail mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{LEADERS.map((p, i) => <Reveal key={p.name} delay={i * 70} className="h-full"><Leader p={p} /></Reveal>)}</div>
          <h3 className="mt-20 text-[24px] font-semibold tracking-[-0.02em]">Advisors and mentors</h3>
          <p className="mt-2 text-[16px] text-ink-2">Leaders from banking regulation, investment, technology and research who guide our work.</p>
          <div className="m-rail m-rail-sm mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{ADVISORS.map((p, i) => <Reveal key={p.name} delay={(i % 4) * 60} className="h-full"><Advisor p={p} /></Reveal>)}</div>
        </div>
      </section>

      <section id="recognition" className="sec scroll-mt-20" aria-labelledby="rec-h">
        <div className="wrap">
          <SectionHead align="left" id="rec-h" eyebrow="Recognition" title="Recognised, certified and in production." />
          <div className="m-rail mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {RECOGNITION.slice(0, 4).map((r, i) => (
              <Reveal key={r.title} delay={(i % 4) * 60} className={cx('card group overflow-hidden', i === 0 && 'sm:col-span-2 lg:row-span-2')}>
                <div className={cx('overflow-hidden', i === 0 ? 'aspect-[4/3]' : 'aspect-[16/10]')}><img src={img(r.img)} alt={`${r.title}, ${r.where}`} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-[1.04]" loading="lazy" decoding="async" /></div>
                <div className="p-5"><p className={cx('font-semibold tracking-[-0.015em]', i === 0 ? 'text-[22px]' : 'text-[16px]')}>{r.title}</p><p className="mt-1 text-[13.5px] text-ink-3">{r.where} · {r.year}</p></div>
              </Reveal>
            ))}
            <Reveal delay={240}>
              <a href={SITE.linkedin} target="_blank" rel="noreferrer" className="card card-hover group flex h-full min-h-[220px] flex-col justify-between p-6" style={{ background: 'linear-gradient(150deg, color-mix(in oklab, #0a66c2 12%, transparent), transparent 70%)' }}>
                <span className="inline-flex h-12 w-12 items-center justify-center rounded-[12px] bg-[#0a66c2] text-white"><Icon name="LinkedinLogo" size={26} weight="fill" /></span>
                <span>
                  <span className="block text-[19px] font-semibold tracking-[-0.015em]">See more on LinkedIn</span>
                  <span className="mt-1.5 block text-[14px] leading-snug text-ink-3">Every award, event and team moment, as it happens.</span>
                  <span className="link mt-4 text-[14.5px]">Follow Deep Algorithms<Icon name="ArrowUpRight" size={14} weight="bold" /></span>
                </span>
              </a>
            </Reveal>
          </div>
          <Reveal className="mt-10"><CertStrip /></Reveal>
        </div>
      </section>

      <section className="stage sec overflow-hidden" aria-labelledby="life-h">
        <div className="wrap">
          <SectionHead align="left" id="life-h" eyebrow="The team" title="Life at Deep Algorithms." lead="At conferences, on stage and in the room where problems get solved." />
        </div>
        <TeamRoll />
      </section>

      <section id="careers" className="sec scroll-mt-20" aria-labelledby="car-h">
        <div className="wrap">
          <Reveal className="card overflow-hidden p-8 md:p-14">
            <div className="grid items-end gap-10 lg:grid-cols-[1.3fr_1fr]">
              <div>
                <p className="eyebrow">Careers</p>
                <h2 id="car-h" className="t-h2 mt-6">Build the defence attackers have to think about.</h2>
                <p className="t-lead mt-5">We are looking for AI engineers, security researchers and product builders. Tell us what you want to work on.</p>
              </div>
              <div className="flex flex-col items-start gap-3 lg:items-end">
                <Button href={`mailto:${SITE.careersEmail}`} size="lg" arrow>Write to {SITE.careersEmail}</Button>
                <p className="text-[14px] text-ink-3">Hyderabad · Bengaluru · Plano, Texas</p>
              </div>
            </div>
            <ul className="m-rail mt-12 grid gap-4 md:grid-cols-3">
              {TEAMS.map((t) => (
                <li key={t.name} className="flex flex-col rounded-[18px] border border-line p-6">
                  <Icon name={t.icon} size={24} className="text-cyan-2" />
                  <h3 className="mt-5 text-[19px] font-semibold tracking-[-0.015em]">{t.name}</h3>
                  <p className="mt-2 flex-1 text-[15px] leading-relaxed text-ink-2">{t.work}</p>
                  <a href={`mailto:${SITE.careersEmail}?subject=${encodeURIComponent(`Careers: ${t.name}`)}`} className="link mt-5 text-[14.5px]">Write to us about this<Icon name="ArrowRight" size={13} weight="bold" /></a>
                </li>
              ))}
            </ul>
          </Reveal>
        </div>
      </section>

      <section className="sec pt-0" aria-labelledby="off-h">
        <div className="wrap">
          <SectionHead align="left" id="off-h" eyebrow="Offices" title="Where to find us." />
          <div className="mt-12 grid gap-4 md:grid-cols-3">
            {SITE.offices.map((o, i) => (
              <Reveal key={o.city} delay={i * 70} className="card flex flex-col p-7">
                <p className="text-[12.5px] font-semibold uppercase tracking-[.1em] text-cyan-2">{o.label}</p>
                <p className="mt-3 text-[24px] font-semibold tracking-[-0.025em]">{o.city}</p>
                <p className="mt-3 flex-1 text-[15.5px] leading-relaxed text-ink-2">{o.address}</p>
                {o.map && <a href={o.map} target="_blank" rel="noreferrer" className="link mt-5 text-[14.5px]">Open in Maps<Icon name="ArrowUpRight" size={14} weight="bold" /></a>}
              </Reveal>
            ))}
          </div>
          <p className="mt-8 text-[15px] text-ink-2">Evaluating a product? <Link to="/request-demo" className="link">Talk to an engineer<Icon name="ArrowRight" size={13} weight="bold" /></Link></p>
        </div>
      </section>

      <LogoMarquee />
      <CtaBand title="See the difference on your own identities." />
    </>
  );
}
