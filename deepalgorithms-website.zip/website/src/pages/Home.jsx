import { Link } from 'react-router';
import { Seo } from '../lib/head.jsx';
import { SOLUTIONS } from '../data/site.js';
import { POSTS } from '../data/posts.js';
import { Button, Icon, Reveal, SectionHead, Eyebrow, cx } from '../components/ui.jsx';
import { LogoMarquee, CtaBand, FilmPlayer, PostCard, CertStrip } from '../components/blocks.jsx';
import FlowRibbons from '../components/FlowRibbons.jsx';
import BrandMoment from '../components/BrandMoment.jsx';
import Spotlight from '../components/Spotlight.jsx';
import ProductMark from '../components/ProductMark.jsx';
import { HeroActivity } from '../components/viz/home.jsx';
import PerimeterStory from '../components/PerimeterStory.jsx';
import { Explore } from '../components/ProductKit.jsx';

const WHY = [
  { icon: 'Lightning', h: 'Decisions before damage', p: 'Every product acts inline, before the action, the login or the payment completes. Not in a report the next morning.' },
  { icon: 'ChatCircleText', h: 'Every decision explained', p: 'Scores, blocks and holds come with the reasons in plain language, so analysts can act and auditors can follow.' },
  { icon: 'Cloud', h: 'Runs in your environment', p: 'Read-only connectors, an agentless AWS role and a gateway inside your VPC. Your data stays where it is.' },
  { icon: 'Scales', h: 'Built for Indian regulation', p: 'Evidence mapped to DPDPA 2023, RBI and SEBI expectations from the start, not bolted on for an audit.' },
];

const INDUSTRY_ICON = { bfsi: 'Bank', healthcare: 'FirstAidKit', government: 'Buildings', 'digital-platforms': 'Browsers' };
const INDUSTRY_LINE = { bfsi: 'Mule accounts, account takeover, RBI and DPDPA', healthcare: 'Who opened which patient record, and why', government: 'Portals that stay online under attack', 'digital-platforms': 'Bots at sign-up, keys in code, AI in the product' };

/* The headline types itself once, in CSS alone: every letter is in the HTML from
   the first paint (for search engines and anyone without JavaScript), each one
   appears on its own delay with a slightly uneven, human rhythm, and a caret
   follows the last letter typed. Screen readers get the sentence in one piece
   (aria-label), and the HTML carries it once.
   One line from tablet width up; on a phone it wraps rather than shrink. */
const HEADLINE = [['Identity security for ', ''], ['the AI era.', 'grad-text']];
const TYPED = (() => {
  let seed = 11, at = 280;
  const rnd = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
  const out = [];
  for (const [text, cls] of HEADLINE) for (const ch of text) { out.push({ ch, cls, at: Math.round(at) }); at += 34 + rnd() * 30 + (ch === ' ' ? 26 : 0); }
  return out.map((c, i) => ({ ...c, hold: (out[i + 1]?.at ?? c.at) - c.at }));
})();

function TypedHeadline() {
  return (
    <h1 className="t-hero tw mx-auto sm:whitespace-nowrap" aria-label={HEADLINE.map(([t]) => t).join('')}>
      <span aria-hidden="true">
        {TYPED.map((c, i) => (
          <span key={i} className={cx('tw-ch', c.cls, i === TYPED.length - 1 && 'tw-last')} style={{ '--at': `${c.at}ms`, '--hold': `${c.hold}ms` }}>{c.ch}</span>
        ))}
      </span>
    </h1>
  );
}

export default function Home() {
  return (
    <>
      <Seo path="/" description="Deep Algorithms builds security for every identity attackers target: people, machine identities and AI agents, and the fraud, bots and data misuse that follow. Built in India for regulated industries." />

      {/* hero: the promise, centred, then the live product beneath it, full width */}
      <section className="stage relative -mt-[72px] overflow-hidden pt-[72px]">
        <FlowRibbons preset="heroCenter" mobilePreset="heroMobile" fade={false} />
        <div className="hero-drift wrap relative pt-16 text-center md:pt-24">
          <TypedHeadline />
          <p className="rise mx-auto mt-7 max-w-[720px] text-[clamp(18px,1.4vw,21px)] leading-[1.55] text-ink-2" style={{ '--d': '900ms' }}>People, machine identities and AI agents now hold the keys to your business. We learn how each one behaves, and stop the one that is misused <span className="text-ink">before it becomes a breach.</span></p>
          <div className="rise mt-9 flex flex-wrap justify-center gap-3" style={{ '--d': '1100ms' }}>
            <Explore label="See how it works" target="#perimeter" />
            <Button href="#film" variant="ghost" size="lg"><Icon name="Play" size={15} weight="fill" />Watch the film · 1 min</Button>
          </div>
          <ul className="rise mt-9 flex flex-wrap items-center justify-center gap-x-6 gap-y-3" style={{ '--d': '1300ms' }} aria-label="Products">
            {[['zenstra', 'Zenstra AI', '/agentic-ai/agentic-identity'], ['adapid', 'adapID AI', '/adapid-ai'], ['botshield', 'BotShield AI', '/botshield-ai'], ['icms', 'ICMS', '/dpdpa-compliance']].map(([k, n, to]) => (
              <li key={k}><Link to={to} className="group inline-flex items-center gap-2 text-[14px] font-medium text-ink-2 transition-colors hover:text-ink"><ProductMark p={k} size={24} className="transition-transform duration-300 group-hover:scale-110" />{n}</Link></li>
            ))}
          </ul>
        </div>
        <div className="wrap relative mt-6 pb-10 md:mt-8 md:pb-16">
          <div className="mx-auto max-w-[1040px]"><HeroActivity tilt={[9, 0]} range={[2, 3]} pad="7% 10% 9% 10%" /></div>
        </div>
      </section>

      <LogoMarquee />

      {/* the problem */}
      <section id="perimeter" className="sec" aria-labelledby="perimeter-h">
        <div className="wrap">
          <SectionHead id="perimeter-h" eyebrow="The new perimeter" title="Attackers don’t break in anymore. They log in." lead="Most access in your company no longer belongs to a person. Keys, service accounts and AI agents hold it now, and that is where attacks begin." />
          <div className="mt-14 lg:mt-6"><PerimeterStory /></div>
        </div>
      </section>

      {/* the film: the problem in one sentence, then the minute that explains it */}
      <section id="film" className="stage sec scroll-mt-20" aria-labelledby="film-h">
        <div className="wrap">
          <SectionHead id="film-h" eyebrow="Watch · 1 minute" title="Your next breach will use a valid login." lead="A stolen session, a forgotten cloud key, an AI agent acting beyond its task. One minute on how Deep Algorithms catches each of them before it lands." />
          <Reveal up className="mx-auto mt-14 max-w-[1180px]"><FilmPlayer /></Reveal>
        </div>
      </section>

      <BrandMoment />

      {/* each product at work */}
      <section className="sec" aria-labelledby="spot-h">
        <div className="wrap">
          <SectionHead align="left" id="spot-h" eyebrow="In practice" title="Watch each product stop the attack it was built for." lead="One attack per product, stopped before it lands. Pick one, or let them play in turn." />
          <div className="mt-16"><Spotlight /></div>
        </div>
      </section>

      {/* why */}
      <section className="sec" aria-labelledby="why-h">
        <div className="wrap">
          <div className="grid gap-14 lg:grid-cols-[.9fr_1.1fr] lg:gap-20">
            <Reveal>
              <Eyebrow>Why Deep Algorithms</Eyebrow>
              <h2 id="why-h" className="t-h2 mt-6">Built for organisations that cannot afford a breach.</h2>
              <p className="t-lead mt-6">Banks, public-sector teams and hospitals use our products where a single misused identity is a reportable event.</p>
              <div className="mt-9 flex flex-wrap gap-3"><Button to="/platform" variant="ghost" arrow>Why Deep Algorithms</Button></div>
              <div className="card mt-10 flex items-center gap-5 p-5">
                <img src="/img/events/dsci-excellence.webp" alt="" className="h-16 w-24 shrink-0 rounded-[10px] object-cover" loading="lazy" />
                <span><span className="block text-[15.5px] font-semibold">Cybersecurity Excellence, 2025</span><span className="block text-[14px] text-ink-3">Data Security Council of India</span></span>
              </div>
            </Reveal>
            <div className="m-rail grid gap-5 sm:grid-cols-2">
              {WHY.map((w, i) => (
                <Reveal key={w.h} delay={i * 70} className="card p-6 md:p-7">
                  <span className="inline-flex h-11 w-11 items-center justify-center rounded-[12px] border border-line-2 text-cyan-2"><Icon name={w.icon} size={22} /></span>
                  <h3 className="t-h3 mt-5">{w.h}</h3>
                  <p className="mt-2 text-[15.5px] leading-relaxed text-ink-2">{w.p}</p>
                </Reveal>
              ))}
            </div>
          </div>
          <Reveal className="mt-16"><CertStrip /></Reveal>
        </div>
      </section>

      {/* industries */}
      <section className="sec" aria-labelledby="ind-h">
        <div className="wrap">
          <SectionHead id="ind-h" eyebrow="Industries" title="Where a misused identity costs the most." />
          <div className="m-rail mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {SOLUTIONS.map((s, i) => (
              <Reveal key={s.slug} delay={i * 70}>
                <Link to={`/solutions/${s.slug}`} className="card card-hover group flex h-full flex-col p-6">
                  <span className="inline-flex h-12 w-12 items-center justify-center rounded-[14px] bg-cyan/10 text-cyan-2"><Icon name={INDUSTRY_ICON[s.slug]} size={24} /></span>
                  <h3 className="t-h3 mt-6">{s.name}</h3>
                  <p className="mt-2 flex-1 text-[15px] leading-relaxed text-ink-2">{INDUSTRY_LINE[s.slug]}</p>
                  <span className="link mt-6 text-[14.5px]">See how<Icon name="ArrowRight" size={14} weight="bold" /></span>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* research */}
      <section className="sec" aria-labelledby="res-h">
        <div className="wrap">
          <div className="flex flex-wrap items-end justify-between gap-6">
            <SectionHead align="left" id="res-h" eyebrow="Research" title="What attackers are doing now, and what stops them." />
            <Link to="/blogs" className="link">All research<Icon name="ArrowRight" size={14} weight="bold" /></Link>
          </div>
          <div className="m-rail mt-12 grid gap-10 md:grid-cols-3">{POSTS.slice(0, 3).map((p, i) => <Reveal key={p.slug} delay={i * 80}><PostCard post={p} /></Reveal>)}</div>
        </div>
      </section>

      <CtaBand />
    </>
  );
}
