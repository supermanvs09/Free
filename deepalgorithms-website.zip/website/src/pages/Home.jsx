import { useState } from 'react';
import { Link } from 'react-router';
import { Seo } from '../lib/head.jsx';
import { SOLUTIONS, CUSTOMERS, CERTS, DEPLOY } from '../data/site.js';
import { PRODUCT_MENU } from '../data/nav.js';
import { POSTS } from '../data/posts.js';
import { Button, CountUp, Icon, Reveal, SectionHead, Eyebrow, cx } from '../components/ui.jsx';
import { CtaBand, FilmPlayer, PostCard } from '../components/blocks.jsx';
import ProductMark from '../components/ProductMark.jsx';
import { HeroActivity } from '../components/viz/home.jsx';
import { Logo, logoTitle } from '../components/viz/kit.jsx';
import PerimeterStory from '../components/PerimeterStory.jsx';
import LogoOrbit from '../components/LogoOrbit.jsx';
import { Explore, Faq } from '../components/ProductKit.jsx';
import { LogoRoll } from '../components/blocks.jsx';

/* The home page reads the way a security buyer scans a vendor: what it is,
   who trusts it, what the platform covers, why it matters now, how it works,
   who it is for, how it deploys, and the questions people ask before a call. */

const HERO_LOGOS = ['meity', 'canara-bank', 'karnataka-bank', 'dcb-bank', 'ncrtc', 'iit-kanpur', 'iiit-hyderabad'];
const LOGO_NAME = Object.fromEntries(CUSTOMERS);

/* one line per product: what it does, in the buyer's words */
const PITCH = {
  adapid: 'Scores every login and every key, and stops the identity that starts behaving differently.',
  zenstra: 'Checks every AI agent action against its task before it runs, and records each decision.',
  botshield: 'Proves which exposures are real, patches them, and stops bots and floods at the edge.',
  icms: 'Turns every access to personal data into DPDPA evidence, ready before the auditor asks.',
};

const SHARED = [
  { icon: 'Lightning', h: 'Decides before damage', p: 'Inline, before the action, login, payment or request completes.' },
  { icon: 'ChatCircleText', h: 'Explains every decision', p: 'Reasons in plain language that analysts and auditors can follow.' },
  { icon: 'Cloud', h: 'Runs where your data is', p: 'Read-only connectors, agentless roles and a gateway in your VPC.' },
  { icon: 'Scales', h: 'Built for Indian regulation', p: 'Evidence mapped to DPDPA 2023, RBI and SEBI from the start.' },
];

/* Why now, the way established vendors set it: a verdict, the number, what it
   means, where it comes from, and what we do about it. Every figure is sourced. */
const WHY_NOW = [
  { verdict: 'Outnumbered.', v: '82:1', l: 'machine identities for every person in the average organisation. Most were created by a deploy, not by a decision.', s: 'CyberArk Identity Security Landscape, 2025', to: '/adapid-ai/nhi-security', cta: 'How adapID finds every one' },
  { verdict: 'Costlier than ever.', v: '₹25.5 Cr', l: 'average cost of a data breach in India in 2026, up 16% in a year and the highest on record.', s: 'IBM Cost of a Data Breach Report, 2026', to: '/adapid-ai', cta: 'How we stop it before it lands' },
  { verdict: 'On the clock.', v: '72 hrs', l: 'to report a personal data breach in full to the Data Protection Board, with the facts to back it.', s: 'DPDP Rules, 2025', to: '/dpdpa-compliance', cta: 'How ICMS gets you ready' },
];

/* who uses what: the same platform, read by the people who buy and run it */
const ROLES = [
  {
    id: 'ciso', tab: 'CISO', h: 'One view of identity risk, and evidence the board can read.',
    p: 'See people, machine identities and AI agents in one place, ranked by risk, with every decision explained. Report on what was stopped, not on how many alerts fired.',
    points: ['Risk across every identity, ranked', 'Decisions with reasons, ready for the board and regulators', 'One vendor for identity, agents, bots and DPDPA'],
    products: ['adapid', 'zenstra', 'botshield', 'icms'], to: '/platform', cta: 'Why Deep Algorithms',
  },
  {
    id: 'soc', tab: 'Security operations', h: 'Fewer alerts, each with a reason and an action already taken.',
    p: 'Risk scores come with the evidence behind them. High risk is held or blocked by policy in seconds, so analysts confirm a decision instead of starting an investigation.',
    points: ['Scores with the signals that raised them', 'Step-up, hold or block by policy, in seconds', 'Every agent action recorded with its task and outcome'],
    products: ['adapid', 'zenstra'], to: '/adapid-ai', cta: 'See adapID AI',
  },
  {
    id: 'iam', tab: 'Identity and cloud', h: 'Every role, key and service account, with what it can reach and what it uses.',
    p: 'adapID finds machine identities across your AWS accounts, compares 90 days of activity with what each one is allowed, and maps the paths through Active Directory to Domain Admins.',
    points: ['Unused access found and ready to remove', 'Leaked secrets in GitHub and CodeCommit triaged', 'Active Directory attack paths closed before they are taken'],
    products: ['adapid'], to: '/adapid-ai/nhi-security', cta: 'See NHI Security for AWS',
  },
  {
    id: 'dpo', tab: 'Compliance and DPO', h: 'DPDPA evidence generated as data is used, not assembled before an audit.',
    p: 'ICMS finds personal data, checks each access against its purpose and consent, and keeps the record. When a breach happens, the 72-hour report starts with the facts already in hand.',
    points: ['Personal data discovered across your stores', 'Access checked against purpose and consent', 'Audit package for DPDPA, RBI and SEBI in minutes'],
    products: ['icms'], to: '/dpdpa-compliance', cta: 'See ICMS',
  },
  {
    id: 'fraud', tab: 'Fraud and digital banking', h: 'Account takeover, scams and mule accounts stopped at login and payment.',
    p: 'Behavioural signals, device security and transaction intelligence score every session and payment in under 80 ms, and BotShield stops automated attacks before they reach the login page.',
    points: ['Risk decision at every event in under 80 ms', 'Mule accounts and payment scams flagged with reasons', 'Bots stopped by intent, without puzzles for customers'],
    products: ['adapid', 'botshield'], to: '/adapid-ai/fraud-prevention', cta: 'See Identity Fraud Prevention',
  },
];

const CONNECT = ['okta', 'entra', 'ad', 'm365', 'google', 'aws', 'github', 'atlassian', 'salesforce', 'slack'];

const FAQ = [
  { title: 'What does Deep Algorithms do?', body: 'We secure the identities attackers use to get in: people, machine identities such as keys and service accounts, and AI agents. Four products cover them: adapID AI for human and machine identities and fraud, Zenstra AI for AI agents, BotShield AI for exposure, bots and DDoS, and ICMS for DPDPA compliance.' },
  { title: 'Which product should we start with?', body: 'Start with the risk that costs you most today. Each product runs on its own and adds to the others when you add it. Agents acting on your systems: Zenstra. Logins, cloud keys or fraud: adapID. Public apps, bots or DDoS: BotShield. Personal data and DPDPA: ICMS.' },
  { title: 'Do we have to move our data?', body: 'No. adapID uses read-only connectors and one read-only role per AWS account, Zenstra runs as a gateway inside your VPC, BotShield works inline at the edge without diverting traffic, and ICMS connects to the stores that already hold personal data.' },
  { title: 'Which certifications do you hold?', body: 'ISO/IEC 27001, SOC 2 Type II, ISO/IEC 42001 for AI management and ISO/IEC 27701 for privacy. Compliance documentation is available on request from the Trust center.' },
  { title: 'Do you map to Indian regulation?', body: 'Yes. Evidence is mapped to the DPDP Act 2023 and the DPDP Rules 2025, and to RBI and SEBI expectations, from the start rather than added for an audit.' },
  { title: 'What happens in a demo?', body: 'A 30-minute session with a Deep Algorithms engineer, on your own environment where you want it, with your own questions. For AWS, you can connect a sandbox account with a read-only role and walk through the results together.' },
];

const INDUSTRY_ICON = { bfsi: 'Bank', healthcare: 'FirstAidKit', government: 'Buildings', 'digital-platforms': 'Browsers' };
const INDUSTRY_LINE = { bfsi: 'Mule accounts, account takeover, RBI and DPDPA', healthcare: 'Who opened which patient record, and why', government: 'Portals that stay online under attack', 'digital-platforms': 'Bots at sign-up, keys in code, AI in the product' };

function WhyNow() {
  return (
    <section className="stage band-brand sec relative overflow-hidden" aria-labelledby="now-h">
      <div aria-hidden="true" className="absolute inset-0 opacity-60" style={{ backgroundImage: 'linear-gradient(rgb(255 255 255 / .05) 1px, transparent 1px), linear-gradient(90deg, rgb(255 255 255 / .05) 1px, transparent 1px)', backgroundSize: '64px 64px', maskImage: 'radial-gradient(70% 70% at 50% 40%, #000, transparent)', WebkitMaskImage: 'radial-gradient(70% 70% at 50% 40%, #000, transparent)' }} />
      <div className="wrap relative">
        <SectionHead id="now-h" eyebrow="Why identity, why now" title="Identity is now the easiest way in, and the most expensive to get wrong." lead="Three numbers boards and regulators are asking about, and what we do about each." />
        <div className="mt-14 grid gap-px overflow-hidden rounded-[16px] border border-line bg-line md:grid-cols-3">
          {WHY_NOW.map((n, i) => (
            <Reveal key={n.v} delay={i * 90} className="flex flex-col bg-[#05214a]/90 p-7 max-md:items-center max-md:text-center md:p-9">
              <p className="text-[18px] font-semibold tracking-[-0.01em] text-cyan-2">{n.verdict}</p>
              <p className="mt-5 font-semibold tracking-[-0.04em] text-white" style={{ fontSize: 'clamp(48px, 5vw, 72px)', lineHeight: 1 }}><CountUp value={n.v} /></p>
              <p className="mt-5 max-w-[320px] flex-1 text-[16px] leading-relaxed text-ink-2">{n.l}</p>
              <p className="mt-6 w-full border-t border-line pt-4 text-[12.5px] text-ink-3">Source: {n.s}</p>
              <Link to={n.to} className="link mt-4 text-[14.5px]">{n.cta}<Icon name="ArrowRight" size={14} weight="bold" /></Link>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* Phones: the four products as an accordion, the first one open, so the page
   stays short and each product is one tap from its detail. */
function PlatformAccordion() {
  return (
    <div className="mt-10 overflow-hidden rounded-[16px] border border-line bg-bg-1 md:hidden">
      {PRODUCT_MENU.map((l, i) => (
        <details key={l.key} open={i === 0} className="acc group border-b border-line last:border-0" style={{ '--acc': l.acc }}>
          <summary className="flex cursor-pointer list-none items-center gap-3.5 p-4 [&::-webkit-details-marker]:hidden">
            <ProductMark p={l.key} size={36} />
            <span className="min-w-0 flex-1">
              <span className="block text-[16.5px] font-semibold">{l.name}</span>
              <span className="block truncate text-[13px] text-ink-3">{l.blurb.replace(/, in one platform$/, '')}</span>
            </span>
            <Icon name="CaretDown" size={16} className="shrink-0 text-ink-3 transition-transform duration-300 group-open:rotate-180" />
          </summary>
          <div className="px-4 pb-5">
            <p className="text-[15px] leading-relaxed text-ink-2">{PITCH[l.key]}</p>
            <ul className="mt-3">
              {l.items.slice(0, 3).map((m) => (
                <li key={m.name}><Link to={m.path} className="flex items-center gap-2.5 py-2 text-[15px] text-ink"><Icon name="CheckCircle" size={17} weight="fill" style={{ color: l.acc }} />{m.name}</Link></li>
              ))}
            </ul>
            <Link to={l.path} className="link mt-3 text-[15px]">Explore {l.name}<Icon name="ArrowRight" size={14} weight="bold" /></Link>
          </div>
        </details>
      ))}
    </div>
  );
}

function Roles() {
  const [on, setOn] = useState(0);
  const R = ROLES[on];
  const key = (e) => {
    const d = e.key === 'ArrowRight' ? 1 : e.key === 'ArrowLeft' ? -1 : 0;
    if (!d) return;
    e.preventDefault();
    const n = (on + d + ROLES.length) % ROLES.length;
    setOn(n);
    document.getElementById(`role-${ROLES[n].id}`)?.focus();
  };
  return (
    <div className="mt-12">
      <div role="tablist" aria-label="Roles" className="no-scrollbar -mx-5 flex gap-2 overflow-x-auto px-5 md:mx-0 md:px-0" onKeyDown={key}>
        {ROLES.map((r, i) => (
          <button key={r.id} id={`role-${r.id}`} type="button" role="tab" aria-selected={i === on} aria-controls="role-panel" tabIndex={i === on ? 0 : -1} onClick={() => setOn(i)}
            className={cx('shrink-0 rounded-full border px-4 py-2.5 text-[15px] font-medium transition-colors', i === on ? 'border-transparent bg-fg text-bg' : 'border-line-2 text-ink-2 hover:text-ink')}>
            {r.tab}
          </button>
        ))}
      </div>
      <div id="role-panel" role="tabpanel" aria-labelledby={`role-${R.id}`} key={R.id} className="fadein mt-6 grid gap-8 rounded-[16px] border border-line bg-bg-1 p-6 md:p-9 lg:grid-cols-[1.15fr_.85fr] lg:gap-14">
        <div>
          <h3 className="text-[clamp(22px,2vw,28px)] font-semibold leading-tight tracking-[-0.02em]">{R.h}</h3>
          <p className="mt-4 max-w-[60ch] text-[16.5px] leading-relaxed text-ink-2">{R.p}</p>
          <Link to={R.to} className="link mt-6 text-[15px]">{R.cta}<Icon name="ArrowRight" size={14} weight="bold" /></Link>
        </div>
        <div className="lg:border-l lg:border-line lg:pl-12">
          <ul className="space-y-3">
            {R.points.map((x) => (
              <li key={x} className="flex gap-3 text-[15.5px] leading-snug text-ink">
                <Icon name="CheckCircle" size={20} weight="fill" className="mt-px shrink-0 text-cyan-2" />{x}
              </li>
            ))}
          </ul>
          <p className="mt-7 text-[12.5px] font-semibold uppercase tracking-[.1em] text-ink-3">Products</p>
          <div className="mt-3 flex flex-wrap gap-2">
            {R.products.map((k) => {
              const l = PRODUCT_MENU.find((m) => m.key === k);
              return <Link key={k} to={l.path} className="inline-flex items-center gap-2 rounded-full border border-line-2 py-1.5 pl-1.5 pr-3.5 text-[14px] font-medium text-ink-2 hover:text-ink"><ProductMark p={k} size={24} />{l.name}</Link>;
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Home() {
  return (
    <>
      <Seo path="/" description="Deep Algorithms is an identity security platform for people, machine identities and AI agents: four products that stop identity attacks, fraud, bots and data misuse before they become a breach. ISO 27001, SOC 2 Type II. Built in India for regulated industries." />

      {/* hero: what we are, proof, and the product, in one view */}
      <section className="stage band-brand hero-under relative overflow-hidden" aria-labelledby="hero-h">
        <div className="wrap relative grid items-center gap-12 pb-12 pt-10 md:pt-16 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.08fr)] lg:gap-10 lg:pb-16 lg:pt-20">
          <div className="max-w-[600px] max-md:mx-auto max-md:text-center">
            <Eyebrow className="rise">Identity security for the AI era</Eyebrow>
            <h1 id="hero-h" className="t-hero rise mt-6" style={{ '--d': '60ms' }}>Secure every identity: people, machines and AI agents.</h1>
            <p className="t-lead rise mt-6 max-w-[540px] max-md:mx-auto" style={{ '--d': '120ms' }}>Deep Algorithms learns how every person, machine identity and AI agent behaves, and stops the one that is misused before it becomes a breach.</p>
            <div className="rise mt-9 flex flex-wrap gap-3 max-md:flex-col max-md:[&>*]:w-full" style={{ '--d': '180ms' }}>
              <Explore label="See the platform" target="#orbit" />
              <Button href="#film" variant="ghost" size="lg"><Icon name="Play" size={15} weight="fill" />Watch the film · 1 min</Button>
            </div>
            <ul className="rise mt-9 flex flex-wrap gap-2 max-md:justify-center" style={{ '--d': '240ms' }} aria-label="Certifications">
              {CERTS.map((c) => <li key={c.code} className="badge-cert"><Icon name="SealCheck" size={15} />{c.name}</li>)}
            </ul>
          </div>
          <div className="film-light rise relative lg:-mr-8" style={{ '--d': '200ms' }}>
            <HeroActivity tilt={[5, -9]} range={[2, 3]} pad="6% 4% 9% 6%" />
          </div>
        </div>
        <div className="border-t border-line">
          <div className="wrap flex flex-col gap-5 py-7 lg:flex-row lg:items-center lg:gap-12">
            <p className="shrink-0 text-[14px] leading-snug text-ink-3 max-lg:text-center lg:w-[210px]">Trusted by banks, government and enterprises across India</p>
            <ul className="grid flex-1 grid-cols-7 items-center gap-x-8 max-lg:hidden">
              {HERO_LOGOS.map((k) => <li key={k} className="flex justify-center"><img src={`/img/logos/${k}-white.webp`} alt={LOGO_NAME[k]} loading="eager" decoding="async" className="h-9 w-auto max-w-[118px] object-contain opacity-85" /></li>)}
            </ul>
            <LogoRoll keys={HERO_LOGOS} className="lg:hidden" />
          </div>
        </div>
      </section>

      <WhyNow />

      {/* the logo moment: our mark opens into the plate with our line, folds back, and the identity orbit opens out of it, then the four products */}
      <section id="orbit" className="sec scroll-mt-20" aria-labelledby="orbit-h">
        <div className="wrap">
          <SectionHead id="orbit-h" eyebrow="How it works" title="People, machines and AI agents, secured from one centre." />
          <div className="mt-10"><LogoOrbit /></div>
        </div>
      </section>

      {/* the platform: four products, one standard */}
      <section id="platform" className="sec scroll-mt-20" aria-labelledby="platform-h">
        <div className="wrap">
          <SectionHead align="left" id="platform-h" eyebrow="The platform" title="One platform. Four products. Every identity that can log in." lead="Start with the risk that costs you most today. Each product runs on its own, deploys where your data already is, and explains every decision it makes." />
          <PlatformAccordion />
          <div className="mt-12 grid gap-4 max-md:hidden md:grid-cols-2 xl:grid-cols-4">
            {PRODUCT_MENU.map((l, i) => (
              <Reveal key={l.key} delay={i * 60} className="card flex flex-col p-6" style={{ '--acc': l.acc }}>
                <ProductMark p={l.key} size={44} />
                <h3 className="mt-5 text-[20px] font-semibold tracking-[-0.015em]">{l.name}</h3>
                <p className="mt-1 text-[12.5px] font-semibold uppercase tracking-[.09em] text-ink-3">{l.blurb.replace(/, in one platform$/, '')}</p>
                <p className="mt-4 text-[15px] leading-relaxed text-ink-2">{PITCH[l.key]}</p>
                <ul className="mt-5 flex-1 border-t border-line">
                  {l.items.slice(0, 3).map((m) => (
                    <li key={m.name} className="border-b border-line">
                      <Link to={m.path} className="flex items-center gap-2.5 py-2.5 text-[14.5px] text-ink hover:text-cyan-2">
                        <svg width="14" height="14" viewBox="0 0 14 14" aria-hidden="true" className="shrink-0" style={{ color: l.acc }}><path d="m3 7.3 2.6 2.5L11 4.3" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" /></svg>
                        {m.name}
                      </Link>
                    </li>
                  ))}
                </ul>
                <Link to={l.path} className="link mt-5 text-[14.5px]">Explore {l.name}<Icon name="ArrowRight" size={14} weight="bold" /></Link>
              </Reveal>
            ))}
          </div>
          <Reveal className="mt-6 grid gap-px overflow-hidden rounded-[16px] border border-line bg-line sm:grid-cols-2 xl:grid-cols-4">
            {SHARED.map((w) => (
              <div key={w.h} className="flex gap-4 bg-bg-1 p-5">
                <Icon name={w.icon} size={22} className="mt-0.5 shrink-0 text-cyan-2" />
                <span><span className="block text-[15px] font-semibold">{w.h}</span><span className="mt-1 block text-[14px] leading-snug text-ink-3">{w.p}</span></span>
              </div>
            ))}
          </Reveal>
        </div>
      </section>


      {/* how attacks begin now: the three identities, told one at a time */}
      <section id="perimeter" className="sec scroll-mt-20" aria-labelledby="perimeter-h">
        <div className="wrap">
          <SectionHead align="left" id="perimeter-h" eyebrow="Where attacks begin now" title="Attackers don’t break in anymore. They log in." lead="Most access in your company no longer belongs to a person. Keys, service accounts and AI agents hold it now, and that is where attacks begin." />
          <div className="mt-14 lg:mt-6"><PerimeterStory /></div>
        </div>
      </section>

      {/* the film */}
      <section id="film" className="stage sec scroll-mt-20" aria-labelledby="film-h">
        <div className="wrap">
          <SectionHead id="film-h" eyebrow="Watch · 1 minute" title="See the platform in one minute." lead="Three identities attackers use, and how each Deep Algorithms product stops them before the damage is done." />
          <Reveal up className="mx-auto mt-14 max-w-[1180px]"><FilmPlayer /></Reveal>
        </div>
      </section>

      {/* who it is for */}
      <section className="sec" aria-labelledby="roles-h">
        <div className="wrap">
          <SectionHead align="left" id="roles-h" eyebrow="By role" title="Built for the people who answer for a breach." lead="The same platform, seen by the teams who buy it, run it and report on it." />
          <Roles />
        </div>
      </section>

      {/* industries */}
      <section className="sec pt-0" aria-labelledby="ind-h">
        <div className="wrap">
          <div className="flex flex-wrap items-end justify-between gap-6">
            <SectionHead align="left" id="ind-h" eyebrow="By industry" title="Where a misused identity costs the most." />
            <Link to="/products" className="link">Compare all products<Icon name="ArrowRight" size={14} weight="bold" /></Link>
          </div>
          <div className="m-rail mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {SOLUTIONS.map((s, i) => (
              <Reveal key={s.slug} delay={i * 60}>
                <Link to={`/solutions/${s.slug}`} className="card card-hover group flex h-full flex-col p-6">
                  <span className="inline-flex h-11 w-11 items-center justify-center rounded-[12px] bg-cyan/10 text-cyan-2"><Icon name={INDUSTRY_ICON[s.slug]} size={22} /></span>
                  <h3 className="t-h3 mt-5">{s.name}</h3>
                  <p className="mt-2 flex-1 text-[15px] leading-relaxed text-ink-2">{INDUSTRY_LINE[s.slug]}</p>
                  <span className="link mt-6 text-[14.5px]">See how<Icon name="ArrowRight" size={14} weight="bold" /></span>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* deployment, connectors and trust */}
      <section className="sec alt" aria-labelledby="dep-h">
        <div className="wrap">
          <div className="grid gap-12 lg:grid-cols-[.85fr_1.15fr] lg:gap-16">
            <Reveal>
              <Eyebrow>Deployment and trust</Eyebrow>
              <h2 id="dep-h" className="t-h2 mt-6">Deployed where the risk is. Your data stays put.</h2>
              <p className="t-lead mt-5">No product asks you to move your data or rewrite your applications. Every one is certified, and every decision it makes can be explained to an auditor.</p>
              <div className="mt-8 flex items-center gap-5 rounded-[16px] border border-line bg-bg-1 p-5">
                <img src="/img/events/dsci-excellence.webp" alt="" className="h-14 w-20 shrink-0 rounded-[10px] object-cover" loading="lazy" />
                <span><span className="block text-[15.5px] font-semibold">Cybersecurity Excellence, 2025</span><span className="block text-[14px] text-ink-3">Data Security Council of India</span></span>
              </div>
              <Link to="/trust" className="link mt-7 text-[15px]">Visit the Trust center<Icon name="ArrowRight" size={14} weight="bold" /></Link>
            </Reveal>
            <Reveal delay={80}>
              <ul className="divide-y divide-line overflow-hidden rounded-[16px] border border-line bg-bg-1">
                {DEPLOY.map(([n, , t]) => (
                  <li key={n} className="grid gap-2 p-5 md:grid-cols-[210px_1fr] md:gap-6">
                    <span className="flex items-center gap-2.5 text-[15.5px] font-semibold"><ProductMark p={n} size={28} />{n}</span>
                    <span className="text-[15px] leading-relaxed text-ink-2">{t}</span>
                  </li>
                ))}
              </ul>
              <ul className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-4">
                {CERTS.map((c) => (
                  <li key={c.code} className="rounded-[14px] border border-line bg-bg-1 p-4">
                    <Icon name="SealCheck" size={20} className="text-cyan-2" />
                    <span className="mt-2 block text-[14.5px] font-semibold">{c.name}</span>
                    <span className="block text-[12.5px] leading-snug text-ink-3">{c.desc}</span>
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>
          <Reveal className="mt-16 border-t border-line pt-10">
            <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:gap-12">
              <div className="lg:w-[300px] lg:shrink-0">
                <p className="text-[16px] font-semibold">Connects to the systems you already run</p>
                <p className="mt-1 text-[14px] leading-snug text-ink-3">Read-only, through each provider’s own API. adapID connects to these identity sources today.</p>
              </div>
              <ul className="grid flex-1 grid-cols-2 gap-2 sm:grid-cols-5">
                {CONNECT.map((k) => (
                  <li key={k} className="flex items-center gap-2.5 rounded-[12px] border border-line bg-bg-1 px-3 py-2.5 text-[14px] font-medium text-ink-2">
                    <Logo k={k} size="1.25em" />{logoTitle(k)}
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>
        </div>
      </section>

      {/* research */}
      <section className="sec" aria-labelledby="res-h">
        <div className="wrap">
          <div className="flex flex-wrap items-end justify-between gap-6">
            <SectionHead align="left" id="res-h" eyebrow="Resources" title="What attackers are doing now, and what stops them." />
            <Link to="/blogs" className="link">All research<Icon name="ArrowRight" size={14} weight="bold" /></Link>
          </div>
          <div className="m-rail mt-12 grid gap-10 md:grid-cols-3">{POSTS.slice(0, 3).map((p, i) => <Reveal key={p.slug} delay={i * 80}><PostCard post={p} /></Reveal>)}</div>
        </div>
      </section>

      <div className="alt"><Faq items={FAQ} title="What teams ask before a first call" /></div>

      <CtaBand />
    </>
  );
}
