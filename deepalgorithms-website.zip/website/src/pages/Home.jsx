import { Link } from 'react-router';
import { Seo } from '../lib/head.jsx';
import { SOLUTIONS } from '../data/site.js';
import { POSTS } from '../data/posts.js';
import { Button, Icon, Reveal, SectionHead, Eyebrow } from '../components/ui.jsx';
import { LogoMarquee, CtaBand, FilmPlayer, PostCard, CertStrip } from '../components/blocks.jsx';
import FlowRibbons from '../components/FlowRibbons.jsx';
import BrandMoment from '../components/BrandMoment.jsx';
import Spotlight from '../components/Spotlight.jsx';
import { HeroActivity, AgentOverreach, KeySprawl, LegitLogin } from '../components/viz/home.jsx';

const PROBLEMS = [
  { V: AgentOverreach, kicker: 'AI agents', title: 'Agents act with access nobody reviewed', body: 'Copilots and agents read data, call tools and move money. One request can reach far beyond the task it was given.' },
  { V: KeySprawl, kicker: 'Machine identities', title: 'Keys outnumber people, and nobody owns them', body: 'Service accounts, roles and keys multiply with every deploy. Most are never rotated, and many have no owner.' },
  { V: LegitLogin, kicker: 'People', title: 'A stolen login looks like a normal one', body: 'Attackers sign in rather than break in. MFA passes, rules stay quiet, and only behaviour gives them away.' },
];

const WHY = [
  { icon: 'Lightning', h: 'Decisions before damage', p: 'Every product acts inline, before the action, the login or the payment completes. Not in a report the next morning.' },
  { icon: 'ChatCircleText', h: 'Every decision explained', p: 'Scores, blocks and holds come with the reasons in plain language, so analysts can act and auditors can follow.' },
  { icon: 'Cloud', h: 'Runs in your environment', p: 'Read-only connectors, an agentless AWS role and a gateway inside your VPC. Your data stays where it is.' },
  { icon: 'Scales', h: 'Built for Indian regulation', p: 'Evidence mapped to DPDPA 2023, RBI and SEBI expectations from the start, not bolted on for an audit.' },
];

const INDUSTRY_ICON = { bfsi: 'Bank', healthcare: 'FirstAidKit', government: 'Buildings', 'digital-platforms': 'Browsers' };
const INDUSTRY_LINE = { bfsi: 'Mule accounts, account takeover, RBI and DPDPA', healthcare: 'Who opened which patient record, and why', government: 'Portals that stay online under attack', 'digital-platforms': 'Bots at sign-up, keys in code, AI in the product' };

export default function Home() {
  return (
    <>
      <Seo path="/" description="Deep Algorithms builds security for every identity attackers target: people, machine identities and AI agents, and the fraud, bots and data misuse that follow. Built in India for regulated industries." />

      {/* hero: light ribbons behind, the live product in perspective */}
      <section className="relative -mt-[72px] overflow-hidden pt-[72px]">
        <FlowRibbons preset="hero" mobilePreset="heroMobile" />
        <div aria-hidden="true" className="pointer-events-none absolute inset-0" style={{ background: 'linear-gradient(90deg, rgb(4 6 11 / .75) 0%, rgb(4 6 11 / .35) 38%, transparent 60%)' }} />
        <div className="wrap relative grid min-h-[min(100svh,980px)] items-center gap-12 pb-16 pt-14 lg:grid-cols-[1fr_1.12fr] lg:gap-6 lg:pb-24 lg:pt-10">
          <div className="max-w-[640px]">
            <p className="eyebrow rise">Identity security for the AI era</p>
            <h1 className="t-hero rise mt-7" style={{ '--d': '80ms' }}>Every login, key and AI agent. <span className="grad-text">Secured before it acts.</span></h1>
            <p className="t-lead rise mt-7 max-w-[540px]" style={{ '--d': '160ms' }}>Deep Algorithms builds security for the identities attackers now target: people, machine identities and AI agents, and the fraud, bots and data misuse that follow them.</p>
            <div className="rise mt-10 flex flex-wrap gap-3" style={{ '--d': '240ms' }}>
              <Button to="/request-demo" size="lg" arrow>Book a demo</Button>
              <Button href="#film" variant="ghost" size="lg"><Icon name="Play" size={15} weight="fill" />Watch the film · 1 min</Button>
            </div>
            <p className="rise mt-8 text-[14px] text-ink-3" style={{ '--d': '320ms' }}>ISO 27001 · SOC 2 Type II · ISO 42001 · ISO 27701</p>
          </div>
          <div className="relative lg:-mr-10"><HeroActivity /></div>
        </div>
      </section>

      <LogoMarquee />

      {/* the problem */}
      <section className="sec" aria-labelledby="perimeter-h">
        <div className="wrap">
          <SectionHead id="perimeter-h" eyebrow="The new perimeter" title="Attackers don’t break in anymore. They log in." lead="Most access in your company no longer belongs to a person. Keys, service accounts and AI agents hold it now, and that is where attacks begin." />
          <div className="mt-16 grid gap-6 lg:grid-cols-3">
            {PROBLEMS.map(({ V, kicker, title, body }, i) => (
              <Reveal key={title} delay={i * 90} className="card flex flex-col p-5 md:p-6">
                <div className="-mx-1"><V /></div>
                <p className="kicker mt-6">{kicker}</p>
                <h3 className="t-h3 mt-2">{title}</h3>
                <p className="mt-2 text-[15.5px] leading-relaxed text-ink-2">{body}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* the film: the problem in one sentence, then the minute that explains it */}
      <section id="film" className="sec scroll-mt-20" aria-labelledby="film-h">
        <div className="wrap">
          <SectionHead id="film-h" eyebrow="Watch · 1 minute" title="Most access in your company no longer belongs to a person." lead="Keys, service accounts and AI agents hold it now, and attackers know it. See how Deep Algorithms finds every one of them and stops misuse before it lands." />
          <Reveal up className="mx-auto mt-14 max-w-[1180px]"><FilmPlayer /></Reveal>
        </div>
      </section>

      <BrandMoment />

      {/* each product at work */}
      <section className="sec" aria-labelledby="spot-h">
        <div className="wrap">
          <SectionHead align="left" id="spot-h" eyebrow="In practice" title="See each product stop the attack it was built for." lead="Four products, four different problems. Pick one, or watch them in turn." />
          <div className="mt-16"><Spotlight /></div>
        </div>
      </section>

      {/* why */}
      <section className="sec" aria-labelledby="why-h">
        <div className="wrap">
          <div className="grid gap-14 lg:grid-cols-[.9fr_1.1fr] lg:gap-20">
            <Reveal>
              <Eyebrow>Why Deep Algorithms</Eyebrow>
              <h2 id="why-h" className="t-h2 mt-6">Built for organisations that cannot afford a breach.</h2>
              <p className="t-lead mt-6">Banks, public-sector teams and hospitals use our products where a single misused identity is a reportable event.</p>
              <div className="mt-9 flex flex-wrap gap-3"><Button to="/platform" variant="ghost" arrow>Why Deep Algorithms</Button></div>
              <div className="card mt-10 flex items-center gap-5 p-5">
                <img src="/img/events/dsci-excellence.webp" alt="" className="h-16 w-24 shrink-0 rounded-[10px] object-cover" loading="lazy" />
                <span><span className="block text-[15.5px] font-semibold">Cybersecurity Excellence, 2025</span><span className="block text-[14px] text-ink-3">Data Security Council of India</span></span>
              </div>
            </Reveal>
            <div className="grid gap-5 sm:grid-cols-2">
              {WHY.map((w, i) => (
                <Reveal key={w.h} delay={i * 70} className="card p-6 md:p-7">
                  <span className="inline-flex h-11 w-11 items-center justify-center rounded-[12px] border border-line-2 text-cyan-2"><Icon name={w.icon} size={22} /></span>
                  <h3 className="t-h3 mt-5">{w.h}</h3>
                  <p className="mt-2 text-[15.5px] leading-relaxed text-ink-2">{w.p}</p>
                </Reveal>
              ))}
            </div>
          </div>
          <Reveal className="mt-16"><CertStrip /></Reveal>
        </div>
      </section>

      {/* industries */}
      <section className="sec" aria-labelledby="ind-h">
        <div className="wrap">
          <SectionHead id="ind-h" eyebrow="Industries" title="Where a misused identity costs the most." />
          <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {SOLUTIONS.map((s, i) => (
              <Reveal key={s.slug} delay={i * 70}>
                <Link to={`/solutions/${s.slug}`} className="card card-hover group flex h-full flex-col p-6">
                  <span className="inline-flex h-12 w-12 items-center justify-center rounded-[14px] bg-cyan/10 text-cyan-2"><Icon name={INDUSTRY_ICON[s.slug]} size={24} /></span>
                  <h3 className="t-h3 mt-6">{s.name}</h3>
                  <p className="mt-2 flex-1 text-[15px] leading-relaxed text-ink-2">{INDUSTRY_LINE[s.slug]}</p>
                  <span className="link mt-6 text-[14.5px]">See how<Icon name="ArrowRight" size={14} weight="bold" /></span>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* research */}
      <section className="sec" aria-labelledby="res-h">
        <div className="wrap">
          <div className="flex flex-wrap items-end justify-between gap-6">
            <SectionHead align="left" id="res-h" eyebrow="Research" title="What we are seeing in the field." />
            <Link to="/blogs" className="link">All research<Icon name="ArrowRight" size={14} weight="bold" /></Link>
          </div>
          <div className="mt-12 grid gap-10 md:grid-cols-3">{POSTS.slice(0, 3).map((p, i) => <Reveal key={p.slug} delay={i * 80}><PostCard post={p} /></Reveal>)}</div>
        </div>
      </section>

      <CtaBand />
    </>
  );
}
