import { useState } from 'react';
import { Link } from 'react-router';
import { Seo } from '../lib/head.jsx';
import { SOLUTIONS, CERTS, DEPLOY } from '../data/site.js';
import { PRODUCT_MENU } from '../data/nav.js';
import { POSTS } from '../data/posts.js';
import { Button, CountUp, Icon, Reveal, SectionHead, Eyebrow, cx } from '../components/ui.jsx';
import { CtaBand, FilmPlayer, PostCard, TrustedRow } from '../components/blocks.jsx';
import ProductMark from '../components/ProductMark.jsx';
import ThreatHero from '../components/ThreatHero.jsx';
import CertSeal from '../components/CertSeal.jsx';
import RoleCards from '../components/RoleCards.jsx';
import { Logo, logoTitle } from '../components/viz/kit.jsx';
import PerimeterStory from '../components/PerimeterStory.jsx';
import LogoOrbit from '../components/LogoOrbit.jsx';
import { Explore, Faq } from '../components/ProductKit.jsx';

/* The home page reads the way a security buyer scans a vendor: what it is,
   who trusts it, what the platform covers, why it matters now, how it works,
   who it is for, how it deploys, and the questions people ask before a call. */


/* one line per product: what it does, in the buyer's words */
const PITCH = {
  adapid: 'Scores every login and every key, and stops the identity that starts behaving differently.',
  zenstra: 'Checks every AI agent action against its task before it runs, and records each decision.',
  botshield: 'Proves which exposures are real, patches them, and stops bots and floods at the edge.',
  icms: 'Turns every access to personal data into DPDPA evidence, ready before the auditor asks.',
};

const SHARED = [
  { icon: 'Lightning', h: 'Decides before damage', p: 'Inline, before the action, login, payment or request completes.' },
  { icon: 'ChatCircleText', h: 'Explains every decision', p: 'Reasons in plain language that analysts and auditors can follow.' },
  { icon: 'Cloud', h: 'Runs where your data is', p: 'Read-only connectors, agentless roles and a gateway in your VPC.' },
  { icon: 'Scales', h: 'Built for Indian regulation', p: 'Evidence mapped to DPDPA 2023, RBI and SEBI from the start.' },
];

/* Why now, the way established vendors set it: a verdict, the number, what it
   means, where it comes from, and what we do about it. Every figure is sourced. */
const WHY_NOW = [
  { verdict: 'Outnumbered.', v: '82:1', l: 'machine identities for every person in the average organisation. Most were created by a deploy, not by a decision.', s: 'CyberArk Identity Security Landscape, 2025', to: '/adapid-ai/nhi-security', cta: 'How adapID finds every one' },
  { verdict: 'Costlier than ever.', v: '₹25.5 Cr', l: 'average cost of a data breach in India in 2026, up 16% in a year and the highest on record.', s: 'IBM Cost of a Data Breach Report, 2026', to: '/adapid-ai', cta: 'How we stop it before it lands' },
  { verdict: 'On the clock.', v: '72 hrs', l: 'to report a personal data breach in full to the Data Protection Board, with the facts to back it.', s: 'DPDP Rules, 2025', to: '/dpdpa-compliance', cta: 'How ICMS gets you ready' },
];

const CONNECT = ['okta', 'entra', 'ad', 'm365', 'google', 'aws', 'github', 'atlassian', 'salesforce', 'slack'];

const FAQ = [
  { title: 'What does Deep Algorithms do?', body: 'We secure the identities attackers use to get in: people, machine identities such as keys and service accounts, and AI agents. Four products cover them: adapID AI for human and machine identities and fraud, Zenstra AI for AI agents, BotShield AI for exposure, bots and DDoS, and ICMS for DPDPA compliance.' },
  { title: 'Which product should we start with?', body: 'Start with the risk that costs you most today. Each product runs on its own and adds to the others when you add it. Agents acting on your systems: Zenstra. Logins, cloud keys or fraud: adapID. Public apps, bots or DDoS: BotShield. Personal data and DPDPA: ICMS.' },
  { title: 'Do we have to move our data?', body: 'No. adapID uses read-only connectors and one read-only role per AWS account, Zenstra runs as a gateway inside your VPC, BotShield works inline at the edge without diverting traffic, and ICMS connects to the stores that already hold personal data.' },
  { title: 'Which certifications do you hold?', body: 'ISO/IEC 27001, SOC 2 Type II, ISO/IEC 42001 for AI management and ISO/IEC 27701 for privacy. Compliance documentation is available on request from the Trust center.' },
  { title: 'Do you map to Indian regulation?', body: 'Yes. Evidence is mapped to the DPDP Act 2023 and the DPDP Rules 2025, and to RBI and SEBI expectations, from the start rather than added for an audit.' },
  { title: 'What happens in a demo?', body: 'A 30-minute session with a Deep Algorithms engineer, on your own environment where you want it, with your own questions. For AWS, you can connect a sandbox account with a read-only role and walk through the results together.' },
];

const INDUSTRY_ICON = { bfsi: 'Bank', healthcare: 'FirstAidKit', government: 'Buildings', 'digital-platforms': 'Browsers' };
const INDUSTRY_LINE = { bfsi: 'Mule accounts, account takeover, RBI and DPDPA', healthcare: 'Who opened which patient record, and why', government: 'Portals that stay online under attack', 'digital-platforms': 'Bots at sign-up, keys in code, AI in the product' };

function WhyNow() {
  return (
    <section className="stage band-brand sec relative overflow-hidden" aria-labelledby="now-h">
      <div aria-hidden="true" className="absolute inset-0 opacity-60" style={{ backgroundImage: 'linear-gradient(rgb(255 255 255 / .05) 1px, transparent 1px), linear-gradient(90deg, rgb(255 255 255 / .05) 1px, transparent 1px)', backgroundSize: '64px 64px', maskImage: 'radial-gradient(70% 70% at 50% 40%, #000, transparent)', WebkitMaskImage: 'radial-gradient(70% 70% at 50% 40%, #000, transparent)' }} />
      <div className="wrap relative">
        <SectionHead id="now-h" eyebrow="Why identity, why now" title="Identity is now the easiest way in, and the most expensive to get wrong." lead="Three numbers boards and regulators are asking about, and what we do about each." />
        <div className="mt-14 grid gap-px overflow-hidden rounded-[16px] border border-line bg-line md:grid-cols-3">
          {WHY_NOW.map((n, i) => (
            <Reveal key={n.v} delay={i * 90} className="flex flex-col bg-[#05214a]/90 p-7 max-md:items-center max-md:text-center md:p-9">
              <p className="text-[18px] font-semibold tracking-[-0.01em] text-cyan-2">{n.verdict}</p>
              <p className="mt-5 font-semibold tracking-[-0.04em] text-white" style={{ fontSize: 'clamp(48px, 5vw, 72px)', lineHeight: 1 }}><CountUp value={n.v} /></p>
              <p className="mt-5 max-w-[320px] flex-1 text-[16px] leading-relaxed text-ink-2">{n.l}</p>
              <p className="mt-6 w-full border-t border-line pt-4 text-[12.5px] text-ink-3">Source: {n.s}</p>
              <Link to={n.to} className="link mt-4 text-[14.5px]">{n.cta}<Icon name="ArrowRight" size={14} weight="bold" /></Link>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* Desktop: the four products as an explorer, the way enterprise platforms show
   theirs: pick one on the left, see what it does, what it covers and what it
   works with on the right. */
const WORKS = {
  adapid: { label: 'Connects to', logos: ['okta', 'entra', 'ad', 'aws', 'm365', 'google'] },
  zenstra: { label: 'Connects to', logos: ['copilotstudio', 'claude', 'cursor', 'n8n', 'langgraph', 'zapier'] },
};
function PlatformExplorer() {
  const [on, setOn] = useState(0);
  const L = PRODUCT_MENU[on];
  const dep = DEPLOY.find(([n]) => n === L.name)?.[2];
  const key = (e) => {
    const d = e.key === 'ArrowDown' ? 1 : e.key === 'ArrowUp' ? -1 : 0;
    if (!d) return;
    e.preventDefault();
    const from = PRODUCT_MENU.findIndex((l) => `px-${l.key}` === e.target.id); // move from the tab that has focus
    const n = ((from < 0 ? on : from) + d + PRODUCT_MENU.length) % PRODUCT_MENU.length;
    setOn(n);
    document.getElementById(`px-${PRODUCT_MENU[n].key}`)?.focus();
  };
  return (
    <div className="mt-12 grid gap-5 max-md:hidden lg:grid-cols-[340px_minmax(0,1fr)]">
      <div role="tablist" aria-label="Products" aria-orientation="vertical" onKeyDown={key} className="grid gap-2 md:grid-cols-2 lg:grid-cols-1">
        {PRODUCT_MENU.map((l, i) => (
          <button key={l.key} id={`px-${l.key}`} type="button" role="tab" aria-selected={i === on} aria-controls="px-panel" tabIndex={i === on ? 0 : -1} onClick={() => setOn(i)}
            className={cx('relative flex items-center gap-4 rounded-[16px] border p-4 text-left transition-all duration-300', i === on ? 'border-line-2 bg-bg-1 shadow-[0_18px_40px_-28px_rgba(6,25,55,.45)]' : 'border-transparent hover:bg-fg/[.03]')}
            style={{ '--acc': l.acc }}>
            <span aria-hidden="true" className={cx('absolute bottom-4 left-0 top-4 w-[3px] rounded-full transition-opacity', i === on ? 'opacity-100' : 'opacity-0')} style={{ background: l.acc }} />
            <ProductMark p={l.key} size={40} />
            <span className="min-w-0">
              <span className="block text-[16.5px] font-semibold tracking-[-0.01em]">{l.name}</span>
              <span className="mt-0.5 block text-[13.5px] leading-snug text-ink-3">{l.blurb.replace(/, in one platform$/, '')}</span>
            </span>
          </button>
        ))}
      </div>
      <div id="px-panel" role="tabpanel" aria-labelledby={`px-${L.key}`} key={L.key} className="fadein card relative overflow-hidden p-8 xl:p-10" style={{ '--acc': L.acc }}>
        <div aria-hidden="true" className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full opacity-[.14] blur-3xl" style={{ background: L.acc }} />
        <div className="relative grid gap-10 xl:grid-cols-[minmax(0,1.15fr)_minmax(0,1fr)]">
          <div>
            <p className="text-[12.5px] font-semibold uppercase tracking-[.1em]" style={{ color: L.acc }}>{L.blurb.replace(/, in one platform$/, '')}</p>
            <h3 className="mt-3 text-[30px] font-semibold leading-tight tracking-[-0.025em]">{L.name}</h3>
            <p className="mt-4 text-[17px] leading-relaxed text-ink-2">{PITCH[L.key]}</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button to={L.path} arrow>Explore {L.name}</Button>
              <Button to="/request-demo" variant="ghost">Book a demo</Button>
            </div>
          </div>
          <div className="space-y-6">
            <div>
              <p className="text-[12px] font-semibold uppercase tracking-[.1em] text-ink-3">{L.kind === 'products' ? 'Products' : 'What it covers'}</p>
              <ul className="mt-2 divide-y divide-line border-y border-line">
                {L.items.slice(0, 4).map((m) => (
                  <li key={m.name}>
                    <Link to={m.path} className="group flex items-center gap-2.5 py-2.5 text-[15px] text-ink hover:text-cyan-2">
                      <svg width="14" height="14" viewBox="0 0 14 14" aria-hidden="true" className="shrink-0" style={{ color: L.acc }}><path d="m3 7.3 2.6 2.5L11 4.3" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>
                      <span className="flex-1">{m.name}</span>
                      <Icon name="ArrowRight" size={13} className="text-ink-3 opacity-0 transition-opacity group-hover:opacity-100" />
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            {WORKS[L.key] ? (
              <div>
                <p className="text-[12px] font-semibold uppercase tracking-[.1em] text-ink-3">{WORKS[L.key].label}</p>
                <ul className="mt-3 flex flex-wrap gap-2">
                  {WORKS[L.key].logos.map((k) => <li key={k} title={logoTitle(k)} className="flex h-11 w-11 items-center justify-center rounded-[11px] border border-line bg-white text-[#0e1014]"><Logo k={k} size={22} /><span className="sr-only">{logoTitle(k)}</span></li>)}
                </ul>
              </div>
            ) : (
              <div>
                <p className="text-[12px] font-semibold uppercase tracking-[.1em] text-ink-3">Protects</p>
                <p className="mt-2 text-[15px] leading-relaxed text-ink-2">{L.covers.replace(/^For /, '')}</p>
              </div>
            )}
            {dep && <p className="flex gap-2.5 rounded-[12px] bg-fg/[.035] p-3.5 text-[14px] leading-snug text-ink-2"><Icon name="HardDrives" size={18} className="mt-0.5 shrink-0 text-ink-3" />{dep}</p>}
          </div>
        </div>
      </div>
    </div>
  );
}

/* Phones: the four products as an accordion, the first one open, so the page
   stays short and each product is one tap from its detail. */
function PlatformAccordion() {
  return (
    <div className="mt-10 overflow-hidden rounded-[16px] border border-line bg-bg-1 md:hidden">
      {PRODUCT_MENU.map((l, i) => (
        <details key={l.key} open={i === 0} className="acc group border-b border-line last:border-0" style={{ '--acc': l.acc }}>
          <summary className="flex cursor-pointer list-none items-center gap-3.5 p-4 [&::-webkit-details-marker]:hidden">
            <ProductMark p={l.key} size={36} />
            <span className="min-w-0 flex-1">
              <span className="block text-[16.5px] font-semibold">{l.name}</span>
              <span className="block truncate text-[13px] text-ink-3">{l.blurb.replace(/, in one platform$/, '')}</span>
            </span>
            <Icon name="CaretDown" size={16} className="shrink-0 text-ink-3 transition-transform duration-300 group-open:rotate-180" />
          </summary>
          <div className="px-4 pb-5">
            <p className="text-[15px] leading-relaxed text-ink-2">{PITCH[l.key]}</p>
            <ul className="mt-3">
              {l.items.slice(0, 3).map((m) => (
                <li key={m.name}><Link to={m.path} className="flex items-center gap-2.5 py-2 text-[15px] text-ink"><Icon name="CheckCircle" size={17} weight="fill" style={{ color: l.acc }} />{m.name}</Link></li>
              ))}
            </ul>
            <Link to={l.path} className="link mt-3 text-[15px]">Explore {l.name}<Icon name="ArrowRight" size={14} weight="bold" /></Link>
          </div>
        </details>
      ))}
    </div>
  );
}

export default function Home() {
  return (
    <>
      <Seo path="/" description="Deep Algorithms is an identity security platform for people, machine identities and AI agents: four products that stop identity attacks, fraud, bots and data misuse before they become a breach. ISO 27001, SOC 2 Type II. Built in India for regulated industries." />

      {/* hero: what we are, proof, and the product, in one view */}
      <section className="stage band-brand hero-deep hero-under relative overflow-hidden" aria-labelledby="hero-h">
        <div className="wrap relative grid items-center gap-12 pb-12 pt-10 md:pt-16 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.08fr)] lg:gap-10 lg:pb-16 lg:pt-20">
          <div className="max-w-[600px] max-md:mx-auto max-md:text-center">
            <h1 id="hero-h" className="t-hero rise" style={{ '--d': '40ms' }}>Stop identity attacks before the damage. <span className="text-[#7cc4ff]">Human, machine or AI.</span></h1>
            <p className="t-lead rise mt-6 max-w-[500px] max-md:mx-auto" style={{ '--d': '110ms' }}>Deep Algorithms learns how every person, machine identity and AI agent should behave, and stops the one that doesn’t, with the reason why.</p>
            <div className="rise mt-9 flex flex-wrap gap-3 max-md:flex-col max-md:[&>*]:w-full" style={{ '--d': '180ms' }}>
              <Explore label="See the platform" target="#orbit" />
              <Button href="#film" variant="ghost" size="lg"><Icon name="Play" size={15} weight="fill" />Watch the film · 1 min</Button>
            </div>
            <div className="rise mt-8 flex items-center gap-2 text-[13.5px] text-ink-3 max-md:justify-center" style={{ '--d': '240ms' }}>
              <Icon name="SealCheck" size={16} className="shrink-0 text-cyan-2" />
              <ul aria-label="Certifications" className="flex flex-wrap gap-x-2 gap-y-1">
                {CERTS.map((c, i) => <li key={c.code}>{i > 0 && <span aria-hidden="true" className="mr-2">·</span>}{c.name.replace('ISO/IEC ', 'ISO ')}</li>)}
              </ul>
            </div>
          </div>
          <div className="rise relative lg:pl-6" style={{ '--d': '200ms' }}>
            <ThreatHero />
          </div>
        </div>
        <TrustedRow />
      </section>

      <WhyNow />

      {/* the logo moment: the mark rises into the plate with our line, then pops out and lands in the identity orbit, then the four products */}
      <section id="orbit" className="sec scroll-mt-20" aria-labelledby="orbit-h">
        <div className="wrap"><LogoOrbit /></div>
      </section>

      {/* the platform: four products, one standard */}
      <section id="platform" className="sec scroll-mt-20" aria-labelledby="platform-h">
        <div className="wrap">
          <SectionHead align="left" id="platform-h" eyebrow="The platform" title="One platform. Four products. Every identity, human or machine." lead="Start with the risk that costs you most today. Each product runs on its own, deploys where your data already is, and explains every decision it makes." />
          <PlatformAccordion />
          <PlatformExplorer />
          <Reveal className="mt-6 grid gap-px overflow-hidden rounded-[16px] border border-line bg-line sm:grid-cols-2 xl:grid-cols-4">
            {SHARED.map((w) => (
              <div key={w.h} className="flex gap-4 bg-bg-1 p-5">
                <Icon name={w.icon} size={22} className="mt-0.5 shrink-0 text-cyan-2" />
                <span><span className="block text-[15px] font-semibold">{w.h}</span><span className="mt-1 block text-[14px] leading-snug text-ink-3">{w.p}</span></span>
              </div>
            ))}
          </Reveal>
        </div>
      </section>


      {/* how attacks begin now: the three identities, told one at a time */}
      <section id="perimeter" className="sec scroll-mt-20" aria-labelledby="perimeter-h">
        <div className="wrap">
          <SectionHead align="left" id="perimeter-h" eyebrow="Where attacks begin now" title="Attackers don’t break in anymore. They log in." lead="Most access in your company no longer belongs to a person. Keys, service accounts and AI agents hold it now, and that is where attacks begin." />
          <div className="mt-14 lg:mt-6"><PerimeterStory /></div>
        </div>
      </section>

      {/* the film */}
      <section id="film" className="stage sec scroll-mt-20" aria-labelledby="film-h">
        <div className="wrap">
          <SectionHead id="film-h" eyebrow="Watch · 1 minute" title="See the platform in one minute." lead="Three identities attackers use, and how each Deep Algorithms product stops them before the damage is done." />
          <Reveal up className="mx-auto mt-14 max-w-[1000px]"><FilmPlayer /></Reveal>
        </div>
      </section>

      {/* who it is for */}
      <section className="sec" aria-labelledby="roles-h">
        <div className="wrap">
          <SectionHead id="roles-h" eyebrow="Who we help" title="Built for the people who answer for a breach." lead="The same platform, seen by the teams who buy it, run it and report on it." />
          <RoleCards />
        </div>
      </section>

      {/* industries */}
      <section className="sec pt-0" aria-labelledby="ind-h">
        <div className="wrap">
          <div className="flex flex-wrap items-end justify-between gap-6">
            <SectionHead align="left" id="ind-h" eyebrow="By industry" title="Where a misused identity costs the most." />
            <Link to="/products" className="link">Compare all products<Icon name="ArrowRight" size={14} weight="bold" /></Link>
          </div>
          <div className="m-rail mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {SOLUTIONS.map((s, i) => (
              <Reveal key={s.slug} delay={i * 60}>
                <Link to={`/solutions/${s.slug}`} className="card card-hover group flex h-full flex-col overflow-hidden">
                  <span className="relative block aspect-[16/11] overflow-hidden">
                    <img src={`/img/photos/${s.slug}.webp`} alt="" width="1200" height="800" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-[1.05]" loading="lazy" decoding="async" />
                    <span aria-hidden="true" className="absolute inset-0" style={{ background: 'linear-gradient(180deg, transparent 45%, rgb(4 25 58 / .55))' }} />
                    <span className="absolute bottom-3 left-3 inline-flex h-10 w-10 items-center justify-center rounded-[11px] bg-white text-[#0a6dbb] shadow-[0_10px_24px_-10px_rgba(0,0,0,.6)]"><Icon name={INDUSTRY_ICON[s.slug]} size={21} /></span>
                  </span>
                  <span className="flex flex-1 flex-col p-6">
                    <h3 className="t-h3">{s.name}</h3>
                    <span className="mt-2 flex-1 text-[15px] leading-relaxed text-ink-2">{INDUSTRY_LINE[s.slug]}</span>
                    <span className="link mt-6 text-[14.5px]">See how<Icon name="ArrowRight" size={14} weight="bold" /></span>
                  </span>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* deployment, connectors and trust */}
      <section className="sec alt" aria-labelledby="dep-h">
        <div className="wrap">
          <div className="grid gap-12 lg:grid-cols-[.85fr_1.15fr] lg:gap-16">
            <Reveal>
              <Eyebrow>Deployment and trust</Eyebrow>
              <h2 id="dep-h" className="t-h2 mt-6">Deployed where the risk is. Your data stays put.</h2>
              <p className="t-lead mt-5">No product asks you to move your data or rewrite your applications. Every one is certified, and every decision it makes can be explained to an auditor.</p>
              <div className="mt-8 flex items-center gap-5 rounded-[16px] border border-line bg-bg-1 p-5">
                <img src="/img/events/dsci-excellence.webp" alt="" className="h-14 w-20 shrink-0 rounded-[10px] object-cover" loading="lazy" />
                <span><span className="block text-[15.5px] font-semibold">Cybersecurity Excellence, 2025</span><span className="block text-[14px] text-ink-3">Data Security Council of India</span></span>
              </div>
              <Link to="/trust" className="link mt-7 text-[15px]">Visit the Trust center<Icon name="ArrowRight" size={14} weight="bold" /></Link>
            </Reveal>
            <Reveal delay={80}>
              <ul className="divide-y divide-line overflow-hidden rounded-[16px] border border-line bg-bg-1">
                {DEPLOY.map(([n, , t]) => (
                  <li key={n} className="grid gap-2 p-5 md:grid-cols-[210px_1fr] md:gap-6">
                    <span className="flex items-center gap-2.5 text-[15.5px] font-semibold"><ProductMark p={n} size={28} />{n}</span>
                    <span className="text-[15px] leading-relaxed text-ink-2">{t}</span>
                  </li>
                ))}
              </ul>
              <ul className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-4">
                {CERTS.map((c) => (
                  <li key={c.code} className="rounded-[14px] border border-line bg-bg-1 p-4">
                    <CertSeal code={c.code} size={44} />
                    <span className="mt-3 block text-[14.5px] font-semibold">{c.name}</span>
                    <span className="block text-[12.5px] leading-snug text-ink-3">{c.desc}</span>
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>
          <Reveal className="mt-20 border-t border-line pt-16">
            <h3 className="text-center text-[clamp(26px,2.6vw,36px)] font-semibold tracking-[-0.025em]">Works with the systems you already run.</h3>
            <p className="mx-auto mt-3 max-w-[620px] text-center text-[16px] leading-relaxed text-ink-2">Read-only, through each provider’s own API. These are the identity sources adapID AI connects to today.</p>
            <ul className="mx-auto mt-10 grid max-w-[1040px] grid-cols-2 gap-px overflow-hidden rounded-[18px] border border-line bg-line sm:grid-cols-5">
              {CONNECT.map((k) => (
                <li key={k} className="group flex items-center justify-center gap-3 bg-bg-1 px-3 py-6 text-[15px] font-medium text-ink transition-colors hover:bg-bg">
                  <span className="transition-transform duration-300 group-hover:scale-110"><Logo k={k} size="1.6em" /></span>{logoTitle(k)}
                </li>
              ))}
            </ul>
            <p className="mt-5 text-center text-[14px] text-ink-3">Zenstra AI also connects to Copilot Studio, Claude, Cursor, n8n, LangGraph and Zapier, and to your cloud accounts.</p>
          </Reveal>
        </div>
      </section>

      {/* research */}
      <section className="sec" aria-labelledby="res-h">
        <div className="wrap">
          <div className="flex flex-wrap items-end justify-between gap-6">
            <SectionHead align="left" id="res-h" eyebrow="Resources" title="What attackers are doing now, and what stops them." />
            <Link to="/blogs" className="link">All research<Icon name="ArrowRight" size={14} weight="bold" /></Link>
          </div>
          <div className="m-rail mt-12 grid gap-10 md:grid-cols-3">{POSTS.slice(0, 3).map((p, i) => <Reveal key={p.slug} delay={i * 80}><PostCard post={p} /></Reveal>)}</div>
        </div>
      </section>

      <div className="alt"><Faq items={FAQ} title="What teams ask before a first call" /></div>

      <CtaBand />
    </>
  );
}
