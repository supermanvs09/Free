import { useState } from 'react';
import { Link } from 'react-router';
import { Seo } from '../lib/head.jsx';
import { SITE, CERTS } from '../data/site.js';
import { LEADERS, ADVISORS, RECOGNITION, TEAM_PHOTOS, BELIEFS } from '../data/company.js';
import { Breadcrumb, Button, Icon, Reveal, SectionHead, Tabs, cx } from '../components/ui.jsx';
import { CtaBand, LogoMarquee } from '../components/blocks.jsx';
import FlowRibbons from '../components/FlowRibbons.jsx';
import Stage3D, { Pop } from '../components/Stage3D.jsx';
import ProductMark from '../components/ProductMark.jsx';

const img = (k) => `/img/events/${k}.webp`;

/* The story so far, from the events and recognition we can show. */
const YEARS = [
  { y: '2022', h: 'Founded in Hyderabad', p: 'Deep Algorithms starts from one observation: attackers had adopted AI, and the tools defending against them had not.', items: [['Company founded', 'Hyderabad, India']], photo: null },
  { y: '2024', h: 'On the national stage', p: 'Our work on identity and data security reaches government and industry forums across India.', items: [['Bharat Mandapam', 'Delhi'], ['CCoE DSCI Chapter Meet', 'Hyderabad'], ['Cybersecurity and Privacy conference', 'Telangana']], photo: 'bharat-mandapam' },
  { y: '2025', h: 'Recognised for the work', p: 'Awards from the Data Security Council of India and industry bodies, and an international stage in Dubai.', items: [['Cybersecurity Excellence', 'Data Security Council of India'], ['Business Excellence Award', 'Best Cybersecurity Solutions Provider'], ['GITEX GLOBAL × Expand North Star', 'Dubai'], ['NEC–Globis Innovation', 'T-Hub']], photo: 'dsci-excellence' },
  { y: '2026', h: 'Growing the team', p: 'A new office, training with the Cyber Bureau in Hyderabad and the AI Summit in Delhi.', items: [['New office inauguration', 'Deep Algorithms'], ['Cyber Security Training', 'Cyber Bureau Hyderabad'], ['AI Summit', 'Delhi']], photo: 'office-inauguration' },
];

function Timeline() {
  const [i, setI] = useState(3);
  const y = YEARS[i];
  return (
    <div>
      <Tabs items={YEARS.map((x) => x.y)} value={i} onChange={setI} label="Years" />
      <div key={i} className="fadein mt-10 grid items-center gap-10 lg:grid-cols-[1fr_1.1fr] lg:gap-16">
        <div>
          <p className="text-[64px] font-semibold leading-none tracking-[-0.05em] text-cyan-2 num md:text-[88px]">{y.y}</p>
          <h3 className="mt-4 text-[28px] font-semibold tracking-[-0.03em] md:text-[34px]">{y.h}</h3>
          <p className="mt-3 text-[17px] leading-relaxed text-ink-2">{y.p}</p>
          <ul className="mt-7 divide-y divide-line border-y border-line">
            {y.items.map(([t, w]) => <li key={t} className="flex flex-wrap items-baseline justify-between gap-2 py-3.5"><span className="text-[16px] font-medium">{t}</span><span className="text-[14px] text-ink-3">{w}</span></li>)}
          </ul>
        </div>
        <div className="relative aspect-[4/3] overflow-hidden rounded-[24px] border border-line bg-bg-1">
          {y.photo ? <img src={img(y.photo)} alt={y.items[0][0]} className="h-full w-full object-cover" loading="lazy" decoding="async" />
            : <div className="flex h-full items-center justify-center"><span className="flex h-28 w-28 items-center justify-center rounded-[30px] bg-white p-6"><img src="/brand/mark.webp" alt="" className="h-full w-full" /></span></div>}
          <div aria-hidden="true" className="absolute inset-x-0 bottom-0 h-1/3" style={{ background: 'linear-gradient(transparent, rgb(10 11 14 / .85))' }} />
        </div>
      </div>
    </div>
  );
}

/* Leaders: a portrait, the role in one line and a short record. */
function Leader({ p }) {
  return (
    <div className="card card-hover group relative flex h-full flex-col p-6">
      <div className="flex items-center gap-4">
        <span className="relative block h-[68px] w-[68px] shrink-0 rounded-full p-[2px]" style={{ background: 'linear-gradient(140deg, #3cc8f6, #0068ac 60%, rgb(148 170 200 / .25))' }}>
          <img src={`/img/people/${p.img}.webp`} alt="" width="64" height="64" className="h-full w-full rounded-full bg-[#0f1115] object-cover" loading="lazy" decoding="async" />
        </span>
        <span className="min-w-0 pr-7">
          <span className="block text-[17px] font-semibold leading-tight tracking-[-0.015em]">{p.name}</span>
          <span className="mt-1 block text-[13.5px] font-medium text-cyan-2">{p.role}</span>
        </span>
      </div>
      <p className="mt-5 flex-1 border-t border-line pt-4 text-[14px] leading-relaxed text-ink-2">{p.bio}</p>
      <a href={p.linkedin} target="_blank" rel="noreferrer" className="absolute right-4 top-4 inline-flex h-9 w-9 items-center justify-center rounded-full text-ink-3 transition-colors hover:bg-fg/[.06] hover:text-ink" aria-label={`${p.name} on LinkedIn`}><Icon name="LinkedinLogo" size={18} /></a>
    </div>
  );
}

/* Advisors: one compact row each. */
function Advisor({ p }) {
  return (
    <a href={p.linkedin} target="_blank" rel="noreferrer" className="group flex h-full items-start gap-3.5 rounded-[16px] border border-line p-4 transition-colors hover:border-line-2 hover:bg-fg/[.025]" aria-label={`${p.name}, ${p.role}, on LinkedIn`}>
      <img src={`/img/people/${p.img}.webp`} alt="" width="48" height="48" className="h-12 w-12 shrink-0 rounded-full bg-[#0f1115] object-cover" loading="lazy" decoding="async" />
      <span className="min-w-0 flex-1">
        <span className="flex items-center gap-1.5 text-[15px] font-semibold leading-tight">{p.name}<Icon name="LinkedinLogo" size={14} className="text-ink-3 opacity-0 transition-opacity group-hover:opacity-100" /></span>
        <span className="mt-0.5 block text-[12.5px] font-medium text-cyan-2">{p.role}</span>
        <span className="mt-1.5 block text-[13px] leading-snug text-ink-3">{p.bio}</span>
      </span>
    </a>
  );
}

/* The four products, as the company's calling card: a panel in perspective,
   each product lifting out of it at its own depth. */
const LINEUP = [
  ['zenstra', 'Zenstra AI', 'AI agents', '/agentic-ai/agentic-identity', '#93a2ff'],
  ['adapid', 'adapID AI', 'People and machine identities', '/adapid-ai', '#3cc8f6'],
  ['botshield', 'BotShield AI', 'Apps, APIs and the edge', '/botshield-ai', '#34e0c3'],
  ['icms', 'ICMS Compliance Suite', 'Personal data and DPDPA', '/dpdpa-compliance', '#f4c76c'],
];
function ProductPanel() {
  return (
    <Stage3D tilt={[10, -16]} className="relative mx-auto w-full max-w-[600px]">
      <div className="rounded-[28px] border border-line-2 p-5 shadow-[0_60px_120px_-50px_rgba(0,0,0,.9)] md:p-7" style={{ background: 'linear-gradient(180deg, rgb(21 23 27 / .92), rgb(13 15 19 / .92))' }}>
        <div className="flex items-center gap-3 border-b border-line pb-4">
          <span className="grid h-9 w-9 place-items-center rounded-[10px] bg-white p-1.5"><img src="/brand/mark.webp" alt="" className="h-full w-full" /></span>
          <span className="text-[15px] font-semibold">Deep Algorithms</span>
          <span className="ml-auto text-[12.5px] text-ink-3">Products</span>
        </div>
        <ul className="mt-5 grid grid-cols-2 gap-3 md:gap-4">
          {LINEUP.map(([k, name, what, , acc], i) => (
            <li key={k}>
              <Pop z={[60, 100, 80, 120][i]} delay={350 + i * 140}>
                <div className="rounded-[18px] border border-line-2 p-4 md:p-5" style={{ background: 'linear-gradient(160deg, rgb(255 255 255 / .07), rgb(255 255 255 / .02))', boxShadow: `0 24px 50px -24px rgba(0,0,0,.9), 0 0 40px -16px ${acc}` }}>
                  <ProductMark p={k} size={52} className="md:!h-[60px] md:!w-[60px]" />
                  <p className="mt-4 text-[15px] font-semibold leading-tight md:text-[16px]">{name}</p>
                  <p className="mt-1 text-[12.5px] leading-snug" style={{ color: acc }}>{what}</p>
                </div>
              </Pop>
            </li>
          ))}
        </ul>
      </div>
    </Stage3D>
  );
}

/* Where people join, described by the work rather than by job titles. */
const TEAMS = [
  { name: 'AI engineering', icon: 'Cpu', work: 'Behaviour models that score people, machine identities and AI agents in milliseconds, and explain every score in plain language.' },
  { name: 'Security research', icon: 'Detective', work: 'Attack paths, mule networks and new identity attacks, studied in the field and written up as the reports on this site.' },
  { name: 'Product engineering', icon: 'Code', work: 'Gateways, connectors and consoles that run inside customers’ own clouds, built for banks, hospitals and government.' },
];

export default function About() {
  return (
    <>
      <Seo title="About Us: The Team Behind Deep Algorithms" path="/about-us" description="Deep Algorithms is an AI-native cybersecurity company founded in Hyderabad in 2022, with offices in Bengaluru and Plano, Texas. Meet the team, our advisors and what we believe." crumbs={[{ name: 'About us', path: '/about-us' }]} />

      <section className="stage relative -mt-[72px] overflow-hidden pt-[72px]">
        <FlowRibbons preset="hero" mobilePreset="heroMobile" intensity={0.7} />
        <div aria-hidden="true" className="pointer-events-none absolute inset-0" style={{ background: 'linear-gradient(90deg, rgb(10 11 14 / .8), rgb(10 11 14 / .3) 50%, transparent 75%)' }} />
        <div className="wrap relative grid items-center gap-14 pb-20 pt-10 lg:min-h-[min(90svh,900px)] lg:grid-cols-[1fr_1fr] lg:gap-10">
          <div>
            <Breadcrumb items={[{ name: 'About us' }]} className="rise mb-8" />
            <p className="eyebrow rise">About Deep Algorithms</p>
            <h1 className="t-hero rise mt-7" style={{ '--d': '80ms' }}>We build defence <span className="grad-text">that thinks.</span></h1>
            <p className="t-lead rise mt-7 max-w-[560px]" style={{ '--d': '160ms' }}>An AI-native cybersecurity company, founded in Hyderabad in 2022. We secure every human, machine and AI agent identity, and stop the fraud, bots and data misuse that follow them.</p>
            <dl className="rise mt-10 grid max-w-[560px] grid-cols-2 gap-x-8 gap-y-6 sm:grid-cols-4" style={{ '--d': '240ms' }}>
              {[['Founded', SITE.founded], ['Headquarters', 'Hyderabad'], ['Offices', '3'], ['Certifications', CERTS.length]].map(([k, v]) => (
                <div key={k}><dt className="text-[13px] text-ink-3">{k}</dt><dd className="mt-1 text-[24px] font-semibold tracking-[-0.03em] num">{v}</dd></div>
              ))}
            </dl>
          </div>
          <ProductPanel />
        </div>
      </section>

      <section className="sec" aria-labelledby="story-h">
        <div className="wrap grid gap-12 lg:grid-cols-[1fr_1.1fr] lg:gap-20">
          <Reveal>
            <p className="eyebrow">Our story</p>
            <h2 id="story-h" className="t-h2 mt-6">The defence must be as intelligent as the attack.</h2>
          </Reveal>
          <Reveal delay={100} className="space-y-5 text-[18px] leading-[1.75] text-ink-2">
            <p className="text-[22px] font-medium leading-snug tracking-[-0.015em] text-ink">“We don’t sell security products. We build defence that thinks.”</p>
            <p>Deep Algorithms was founded on one observation: the threat landscape changed fundamentally when attackers adopted AI. Bots that mimic people. Identity compromises that drift unseen for months. Data access that looks exactly like legitimate work. Tools built for a rule-based world cannot keep pace.</p>
            <p>So we set out to build a new class of security intelligence: one that learns your environment, understands what normal looks like in your context, and detects the deviation before it becomes a breach.</p>
            <div className="flex flex-wrap gap-2 pt-2">
              {LINEUP.map(([k, n, , to]) => (
                <Link key={n} to={to} className="inline-flex h-10 items-center gap-2 rounded-full border border-line-2 pl-2 pr-4 text-[14.5px] text-ink transition-colors hover:border-fg/30"><ProductMark p={k} size={24} />{n}</Link>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      <section className="sec" aria-labelledby="tl-h">
        <div className="wrap">
          <SectionHead align="left" id="tl-h" eyebrow="The story so far" title="Four years, one direction." />
          <div className="mt-12"><Timeline /></div>
        </div>
      </section>

      <section id="leadership" className="sec scroll-mt-20" aria-labelledby="lead-h">
        <div className="wrap">
          <SectionHead align="left" id="lead-h" eyebrow="Leadership" title="Decades in AI, banking and security, in one team." lead="Founders, operators and researchers from IIT, IIM, IIIT and Imperial College London." />
          <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{LEADERS.map((p, i) => <Reveal key={p.name} delay={i * 70} className="h-full"><Leader p={p} /></Reveal>)}</div>
          <h3 className="mt-20 text-[24px] font-semibold tracking-[-0.02em]">Advisors and mentors</h3>
          <p className="mt-2 text-[16px] text-ink-2">Leaders from banking regulation, investment, technology and research who guide our work.</p>
          <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{ADVISORS.map((p, i) => <Reveal key={p.name} delay={(i % 4) * 60} className="h-full"><Advisor p={p} /></Reveal>)}</div>
        </div>
      </section>

      <section className="sec" aria-labelledby="bel-h">
        <div className="wrap">
          <SectionHead id="bel-h" eyebrow="What we believe" title="The principles we build to." lead="Not values on a wall. Constraints on every line of code." />
          <ol className="mt-14 grid gap-x-12 md:grid-cols-2">
            {BELIEFS.map((b, i) => (
              <Reveal as="li" key={b.title} delay={(i % 2) * 80} className="flex gap-6 border-t border-line py-7">
                <span className="text-[15px] font-semibold text-cyan-2 num">{String(i + 1).padStart(2, '0')}</span>
                <span><span className="block text-[21px] font-semibold tracking-[-0.02em]">{b.title}</span><span className="mt-2 block text-[16px] leading-relaxed text-ink-2">{b.body}</span></span>
              </Reveal>
            ))}
          </ol>
        </div>
      </section>

      <section id="recognition" className="sec scroll-mt-20" aria-labelledby="rec-h">
        <div className="wrap">
          <SectionHead align="left" id="rec-h" eyebrow="Recognition" title="Recognised in India and beyond." />
          <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {RECOGNITION.map((r, i) => (
              <Reveal key={r.title} delay={(i % 4) * 60} className={cx('card group overflow-hidden', i === 0 && 'sm:col-span-2 lg:row-span-2')}>
                <div className={cx('overflow-hidden', i === 0 ? 'aspect-[4/3]' : 'aspect-[16/10]')}><img src={img(r.img)} alt={`${r.title}, ${r.where}`} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-[1.04]" loading="lazy" decoding="async" /></div>
                <div className="p-5"><p className={cx('font-semibold tracking-[-0.015em]', i === 0 ? 'text-[22px]' : 'text-[16px]')}>{r.title}</p><p className="mt-1 text-[13.5px] text-ink-3">{r.where} · {r.year}</p></div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="stage sec" aria-labelledby="life-h">
        <div className="wrap">
          <SectionHead align="left" id="life-h" eyebrow="The team" title="Life at Deep Algorithms." lead="At conferences, on stage and in the room where problems get solved." />
        </div>
        <div className="no-scrollbar mt-12 flex snap-x gap-4 overflow-x-auto px-5 pb-4 md:px-10 xl:px-[max(40px,calc((100vw-1320px)/2+40px))]">
          {TEAM_PHOTOS.map((t) => (
            <figure key={t.img} className="w-[78vw] shrink-0 snap-start sm:w-[420px]">
              <img src={img(t.img)} alt={t.title} className="aspect-[4/3] w-full rounded-[20px] border border-line object-cover" loading="lazy" decoding="async" />
              <figcaption className="mt-3 text-[14px] text-ink-3">{t.title}</figcaption>
            </figure>
          ))}
        </div>
      </section>

      <section id="careers" className="sec scroll-mt-20" aria-labelledby="car-h">
        <div className="wrap">
          <Reveal className="card overflow-hidden p-8 md:p-14">
            <div className="grid items-end gap-10 lg:grid-cols-[1.3fr_1fr]">
              <div>
                <p className="eyebrow">Careers</p>
                <h2 id="car-h" className="t-h2 mt-6">Build the defence attackers have to think about.</h2>
                <p className="t-lead mt-5">We are looking for AI engineers, security researchers and product builders. Tell us what you want to work on.</p>
              </div>
              <div className="flex flex-col items-start gap-3 lg:items-end">
                <Button href={`mailto:${SITE.careersEmail}`} size="lg" arrow>Write to {SITE.careersEmail}</Button>
                <p className="text-[14px] text-ink-3">Hyderabad · Bengaluru · Plano, Texas</p>
              </div>
            </div>
            <ul className="mt-12 grid gap-4 md:grid-cols-3">
              {TEAMS.map((t) => (
                <li key={t.name} className="flex flex-col rounded-[18px] border border-line p-6">
                  <Icon name={t.icon} size={24} className="text-cyan-2" />
                  <h3 className="mt-5 text-[19px] font-semibold tracking-[-0.015em]">{t.name}</h3>
                  <p className="mt-2 flex-1 text-[15px] leading-relaxed text-ink-2">{t.work}</p>
                  <a href={`mailto:${SITE.careersEmail}?subject=${encodeURIComponent(`Careers: ${t.name}`)}`} className="link mt-5 text-[14.5px]">Write to us about this<Icon name="ArrowRight" size={13} weight="bold" /></a>
                </li>
              ))}
            </ul>
            <div className="mt-4 flex flex-col gap-2 rounded-[18px] border border-line p-6 md:flex-row md:items-center md:gap-6">
              <p className="shrink-0 text-[13px] font-semibold uppercase tracking-[.1em] text-ink-3">What to send</p>
              <p className="text-[15.5px] leading-relaxed text-ink-2">A few lines on the problem you want to work on, and a link to something you built: code, research or a write-up. It tells us more than a CV.</p>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="sec" aria-labelledby="off-h">
        <div className="wrap">
          <SectionHead align="left" id="off-h" eyebrow="Offices" title="Where to find us." />
          <div className="mt-12 grid gap-4 md:grid-cols-3">
            {SITE.offices.map((o, i) => (
              <Reveal key={o.city} delay={i * 70} className="card flex flex-col p-7">
                <p className="text-[12.5px] font-semibold uppercase tracking-[.1em] text-cyan-2">{o.label}</p>
                <p className="mt-3 text-[24px] font-semibold tracking-[-0.025em]">{o.city}</p>
                <p className="mt-3 flex-1 text-[15.5px] leading-relaxed text-ink-2">{o.address}</p>
                {o.map && <a href={o.map} target="_blank" rel="noreferrer" className="link mt-5 text-[14.5px]">Open in Maps<Icon name="ArrowUpRight" size={14} weight="bold" /></a>}
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <LogoMarquee />
      <CtaBand title="Talk to the team." body="Evaluating a product, exploring a partnership or comparing approaches? Tell us what you are solving and we will bring the right engineer." />
    </>
  );
}
