import { Link } from 'react-router';
import { Seo } from '../lib/head.jsx';
import { CERTS, DEPLOY } from '../data/site.js';
import { RECOGNITION } from '../data/company.js';
import { Button, Icon, Reveal, SectionHead } from '../components/ui.jsx';
import { CtaBand } from '../components/blocks.jsx';
import { Hero, Points } from '../components/ProductKit.jsx';
import ProductMark from '../components/ProductMark.jsx';
import CertSeal, { SEAL_KIND } from '../components/CertSeal.jsx';

/* The page a security reviewer looks for before procurement: what is
   certified, where each product runs, how data is handled, and how to get
   the documents. Every statement here is one the products already make. */

const STANDARD = {
  'ISO 27001': 'The international standard for an information security management system: how risks are assessed, controls chosen and kept working.',
  'SOC 2': 'An independent audit of how controls for security, availability and confidentiality operated over a period of time, not on a single day.',
  'ISO 42001': 'The international standard for managing AI systems responsibly: risk, transparency and oversight across the AI life cycle.',
  'ISO 27701': 'The privacy extension to ISO 27001: how personal data is governed, processed and protected.',
};

const HANDLING = [
  { icon: 'Eye', h: 'Read-only by default', p: 'adapID reads from your identity provider, IAM, HR and SaaS through read-only connectors, and from AWS through one read-only role per account.' },
  { icon: 'HardDrives', h: 'Your data stays where it is', p: 'Zenstra runs as a gateway inside your VPC. BotShield works inline at the edge with no traffic diversion. ICMS connects to the stores that already hold personal data.' },
  { icon: 'ClipboardText', h: 'Every decision on record', p: 'Scores, holds and blocks are stored with the reasons behind them, so an analyst, an auditor or a regulator can follow each one.' },
];

const REGULATION = [
  { icon: 'Scales', h: 'DPDP Act 2023 and DPDP Rules 2025', p: 'Personal data discovered, every access checked against purpose and consent, and breach facts ready for the 72-hour report to the Data Protection Board.' },
  { icon: 'Bank', h: 'RBI', p: 'Identity, fraud and access evidence mapped to the expectations banks and payment providers report against.' },
  { icon: 'Certificate', h: 'SEBI', p: 'Evidence for regulated market entities, generated as systems are used rather than assembled before an inspection.' },
];

export default function Trust() {
  return (
    <>
      <Seo title="Trust Center: Certifications, Deployment and Data Handling" path="/trust" description="Deep Algorithms is certified to ISO/IEC 27001, SOC 2 Type II, ISO/IEC 42001 and ISO/IEC 27701. How each product is deployed, how data is handled, and how to request compliance documentation." crumbs={[{ name: 'Trust center', path: '/trust' }]} />
      <Hero layout="stack" ribbons="band" crumbs={[{ name: 'Trust center' }]} eyebrow="Trust center"
        title="Security you can verify before you sign."
        lead="What Deep Algorithms is certified for, where each product runs, and how your data is handled. Compliance documentation is available on request."
        ctas={<><Button to="/contact" size="lg" arrow>Request compliance documents</Button><Button to="/request-demo" variant="ghost" size="lg">Talk to an engineer</Button></>} />

      <section className="sec" aria-labelledby="cert-h">
        <div className="wrap">
          <SectionHead align="left" id="cert-h" eyebrow="Certifications" title="Independent standards, held across the company." />
          <ul className="m-rail mt-12 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            {CERTS.map((c, i) => (
              <Reveal as="li" key={c.code} delay={i * 60} className="card flex flex-col p-6">
                <span className="flex items-center justify-between gap-3"><CertSeal code={c.code} size={64} /><span className="rounded-full bg-cyan-2/10 px-2.5 py-1 text-[11px] font-semibold uppercase tracking-[.08em] text-cyan-2">{SEAL_KIND[c.code]}</span></span>
                <h3 className="mt-5 text-[19px] font-semibold tracking-[-0.015em]">{c.name}</h3>
                <p className="mt-1 text-[12.5px] font-semibold uppercase tracking-[.09em] text-ink-3">{c.desc}</p>
                <p className="mt-4 text-[15px] leading-relaxed text-ink-2">{STANDARD[c.code]}</p>
              </Reveal>
            ))}
          </ul>
        </div>
      </section>

      <section className="sec alt" aria-labelledby="dep-h">
        <div className="wrap grid gap-12 lg:grid-cols-[.8fr_1.2fr] lg:gap-16">
          <Reveal>
            <p className="eyebrow">Deployment</p>
            <h2 id="dep-h" className="t-h2 mt-6">Where each product runs.</h2>
            <p className="t-lead mt-5">No product asks you to move your data or rewrite your applications.</p>
          </Reveal>
          <Reveal delay={80}>
            <ul className="divide-y divide-line overflow-hidden rounded-[16px] border border-line bg-bg-1">
              {DEPLOY.map(([n, , t]) => (
                <li key={n} className="grid gap-2 p-6 md:grid-cols-[220px_1fr] md:gap-6">
                  <span className="flex items-center gap-2.5 text-[16px] font-semibold"><ProductMark p={n} size={30} />{n}</span>
                  <span className="text-[15.5px] leading-relaxed text-ink-2">{t}</span>
                </li>
              ))}
            </ul>
          </Reveal>
        </div>
      </section>

      <section className="sec" aria-labelledby="data-h">
        <div className="wrap">
          <SectionHead align="left" id="data-h" eyebrow="Data handling" title="Least access in, every decision out." lead="The principles every product is built on, so a security review has fewer questions to ask." />
          <div className="mt-12"><Points items={HANDLING} /></div>
        </div>
      </section>

      <section className="sec alt" aria-labelledby="reg-h">
        <div className="wrap">
          <SectionHead align="left" id="reg-h" eyebrow="Indian regulation" title="Mapped from the start, not bolted on for an audit." />
          <div className="mt-12"><Points items={REGULATION} /></div>
          <Reveal className="mt-8"><Link to="/dpdpa-compliance" className="link">How ICMS produces DPDPA evidence<Icon name="ArrowRight" size={14} weight="bold" /></Link></Reveal>
        </div>
      </section>

      <section className="sec" aria-labelledby="rec-h">
        <div className="wrap">
          <SectionHead align="left" id="rec-h" eyebrow="Recognition" title="Recognised by India’s security community." />
          <ul className="m-rail mt-12 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {RECOGNITION.slice(0, 4).map((r, i) => (
              <Reveal as="li" key={r.title} delay={i * 60} className="card overflow-hidden">
                <img src={`/img/events/${r.img}.webp`} alt="" className="aspect-[16/10] w-full object-cover" loading="lazy" decoding="async" />
                <span className="block p-4"><span className="block text-[15px] font-semibold">{r.title}</span><span className="block text-[13px] text-ink-3">{r.where} · {r.year}</span></span>
              </Reveal>
            ))}
          </ul>
        </div>
      </section>

      <CtaBand title="Need our compliance documentation?" body="Certificates, audit reports and answers to your security questionnaire, shared on request. Write to info@deepalgorithms.in or ask an engineer." primary={{ label: 'Request documents', to: '/contact' }} />
    </>
  );
}
