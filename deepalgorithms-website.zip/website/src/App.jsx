import { lazy, Suspense, useEffect, useRef } from 'react';
import { Routes, Route, useLocation } from 'react-router';
import Header from './components/Header.jsx';
import Footer from './components/Footer.jsx';
import Backdrop from './components/Backdrop.jsx';
import { PRODUCTS } from './data/products.js';
import { ZCAPS } from './data/zenstra.js';
import { SOLUTIONS } from './data/site.js';
import { POSTS } from './data/posts.js';
import { LEGAL } from './data/legal.js';

const Home = lazy(() => import('./pages/Home.jsx'));
const Platform = lazy(() => import('./pages/Platform.jsx'));
const Products = lazy(() => import('./pages/Products.jsx'));
const Solution = lazy(() => import('./pages/Solution.jsx'));
const About = lazy(() => import('./pages/About.jsx'));
const Blog = lazy(() => import('./pages/Blog.jsx'));
const Article = lazy(() => import('./pages/Article.jsx'));
const Demo = lazy(() => import('./pages/Demo.jsx'));
const Contact = lazy(() => import('./pages/Contact.jsx'));
const Legal = lazy(() => import('./pages/Legal.jsx'));
const Sitemap = lazy(() => import('./pages/Sitemap.jsx'));
const NotFound = lazy(() => import('./pages/NotFound.jsx'));
const Capability = lazy(() => import('./pages/products/Capability.jsx'));

/* Every product has its own page; the six Zenstra capabilities share one. */
const PRODUCT_PAGES = {
  zenstra: lazy(() => import('./pages/products/Zenstra.jsx')),
  adapid: lazy(() => import('./pages/products/Cirm.jsx')),
  nhi: lazy(() => import('./pages/products/Nhi.jsx')),
  fraud: lazy(() => import('./pages/products/Fraud.jsx')),
  ad: lazy(() => import('./pages/products/AdSecurity.jsx')),
  botshield: lazy(() => import('./pages/products/BotShield.jsx')),
  ddos: lazy(() => import('./pages/products/Ddos.jsx')),
  icms: lazy(() => import('./pages/products/Icms.jsx')),
};

/* Every public URL; scripts/prerender.mjs renders these and lists them in sitemap.xml. */
export const PATHS = [
  '/', '/platform', '/products',
  ...Object.values(PRODUCTS).map((p) => p.path),
  ...SOLUTIONS.map((s) => `/solutions/${s.slug}`),
  '/about-us', '/blogs', ...POSTS.map((p) => `/blogs/${p.slug}`),
  '/request-demo', '/contact', '/sitemap', ...Object.keys(LEGAL).map((k) => `/${k}`),
];

/* Scroll to top on navigation, or to the #hash target. */
function PageEffects() {
  const { pathname, hash } = useLocation();
  useEffect(() => {
    if (hash) {
      const t = setTimeout(() => document.getElementById(decodeURIComponent(hash.slice(1)))?.scrollIntoView(), 60);
      return () => clearTimeout(t);
    }
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
    return undefined;
  }, [pathname, hash]);
  return null;
}

/* Each page is keyed by its path, so a new page fades up once; the first
   page (prerendered) shows at once. Children are the page's bands: .stage
   bands stay dark, the rest are the light sheets of the mixed theme. */
function Page({ children }) {
  const { pathname } = useLocation();
  const seen = useRef({ path: pathname, moved: false });
  if (seen.current.path !== pathname) seen.current = { path: pathname, moved: true };
  return <div key={pathname} className={seen.current.moved ? 'page page-in' : 'page'}>{children}</div>;
}

export default function App() {
  return (
    <>
      <Backdrop />
      <Header />
      <main id="main" className="pt-[72px]">
        <PageEffects />
        <Suspense fallback={<div className="page"><div className="stage min-h-screen" /></div>}>
          <Page>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/platform" element={<Platform />} />
            <Route path="/products" element={<Products />} />
            {Object.entries(PRODUCT_PAGES).map(([k, P]) => <Route key={k} path={PRODUCTS[k].path} element={<P />} />)}
            {Object.entries(ZCAPS).map(([k, c]) => <Route key={k} path={c.path} element={<Capability id={k} />} />)}
            <Route path="/solutions/:slug" element={<Solution />} />
            <Route path="/about-us" element={<About />} />
            <Route path="/blogs" element={<Blog />} />
            <Route path="/blogs/:slug" element={<Article />} />
            <Route path="/request-demo" element={<Demo />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/sitemap" element={<Sitemap />} />
            {Object.keys(LEGAL).map((k) => <Route key={k} path={`/${k}`} element={<Legal id={k} />} />)}
            <Route path="*" element={<NotFound />} />
          </Routes>
          </Page>
        </Suspense>
      </main>
      <Footer />
    </>
  );
}
