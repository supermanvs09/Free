import { useEffect, useRef, useState } from 'react';
import { Link, useLocation } from 'react-router';
import { SOLUTIONS } from '../data/site.js';
import { POSTS } from '../data/posts.js';
import { PRODUCT_MENU, CHALLENGES, COMPANY_MENU } from '../data/nav.js';
import { getTheme, onTheme, toggleTheme } from '../lib/theme.js';
import { Button, Icon, cx } from './ui.jsx';

/* `dual` stacks the dark-on-light lockup over the white one; CSS shows the
   one that suits the header's tone. */
export function Logo({ className = 'h-[30px]', dual }) {
  if (!dual) return <img src="/brand/logo-lockup-inverse.webp" alt="Deep Algorithms" width="153" height="34" className={cx('w-auto', className)} />;
  return (
    <span className="relative block">
      <img src="/brand/logo-lockup-inverse.webp" alt="Deep Algorithms" width="153" height="34" className={cx('hdr-logo on-d w-auto', className)} />
      <img src="/brand/logo-lockup.webp" alt="" aria-hidden="true" width="153" height="34" className={cx('hdr-logo on-l w-auto', className)} />
    </span>
  );
}

function ThemeButton() {
  const [dark, setDark] = useState(false);
  useEffect(() => { setDark(getTheme() === 'dark'); return onTheme((t) => setDark(t === 'dark')); }, []);
  const onClick = (e) => {
    const b = e.currentTarget.getBoundingClientRect();
    toggleTheme(e.clientX || b.left + b.width / 2, e.clientY || b.top + b.height / 2);
  };
  return (
    <button type="button" onClick={onClick} aria-pressed={dark} aria-label="Dark theme" title={dark ? 'Switch to the light theme' : 'Switch to the dark theme'}
      className="theme-btn inline-flex h-10 w-10 items-center justify-center rounded-full border border-line-2 text-ink-2 transition-colors hover:border-fg/30 hover:text-ink">
      <svg className="i-moon" width="17" height="17" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true"><path d="M13 9.5A5.5 5.5 0 0 1 6.5 3a5.5 5.5 0 1 0 6.5 6.5Z" strokeLinejoin="round" /></svg>
      <svg className="i-sun" width="17" height="17" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" aria-hidden="true"><circle cx="8" cy="8" r="3" /><path d="M8 1.2v1.6M8 13.2v1.6M1.2 8h1.6M13.2 8h1.6M3.2 3.2l1.1 1.1M11.7 11.7l1.1 1.1M3.2 12.8l1.1-1.1M11.7 4.3l1.1-1.1" /></svg>
    </button>
  );
}

const TOPICS = [...new Set(POSTS.map((p) => p.category))].map((c) => ({ name: c, n: POSTS.filter((p) => p.category === c).length }));
export const topicSlug = (c) => c.toLowerCase().replace(/[^a-z0-9]+/g, '-');

const Item = ({ to, name, desc, onNav }) => (
  <Link to={to} onClick={onNav} className="group -mx-3 block rounded-[12px] px-3 py-2.5 transition-colors hover:bg-fg/[.05] focus-visible:bg-fg/[.05]">
    <span className="flex items-center gap-1.5 text-[15px] font-medium text-ink">{name}<Icon name="ArrowRight" size={13} className="-translate-x-1 text-cyan opacity-0 transition-all group-hover:translate-x-0 group-hover:opacity-100" /></span>
    {desc && <span className="mt-0.5 block text-[13.5px] leading-snug text-ink-3">{desc}</span>}
  </Link>
);
const GroupLabel = ({ children }) => <p className="mb-3 text-[12px] font-semibold uppercase tracking-[.1em] text-ink-3">{children}</p>;
const Foot = ({ children }) => <div className="mt-7 flex flex-wrap items-center gap-x-7 gap-y-3 border-t border-line pt-5 text-[14px]">{children}</div>;
const FootLink = ({ to, children }) => <Link to={to} className="inline-flex items-center gap-1.5 font-medium text-ink-2 hover:text-ink">{children}<Icon name="ArrowRight" size={13} /></Link>;

function ProductsMenu() {
  return (
    <>
      <div className="grid grid-cols-4 gap-8 xl:gap-10">
        {PRODUCT_MENU.map((l) => (
          <div key={l.key} className="min-w-0" style={{ '--acc': l.acc }}>
            <Link to={l.path} className="group block border-b border-line pb-4">
              <span className="flex items-center gap-2">
                <span className="h-2 w-2 rounded-full" style={{ background: l.acc, boxShadow: `0 0 12px ${l.acc}` }} />
                <span className="text-[16px] font-semibold tracking-[-0.01em] text-ink group-hover:text-fg">{l.name}</span>
                <span className="ml-auto rounded-full border border-line-2 px-2 py-0.5 text-[11.5px] font-medium text-ink-3">{l.tag}</span>
              </span>
              <span className="mt-1.5 block text-[13.5px] leading-snug text-ink-3">{l.blurb}</span>
            </Link>
            {l.kind === 'products' ? (
              <div className="mt-3">{l.items.map((m) => <Item key={m.path} to={m.path} name={m.name} desc={m.desc} />)}</div>
            ) : (
              <>
                <p className="mb-1 mt-4 text-[12px] font-semibold uppercase tracking-[.1em] text-ink-3">What it covers</p>
                <ul>
                  {l.items.map((m) => (
                    <li key={m.name}>
                      <Link to={m.path} className="group flex items-center gap-2.5 rounded-[10px] py-[7px] text-[14.5px] text-ink-2 hover:text-ink">
                        <svg width="14" height="14" viewBox="0 0 14 14" aria-hidden="true" className="shrink-0" style={{ color: l.acc }}><path d="m3 7.3 2.6 2.5L11 4.3" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" /></svg>
                        {m.name}
                      </Link>
                    </li>
                  ))}
                </ul>
                <p className="mt-3 text-[12.5px] leading-relaxed text-ink-3">{l.covers}</p>
              </>
            )}
            <Link to={l.path} className="link mt-4 text-[14px]">Explore {l.name}<Icon name="ArrowRight" size={13} weight="bold" /></Link>
          </div>
        ))}
      </div>
      <Foot>
        <FootLink to="/products">All products</FootLink>
        <FootLink to="/platform">How the products work together</FootLink>
        <span className="ml-auto text-ink-3">Not sure where to start? <Link to="/request-demo" className="font-medium text-cyan-2 hover:text-fg">Talk to an engineer</Link></span>
      </Foot>
    </>
  );
}

function SolutionsMenu() {
  return (
    <>
      <div className="grid grid-cols-[1fr_1.35fr] gap-12">
        <div>
          <GroupLabel>By industry</GroupLabel>
          {SOLUTIONS.map((s) => <Item key={s.slug} to={`/solutions/${s.slug}`} name={s.name} desc={s.desc} />)}
        </div>
        <div>
          <GroupLabel>By challenge</GroupLabel>
          <div className="grid grid-cols-2 gap-x-8">{CHALLENGES.map((c) => <Item key={c.name} to={c.path} name={c.name} desc={c.desc} />)}</div>
        </div>
      </div>
      <Foot><FootLink to="/products">Compare all products</FootLink><FootLink to="/platform">Why Deep Algorithms</FootLink></Foot>
    </>
  );
}

function ResearchMenu() {
  return (
    <>
      <div className="grid grid-cols-[1fr_1.6fr] gap-12">
        <div>
          <GroupLabel>Topics</GroupLabel>
          <ul className="grid grid-cols-1 gap-0.5">
            {TOPICS.map((t) => (
              <li key={t.name}>
                <Link to={`/blogs?topic=${topicSlug(t.name)}`} className="flex items-center justify-between rounded-[10px] px-3 py-2 text-[14.5px] text-ink-2 hover:bg-fg/[.05] hover:text-ink -mx-3">
                  {t.name}<span className="text-[12.5px] text-ink-3 num">{t.n}</span>
                </Link>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <GroupLabel>Latest</GroupLabel>
          {POSTS.slice(0, 3).map((p) => (
            <Link key={p.slug} to={`/blogs/${p.slug}`} className="group -mx-3 flex gap-4 rounded-[12px] px-3 py-3 hover:bg-fg/[.05]">
              <span className="w-[112px] shrink-0 pt-0.5 text-[12.5px] font-medium text-cyan-2">{p.category}</span>
              <span>
                <span className="block text-[15px] font-medium leading-snug text-ink">{p.title}</span>
                <span className="mt-1 block text-[13px] text-ink-3">{p.read} min read</span>
              </span>
            </Link>
          ))}
        </div>
      </div>
      <Foot><FootLink to="/blogs">All research</FootLink></Foot>
    </>
  );
}

function CompanyMenu() {
  return (
    <>
      <div className="grid grid-cols-[1.3fr_1fr] gap-12">
        <div className="grid grid-cols-2 gap-x-8">{COMPANY_MENU.map((c) => <Item key={c.name} to={c.path} name={c.name} desc={c.desc} />)}</div>
        <div className="border-l border-line pl-10">
          <GroupLabel>Offices</GroupLabel>
          <ul className="space-y-3 text-[14.5px]">
            <li><span className="font-medium text-ink">Hyderabad</span> <span className="text-ink-3">· Headquarters</span></li>
            <li><span className="font-medium text-ink">Bengaluru</span></li>
            <li><span className="font-medium text-ink">Maryland, USA</span></li>
          </ul>
          <p className="mt-6 text-[14px] text-ink-3"><a href="mailto:info@deepalgorithms.in" className="text-ink-2 hover:text-ink">info@deepalgorithms.in</a><br /><a href="tel:+917702846856" className="text-ink-2 hover:text-ink">+91 77028 46856</a></p>
        </div>
      </div>
      <Foot><FootLink to="/about-us">About Deep Algorithms</FootLink><FootLink to="/contact">Contact us</FootLink></Foot>
    </>
  );
}

const NAV = [
  { label: 'Products', menu: ProductsMenu },
  { label: 'Solutions', menu: SolutionsMenu },
  { label: 'Why Deep Algorithms', to: '/platform' },
  { label: 'Research', menu: ResearchMenu },
  { label: 'Company', menu: CompanyMenu },
];

function MobileMenu({ onNav }) {
  const Section = ({ title, children, open }) => (
    <details className="group border-b border-line" open={open}>
      <summary className="flex cursor-pointer list-none items-center justify-between py-4 text-[19px] font-semibold tracking-[-0.01em]">
        {title}<Icon name="CaretDown" size={16} className="text-ink-3 transition-transform group-open:rotate-180" />
      </summary>
      <div className="pb-6">{children}</div>
    </details>
  );
  return (
    <nav aria-label="Mobile" className="wrap pb-10 pt-2">
      <Section title="Products" open>
        <div className="space-y-6">
          {PRODUCT_MENU.map((l) => (
            <div key={l.key}>
              <Link to={l.path} onClick={onNav} className="flex items-center gap-2 text-[16px] font-semibold"><span className="h-2 w-2 rounded-full" style={{ background: l.acc }} />{l.name}<span className="ml-1 text-[12.5px] font-normal text-ink-3">{l.tag}</span></Link>
              <ul className="mt-2 space-y-1 border-l border-line pl-4">
                {l.items.map((m) => <li key={m.name}><Link to={m.path} onClick={onNav} className="block py-1.5 text-[15px] text-ink-2">{m.name}</Link></li>)}
              </ul>
            </div>
          ))}
          <Link to="/products" onClick={onNav} className="link text-[15px]">All products<Icon name="ArrowRight" size={13} weight="bold" /></Link>
        </div>
      </Section>
      <Section title="Solutions">
        <p className="mb-2 text-[12px] font-semibold uppercase tracking-[.1em] text-ink-3">By industry</p>
        <ul className="mb-5 space-y-1">{SOLUTIONS.map((s) => <li key={s.slug}><Link to={`/solutions/${s.slug}`} onClick={onNav} className="block py-1.5 text-[15px] text-ink-2">{s.name}</Link></li>)}</ul>
        <p className="mb-2 text-[12px] font-semibold uppercase tracking-[.1em] text-ink-3">By challenge</p>
        <ul className="space-y-1">{CHALLENGES.map((c) => <li key={c.name}><Link to={c.path} onClick={onNav} className="block py-1.5 text-[15px] text-ink-2">{c.name}</Link></li>)}</ul>
      </Section>
      <Link to="/platform" onClick={onNav} className="block border-b border-line py-4 text-[19px] font-semibold tracking-[-0.01em]">Why Deep Algorithms</Link>
      <Section title="Research">
        <ul className="space-y-1">
          <li><Link to="/blogs" onClick={onNav} className="block py-1.5 text-[15px] text-ink">All research</Link></li>
          {TOPICS.map((t) => <li key={t.name}><Link to={`/blogs?topic=${topicSlug(t.name)}`} onClick={onNav} className="block py-1.5 text-[15px] text-ink-2">{t.name}</Link></li>)}
        </ul>
      </Section>
      <Section title="Company">
        <ul className="space-y-1">{COMPANY_MENU.map((c) => <li key={c.name}><Link to={c.path} onClick={onNav} className="block py-1.5 text-[15px] text-ink-2">{c.name}</Link></li>)}</ul>
      </Section>
      <div className="mt-8 grid gap-3 sm:grid-cols-2">
        <Button to="/request-demo" onClick={onNav} className="w-full">Book a demo</Button>
        <Button to="/contact" variant="ghost" onClick={onNav} className="w-full">Contact us</Button>
      </div>
    </nav>
  );
}

export default function Header() {
  const [open, setOpen] = useState(null);
  const [mobile, setMobile] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [overLight, setOverLight] = useState(false);
  const timer = useRef();
  const { pathname, search, hash } = useLocation();

  useEffect(() => { setOpen(null); setMobile(false); }, [pathname, search, hash]);
  useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') { setOpen(null); setMobile(false); } };
    // Light when a light sheet sits under the bar (mixed theme only; CSS ignores it in dark).
    let raf = 0;
    const measure = () => {
      raf = 0;
      setScrolled(window.scrollY > 8);
      let light = false;
      for (const el of document.querySelectorAll('.page > :not(.stage, .fixed)')) {
        const r = el.getBoundingClientRect();
        if (r.top <= 40 && r.bottom >= 32) { light = true; break; }
      }
      setOverLight(light);
    };
    const onScroll = () => { if (!raf) raf = requestAnimationFrame(measure); };
    measure();
    window.addEventListener('keydown', onKey);
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    return () => { cancelAnimationFrame(raf); window.removeEventListener('keydown', onKey); window.removeEventListener('scroll', onScroll); window.removeEventListener('resize', onScroll); };
  }, []);
  // re-measure once the next page has rendered
  useEffect(() => { const t = setTimeout(() => window.dispatchEvent(new Event('scroll')), 120); return () => clearTimeout(t); }, [pathname]);
  useEffect(() => { document.body.style.overflow = mobile ? 'hidden' : ''; }, [mobile]);

  const enter = (l) => { clearTimeout(timer.current); timer.current = setTimeout(() => setOpen(l), open ? 0 : 90); };
  const leave = () => { clearTimeout(timer.current); timer.current = setTimeout(() => setOpen(null), 200); };
  const Menu = NAV.find((n) => n.label === open)?.menu;
  const solid = scrolled || open || mobile;
  const light = overLight || open || mobile;

  return (
    <header className={cx('fixed inset-x-0 top-0 z-50', light && 'tone-l')} onMouseLeave={leave}>
      <a href="#main" className="sr-only-focusable absolute left-4 top-3 z-50 rounded-full bg-white px-4 py-2 text-[#04121f]">Skip to content</a>
      <div aria-hidden="true" className={cx('hdr-bg absolute inset-0 -z-10 border-b', solid ? 'solid border-line bg-[#05080f]/80 backdrop-blur-xl' : 'border-transparent bg-transparent')} />
      <div className="wrap flex h-[72px] items-center gap-6">
        <Link to="/" aria-label="Deep Algorithms home" className="shrink-0"><Logo dual /></Link>
        <nav aria-label="Primary" className="hidden flex-1 lg:block">
          <ul className="flex items-center gap-0.5 xl:gap-1">
            {NAV.map((n) => (
              <li key={n.label}>
                {n.menu ? (
                  <button type="button" aria-expanded={open === n.label} aria-controls="mega" onMouseEnter={() => enter(n.label)} onClick={() => setOpen(open === n.label ? null : n.label)}
                    className={cx('inline-flex h-10 items-center gap-1.5 rounded-full px-3.5 text-[15px] font-medium transition-colors', open === n.label ? 'bg-fg/[.07] text-ink' : 'text-ink-2 hover:text-ink')}>
                    {n.label}<Icon name="CaretDown" size={11} weight="bold" className={cx('transition-transform duration-300', open === n.label && 'rotate-180')} />
                  </button>
                ) : (
                  <Link to={n.to} onMouseEnter={() => { clearTimeout(timer.current); setOpen(null); }} aria-current={pathname === n.to ? 'page' : undefined}
                    className={cx('inline-flex h-10 items-center rounded-full px-3.5 text-[15px] font-medium transition-colors hover:text-ink', pathname === n.to ? 'text-ink' : 'text-ink-2')}>{n.label}</Link>
                )}
              </li>
            ))}
          </ul>
        </nav>
        <div className="ml-auto flex items-center gap-2 lg:ml-0">
          <Link to="/contact" className="hidden h-10 items-center rounded-full px-3.5 text-[15px] font-medium text-ink-2 transition-colors hover:text-ink xl:inline-flex">Contact</Link>
          <ThemeButton />
          <Button to="/request-demo" size="sm" className="max-sm:hidden">Book a demo</Button>
          <button type="button" className="inline-flex h-11 w-11 items-center justify-center rounded-full text-ink lg:hidden" aria-label={mobile ? 'Close menu' : 'Open menu'} aria-expanded={mobile} aria-controls="mobile-menu" onClick={() => setMobile(!mobile)}>
            <Icon name={mobile ? 'X' : 'List'} size={26} />
          </button>
        </div>
      </div>

      {Menu && (
        <div id="mega" onMouseEnter={() => clearTimeout(timer.current)} className="mega absolute inset-x-0 top-full hidden border-b border-line bg-bg/[.97] shadow-[0_40px_80px_-30px_rgba(0,0,0,.6)] lg:block">
          <div key={open} className="wrap fadein py-9"><Menu /></div>
        </div>
      )}
      {mobile && (
        <div id="mobile-menu" className="fixed inset-x-0 bottom-0 top-[72px] z-40 overflow-y-auto bg-bg lg:hidden">
          <MobileMenu onNav={() => setMobile(false)} />
        </div>
      )}
    </header>
  );
}
