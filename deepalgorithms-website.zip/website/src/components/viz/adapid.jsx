import { Viz, Win, Chip, Gl, Logo, Av, cx } from './kit.jsx';
import { Ring } from './home.jsx';

const ADAP = '#3cc8f6';

/* A1. One identity's morning: each event raises the score, with the reason. */
const DAY = [
  ['09:12', 'Signed in from Mumbai', 'Managed laptop · MFA', 12, 'ok'],
  ['11:05', 'Signed in from Lagos', 'New device · 2 h after Mumbai', 58, 'warn'],
  ['11:07', 'Created a mailbox forwarding rule', 'First time in 14 months', 81, 'crit'],
  ['11:09', 'Downloaded 3,200 files', '40× the daily median', 94, 'crit'],
];
export function AdapRiskTimeline({ k: fk } = {}) {
  return (
    <Viz k={fk} steps={[500, 900, 900, 900, 900, 1000]} hold={4000} label="Illustration: Kavya Reddy's risk score rises from 12 to 94 as a sign-in from a new device, a forwarding rule and a bulk download follow each other; the session is held and step-up is sent.">
      {(k) => {
        const score = k >= 1 ? DAY[Math.min(k, 4) - 1][3] : 12;
        const col = score > 75 ? '#ff6b5d' : score > 40 ? '#f6b955' : '#3fd98f';
        return (
          <Win title="Identity risk" right={<Chip tone="info" plain>adapID AI</Chip>} glow="rgb(0 174 239 / .45)">
            <div className="flex items-center gap-[1em]">
              <Av name="Kavya Reddy" i={3} />
              <span className="min-w-0"><span className="block text-[1.15em] font-semibold">Kavya Reddy</span><span className="block vz-m">Treasury analyst · Okta, Microsoft 365</span></span>
              <span className="ml-auto flex items-center gap-[.6em]"><Ring v={score} color={col} /><span className="hidden vz-m sm:block">risk<br />score</span></span>
            </div>
            <div className="relative mt-[1.1em] space-y-[.55em] pl-[1.6em]">
              <span className="absolute bottom-[.8em] left-[.45em] top-[.8em] w-[2px] rounded-full" style={{ background: 'linear-gradient(#3fd98f, #f6b955 45%, #ff6b5d)' }} />
              {DAY.map((d, i) => (
                <div key={d[0]} className={cx(`s${i + 1}`, 'relative flex items-center gap-[.7em] rounded-[.7em] px-[.8em] py-[.55em]')} style={{ background: d[4] === 'crit' ? 'rgb(255 107 93 / .07)' : 'rgb(255 255 255 / .03)', border: '1px solid rgb(160 190 230 / .08)' }}>
                  <span className="absolute left-[-1.42em] h-[.75em] w-[.75em] rounded-full" style={{ background: d[4] === 'ok' ? '#3fd98f' : d[4] === 'warn' ? '#f6b955' : '#ff6b5d', boxShadow: '0 0 0 .25em #0b111c' }} />
                  <span className="vz-mono w-[3.4em] shrink-0">{d[0]}</span>
                  <span className="min-w-0"><span className="block truncate vz-t">{d[1]}</span><span className="block truncate vz-m">{d[2]}</span></span>
                  <span className="ml-auto vz-mono num" style={{ color: d[4] === 'ok' ? '#7fe3b2' : d[4] === 'warn' ? '#ffd28a' : '#ffaaa1' }}>+{i ? d[3] - DAY[i - 1][3] : d[3]}</span>
                </div>
              ))}
            </div>
            <div className="s5 mt-[1em] flex flex-wrap items-center gap-[.6em] rounded-[.8em] px-[.9em] py-[.7em]" style={{ background: 'rgb(0 174 239 / .08)', border: '1px solid rgb(0 174 239 / .3)' }}>
              <Gl g="lock" className="h-[1.2em] w-[1.2em]" style={{ color: '#6fd4ff' }} />
              <span className="vz-t">Session held · step-up sent to the registered phone</span>
              <span className="ml-auto vz-m">by policy, in 1.4 s</span>
            </div>
          </Win>
        );
      }}
    </Viz>
  );
}

/* A3. NHI for AWS: the account graph, and what a role uses against what it has. */
export function NhiGraph({ k: fk } = {}) {
  const nodes = [
    { id: 'acct', x: 50, y: 14, l: 'prod · 4471', g: 'cloud', c: '#ffd27a' },
    { id: 'l1', x: 18, y: 48, l: 'lambda-kyc-sync', g: 'bolt', c: '#ff8b7e', hot: true },
    { id: 'l2', x: 50, y: 52, l: 'ecs-notify-svc', g: 'server', c: '#9fb4cf' },
    { id: 'l3', x: 82, y: 48, l: 'glue-ledger-etl', g: 'db', c: '#9fb4cf' },
    { id: 'r1', x: 12, y: 86, l: 'secrets/*', g: 'key', c: '#ff8b7e', hot: true },
    { id: 'r2', x: 36, y: 88, l: 's3://kyc-docs', g: 'db', c: '#9fb4cf' },
    { id: 'r3', x: 66, y: 88, l: 'sns:notify', g: 'mail', c: '#9fb4cf' },
    { id: 'r4', x: 88, y: 86, l: 's3://ledger', g: 'db', c: '#9fb4cf' },
  ];
  const edges = [['acct', 'l1'], ['acct', 'l2'], ['acct', 'l3'], ['l1', 'r1'], ['l1', 'r2'], ['l2', 'r3'], ['l3', 'r4'], ['l2', 'r2']];
  const N = Object.fromEntries(nodes.map((n) => [n.id, n]));
  return (
    <Viz k={fk} steps={[500, 800, 800, 900, 1000]} hold={4000} label="Illustration: an AWS account graph shows a Lambda role with access to every secret; it has 214 permissions and has used 9 in 90 days.">
      {(k) => (
        <Win title="Non-human identities · AWS" right={<Chip tone="info" plain>adapID NHI</Chip>} glow="rgb(255 160 60 / .35)">
          <div className="grid gap-[1em]" style={{ gridTemplateColumns: '1.35fr 1fr' }}>
            <div className="relative" style={{ aspectRatio: '1.2' }}>
              <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="absolute inset-0 h-full w-full" aria-hidden="true">
                {edges.map(([a, b], i) => {
                  const hot = N[a].hot || N[b].hot;
                  return <line key={i} x1={N[a].x} y1={N[a].y} x2={N[b].x} y2={N[b].y} stroke={hot && k >= 3 ? 'rgb(255 107 93 / .7)' : 'rgb(140 180 230 / .28)'} strokeWidth="1.2" vectorEffect="non-scaling-stroke" className={i < 3 ? 's1' : 's2'} />;
                })}
              </svg>
              {nodes.map((n, i) => (
                <span key={n.id} className={cx(i < 4 ? 's1' : 's2', 'absolute flex -translate-x-1/2 -translate-y-1/2 flex-col items-center')} style={{ left: `${n.x}%`, top: `${n.y}%` }}>
                  <span className="vz-ic relative" style={{ color: n.hot && k >= 3 ? '#ff8b7e' : n.c, width: '2em', height: '2em', borderColor: n.hot && k >= 3 ? 'rgb(255 107 93 / .55)' : undefined }}>
                    <Gl g={n.g} />{n.hot && k >= 3 && <span className="ping-h" style={{ color: 'rgb(255 107 93 / .6)' }} />}
                  </span>
                  <span className="mt-[.25em] whitespace-nowrap vz-mono" style={{ fontSize: '.7em' }}>{n.l}</span>
                </span>
              ))}
            </div>
            <div className="s3 flex flex-col gap-[.7em]">
              <div className="vz-panel" style={{ padding: '.8em .9em' }}>
                <span className="block vz-mono" style={{ color: '#ffaaa1' }}>lambda-kyc-sync</span>
                <span className="mt-[.5em] block vz-m">Posture score</span>
                <span className="block text-[1.9em] font-semibold num" style={{ color: '#ff7d70' }}>38<span className="vz-m" style={{ fontSize: '.45em' }}> / 100</span></span>
              </div>
              <div className="vz-panel" style={{ padding: '.8em .9em' }}>
                <span className="block vz-m">Permissions in 90 days</span>
                <div className="mt-[.5em] space-y-[.45em]">
                  <div><div className="flex justify-between vz-m"><span>Granted</span><span className="text-white num">214</span></div><div className="vz-meter mt-[.25em]"><i style={{ '--w': '100%', '--mc': '#5d6b82' }} /></div></div>
                  <div><div className="flex justify-between vz-m"><span>Used</span><span className="text-white num">9</span></div><div className="vz-meter mt-[.25em]"><i style={{ '--w': k >= 4 ? '4.2%' : '0%', '--mc': '#3cc8f6' }} /></div></div>
                </div>
              </div>
              <div className="s5"><Chip tone="crit">secretsmanager:* on every secret</Chip></div>
            </div>
          </div>
        </Win>
      )}
    </Viz>
  );
}

/* A5. Fraud: five signals fuse into one decision before money moves. */
export const FRAUD_CASES = {
  mule: { label: 'Mule payee', event: '₹2,40,000 to a new payee', who: 'Anita Desai → Sunil Verma', sig: [62, 30, 96, 48, 88], d: ['Blocked', 'crit'], why: 'Payee shares a device with 22 other accounts', ms: 74 },
  ato: { label: 'Account takeover', event: 'Password reset, then login', who: 'Rohit Menon · net banking', sig: [91, 84, 40, 72, 35], d: ['Step-up', 'warn'], why: 'New device and typing rhythm unlike the owner’s', ms: 61 },
  sim: { label: 'SIM swap', event: 'OTP to a new SIM', who: 'Meera Pillai · UPI', sig: [88, 55, 52, 80, 64], d: ['Hold 4 h', 'warn'], why: 'SIM changed 3 hours before the first payment', ms: 69 },
  synthetic: { label: 'Synthetic onboarding', event: 'New account application', who: 'Applicant 7731', sig: [45, 38, 90, 66, 22], d: ['Review', 'warn'], why: 'PAN and phone seen together on 9 other applications', ms: 78 },
  good: { label: 'Genuine customer', event: '₹4,500 to a known payee', who: 'Kiran Patil · mobile app', sig: [8, 6, 10, 5, 12], d: ['Approved', 'ok'], why: 'Known device, usual amount, usual time', ms: 41 },
};
const SIG = ['Device', 'Behaviour', 'Identity graph', 'Network', 'Transaction'];
export function FraudDecision({ scenario = 'mule', k: fk }) {
  const c = FRAUD_CASES[scenario];
  return (
    <Viz k={fk} key={scenario} steps={[400, 500, 500, 500, 500, 500, 800]} hold={4200} label={`Illustration: ${c.event}. Five signals are scored and the decision is ${c.d[0]} in ${c.ms} milliseconds because ${c.why.toLowerCase()}.`}>
      {(k) => (
        <Win title="Fraud decision" right={<span className="vz-mono">{k >= 7 ? `${c.ms} ms` : '…'}</span>} glow="rgb(0 174 239 / .45)">
          <div className="flex items-center gap-[.8em] rounded-[.8em] px-[.9em] py-[.7em]" style={{ background: 'rgb(255 255 255 / .04)' }}>
            <span className="vz-ic" style={{ color: ADAP }}><Gl g="money" /></span>
            <span className="min-w-0"><span className="block vz-t">{c.event}</span><span className="block truncate vz-m">{c.who}</span></span>
          </div>
          <div className="mt-[1em] space-y-[.7em]">
            {SIG.map((s, i) => {
              const v = c.sig[i], col = v > 75 ? '#ff6b5d' : v > 45 ? '#f6b955' : '#3fd98f';
              return (
                <div key={s} className={`s${i + 1}`}>
                  <div className="flex justify-between vz-m"><span>{s}</span><span className="num" style={{ color: col }}>{k > i ? v : 0}</span></div>
                  <div className="vz-meter mt-[.3em]"><i style={{ '--w': `${k > i ? v : 0}%`, '--mc': col }} /></div>
                </div>
              );
            })}
          </div>
          <div className={cx('s6 mt-[1.1em] flex items-center gap-[.8em] rounded-[.8em] px-[.9em] py-[.75em]')} style={{ background: c.d[1] === 'ok' ? 'rgb(63 217 143 / .08)' : c.d[1] === 'warn' ? 'rgb(246 185 85 / .08)' : 'rgb(255 107 93 / .1)', border: `1px solid ${c.d[1] === 'ok' ? 'rgb(63 217 143 / .3)' : c.d[1] === 'warn' ? 'rgb(246 185 85 / .32)' : 'rgb(255 107 93 / .35)'}` }}>
            <Chip tone={c.d[1]}>{c.d[0]}</Chip><span className="min-w-0 truncate vz-t">{c.why}</span>
          </div>
        </Win>
      )}
    </Viz>
  );
}

/* A6. Mule network: one payee, many accounts behind one device. */
export function MuleNetwork({ k: fk } = {}) {
  const ring = Array.from({ length: 12 }, (_, i) => i);
  return (
    <Viz k={fk} steps={[500, 900, 900, 900]} hold={3800} label="Illustration: a new payee is linked through one device to many other accounts, the signature of a mule network.">
      {(k) => (
        <div className="relative" style={{ aspectRatio: '1.35' }}>
          <svg viewBox="0 0 135 100" className="absolute inset-0 h-full w-full" aria-hidden="true">
            {ring.map((i) => { const a = (i / ring.length) * Math.PI * 2; return <line key={i} x1="80" y1="50" x2={80 + Math.cos(a) * 34} y2={50 + Math.sin(a) * 34} stroke={k >= 3 ? 'rgb(255 107 93 / .5)' : 'rgb(140 180 230 / .25)'} strokeWidth=".5" className="s2" />; })}
            <line x1="22" y1="50" x2="66" y2="50" stroke="rgb(0 174 239 / .7)" strokeWidth=".8" className="flowline s1" />
          </svg>
          <span className="s1 absolute flex -translate-x-1/2 -translate-y-1/2 flex-col items-center" style={{ left: `${(22 / 135) * 100}%`, top: '50%' }}>
            <span className="vz-ic" style={{ color: ADAP, width: '2.4em', height: '2.4em', borderRadius: '50%' }}><Gl g="user" /></span>
            <span className="mt-[.3em] vz-m">Customer</span>
          </span>
          <span className="s1 absolute flex -translate-x-1/2 -translate-y-1/2 flex-col items-center" style={{ left: `${(80 / 135) * 100}%`, top: '50%' }}>
            <span className="vz-ic relative" style={{ color: k >= 3 ? '#ff8b7e' : '#ffd27a', width: '2.8em', height: '2.8em', borderRadius: '50%' }}><Gl g="phone" />{k >= 3 && <span className="ping-h" style={{ color: 'rgb(255 107 93 / .6)', borderRadius: '50%' }} />}</span>
          </span>
          {ring.map((i) => { const a = (i / ring.length) * Math.PI * 2; return (
            <span key={i} className="s2 absolute -translate-x-1/2 -translate-y-1/2" style={{ left: `${((80 + Math.cos(a) * 34) / 135) * 100}%`, top: `${50 + Math.sin(a) * 34}%` }}>
              <span className="vz-ic" style={{ width: '1.6em', height: '1.6em', borderRadius: '50%', color: k >= 3 ? '#ff8b7e' : '#9fb4cf' }}><Gl g="bank" /></span>
            </span>); })}
          <div className="s4 vz-pop absolute bottom-[2%] left-[2%]" style={{ padding: '.7em .9em', width: '46%', '--glow': 'rgb(255 107 93 / .45)' }}>
            <span className="block vz-t">One device, 23 accounts</span><span className="block vz-m">Payee blocked before the transfer</span>
          </div>
        </div>
      )}
    </Viz>
  );
}

/* A7. Active Directory: the path to Domain Admins, and the one change that cuts it. */
const HOPS = [
  { l: 'r.kapoor', s: 'Phished user', g: 'user' },
  { l: 'WKS-2140', s: 'Local admin', g: 'laptop' },
  { l: 'svc-sql-report', s: 'Kerberoastable', g: 'key' },
  { l: 'Server Admins', s: 'Nested group', g: 'tree' },
  { l: 'Domain Admins', s: 'Tier 0', g: 'shield' },
];
export function AdPath({ k: fk } = {}) {
  return (
    <Viz k={fk} steps={[500, 600, 600, 600, 600, 1100, 1000]} hold={4200} label="Illustration: an attack path runs from a phished user through a workstation, a Kerberoastable service account and a nested group to Domain Admins; removing the service account from Server Admins closes 41 paths.">
      {(k) => {
        const cut = k >= 6;
        return (
          <Win title="Attack paths · corp.local" right={cut ? <Chip tone="ok">41 paths closed</Chip> : <Chip tone="crit">4 hops to Tier 0</Chip>} glow="rgb(0 174 239 / .4)">
            <div className="relative flex items-start justify-between gap-[.3em] px-[.2em] pt-[.6em]">
              <svg viewBox="0 0 100 10" preserveAspectRatio="none" className="absolute left-[8%] right-[8%] top-[2.1em] h-[1em] w-[84%]" aria-hidden="true">
                {HOPS.slice(1).map((_, i) => (
                  <line key={i} x1={i * 25} y1="5" x2={(i + 1) * 25} y2="5" stroke={cut && i >= 2 ? 'rgb(140 160 190 / .25)' : 'rgb(255 107 93 / .75)'} strokeWidth="2" vectorEffect="non-scaling-stroke" className={cx(`s${i + 2}`, !cut && 'flowline')} strokeDasharray={cut && i === 2 ? '2 4' : undefined} />
                ))}
              </svg>
              {HOPS.map((h, i) => (
                <span key={h.l} className={cx(`s${i + 1}`, 'relative z-[1] flex w-[18%] flex-col items-center text-center')}>
                  <span className="vz-ic" style={{ width: '2.6em', height: '2.6em', borderRadius: '.8em', background: '#0f1726', color: cut && i >= 3 ? '#7f8da3' : i === 4 ? '#ff8b7e' : '#cfe1f7', borderColor: !cut && i === 4 ? 'rgb(255 107 93 / .6)' : undefined }}><Gl g={h.g} /></span>
                  <span className="mt-[.45em] block w-full truncate vz-t" style={{ fontSize: '.85em' }}>{h.l}</span>
                  <span className="block w-full truncate vz-m" style={{ fontSize: '.75em' }}>{h.s}</span>
                </span>
              ))}
            </div>
            <div className={cx('s6 mt-[1.3em] rounded-[.8em] px-[.9em] py-[.75em]')} style={{ background: 'rgb(63 217 143 / .08)', border: '1px solid rgb(63 217 143 / .3)' }}>
              <span className="block vz-h" style={{ color: '#7fe3b2' }}>The one change that closes the most</span>
              <span className="mt-[.3em] block vz-t">Remove svc-sql-report from Server Admins</span>
              <span className="mt-[.2em] block vz-m">Closes 41 of 57 paths to Domain Admins · no business impact found</span>
            </div>
            <div className="s7 mt-[.8em] grid grid-cols-3 gap-[.5em]">
              {[['Kerberoasting', 'Password rotated'], ['Pass-the-hash', 'Sessions revoked'], ['DCSync attempt', 'Host isolated']].map(([t, r]) => (
                <span key={t} className="rounded-[.6em] px-[.6em] py-[.5em]" style={{ background: 'rgb(255 255 255 / .04)' }}><span className="block truncate vz-t" style={{ fontSize: '.82em' }}>{t}</span><span className="block truncate vz-m" style={{ fontSize: '.76em', color: '#7fe3b2' }}>{r}</span></span>
              ))}
            </div>
          </Win>
        );
      }}
    </Viz>
  );
}

/* Connectors strip used on adapID pages */
export function Connectors({ keys, k: fk }) {
  return (
    <ul className="flex flex-wrap items-center gap-2.5">
      {keys.map((k) => (
        <li key={k} className="inline-flex h-11 items-center gap-2 rounded-full border border-line bg-fg/[.03] px-4 text-[14px] text-ink-2"><Logo k={k} size="18px" color="currentColor" />{({ okta: 'Okta', ad: 'Active Directory', m365: 'Microsoft 365', google: 'Google Workspace', aws: 'AWS', github: 'GitHub', atlassian: 'Atlassian', azure: 'Microsoft Entra ID', gitlab: 'GitLab', upi: 'UPI', snowflake: 'Snowflake', databricks: 'Databricks', postgres: 'PostgreSQL', cloudflare: 'Cloudflare', gcp: 'Google Cloud', kubernetes: 'Kubernetes' })[k] || k}</li>
      ))}
    </ul>
  );
}
