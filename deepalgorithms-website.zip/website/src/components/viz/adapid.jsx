import { Viz, Win, Chip, Gl, Logo, App, Av, cx } from './kit.jsx';
import { Ring } from './home.jsx';

const ADAP = '#3cc8f6';

/* A1. Continuous identity risk: signals from every system one person uses
   raise a single live score, with the reason for each point; when the score
   crosses the policy line, the response runs across those same systems. */
const DAY = [
  ['okta', '09:12', 'Signed in from Mumbai', 'Managed laptop · MFA', 12, 'ok', 'Normal'],
  ['okta', '11:05', 'Signed in from Lagos', 'New device · 2 h after Mumbai', 58, 'warn', 'Impossible travel'],
  ['outlook', '11:07', 'Mail forwarding rule to a Gmail address', 'First time in 14 months', 81, 'crit', 'Never seen'],
  ['salesforce', '11:09', 'Exported 3,200 customer records', '40× this role’s daily median', 94, 'crit', 'Peer outlier'],
];
const RESPOND = [['okta', 'Okta', 'All sessions revoked'], ['m365', 'Microsoft 365', 'Forwarding rule removed'], ['slack', 'Slack', 'SOC and manager told, with reasons']];
export function AdapRiskTimeline({ k: fk } = {}) {
  return (
    <Viz k={fk} steps={[500, 900, 950, 950, 950, 900, 1000]} hold={4200} label="Illustration: Kavya Reddy's identity risk score rises from 12 to 94 as an Okta sign-in from Lagos, a new Microsoft 365 forwarding rule and a bulk Salesforce export follow each other; at the policy line adapID revokes her Okta sessions, removes the rule and alerts the SOC on Slack.">
      {(k) => {
        const n = Math.max(1, Math.min(k, 4));
        const score = DAY[n - 1][4];
        const col = score >= 80 ? '#ff6b5d' : score >= 50 ? '#f6b955' : '#3fd98f';
        // score line through the morning, drawn up to the latest event
        const pts = DAY.slice(0, n).map((d, i) => [6 + i * 29, 52 - (d[4] / 100) * 46]);
        const line = pts.map((p, i) => `${i ? 'L' : 'M'}${p[0]} ${p[1].toFixed(1)}`).join(' ');
        return (
          <Win title="adapID AI · Identity risk" right={k >= 6 ? <Chip tone="ok">Contained · 1.4 s</Chip> : <Chip tone="info">Live</Chip>} glow="rgb(0 174 239 / .45)">
            <div className="flex items-center gap-[.9em]">
              <Av name="Kavya Reddy" i={3} />
              <span className="min-w-0">
                <span className="block text-[1.12em] font-semibold">Kavya Reddy</span>
                <span className="flex items-center gap-[.4em] vz-m">Treasury · watched across <Logo k="okta" size="1em" /><Logo k="m365" size="1em" /><Logo k="salesforce" size="1em" /><Logo k="aws" size="1.2em" /></span>
              </span>
              <span className="ml-auto flex items-center gap-[.55em]"><Ring v={score} color={col} /><span className="vz-m">risk<br />score</span></span>
            </div>

            <div className="mt-[1em] grid gap-[.9em]" style={{ gridTemplateColumns: '1.5fr 1fr' }}>
              <div className="space-y-[.45em]">
                {DAY.map((d, i) => (
                  <div key={d[1]} className={cx(`s${i + 1}`, 'flex items-center gap-[.6em] rounded-[.7em] px-[.6em] py-[.5em]')} style={{ background: d[5] === 'crit' ? 'rgb(255 107 93 / .07)' : 'rgb(255 255 255 / .03)', border: `1px solid ${d[5] === 'crit' ? 'rgb(255 107 93 / .22)' : 'rgb(160 190 230 / .08)'}` }}>
                    <App k={d[0]} />
                    <span className="min-w-0 flex-1"><span className="block truncate vz-t" style={{ fontSize: '.92em' }}>{d[2]}</span><span className="block truncate vz-m" style={{ fontSize: '.8em' }}>{d[1]} · {d[3]}</span></span>
                    <span className="shrink-0 text-right"><span className="block vz-mono num" style={{ color: d[5] === 'ok' ? '#7fe3b2' : d[5] === 'warn' ? '#ffd28a' : '#ffaaa1' }}>+{i ? d[4] - DAY[i - 1][4] : d[4]}</span></span>
                  </div>
                ))}
              </div>
              <div className="vz-panel flex flex-col" style={{ padding: '.7em .7em .5em' }}>
                <span className="vz-h">Score this morning</span>
                <div className="relative mt-[.5em] flex-1" style={{ minHeight: '8em' }}>
                  <svg viewBox="0 0 100 56" preserveAspectRatio="none" className="absolute inset-0 h-full w-full" aria-hidden="true">
                    <rect x="0" y="6" width="100" height="9.2" fill="rgb(255 107 93 / .1)" />
                    <rect x="0" y="15.2" width="100" height="13.8" fill="rgb(246 185 85 / .08)" />
                    <line x1="0" y1="15.2" x2="100" y2="15.2" stroke="rgb(255 107 93 / .55)" strokeDasharray="2 2" vectorEffect="non-scaling-stroke" />
                    <line x1="0" y1="29" x2="100" y2="29" stroke="rgb(246 185 85 / .5)" strokeDasharray="2 2" vectorEffect="non-scaling-stroke" />
                    <path d={line} fill="none" stroke={col} strokeWidth="2" vectorEffect="non-scaling-stroke" strokeLinejoin="round" style={{ transition: 'stroke .4s' }} />
                    {pts.map((p, i) => <circle key={i} cx={p[0]} cy={p[1]} r="1.6" fill={i === pts.length - 1 ? col : '#8fa3bd'} />)}
                  </svg>
                  <span className="absolute right-0 top-[2%] vz-m" style={{ fontSize: '.72em', color: '#ffaaa1' }}>Hold · 80</span>
                  <span className="absolute right-0 top-[38%] vz-m" style={{ fontSize: '.72em', color: '#ffd28a' }}>Step-up · 50</span>
                </div>
                <span className="vz-m" style={{ fontSize: '.75em' }}>Baseline from day one · peer group: Treasury</span>
              </div>
            </div>

            <div className="s5 mt-[.9em] rounded-[.8em] px-[.8em] py-[.65em]" style={{ background: 'rgb(0 174 239 / .07)', border: '1px solid rgb(0 174 239 / .28)' }}>
              <span className="block vz-h" style={{ color: '#6fd4ff' }}>Policy: score above 80 → hold and contain</span>
              <div className="mt-[.5em] grid grid-cols-3 gap-[.5em]">
                {RESPOND.map(([app, n, t], i) => (
                  <span key={n} className={cx(i < 2 ? 's5' : 's6', 'flex items-center gap-[.5em] rounded-[.6em] px-[.5em] py-[.45em]')} style={{ background: 'rgb(255 255 255 / .04)' }}>
                    <Logo k={app} size="1.15em" />
                    <span className="min-w-0"><span className="block truncate vz-t" style={{ fontSize: '.8em' }}>{n}</span><span className="block truncate vz-m" style={{ fontSize: '.72em', color: '#7fe3b2' }}>{t}</span></span>
                  </span>
                ))}
              </div>
            </div>
          </Win>
        );
      }}
    </Viz>
  );
}

/* A3. NHI for AWS: the account graph, and what a role uses against what it has. */
export function NhiGraph({ k: fk } = {}) {
  const nodes = [
    { id: 'acct', x: 50, y: 14, l: 'prod · 4471', g: 'aws', c: '#ffd27a' },
    { id: 'l1', x: 18, y: 48, l: 'lambda-kyc-sync', g: 'lambda', c: '#ff8b7e', hot: true },
    { id: 'l2', x: 50, y: 52, l: 'ecs-notify-svc', g: 'ecs', c: '#9fb4cf' },
    { id: 'l3', x: 82, y: 48, l: 'glue-ledger-etl', g: 'glue', c: '#9fb4cf' },
    { id: 'r1', x: 12, y: 86, l: 'secrets/*', g: 'secrets', c: '#ff8b7e', hot: true },
    { id: 'r2', x: 36, y: 88, l: 's3://kyc-docs', g: 's3', c: '#9fb4cf' },
    { id: 'r3', x: 66, y: 88, l: 'sns:notify', g: 'sns', c: '#9fb4cf' },
    { id: 'r4', x: 88, y: 86, l: 's3://ledger', g: 's3', c: '#9fb4cf' },
  ];
  const edges = [['acct', 'l1'], ['acct', 'l2'], ['acct', 'l3'], ['l1', 'r1'], ['l1', 'r2'], ['l2', 'r3'], ['l3', 'r4'], ['l2', 'r2']];
  const N = Object.fromEntries(nodes.map((n) => [n.id, n]));
  return (
    <Viz k={fk} steps={[500, 800, 800, 900, 1000]} hold={4000} label="Illustration: an AWS account graph shows a Lambda role with access to every secret; it has 214 permissions and has used 9 in 90 days.">
      {(k) => (
        <Win title="Non-human identities · AWS" right={<Chip tone="info" plain>adapID NHI</Chip>} glow="rgb(255 160 60 / .35)">
          <div className="grid gap-[1em]" style={{ gridTemplateColumns: '1.35fr 1fr' }}>
            <div className="relative" style={{ aspectRatio: '1.2' }}>
              <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="absolute inset-0 h-full w-full" aria-hidden="true">
                {edges.map(([a, b], i) => {
                  const hot = N[a].hot || N[b].hot;
                  return <line key={i} x1={N[a].x} y1={N[a].y} x2={N[b].x} y2={N[b].y} stroke={hot && k >= 3 ? 'rgb(255 107 93 / .7)' : 'rgb(140 180 230 / .28)'} strokeWidth="1.2" vectorEffect="non-scaling-stroke" className={i < 3 ? 's1' : 's2'} />;
                })}
              </svg>
              {nodes.map((n, i) => (
                <span key={n.id} className={cx(i < 4 ? 's1' : 's2', 'absolute flex -translate-x-1/2 -translate-y-1/2 flex-col items-center')} style={{ left: `${n.x}%`, top: `${n.y}%` }}>
                  <span className="vz-ic relative" style={{ color: n.hot && k >= 3 ? '#ff8b7e' : n.c, width: '2em', height: '2em', borderColor: n.hot && k >= 3 ? 'rgb(255 107 93 / .55)' : undefined }}>
                    <Logo k={n.g} size={n.g === 'aws' ? '1.6em' : '1.45em'} />{n.hot && k >= 3 && <span className="ping-h" style={{ color: 'rgb(255 107 93 / .6)' }} />}
                  </span>
                  <span className="mt-[.25em] whitespace-nowrap vz-mono" style={{ fontSize: '.7em' }}>{n.l}</span>
                </span>
              ))}
            </div>
            <div className="s3 flex flex-col gap-[.7em]">
              <div className="vz-panel" style={{ padding: '.8em .9em' }}>
                <span className="block vz-mono" style={{ color: '#ffaaa1' }}>lambda-kyc-sync</span>
                <span className="mt-[.5em] block vz-m">Posture score</span>
                <span className="block text-[1.9em] font-semibold num" style={{ color: '#ff7d70' }}>38<span className="vz-m" style={{ fontSize: '.45em' }}> / 100</span></span>
              </div>
              <div className="vz-panel" style={{ padding: '.8em .9em' }}>
                <span className="block vz-m">Permissions in 90 days</span>
                <div className="mt-[.5em] space-y-[.45em]">
                  <div><div className="flex justify-between vz-m"><span>Granted</span><span className="text-white num">214</span></div><div className="vz-meter mt-[.25em]"><i style={{ '--w': '100%', '--mc': '#5d6b82' }} /></div></div>
                  <div><div className="flex justify-between vz-m"><span>Used</span><span className="text-white num">9</span></div><div className="vz-meter mt-[.25em]"><i style={{ '--w': k >= 4 ? '4.2%' : '0%', '--mc': '#3cc8f6' }} /></div></div>
                </div>
              </div>
              <div className="s5"><Chip tone="crit">secretsmanager:* on every secret</Chip></div>
            </div>
          </div>
        </Win>
      )}
    </Viz>
  );
}

/* A5. Fraud: five signals fuse into one decision before money moves. */
export const FRAUD_CASES = {
  mule: { app: 'upi', label: 'Mule payee', event: '₹2,40,000 to a new payee', who: 'Anita Desai → Sunil Verma · UPI', sig: [62, 30, 96, 48, 88], d: ['Blocked', 'crit'], why: 'Payee shares a device with 22 other accounts', ms: 74 },
  ato: { app: 'chrome', label: 'Account takeover', event: 'Password reset, then login', who: 'Rohit Menon · net banking in Chrome', sig: [91, 84, 40, 72, 35], d: ['Step-up', 'warn'], why: 'New device and typing rhythm unlike the owner’s', ms: 61 },
  sim: { app: 'android', label: 'SIM swap', event: 'OTP to a new SIM', who: 'Meera Pillai · UPI on Android', sig: [88, 55, 52, 80, 64], d: ['Hold 4 h', 'warn'], why: 'SIM changed 3 hours before the first payment', ms: 69 },
  synthetic: { app: 'apple', label: 'Synthetic onboarding', event: 'New account application', who: 'Applicant 7731 · iOS app', sig: [45, 38, 90, 66, 22], d: ['Review', 'warn'], why: 'PAN and phone seen together on 9 other applications', ms: 78 },
  good: { app: 'gpay', label: 'Genuine customer', event: '₹4,500 to a known payee', who: 'Kiran Patil · Google Pay', sig: [8, 6, 10, 5, 12], d: ['Approved', 'ok'], why: 'Known device, usual amount, usual time', ms: 41 },
};
const SIG = ['Device', 'Behaviour', 'Identity graph', 'Network', 'Transaction'];
export function FraudDecision({ scenario = 'mule', k: fk }) {
  const c = FRAUD_CASES[scenario];
  return (
    <Viz k={fk} key={scenario} steps={[400, 500, 500, 500, 500, 500, 800]} hold={4200} label={`Illustration: ${c.event}. Five signals are scored and the decision is ${c.d[0]} in ${c.ms} milliseconds because ${c.why.toLowerCase()}.`}>
      {(k) => (
        <Win title="Fraud decision" right={<span className="vz-mono">{k >= 7 ? `${c.ms} ms` : '…'}</span>} glow="rgb(0 174 239 / .45)">
          <div className="flex items-center gap-[.8em] rounded-[.8em] px-[.9em] py-[.7em]" style={{ background: 'rgb(255 255 255 / .04)' }}>
            <App k={c.app} className="lg" />
            <span className="min-w-0"><span className="block vz-t">{c.event}</span><span className="block truncate vz-m">{c.who}</span></span>
          </div>
          <div className="mt-[1em] space-y-[.7em]">
            {SIG.map((s, i) => {
              const v = c.sig[i], col = v > 75 ? '#ff6b5d' : v > 45 ? '#f6b955' : '#3fd98f';
              return (
                <div key={s} className={`s${i + 1}`}>
                  <div className="flex justify-between vz-m"><span>{s}</span><span className="num" style={{ color: col }}>{k > i ? v : 0}</span></div>
                  <div className="vz-meter mt-[.3em]"><i style={{ '--w': `${k > i ? v : 0}%`, '--mc': col }} /></div>
                </div>
              );
            })}
          </div>
          <div className={cx('s6 mt-[1.1em] flex items-center gap-[.8em] rounded-[.8em] px-[.9em] py-[.75em]')} style={{ background: c.d[1] === 'ok' ? 'rgb(63 217 143 / .08)' : c.d[1] === 'warn' ? 'rgb(246 185 85 / .08)' : 'rgb(255 107 93 / .1)', border: `1px solid ${c.d[1] === 'ok' ? 'rgb(63 217 143 / .3)' : c.d[1] === 'warn' ? 'rgb(246 185 85 / .32)' : 'rgb(255 107 93 / .35)'}` }}>
            <Chip tone={c.d[1]}>{c.d[0]}</Chip><span className="min-w-0 truncate vz-t">{c.why}</span>
          </div>
        </Win>
      )}
    </Viz>
  );
}

/* A6. Mule network: one payee, many accounts behind one device. */
export function MuleNetwork({ k: fk } = {}) {
  const ring = Array.from({ length: 12 }, (_, i) => i);
  return (
    <Viz k={fk} steps={[500, 900, 900, 900]} hold={3800} label="Illustration: a new payee is linked through one device to many other accounts, the signature of a mule network.">
      {(k) => (
        <div className="relative" style={{ aspectRatio: '1.35' }}>
          <svg viewBox="0 0 135 100" className="absolute inset-0 h-full w-full" aria-hidden="true">
            {ring.map((i) => { const a = (i / ring.length) * Math.PI * 2; return <line key={i} x1="80" y1="50" x2={80 + Math.cos(a) * 34} y2={50 + Math.sin(a) * 34} stroke={k >= 3 ? 'rgb(255 107 93 / .5)' : 'rgb(140 180 230 / .25)'} strokeWidth=".5" className="s2" />; })}
            <line x1="22" y1="50" x2="66" y2="50" stroke="rgb(0 174 239 / .7)" strokeWidth=".8" className="flowline s1" />
          </svg>
          <span className="s1 absolute flex -translate-x-1/2 -translate-y-1/2 flex-col items-center" style={{ left: `${(22 / 135) * 100}%`, top: '50%' }}>
            <span className="vz-ic" style={{ color: ADAP, width: '2.4em', height: '2.4em', borderRadius: '50%' }}><Gl g="user" /></span>
            <span className="mt-[.3em] vz-m">Customer</span>
          </span>
          <span className="s1 absolute flex -translate-x-1/2 -translate-y-1/2 flex-col items-center" style={{ left: `${(80 / 135) * 100}%`, top: '50%' }}>
            <span className="vz-ic relative" style={{ color: k >= 3 ? '#ff8b7e' : '#ffd27a', width: '2.8em', height: '2.8em', borderRadius: '50%' }}><Gl g="phone" />{k >= 3 && <span className="ping-h" style={{ color: 'rgb(255 107 93 / .6)', borderRadius: '50%' }} />}</span>
          </span>
          {ring.map((i) => { const a = (i / ring.length) * Math.PI * 2; return (
            <span key={i} className="s2 absolute -translate-x-1/2 -translate-y-1/2" style={{ left: `${((80 + Math.cos(a) * 34) / 135) * 100}%`, top: `${50 + Math.sin(a) * 34}%` }}>
              <span className="vz-ic" style={{ width: '1.6em', height: '1.6em', borderRadius: '50%', color: k >= 3 ? '#ff8b7e' : '#9fb4cf' }}><Gl g="bank" /></span>
            </span>); })}
          <div className="s4 vz-pop absolute bottom-[2%] left-[2%]" style={{ padding: '.7em .9em', width: '46%', '--glow': 'rgb(255 107 93 / .45)' }}>
            <span className="block vz-t">One device, 23 accounts</span><span className="block vz-m">Payee blocked before the transfer</span>
          </div>
        </div>
      )}
    </Viz>
  );
}

/* A7. Active Directory: the path to Domain Admins, and the one change that cuts it. */
/* A5. Active Directory: the path an attacker would take to Tier 0, hop by hop
   with the technique on each edge; the one fix that cuts it; and live
   detection when someone tries anyway. Node positions are in % of the graph. */
const NODES = [
  { id: 'u', l: 'r.kapoor', s: 'User · phished', g: 'user', x: 9, y: 30 },
  { id: 'w', l: 'WKS-2140', s: 'Workstation', g: 'laptop', x: 30, y: 70 },
  { id: 's', l: 'svc-sql-report', s: 'Service account', g: 'key', x: 51, y: 30 },
  { id: 'g', l: 'Server Admins', s: 'Group · 3 levels deep', g: 'tree', x: 72, y: 70 },
  { id: 'd', l: 'Domain Admins', s: 'Tier 0', g: 'dc', x: 91, y: 30 },
];
const EDGES = [['u', 'w', 'Logs on as local admin'], ['w', 's', 'Kerberoasting'], ['s', 'g', 'GenericAll on group'], ['g', 'd', 'DCSync rights']];
const at = (id) => NODES.find((n) => n.id === id);
export function AdPath({ k: fk } = {}) {
  return (
    <Viz k={fk} steps={[500, 800, 800, 800, 800, 1200, 1000, 1000]} hold={4400} label="Illustration: an attacker moves from a phished user to a workstation, Kerberoasts a service account, abuses its GenericAll right on Server Admins and reaches Domain Admins; removing that one right cuts 41 of 57 paths, and a later DCSync attempt is blocked and the host isolated.">
      {(k) => {
        const hop = Math.min(k, 4), cut = k >= 5;
        const tok = cut ? at('s') : at(EDGES[Math.max(0, hop - 1)][hop ? 1 : 0]);
        return (
          <Win title={<span className="inline-flex items-center gap-[.5em]"><Logo k="windows" size="1em" />Attack paths · corp.local</span>} right={cut ? <Chip tone="ok">16 paths left · was 57</Chip> : <Chip tone="crit">{hop} of 4 hops to Tier 0</Chip>} glow="rgb(0 174 239 / .4)">
            <div className="relative" style={{ height: '19em' }}>
              <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="absolute inset-0 h-full w-full" aria-hidden="true">
                {EDGES.map(([a, b], i) => {
                  const A = at(a), B = at(b), live = hop > i, dead = cut && i >= 2;
                  return <line key={a + b} x1={A.x} y1={A.y} x2={B.x} y2={B.y} vectorEffect="non-scaling-stroke" strokeWidth={live ? 2 : 1.2}
                    stroke={dead ? 'rgb(140 160 190 / .22)' : live ? 'rgb(255 107 93 / .85)' : 'rgb(160 190 230 / .28)'} strokeDasharray={live && !dead ? undefined : '3 4'} className={live && !dead && !cut ? 'flowline' : undefined} />;
                })}
              </svg>
              {EDGES.map(([a, b, t], i) => {
                const A = at(a), B = at(b), live = hop > i, dead = cut && i >= 2;
                return (
                  <span key={t} className="absolute -translate-x-1/2 -translate-y-1/2 whitespace-nowrap rounded-full px-[.55em] py-[.15em]" style={{ left: `${(A.x + B.x) / 2}%`, top: `${(A.y + B.y) / 2}%`, fontSize: '.72em', fontWeight: 600, transition: 'all .5s', opacity: live || cut ? 1 : 0.35, background: dead ? '#111a29' : live ? 'rgb(255 107 93 / .16)' : '#111a29', color: dead ? '#6f7d92' : live ? '#ffaaa1' : '#8a97aa', border: `1px solid ${live && !dead ? 'rgb(255 107 93 / .4)' : 'rgb(160 190 230 / .14)'}`, textDecoration: dead ? 'line-through' : 'none' }}>{t}</span>
                );
              })}
              {cut && <span className="absolute -translate-x-1/2 -translate-y-1/2 vz-chip c-ok" style={{ left: '61.5%', top: '50%', marginTop: '1.7em' }}>Right removed</span>}
              {NODES.map((n, i) => {
                const reached = !cut ? hop >= i : i <= 2, tier0 = n.id === 'd', top = n.y < 50;
                // names sit on the outer side of each node, so edges never cross them
                const name = <><span className="block w-full truncate vz-t" style={{ fontSize: '.82em' }}>{n.l}</span><span className="block w-full truncate vz-m" style={{ fontSize: '.7em' }}>{n.s}</span></>;
                return (
                  <span key={n.id} className="absolute flex w-[8.6em] flex-col items-center text-center" style={{ left: `${n.x}%`, top: `${n.y}%`, transform: `translate(-50%, ${top ? 'calc(-100% + 1.25em)' : '-1.25em'})` }}>
                    {top && <span className="mb-[.35em] block w-full">{name}</span>}
                    <span className="vz-ic" style={{ width: '2.5em', height: '2.5em', borderRadius: '.75em', background: '#0f1726', transition: 'all .5s', color: tier0 ? (cut ? '#4be29a' : '#ff8b7e') : reached ? '#ffb3aa' : '#cfe1f7', borderColor: tier0 && !cut ? 'rgb(255 107 93 / .7)' : reached && !cut ? 'rgb(255 107 93 / .4)' : undefined, boxShadow: tier0 && !cut && hop >= 4 ? '0 0 1.6em rgb(255 107 93 / .5)' : 'none' }}>
                      {n.g === 'dc' ? <Logo k="dc" size="1.5em" /> : <Gl g={n.g} />}
                    </span>
                    {!top && <span className="mt-[.35em] block w-full">{name}</span>}
                  </span>
                );
              })}
              {k >= 1 && <span aria-hidden="true" className="absolute h-[.9em] w-[.9em] -translate-x-1/2 rounded-full" style={{ left: `calc(${tok.x}% + 1.6em)`, top: `calc(${tok.y}% - 1.75em)`, background: cut ? '#7f8da3' : '#ff6b5d', boxShadow: cut ? 'none' : '0 0 0 .35em rgb(255 107 93 / .2), 0 0 1.2em #ff6b5d', transition: 'left .75s cubic-bezier(.65,0,.35,1), top .75s cubic-bezier(.65,0,.35,1), background .4s' }} />}
            </div>
            <div className="s5 mt-[.6em] flex items-center gap-[.8em] rounded-[.8em] px-[.9em] py-[.65em]" style={{ background: 'rgb(63 217 143 / .08)', border: '1px solid rgb(63 217 143 / .3)' }}>
              <Gl g="check" className="h-[1.3em] w-[1.3em] shrink-0" style={{ color: '#4be29a' }} />
              <span className="min-w-0"><span className="block vz-t">Remove GenericAll from svc-sql-report</span><span className="block truncate vz-m">The one change that closes 41 of 57 paths · no business impact found</span></span>
            </div>
            <div className="s7 mt-[.6em] flex items-center gap-[.8em] rounded-[.8em] px-[.9em] py-[.6em]" style={{ background: 'rgb(255 255 255 / .03)', border: '1px solid rgb(160 190 230 / .1)' }}>
              <span className="vz-mono shrink-0" style={{ color: '#8a97aa' }}>14:22:07</span>
              <span className="min-w-0 flex-1 truncate vz-t" style={{ fontSize: '.9em' }}>DCSync attempt from WKS-2140</span>
              <Chip tone="crit">Blocked</Chip><span className="s8"><Chip tone="ok">Host isolated</Chip></span>
            </div>
          </Win>
        );
      }}
    </Viz>
  );
}

/* Connectors strip used on adapID pages */
export function Connectors({ keys, k: fk }) {
  return (
    <ul className="flex flex-wrap items-center gap-2.5">
      {keys.map((k) => (
        <li key={k} className="inline-flex h-11 items-center gap-2 rounded-full border border-line bg-fg/[.03] px-4 text-[14px] text-ink-2"><Logo k={k} size="18px" />{({ okta: 'Okta', entra: 'Microsoft Entra ID', salesforce: 'Salesforce', slack: 'Slack', ad: 'Active Directory', m365: 'Microsoft 365', google: 'Google Workspace', aws: 'AWS', github: 'GitHub', atlassian: 'Atlassian', azure: 'Microsoft Entra ID', gitlab: 'GitLab', upi: 'UPI', snowflake: 'Snowflake', databricks: 'Databricks', postgres: 'PostgreSQL', cloudflare: 'Cloudflare', gcp: 'Google Cloud', kubernetes: 'Kubernetes' })[k] || k}</li>
      ))}
    </ul>
  );
}
