import Stage3D, { Pop } from '../Stage3D.jsx';
import { Viz, Win, Chip, Gl, Logo, App, Av, Spark, cx } from './kit.jsx';
import ProductMark from '../ProductMark.jsx';

/* ---------------- Home hero: live identity activity, in 3D ----------------
   Three identities act within a minute; each is decided by the product built
   for it. The decisions that matter lift out of the frame. Illustrative data. */
const ACT = [
  { app: 'okta', g: 'user', who: 'Priya Nair', sub: 'Treasury · Okta', act: 'Sign-in from a new device', where: 'Lagos · 02:14', d: ['Step-up', 'warn'], by: 'adapid', at: 4 },
  { app: 'iam', g: 'key', who: 'AKIA••7Q2F', sub: 'deploy-bot · AWS IAM', act: 's3:ListBuckets from an unknown IP', where: '185.220.x.x', d: ['Revoked', 'crit'], by: 'adapid', at: 5 },
  { app: 'copilotstudio', g: 'agent', who: 'invoice-agent', sub: 'Copilot Studio', act: 'Salesforce export to an outside address', where: 'outside its task', d: ['Blocked', 'crit'], by: 'zenstra', at: 4 },
];

export function HeroActivity({ k: fk, tilt = [7, -16], range, pad = '9% 6% 12% 12%' } = {}) {
  return (
    <Stage3D tilt={tilt} range={range} className="relative">
      <Viz k={fk} steps={[500, 700, 700, 900, 900, 1000]} hold={4200} label="Illustration: three identities act within a minute. A sign-in from a new device is sent for step-up, a cloud key used from an unknown address is revoked and an AI agent export is blocked before it runs.">
        {(k) => (
          <div className="relative" style={{ padding: pad }}>
            <Win title="Live identity activity" right={<Chip tone="info">3 decisions · last 60 s</Chip>} glow="rgb(0 150 240 / .55)">
              <div className="vz-rows">
                <div className="hd" style={{ gridTemplateColumns: '1.25fr 1.6fr .85fr' }}><span>Identity</span><span>Action</span><span>Decision</span></div>
                {ACT.map((a, i) => (
                  <div key={a.who} className={cx(`s${i + 1}`, k >= a.at && a.d[1] === 'crit' && 'hot')} style={{ gridTemplateColumns: '1.25fr 1.6fr .85fr' }}>
                    <span className="flex min-w-0 items-center gap-[.6em]">
                      <App k={a.app} />
                      <span className="min-w-0"><span className={cx('block truncate vz-t', a.g === 'key' && 'mono')}>{a.who}</span><span className="block truncate vz-m">{a.sub}</span></span>
                    </span>
                    <span className="min-w-0"><span className="block truncate vz-t" style={{ fontWeight: 450 }}>{a.act}</span><span className="block truncate vz-m">{a.where}</span></span>
                    <span className="flex items-center gap-[.4em]"><ProductMark p={a.by} size="1.35em" />{k >= a.at ? <Chip tone={a.d[1]}>{a.d[0]}</Chip> : <Chip tone="mute">Scoring…</Chip>}</span>
                  </div>
                ))}
              </div>
              <div className="mt-[1em] grid grid-cols-3 gap-[.8em] s3">
                {[['Allowed today', '1,284', '#27b8f2', [4, 6, 5, 7, 6, 8, 9, 8, 10, 11]], ['Held for a person', '6', '#f6b955', [1, 0, 1, 2, 1, 1, 0, 1, 2, 1]], ['Blocked', '23', '#ff6b5d', [1, 2, 1, 3, 2, 2, 4, 3, 2, 3]]].map(([l, v, c, d]) => (
                  <div key={l} className="vz-panel" style={{ padding: '.8em .9em' }}>
                    <span className="vz-m block">{l}</span>
                    <span className="mt-[.2em] block text-[1.5em] font-semibold tracking-[-0.03em] num">{v}</span>
                    <span className="mt-[.4em] block h-[1.6em]"><Spark data={d} color={c} /></span>
                  </div>
                ))}
              </div>
            </Win>

            {/* the agent decision leaves the frame on the left */}
            <Pop z={110} delay={500} className="absolute" style={{ left: '0%', top: '66%', width: '40%' }} glow="rgb(255 107 93 / .5)">
              <div className={cx('vz-pop s4')} style={{ padding: '1em 1.1em', '--glow': 'rgb(255 107 93 / .55)' }}>
                <div className="flex items-center gap-[.5em]"><App k="copilotstudio" /><span className="vz-t">invoice-agent</span><span className="ml-auto inline-flex items-center gap-[.35em] vz-m"><ProductMark p="zenstra" size="1.4em" />Zenstra AI</span></div>
                <div className="mt-[.8em] flex items-center gap-[.45em] vz-mono" style={{ color: '#ff9b90' }}><Logo k="salesforce" size="1.2em" />salesforce.export → ext-mail.io</div>
                <div className="mt-[.8em] flex items-center justify-between rounded-[.6em] px-[.8em] py-[.55em]" style={{ background: 'rgb(255 107 93 / .14)', border: '1px solid rgb(255 107 93 / .35)' }}>
                  <span className="font-semibold" style={{ color: '#ffb1a8' }}>Blocked before it ran</span><span className="vz-mono" style={{ color: '#ffb1a8' }}>4 ms</span>
                </div>
              </div>
            </Pop>

            {/* the risk score rises out of the top right */}
            <Pop z={80} delay={700} className="absolute" style={{ right: '0%', top: '0%', width: '29%' }}>
              <div className="vz-pop s4" style={{ padding: '.9em 1em', '--glow': 'rgb(246 185 85 / .45)' }}>
                <div className="flex items-center gap-[.6em]">
                  <Ring v={k >= 4 ? 94 : 22} color={k >= 4 ? '#f6b955' : '#27b8f2'} />
                  <span className="min-w-0"><span className="block vz-t truncate">Priya Nair</span><span className="block vz-m">Risk {k >= 4 ? 'high' : 'normal'}</span></span>
                </div>
                <ul className="mt-[.7em] space-y-[.3em] vz-m">
                  <li>· New device, first seen</li>
                  <li>· Lagos, 2 h after Mumbai</li>
                </ul>
                <div className="mt-[.6em] inline-flex items-center gap-[.35em] vz-m"><ProductMark p="adapid" size="1.4em" />adapID AI</div>
              </div>
            </Pop>

            {/* the revoked key slides out at the bottom */}
            <Pop z={60} delay={900} className="absolute" style={{ right: '0%', bottom: '1%', width: '44%' }}>
              <div className="vz-pop s5 flex items-center gap-[.7em]" style={{ padding: '.75em .9em', '--glow': 'rgb(255 107 93 / .4)' }}>
                <App k="iam" />
                <span className="min-w-0"><span className="block vz-t">Key revoked</span><span className="block truncate vz-mono">AKIA••7Q2F · deploy-bot</span></span>
                <Chip tone="crit" className="ml-auto">0 s</Chip>
              </div>
            </Pop>
          </div>
        )}
      </Viz>
    </Stage3D>
  );
}

export function Ring({ v, color = '#27b8f2', size = '3.4em', label = true, k: fk }) {
  const r = 15.9, c = 2 * Math.PI * r;
  return (
    <span className="relative inline-flex shrink-0 items-center justify-center" style={{ width: size, height: size }}>
      <svg viewBox="0 0 36 36" className="absolute inset-0 -rotate-90"><circle cx="18" cy="18" r={r} fill="none" stroke="rgb(255 255 255 / .1)" strokeWidth="3" /><circle cx="18" cy="18" r={r} fill="none" stroke={color} strokeWidth="3" strokeLinecap="round" strokeDasharray={`${(v / 100) * c} ${c}`} style={{ transition: 'stroke-dasharray 1.2s cubic-bezier(.16,1,.3,1), stroke .4s' }} /></svg>
      {label && <span className="relative text-[1.05em] font-bold num" style={{ color }}>{v}</span>}
    </span>
  );
}

/* ---------------- The new perimeter: three small problem pictures ---------------- */

/* An agent asked for one thing reaches for three: calls inside the task stay
   inside the dashed line, the ones beyond it fall outside and turn red. */
export function AgentOverreach({ k: fk } = {}) {
  const calls = [['sharepoint', 'files.read', 'vendor-q3.pdf', 'in'], ['outlook', 'mail.search', '3 years of mail', 'out'], ['salesforce', 'crm.export', 'to an outside address', 'out']];
  return (
    <Viz k={fk} steps={[600, 800, 800, 800]} hold={3600} label="Illustration: an AI agent asked to summarise one contract also searches three years of mail and tries to export CRM data.">
      {(k) => (
        <div className="relative" style={{ padding: '4%' }}>
          <div className="vz-panel" style={{ padding: '.9em 1em' }}>
            <div className="flex items-center gap-[.6em]"><App k="copilotstudio" /><span><span className="block vz-t">invoice-agent</span><span className="block vz-m">Copilot Studio · Finance</span></span><Chip tone="zen" plain className="ml-auto">AI agent</Chip></div>
            <div className="mt-[.8em] rounded-[.6em] px-[.8em] py-[.6em] vz-m" style={{ background: 'rgb(255 255 255 / .04)' }}>Task: <span style={{ color: '#edeff3' }}>Summarise the Q3 vendor contract</span></div>
          </div>
          <div className="relative mt-[1em]">
            <div className="absolute inset-x-0 top-0 rounded-[.8em]" style={{ height: '3.5em', border: '1.5px dashed rgb(147 162 255 / .5)' }} />
            <span className="absolute right-[.8em] top-[-.75em] px-[.4em] text-[.75em] font-semibold uppercase tracking-[.08em]" style={{ background: '#0f1115', color: '#aab6ff' }}>Inside the task</span>
            <div className="space-y-[.55em]" style={{ paddingTop: '.5em' }}>
              {calls.map(([app, c, d, w], i) => (
                <div key={c} className={cx(`s${i + 1}`, 'flex items-center gap-[.7em] rounded-[.6em] px-[.8em] py-[.55em]')} style={{ marginInline: '.5em', marginTop: i === 1 ? '1.2em' : undefined, background: w === 'out' ? 'rgb(255 107 93 / .1)' : 'rgb(255 255 255 / .04)', border: `1px solid ${w === 'out' ? 'rgb(255 107 93 / .32)' : 'rgb(255 255 255 / .08)'}` }}>
                  <Logo k={app} size="1.25em" /><span className="vz-mono" style={{ color: w === 'out' ? '#ff9b90' : '#dddfe3' }}>{c}</span><span className="vz-m truncate">{d}</span>
                  <span className="ml-auto">{w === 'in' ? <Chip tone="ok">In task</Chip> : <Chip tone="crit">{i === 1 ? 'Beyond task' : 'Blocked'}</Chip>}</span>
                </div>
              ))}
            </div>
          </div>
          <p className={cx('s4 mt-[1em] vz-m')}>One request, three systems. Only one was part of the job.</p>
        </div>
      )}
    </Viz>
  );
}

/* One person, fifteen machine identities, multiplying with each deploy. */
export function KeySprawl({ k: fk } = {}) {
  const keys = Array.from({ length: 15 }, (_, i) => i);
  const flagged = { 3: 'No owner', 9: '412 days old', 12: 'Admin' };
  return (
    <Viz k={fk} steps={[500, 900, 900, 900]} hold={3800} label="Illustration: one person sits among fifteen machine identities; three are flagged as unowned, stale or over-privileged.">
      {(k) => (
        <div className="relative" style={{ padding: '4%' }}>
          <div className="relative mx-auto" style={{ width: '100%', aspectRatio: '1.25' }}>
            <svg viewBox="0 0 100 80" className="absolute inset-0 h-full w-full" aria-hidden="true">
              {keys.map((i) => {
                const a = (i / keys.length) * Math.PI * 2 - Math.PI / 2, r = i % 2 ? 30 : 36;
                return <line key={i} x1="50" y1="40" x2={50 + Math.cos(a) * r} y2={40 + Math.sin(a) * r * 0.86} stroke={flagged[i] ? 'rgb(255 107 93 / .55)' : 'rgb(120 170 230 / .2)'} strokeWidth=".35" className={i < 5 ? 's1' : i < 10 ? 's2' : 's3'} />;
              })}
            </svg>
            <span className="absolute left-1/2 top-1/2 flex -translate-x-1/2 -translate-y-1/2 flex-col items-center">
              <span className="vz-ic" style={{ width: '3em', height: '3em', borderRadius: '50%', color: '#7fd3ff', background: 'rgb(0 174 239 / .14)', borderColor: 'rgb(0 174 239 / .4)' }}><Gl g="user" /></span>
              <span className="mt-[.3em] vz-m">1 person</span>
            </span>
            {keys.map((i) => {
              const a = (i / keys.length) * Math.PI * 2 - Math.PI / 2, r = i % 2 ? 30 : 36;
              const f = flagged[i];
              return (
                <span key={i} className={cx('absolute -translate-x-1/2 -translate-y-1/2', i < 5 ? 's1' : i < 10 ? 's2' : 's3')} style={{ left: `${50 + Math.cos(a) * r}%`, top: `${((40 + Math.sin(a) * r * 0.86) / 80) * 100}%` }}>
                  <span className="vz-ic" style={{ width: '2em', height: '2em', borderRadius: '50%', color: '#edeff3', borderColor: f ? 'rgb(255 107 93 / .6)' : undefined, background: f ? 'rgb(255 107 93 / .16)' : undefined }}><Logo k={SPRAWL[i]} size="1.15em" /></span>
                  {f && k >= 4 && <span className="absolute left-1/2 top-full mt-[.3em] -translate-x-1/2 whitespace-nowrap"><Chip tone="crit">{f}</Chip></span>}
                </span>
              );
            })}
          </div>
          <div className="s3 mt-[.4em] flex items-center justify-between vz-m"><span>Machine identities</span><span className="text-[1.6em] font-semibold text-white num">15<span className="vz-m" style={{ fontSize: '.55em' }}> for every person</span></span></div>
        </div>
      )}
    </Viz>
  );
}

/* Two sign-ins that both pass MFA. Only behaviour tells them apart. */
const SPRAWL = ['iam', 'actions', 'kubernetes', 'lambda', 's3', 'docker', 'vault', 'secrets', 'ec2', 'actions', 'terraform', 'iam', 'gcp', 'kubernetes', 'rds'];
export function LegitLogin({ k: fk } = {}) {
  return (
    <Viz k={fk} steps={[600, 900, 1100, 900]} hold={3800} label="Illustration: two sign-ins to the same account both pass MFA; the second, from a new device in Lagos two hours after Mumbai, is flagged as impossible travel.">
      {(k) => (
        <div className="relative" style={{ padding: '4%' }}>
          <div className="vz-panel" style={{ padding: '.4em 0' }}>
            <div className="flex items-center justify-between px-[1em] py-[.5em]"><span className="inline-flex items-center gap-[.45em] vz-h"><Logo k="okta" size="1.2em" />Okta · sign-in log</span><span className="vz-mono">kavya.reddy</span></div>
            {[['Mumbai', 'Managed laptop · MFA passed', '09:12', false], ['Lagos', 'New device · MFA passed', '11:05', true]].map(([c, d, t, bad], i) => (
              <div key={c} className={cx(`s${i + 1}`, 'flex items-center gap-[.7em] border-t px-[1em] py-[.7em]')} style={{ borderColor: 'rgb(160 190 230 / .08)', background: bad && k >= 3 ? 'linear-gradient(90deg, rgb(255 107 93 / .12), transparent)' : undefined }}>
                <Av name="Kavya Reddy" i={3} />
                <span className="min-w-0"><span className="block vz-t">Kavya Reddy · {c}</span><span className="block truncate vz-m">{d}</span></span>
                <span className="ml-auto flex flex-col items-end gap-[.3em]"><span className="vz-mono">{t}</span><Chip tone="ok">Success</Chip></span>
              </div>
            ))}
          </div>
          <div className="s3 mt-[.9em] vz-panel" style={{ padding: '.9em 1em' }}>
            <div className="flex items-center justify-between"><span className="vz-m">Behaviour risk</span><span className="text-[1.5em] font-semibold num" style={{ color: k >= 3 ? '#ff7d70' : '#4be29a' }}>{k >= 3 ? 94 : 12}</span></div>
            <div className="mt-[.5em] h-[.5em] overflow-hidden rounded-full" style={{ background: 'linear-gradient(90deg, #3fd98f, #f6b955 55%, #ff6b5d)' }}>
              <div className="h-full transition-all duration-1000" style={{ marginLeft: `${k >= 3 ? 94 : 12}%`, width: '2px', background: '#fff', boxShadow: '0 0 6px #fff' }} />
            </div>
            <div className="s4 mt-[.8em] flex flex-wrap gap-[.4em]"><Chip tone="crit">Impossible travel</Chip><Chip tone="warn">First-seen device</Chip></div>
          </div>
        </div>
      )}
    </Viz>
  );
}
