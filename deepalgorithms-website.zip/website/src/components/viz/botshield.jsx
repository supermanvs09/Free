import { Viz, Win, Chip, Gl, Logo, cx } from './kit.jsx';

const BOT = '#34e0c3';

/* B1. The CTEM loop: three agents narrow thousands of assets to the few that matter. */
const STAGES = [
  { k: 'Recon agent', v: '1,284', l: 'assets mapped', g: 'search', c: 'var(--vz-blue)' },
  { k: 'Red team agent', v: '37 → 6', l: 'exposures proven exploitable', g: 'bolt', c: '#ff8b7e' },
  { k: 'Blue team agent', v: '6', l: 'virtual patches live', g: 'shield', c: BOT },
];
export function CtemLoop({ k: fk } = {}) {
  return (
    <Viz k={fk} steps={[500, 900, 900, 900, 1000]} hold={4000} label="Illustration: a reconnaissance agent maps 1,284 assets, a red team agent proves 6 of 37 exposures exploitable and a blue team agent deploys 6 virtual patches while fixes are routed to owners.">
      {(k) => (
        <Win title="BotShield · Exposure loop" right={<Chip tone="ok">Continuous</Chip>} glow="rgb(52 224 195 / .4)">
          <div className="relative grid grid-cols-3 gap-[.7em]">
            <svg viewBox="0 0 300 40" preserveAspectRatio="none" className="pointer-events-none absolute left-0 right-0 top-[2.2em] h-[1.2em] w-full" aria-hidden="true">
              <line x1="50" y1="20" x2="250" y2="20" stroke="rgb(52 224 195 / .45)" strokeWidth="1.5" vectorEffect="non-scaling-stroke" className="flowline" />
            </svg>
            {STAGES.map((s, i) => (
              <div key={s.k} className={cx(`s${i + 1}`, 'relative z-[1] flex flex-col items-center text-center')}>
                <span className="vz-ic" style={{ width: '3em', height: '3em', borderRadius: '50%', color: s.c, background: 'var(--vz-solid)', borderColor: `${s.c}66` }}><Gl g={s.g} /></span>
                <span className="mt-[.6em] vz-h" style={{ color: s.c }}>{s.k}</span>
                <span className="mt-[.3em] block text-[1.7em] font-semibold tracking-[-0.03em] num">{s.v}</span>
                <span className="block vz-m">{s.l}</span>
              </div>
            ))}
          </div>
          <div className="s4 mt-[1.1em] vz-rows vz-panel">
            <div className="hd" style={{ gridTemplateColumns: '1.5fr 1fr .9fr' }}><span>Proven exposure</span><span>Where</span><span>Status</span></div>
            {[['OTP endpoint lacks rate limit', 'api.bank.in', 'Patched', 'nginx'], ['Session token in URL', 'm.bank.in', 'Patched', 'android'], ['Debug route exposed', 'pay.bank.in', 'Fix in Jira', 'nginx']].map((r, i) => (
              <div key={r[0]} style={{ gridTemplateColumns: '1.5fr 1fr .9fr' }}>
                <span className="truncate vz-t">{r[0]}</span><span className="flex min-w-0 items-center gap-[.4em]"><Logo k={r[3]} size="1.05em" /><span className="truncate vz-mono">{r[1]}</span></span><span>{i < 2 ? <Chip tone="ok">{r[2]}</Chip> : <span className="vz-chip c-info plain"><Logo k="jira" size="1em" />{r[2]}</span>}</span>
              </div>
            ))}
          </div>
          <div className="s5 mt-[.8em] flex items-center gap-[.5em] vz-m"><Gl g="clock" className="h-[1.1em] w-[1.1em]" style={{ color: BOT }} />Next cycle in 6 h. Nothing waits for a quarterly test.</div>
        </Win>
      )}
    </Viz>
  );
}
