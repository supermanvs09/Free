import { Viz, Win, Chip, Gl, Logo, cx } from './kit.jsx';

const BOT = '#34e0c3';

/* B1. The CTEM loop: three agents narrow thousands of assets to the few that matter. */
const STAGES = [
  { k: 'Recon agent', v: '1,284', l: 'assets mapped', g: 'search', c: '#6fd4ff' },
  { k: 'Red team agent', v: '37 → 6', l: 'exposures proven exploitable', g: 'bolt', c: '#ff8b7e' },
  { k: 'Blue team agent', v: '6', l: 'virtual patches live', g: 'shield', c: BOT },
];
export function CtemLoop({ k: fk } = {}) {
  return (
    <Viz k={fk} steps={[500, 900, 900, 900, 1000]} hold={4000} label="Illustration: a reconnaissance agent maps 1,284 assets, a red team agent proves 6 of 37 exposures exploitable and a blue team agent deploys 6 virtual patches while fixes are routed to owners.">
      {(k) => (
        <Win title="BotShield · Exposure loop" right={<Chip tone="ok">Continuous</Chip>} glow="rgb(52 224 195 / .4)">
          <div className="relative grid grid-cols-3 gap-[.7em]">
            <svg viewBox="0 0 300 40" preserveAspectRatio="none" className="pointer-events-none absolute left-0 right-0 top-[2.2em] h-[1.2em] w-full" aria-hidden="true">
              <line x1="50" y1="20" x2="250" y2="20" stroke="rgb(52 224 195 / .45)" strokeWidth="1.5" vectorEffect="non-scaling-stroke" className="flowline" />
            </svg>
            {STAGES.map((s, i) => (
              <div key={s.k} className={cx(`s${i + 1}`, 'relative z-[1] flex flex-col items-center text-center')}>
                <span className="vz-ic" style={{ width: '3em', height: '3em', borderRadius: '50%', color: s.c, background: '#121418', borderColor: `${s.c}66` }}><Gl g={s.g} /></span>
                <span className="mt-[.6em] vz-h" style={{ color: s.c }}>{s.k}</span>
                <span className="mt-[.3em] block text-[1.7em] font-semibold tracking-[-0.03em] num">{s.v}</span>
                <span className="block vz-m">{s.l}</span>
              </div>
            ))}
          </div>
          <div className="s4 mt-[1.1em] vz-rows vz-panel">
            <div className="hd" style={{ gridTemplateColumns: '1.5fr 1fr .9fr' }}><span>Proven exposure</span><span>Where</span><span>Status</span></div>
            {[['OTP endpoint lacks rate limit', 'api.bank.in', 'Patched', 'nginx'], ['Session token in URL', 'm.bank.in', 'Patched', 'android'], ['Debug route exposed', 'pay.bank.in', 'Fix in Jira', 'nginx']].map((r, i) => (
              <div key={r[0]} style={{ gridTemplateColumns: '1.5fr 1fr .9fr' }}>
                <span className="truncate vz-t">{r[0]}</span><span className="flex min-w-0 items-center gap-[.4em]"><Logo k={r[3]} size="1.05em" /><span className="truncate vz-mono">{r[1]}</span></span><span>{i < 2 ? <Chip tone="ok">{r[2]}</Chip> : <span className="vz-chip c-info plain"><Logo k="jira" size="1em" />{r[2]}</span>}</span>
              </div>
            ))}
          </div>
          <div className="s5 mt-[.8em] flex items-center gap-[.5em] vz-m"><Gl g="clock" className="h-[1.1em] w-[1.1em]" style={{ color: BOT }} />Next cycle in 6 h. Nothing waits for a quarterly test.</div>
        </Win>
      )}
    </Viz>
  );
}

/* B2. Bot defence: intent, not signatures. A login endpoint under credential stuffing:
   people on their own browsers and phones get through; automation frameworks
   are recognised by how they behave, whatever IP they rotate to. */
const BOTS = ['puppeteer', 'selenium', 'chrome'];
const BOT_NAMES = ['Puppeteer', 'Selenium', 'Headless Chrome'];
const PEOPLE = ['chrome', 'android', 'apple'];
export function BotIntent({ k: fk } = {}) {
  const reqs = Array.from({ length: 18 }, (_, i) => ({ bot: [1, 2, 4, 5, 7, 8, 10, 11, 13, 14, 16, 17].includes(i), i }));
  return (
    <Viz k={fk} steps={[500, 900, 1000, 900]} hold={3800} label="Illustration: requests to a login endpoint are sorted by intent; credential-stuffing bots rotating IP addresses are blocked while people sign in normally.">
      {(k) => (
        <Win title="POST /login · last 60 s" right={<Chip tone={k >= 2 ? 'crit' : 'mute'}>{k >= 2 ? 'Credential stuffing' : 'Watching'}</Chip>} glow="rgb(52 224 195 / .4)">
          <div className="grid grid-cols-6 gap-[.4em] sm:grid-cols-9">
            {reqs.map((r) => (
              <span key={r.i} className={cx('s1 flex h-[2.4em] items-center justify-center rounded-[.6em]')} style={{ background: k >= 2 ? (r.bot ? 'rgb(255 107 93 / .14)' : 'rgb(63 217 143 / .1)') : 'rgb(255 255 255 / .05)', border: `1px solid ${k >= 2 ? (r.bot ? 'rgb(255 107 93 / .35)' : 'rgb(63 217 143 / .3)') : 'rgb(255 255 255 / .08)'}`, color: k >= 2 ? (r.bot ? '#ff8b7e' : '#4be29a') : '#9ea0a4', transition: 'all .5s', transitionDelay: `${r.i * 30}ms` }}>
                {k >= 2 ? <Logo k={r.bot ? BOTS[r.i % 3] : PEOPLE[r.i % 3]} size="1.25em" /> : <Gl g="user" className="h-[1.2em] w-[1.2em]" />}
              </span>
            ))}
          </div>
          <div className="s3 mt-[1em] grid grid-cols-3 gap-[.6em]">
            {[['Blocked by intent', '18,204', '#ff7d70'], ['People signed in', '2,931', '#4be29a'], ['IPs rotated', '6,410', '#ffd28a']].map(([l, v, c]) => (
              <div key={l} className="vz-panel" style={{ padding: '.7em .8em' }}><span className="block vz-m">{l}</span><span className="block text-[1.4em] font-semibold num" style={{ color: c }}>{v}</span></div>
            ))}
          </div>
          <div className="s4 mt-[.8em] flex flex-wrap items-center gap-[.5em] vz-m">
            <span>Automation seen:</span>
            {BOTS.map((b, i) => <span key={b} className="inline-flex items-center gap-[.35em] rounded-full px-[.6em] py-[.2em]" style={{ background: 'rgb(255 107 93 / .1)', border: '1px solid rgb(255 107 93 / .28)', color: '#ffb1a8' }}><Logo k={b} size="1em" />{BOT_NAMES[i]}</span>)}
            <span className="ml-auto">by typing cadence, header order, retry timing</span>
          </div>
        </Win>
      )}
    </Viz>
  );
}

/* B3. DDoS at the edge: the flood is absorbed near users; clean traffic carries on. */
export function DdosEdge({ k: fk } = {}) {
  const flood = Array.from({ length: 22 }, (_, i) => i);
  return (
    <Viz k={fk} steps={[500, 900, 900, 1000]} hold={4000} label="Illustration: an application-layer flood is absorbed at edge nodes close to users while legitimate traffic reaches the origin, with no diversion to a scrubbing centre.">
      {(k) => (
        <Win title="DDoS mitigation · live" right={<Chip tone={k >= 3 ? 'ok' : 'crit'}>{k >= 3 ? 'Mitigated in 9 s' : '1.8 M req/s'}</Chip>} glow="rgb(52 224 195 / .4)">
          <div className="relative" style={{ aspectRatio: '2.4' }}>
            <svg viewBox="0 0 240 100" className="absolute inset-0 h-full w-full" aria-hidden="true">
              <defs><linearGradient id="dd-edge" x1="0" x2="1"><stop offset="0" stopColor={BOT} stopOpacity="0" /><stop offset=".5" stopColor={BOT} stopOpacity=".55" /><stop offset="1" stopColor={BOT} stopOpacity="0" /></linearGradient></defs>
              <rect x="128" y="6" width="3" height="88" rx="1.5" fill="url(#dd-edge)" className="s1" />
              {flood.map((i) => {
                const y = 10 + (i * 37) % 80, stop = 126, len = 40 + (i * 13) % 50;
                return <line key={i} x1={stop - len - (i % 5) * 10} y1={y} x2={k >= 2 ? stop : stop - 10} y2={y} stroke={i % 4 === 0 ? 'rgb(111 212 255 / .9)' : 'rgb(255 107 93 / .7)'} strokeWidth={i % 4 === 0 ? 1.2 : .8} strokeLinecap="round" className="s1 flowline" />;
              })}
              {[20, 50, 80].map((y, i) => <line key={y} x1="134" y1={y} x2="210" y2="50" stroke="rgb(111 212 255 / .8)" strokeWidth="1" className={cx('s3', 'flowline')} style={{ animationDelay: `${i * 0.2}s` }} />)}
            </svg>
            <span className="s1 absolute left-[1%] top-1/2 -translate-y-1/2 vz-m">Requests</span>
            <span className="s1 absolute top-[2%] vz-h" style={{ left: '49%', color: BOT }}>Edge</span>
            <span className="s3 absolute right-[2%] top-1/2 flex -translate-y-1/2 flex-col items-center"><span className="vz-ic" style={{ color: '#6fd4ff', width: '2.6em', height: '2.6em' }}><Gl g="server" /></span><span className="mt-[.3em] vz-m">Origin</span></span>
          </div>
          <div className="s2 mt-[.8em] grid grid-cols-3 gap-[.6em]">
            {[['L3 volumetric', 96], ['L4 protocol', 88], ['L7 application', k >= 3 ? 99 : 41]].map(([l, v]) => (
              <div key={l}><div className="flex justify-between vz-m"><span>{l}</span><span className="num text-white">{v}%</span></div><div className="vz-meter mt-[.3em]"><i style={{ '--w': `${v}%`, '--mc': v > 80 ? BOT : '#f6b955' }} /></div></div>
            ))}
          </div>
          <div className="s4 mt-[.9em] flex items-center justify-between vz-m"><span>Diversion to a scrubbing centre</span><span className="text-white">None</span></div>
        </Win>
      )}
    </Viz>
  );
}
