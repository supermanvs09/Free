import { useEffect, useRef, useState } from 'react';
import { useInView, useReducedMotion, cx } from '../../lib/motion.js';
import { Icon } from '../ui.jsx';

/* The fraud hero, in one glance: the three frauds a bank loses money to, each
   as it arrives, what gave it away, and what happened, in milliseconds. The
   full story of one of them (Anita) is told further down the page. Values are
   illustrative. */

const ROWS = [
  { icon: 'UserCircle', kind: 'Account takeover', what: 'Right password, new phone, typing unlike the customer', act: 'Stepped up', tone: 'warn', ms: 41 },
  { icon: 'Phone', kind: 'Payment scam', what: '₹2,40,000 to a new payee, customer on a call', act: 'Paused', tone: 'hold', ms: 63 },
  { icon: 'Bank', kind: 'Mule account', what: 'Payee account flagged in shared fraud intelligence', act: 'Blocked', tone: 'crit', ms: 38 },
];
const TONE = {
  warn: 'bg-[#f6b955]/15 text-[#f6c776]',
  hold: 'bg-[#ff9a5c]/15 text-[#ffb27f]',
  crit: 'bg-[#ff6b5d]/15 text-[#ff8a7e]',
};

export function FraudDecisions() {
  const ref = useRef(null);
  const seen = useInView(ref, { threshold: 0.3 });
  const reduce = useReducedMotion();
  const [k, setK] = useState(ROWS.length * 2); // without scripts, every row with its outcome
  useEffect(() => {
    if (reduce || !seen) { setK(ROWS.length * 2); return undefined; }
    // row i arrives at step 2i, its outcome at 2i+1; then hold, and again
    let i = 0, t;
    const next = () => { setK(i); t = setTimeout(() => { i = i >= ROWS.length * 2 ? 0 : i + 1; next(); }, i >= ROWS.length * 2 ? 4200 : i % 2 ? 700 : 900); };
    next();
    return () => clearTimeout(t);
  }, [seen, reduce]);
  return (
    <figure ref={ref} className="mx-auto w-full max-w-[540px] lg:mr-0" aria-label="Illustration: three sessions in a bank's app. An account takeover, with the right password but a new phone and typing unlike the customer, is stepped up in 41 ms. A payment scam, 2,40,000 rupees to a new payee while the customer is on a call, is paused in 63 ms. A payment to a mule account flagged in shared fraud intelligence is blocked in 38 ms.">
      <div aria-hidden="true" className="overflow-hidden rounded-[20px] border border-white/12 bg-[#071733]/85 shadow-[0_40px_90px_-40px_rgba(0,0,0,.9)] backdrop-blur">
        <div className="flex items-center gap-2.5 border-b border-white/10 px-5 py-3.5">
          <span className="relative flex h-2 w-2"><span className="absolute inset-0 animate-ping rounded-full bg-[#3fd98f] opacity-60" /><span className="relative h-2 w-2 rounded-full bg-[#3fd98f]" /></span>
          <span className="text-[13.5px] font-semibold text-white">Live decisions</span>
          <span className="ml-auto text-[12.5px] text-white/55">Mobile banking · Internet banking · UPI</span>
        </div>
        <ul>
          {ROWS.map((r, i) => {
            const shown = k >= i * 2, done = k >= i * 2 + 1;
            return (
              <li key={r.kind} className={cx('flex items-center gap-3.5 border-b border-white/[.07] px-5 py-4 transition-all duration-500 last:border-0', shown ? 'opacity-100' : 'translate-y-1 opacity-0')}>
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-[12px] bg-white/[.07] text-[#9fd3ff]"><Icon name={r.icon} size={20} /></span>
                <span className="min-w-0 flex-1">
                  <span className="block text-[14.5px] font-semibold text-white">{r.kind}</span>
                  <span className="mt-0.5 block text-[12.5px] leading-snug text-white/60">{r.what}</span>
                </span>
                <span className="w-[92px] shrink-0 text-right">
                  <span className={cx('inline-block rounded-full px-2.5 py-1 text-[12px] font-semibold transition-all duration-300', done ? TONE[r.tone] : 'bg-white/[.06] text-white/45')}>{done ? r.act : 'Scoring…'}</span>
                  <span className={cx('mt-1 block text-[11.5px] tabular-nums text-white/45 transition-opacity duration-300', done ? 'opacity-100' : 'opacity-0')}>{r.ms} ms</span>
                </span>
              </li>
            );
          })}
        </ul>
        <div className="flex items-center gap-2 border-t border-white/10 bg-white/[.03] px-5 py-3 text-[12.5px] text-white/70">
          <Icon name="ChatCircleText" size={15} className="text-[#9fd3ff]" />Every decision comes with its reason, for the analyst and the auditor.
        </div>
      </div>
    </figure>
  );
}
