/* The official product marks (from the product teams' own artwork):
   Zenstra AI's star, adapID AI's shield and lock, BotShield AI's robot shield
   and the ICMS Compliance Suite shield. Each reads on dark and light. */
const LINE = {
  zen: 'zenstra', zenstra: 'zenstra',
  adap: 'adapid', adapid: 'adapid', cirm: 'adapid', nhi: 'adapid', fraud: 'adapid', ad: 'adapid',
  bot: 'botshield', botshield: 'botshield', ddos: 'botshield',
  icms: 'icms',
  'Zenstra AI': 'zenstra', 'adapID AI': 'adapid', 'BotShield AI': 'botshield', 'ICMS Compliance Suite': 'icms',
};
const NAME = { zenstra: 'Zenstra AI', adapid: 'adapID AI', botshield: 'BotShield AI', icms: 'ICMS Compliance Suite' };

const FIRST = { Zenstra: 'zenstra', adapID: 'adapid', BotShield: 'botshield', ICMS: 'icms' };
export const lineOf = (p) => LINE[p] || FIRST[String(p).split(' ')[0]] || p;

/* `p` is a product key, line key or product name; `alt` names it when the mark stands alone. */
export default function ProductMark({ p, size = 28, alt, className, style, loading = 'lazy' }) {
  const k = lineOf(p);
  if (!NAME[k]) return null;
  const px = typeof size === 'number' ? size : undefined; // em sizes inside product pictures
  return <img src={`/brand/products/${k}.webp`} alt={alt ? NAME[k] : ''} width={px} height={px} loading={loading} decoding="async" className={className} style={{ width: size, height: size, objectFit: 'contain', flexShrink: 0, ...style }} draggable="false" />;
}

