import Scene from './Scene.jsx';
import { TAU, seg, ease, lerp, hash, glow, ring, rgba, clamp, drawIcon, preload } from './engine.js';
import { view, drawGlobe, city, arc, along } from './globe.js';

/* A flood from 26 places at once breaks on a shield at the edge, near the
   bank's own users; a thin stream of real customers passes straight through
   to checkout, which never slows down. */
const TARGET = [19.08, 72.88];
const SRC = Array.from({ length: 26 }, (_, i) => [lerp(-35, 58, hash(i, 21)), lerp(10, 150, hash(i, 22))]).filter(([la, lo]) => Math.hypot(la - TARGET[0], (lo - TARGET[1]) * 0.8) > 22);
const CLEAN = [[28.6, 77.2], [12.97, 77.6], [22.57, 88.36], [13.08, 80.27], [17.38, 78.48]];
const RED = '#ff6b5d', CYAN = '#4fd2ff', TEAL = '#34e0c3';
const T = { atk: 1.6, shield: 1.9, absorbed: 3.0, end: 9.8 }, LOOP = 12;
preload([['server2', '#e8f8ff', 1.7]]);

function draw(ctx, w, h, t, { narrow, mx }) {
  const out = {};
  const fade = 1 - seg(t, LOOP - 0.6, LOOP);
  const R = narrow ? w * 0.62 : Math.min(w * 0.4, h * 0.56);
  const g = { cx: w / 2, cy: narrow ? h * 0.66 : h * 0.6, R, v: view(14, 64 + Math.sin(t * 0.2) * 4 + mx * 5) };
  drawGlobe(ctx, g, ease(seg(t, 0, 0.8)) * fade);

  const tg = city(g, ...TARGET);
  const atk = ease(seg(t, T.atk, T.atk + 0.8)) * (1 - seg(t, T.end, T.end + 1.2));
  const sh = ease(seg(t, T.shield, T.shield + 0.7)) * (1 - seg(t, T.end + 0.6, T.end + 1.6));
  const SR = R * 0.17;

  // faint attack paths
  const paths = SRC.map((s) => arc(g, s, TARGET, 0.18, 36));
  ctx.globalCompositeOperation = 'lighter';
  if (atk > 0) for (const p of paths) {
    ctx.strokeStyle = rgba(RED, 0.14 * atk * fade); ctx.lineWidth = 1;
    ctx.beginPath(); p.forEach((q, i) => (q.z > -0.1 ? (i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y)) : null)); ctx.stroke();
  }
  // attack packets: fly, hit the shield, burst
  paths.forEach((p, i) => {
    const hit = p.findIndex((q) => Math.hypot(q.x - tg.x, q.y - tg.y) < SR) / (p.length - 1);
    const uh = hit > 0 ? hit : 0.92;
    const per = 0.13 + hash(i, 31) * 0.14, dur = 1.0 + hash(i, 32) * 0.5;
    for (let j = 0; j < 90; j++) {
      const e = T.atk + hash(i, 33) * per + j * per;
      if (e > T.end) break;
      const u = (t - e) / dur;
      if (u < 0) break;
      if (u < uh) {
        const q = along(p, u), q0 = along(p, Math.max(0, u - 0.08));
        if (q.z < -0.05) continue;
        const sg = ctx.createLinearGradient(q0.x, q0.y, q.x, q.y);
        sg.addColorStop(0, rgba(RED, 0)); sg.addColorStop(1, rgba('#ff9a8c', 0.95 * fade));
        ctx.strokeStyle = sg; ctx.lineWidth = 1.8; ctx.beginPath(); ctx.moveTo(q0.x, q0.y); ctx.lineTo(q.x, q.y); ctx.stroke();
        glow(ctx, q.x, q.y, 6, RED, 0.7 * fade);
      } else if (u < uh + 0.35 && sh > 0.3) {
        const b = (u - uh) / 0.35, q = along(p, uh);
        glow(ctx, q.x, q.y, 16 * (1 - b) + 4, '#ffb3a8', (1 - b) * 0.8 * fade);
        for (let k = 0; k < 5; k++) { const a = hash(i * 40 + j, k) * TAU, r = b * 16; ctx.fillStyle = rgba('#ffd2c9', (1 - b) * 0.9 * fade); ctx.fillRect(q.x + Math.cos(a) * r, q.y + Math.sin(a) * r, 1.6, 1.6); }
      }
    }
  });
  // real customers: straight through to checkout
  CLEAN.forEach((s, i) => {
    const p = arc(g, s, TARGET, 0.12, 24);
    ctx.strokeStyle = rgba(CYAN, 0.18 * fade); ctx.lineWidth = 1;
    ctx.beginPath(); p.forEach((q, k) => (k ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y))); ctx.stroke();
    for (let j = 0; j < 3; j++) { const u = ((t * 0.45 + i * 0.21 + j / 3) % 1); const q = along(p, u); glow(ctx, q.x, q.y, 6, CYAN, 0.9 * fade); }
  });

  // the edge shield
  if (sh > 0) {
    const pu = (t % 1.2) / 1.2;
    const sg = ctx.createRadialGradient(tg.x, tg.y, SR * 0.2, tg.x, tg.y, SR);
    sg.addColorStop(0, rgba(TEAL, 0.02 * sh)); sg.addColorStop(0.8, rgba(TEAL, 0.12 * sh)); sg.addColorStop(1, rgba(TEAL, 0.32 * sh));
    ctx.fillStyle = sg; ctx.beginPath(); ctx.arc(tg.x, tg.y, SR * (0.85 + 0.15 * sh), 0, TAU); ctx.fill();
    ring(ctx, tg.x, tg.y, SR * (0.85 + 0.15 * sh), TEAL, 0.85 * sh * fade, 1.6);
    ring(ctx, tg.x, tg.y, SR * (1 + pu * 0.25), TEAL, (1 - pu) * 0.4 * sh * fade, 1);
  }
  ctx.globalCompositeOperation = 'source-over';
  // checkout, the bank's origin
  const ok = 1 - 0.0;
  glow(ctx, tg.x, tg.y, 26, CYAN, 0.6 * fade);
  ctx.fillStyle = rgba('#0f1c26', 0.95 * fade); ctx.strokeStyle = rgba(CYAN, 0.9 * fade); ctx.lineWidth = 1.4;
  ctx.beginPath(); ctx.arc(tg.x, tg.y, 13, 0, TAU); ctx.fill(); ctx.stroke();
  drawIcon(ctx, 'server2', tg.x, tg.y, 14, '#e8f8ff', ok * fade, 1.7);

  // labels
  const calm = 1 - atk;
  out.edgeCalm = { x: narrow ? 14 : 24, y: narrow ? 14 : 24, o: calm * fade, ax: 0, ay: 0 };
  out.edgeAtk = { x: narrow ? 14 : 24, y: narrow ? 14 : 24, o: atk * fade, ax: 0, ay: 0 };
  out.origin = { x: narrow ? w - 14 : w - 24, y: narrow ? 14 : 24, o: ease(seg(t, 0.3, 0.9)) * fade, ax: -100, ay: 0 };
  out.target = { x: tg.x, y: tg.y + 22, o: ease(seg(t, 0.5, 1.0)) * fade, ay: 0 };
  out.absorbed = { x: tg.x + SR * 1.1, y: tg.y - SR * 1.1, o: ease(seg(t, T.absorbed, T.absorbed + 0.5)) * (1 - seg(t, T.end + 0.4, T.end + 1)) * fade, ax: 0, ay: -100 };
  out.p95 = { x: w / 2, y: h - (narrow ? 14 : 22), o: ease(seg(t, T.absorbed + 0.8, T.absorbed + 1.3)) * fade, ay: -100 };
  return out;
}

export const DDOS = { draw, loop: LOOP, still: 6.5, ratio: 1.45, narrowRatio: 0.95 };

const Stat = ({ k, v, c, sub }) => <span className="scn-card"><span style={{ textTransform: 'uppercase', letterSpacing: '.08em', fontSize: '.74em', fontWeight: 600 }}>{k}</span><b style={{ fontSize: '1.45em', color: c, letterSpacing: '-.02em' }}>{v}</b>{sub && <span>{sub}</span>}</span>;

export function EdgeShield({ t }) {
  return (
    <Scene scene={DDOS} t={t}
      label="Illustration: a DDoS flood of 1.8 million requests a second arrives from many countries at once and breaks on a shield at the edge, near the bank's users. Real customers pass straight through to checkout, the bank's servers see their normal 4,200 requests a second, and checkout keeps responding in 182 milliseconds."
      labels={{
        edgeCalm: <Stat k="At the edge" v="6,100 req/s" c="#e9ecef" sub="A normal Tuesday" />,
        edgeAtk: <Stat k="At the edge" v="1.8 M req/s" c="#ff8b7e" sub="41,200 IPs · HTTP and SYN flood" />,
        origin: <Stat k="Reaching your servers" v="4,200 req/s" c="#6fd4ff" sub="Unchanged" />,
        target: <span className="scn-tag" style={{ color: '#9fe6ff' }}>checkout.bank.in</span>,
        absorbed: <span className="scn-tag" style={{ color: '#5ff0d6' }}>Absorbed at the edge · mitigated in 9 s</span>,
        p95: <span className="scn-card text-center" style={{ borderColor: 'rgb(52 224 195 / .4)' }}><b>Checkout still answers in 182 ms</b><span>No diversion to a scrubbing centre. Customers keep paying.</span></span>,
      }} />
  );
}
