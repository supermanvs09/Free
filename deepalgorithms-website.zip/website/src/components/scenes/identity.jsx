import Scene from './Scene.jsx';
import { TAU, clamp, seg, ease, lerp, hash, rot, camera, glow, orb, ring, drawIcon, text, rgba, preload } from './engine.js';

/* One person at the centre of a small universe: three orbits of machine
   identities (service accounts, cloud keys, AI agents) appear one deploy at a
   time until there are fifteen; then three of them turn red, each with the
   reason adapID flags it. */
const KINDS = [
  { name: 'Service accounts', g: 'server', c: '#a9c1de', R: 0.62, tilt: [0.42, 0.55], speed: 0.2 },
  { name: 'Cloud keys', g: 'key', c: '#ffd27a', R: 0.94, tilt: [0.2, -0.42], speed: -0.15 },
  { name: 'AI agents', g: 'bot', c: '#b4bfff', R: 1.24, tilt: [0.62, 0.12], speed: 0.11 },
];
const RED = '#ff6b5d', CORE = '#3cc8f6';
const FLAGS = { 1: ['f0', 'No owner'], 9: ['f1', 'Key unused for 412 days'], 11: ['f2', 'Admin on production'] };
const N = 15, APPEAR = 0.7, GAP = 0.2, FLAG = 5.4, LOOP = 13;
const DUST = Array.from({ length: 140 }, (_, i) => [hash(i, 1) * 2 - 1, hash(i, 2) * 2 - 1, hash(i, 3) * 2 - 1, hash(i, 4)]);
preload([['server', '#a9c1de'], ['key', '#ffd27a'], ['bot', '#b4bfff'], ['server', RED], ['key', RED], ['bot', RED], ['user', '#e9f8ff', 1.7]]);

function nodes(t) {
  return Array.from({ length: N }, (_, n) => {
    const r = n % 3, i = Math.floor(n / 3), K = KINDS[r];
    const th = (i / 5) * TAU + r * 0.7 + K.speed * t;
    let p = [K.R * Math.cos(th), 0, K.R * Math.sin(th)];
    p = rot(p, K.tilt[0], 0, K.tilt[1]);
    return { n, r, K, p, at: APPEAR + n * GAP, flag: FLAGS[n] };
  });
}

/* how many identities are on screen at time t */
export const identityCount = (t) => Math.max(0, Math.min(N, Math.floor((t - APPEAR - 0.2) / GAP) + 1));

function draw(ctx, w, h, t, { narrow, mx, my, film }) {
  const out = {};
  const fade = 1 - seg(t, LOOP - 0.8, LOOP);
  const unit = Math.min(w, h) * (narrow ? 0.34 : 0.38);
  const cx = w * 0.5, cy = h * (narrow ? 0.47 : 0.5);
  const cam = camera(cx, cy, unit, 4.2);
  const ay = -0.5 + t * 0.09 + mx * 0.18, ax = 0.18 + my * 0.1;
  const flagged = ease(seg(t, FLAG, FLAG + 0.6));

  // nebula and drifting dust
  const neb = ctx.createRadialGradient(cx, cy, 0, cx, cy, Math.max(w, h) * 0.7);
  neb.addColorStop(0, rgba('#1d6f9c', 0.22 * fade)); neb.addColorStop(0.45, rgba('#16324a', 0.12 * fade)); neb.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = neb; ctx.fillRect(0, 0, w, h);
  ctx.globalCompositeOperation = 'lighter';
  for (const [x, y, z, s] of DUST) {
    const q = cam(rot([x * 2.2, y * 1.6, z * 2.2], ax * 0.5, ay * 0.4 + t * 0.01, 0));
    const a = (0.18 + 0.4 * s) * clamp((q.z + 2.2) / 3) * fade;
    ctx.fillStyle = rgba('#9fdcff', a); ctx.fillRect(q.x, q.y, 1.2 * q.k, 1.2 * q.k);
  }
  ctx.globalCompositeOperation = 'source-over';

  // orbits, brighter in front
  for (const K of KINDS) {
    const show = ease(seg(t, APPEAR - 0.3, APPEAR + 0.9)) * fade;
    let prev = null;
    for (let s = 0; s <= 96; s++) {
      const th = (s / 96) * TAU;
      const q = cam(rot(rot([K.R * Math.cos(th), 0, K.R * Math.sin(th)], K.tilt[0], 0, K.tilt[1]), ax, ay, 0));
      if (prev) { ctx.strokeStyle = rgba(K.c, (0.07 + 0.16 * clamp((q.z + 1) / 2)) * show); ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(prev.x, prev.y); ctx.lineTo(q.x, q.y); ctx.stroke(); }
      prev = q;
    }
  }

  // identities
  const list = nodes(t).map((d) => ({ ...d, q: cam(rot(d.p, ax, ay, 0)) }));
  const core = cam([0, 0, 0]);
  const coreIn = ease(seg(t, 0.05, 0.8)) * fade;

  // edges and the light that travels along them
  ctx.globalCompositeOperation = 'lighter';
  for (const d of list) {
    const x = ease(seg(t, d.at, d.at + 0.45));
    if (x <= 0) continue;
    const red = d.flag && flagged > 0;
    const col = red ? RED : d.K.c;
    const ex = lerp(core.x, d.q.x, x), ey = lerp(core.y, d.q.y, x);
    const g = ctx.createLinearGradient(core.x, core.y, ex, ey);
    g.addColorStop(0, rgba(CORE, 0.05 * fade)); g.addColorStop(1, rgba(col, (red ? 0.65 : 0.32) * clamp((d.q.z + 1.4) / 2.2) * fade));
    ctx.strokeStyle = g; ctx.lineWidth = red ? 1.6 : 1; ctx.beginPath(); ctx.moveTo(core.x, core.y); ctx.lineTo(ex, ey); ctx.stroke();
    const u = ((t * 0.55 + hash(d.n, 9)) % 1);
    if (x >= 1) glow(ctx, lerp(core.x, d.q.x, u), lerp(core.y, d.q.y, u), 7 * d.q.k, col, 0.8 * fade);
  }
  ctx.globalCompositeOperation = 'source-over';

  const drawNode = (d) => {
    const x = ease(seg(t, d.at, d.at + 0.5));
    if (x <= 0) return;
    const red = d.flag && flagged > 0;
    const col = red ? RED : d.K.c;
    const s = unit * 0.115 * d.q.k * (0.6 + 0.4 * x);
    const depth = 0.45 + 0.55 * clamp((d.q.z + 1.2) / 2.2);
    const a = x * depth * fade;
    // arrival burst
    const b = seg(t, d.at, d.at + 0.9);
    if (b > 0 && b < 1) ring(ctx, d.q.x, d.q.y, s * (1 + b * 1.5), d.K.c, (1 - b) * 0.45 * fade, 1.2);
    if (red) {
      ctx.globalCompositeOperation = 'lighter';
      glow(ctx, d.q.x, d.q.y, s * 3.4, RED, 0.55 * flagged * fade);
      ctx.globalCompositeOperation = 'source-over';
      const pu = ((t - FLAG) % 1.4) / 1.4;
      ring(ctx, d.q.x, d.q.y, s * (1.1 + pu * 1.6), RED, (1 - pu) * 0.7 * flagged * fade, 1.6);
    }
    const g = ctx.createRadialGradient(d.q.x - s * 0.3, d.q.y - s * 0.3, s * 0.1, d.q.x, d.q.y, s);
    g.addColorStop(0, rgba('#2a2e36', a)); g.addColorStop(1, rgba('#111318', a));
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(d.q.x, d.q.y, s, 0, TAU); ctx.fill();
    ctx.strokeStyle = rgba(col, (red ? 0.9 : 0.55) * a); ctx.lineWidth = 1.4; ctx.stroke();
    drawIcon(ctx, d.K.g, d.q.x, d.q.y, s * 1.05, red ? RED : d.K.c, a);
    if (d.flag) { const right = d.q.x >= cx; out[d.flag[0]] = { x: d.q.x + (right ? 1 : -1) * s * 1.35, y: d.q.y, o: ease(seg(t, FLAG + 0.3 + (d.n % 3) * 0.35, FLAG + 0.8 + (d.n % 3) * 0.35)) * fade, ax: right ? 0 : -100, ay: -50 }; }
  };
  list.filter((d) => d.q.z < 0).sort((a, b) => a.q.z - b.q.z).forEach(drawNode);

  // the person at the centre
  const cr = unit * 0.2 * (0.7 + 0.3 * coreIn);
  ctx.globalCompositeOperation = 'lighter';
  glow(ctx, core.x, core.y, cr * 4.2, CORE, 0.5 * coreIn);
  ctx.globalCompositeOperation = 'source-over';
  const pu = (t % 2.4) / 2.4;
  ring(ctx, core.x, core.y, cr * (1.15 + pu * 0.9), CORE, (1 - pu) * 0.45 * coreIn, 1.4);
  orb(ctx, core.x, core.y, cr, CORE, coreIn, 0.8);
  drawIcon(ctx, 'user', core.x, core.y, cr * 1.05, '#e9f8ff', coreIn, 1.7);

  list.filter((d) => d.q.z >= 0).sort((a, b) => a.q.z - b.q.z).forEach(drawNode);

  // the count (the film sets it large beside the scene instead)
  const shown = list.filter((d) => t >= d.at + 0.2).length;
  const ca = ease(seg(t, APPEAR, APPEAR + 0.5)) * fade;
  if (film) { /* counted outside */ } else if (narrow) {
    text(ctx, String(shown), w / 2, h * 0.87, { size: 30, weight: 650, alpha: ca, color: '#ffffff' });
    text(ctx, 'machine identities for one person', w / 2, h * 0.87 + 25, { size: 12.5, alpha: ca, color: '#b8bcc3' });
  } else {
    text(ctx, String(shown), w / 2 - 6, h * 0.93, { size: 34, weight: 650, align: 'right', alpha: ca, color: '#ffffff' });
    text(ctx, shown === 1 ? 'machine identity for one person' : 'machine identities for one person', w / 2 + 6, h * 0.93 + 2, { size: 15, align: 'left', alpha: ca, color: '#b8bcc3' });
  }

  // legend
  const lg = ease(seg(t, 0.3, 1.1)) * fade;
  out.legend = { x: narrow ? 14 : 22, y: narrow ? 14 : 22, o: lg, ax: 0, ay: 0 };
  out.verdict = { x: w / 2, y: narrow ? h * 0.73 : h * 0.82, o: ease(seg(t, FLAG + 1.8, FLAG + 2.4)) * fade };
  return out;
}

export const IDENTITY = { draw, loop: LOOP, still: 9.5, ratio: 1.3, narrowRatio: 0.92 };
const IDENTITY_FILM = { ...IDENTITY, draw: (ctx, w, h, t, o) => draw(ctx, w, h, t, { ...o, film: true }) };

const Tag = ({ children }) => <span className="scn-tag" style={{ color: '#ff8b7e' }}><span style={{ width: '.5em', height: '.5em', borderRadius: '50%', background: 'currentColor' }} />{children}</span>;

/* `film` drops the legend, the count and the summary card: in the film the
   narration and the words beside the scene already say them. */
export function IdentityUniverse({ t, film, dpr }) {
  return (
    <Scene scene={film ? IDENTITY_FILM : IDENTITY} t={t} dpr={dpr}
      label="Illustration: one person at the centre of three orbits of machine identities, service accounts, cloud keys and AI agents, appearing one deploy at a time until there are fifteen. Three turn red: one has no owner, one key has not been used for 412 days, one agent is an admin on production."
      labels={{
        ...(film ? {} : { legend: (
          <span className="flex flex-col gap-[.35em]" style={{ fontSize: '.92em' }}>
            {KINDS.map((K) => <span key={K.name} className="inline-flex items-center gap-[.5em]" style={{ color: '#c9ccd2' }}><span style={{ width: '.55em', height: '.55em', borderRadius: '50%', background: K.c, boxShadow: `0 0 .6em ${K.c}` }} />{K.name}</span>)}
          </span>
        ) }),
        f0: <Tag>{FLAGS[1][1]}</Tag>,
        f1: <Tag>{FLAGS[9][1]}</Tag>,
        f2: <Tag>{FLAGS[11][1]}</Tag>,
        ...(film ? {} : { verdict: <span className="scn-card text-center" style={{ borderColor: 'rgb(255 107 93 / .4)' }}><b>3 of 15 need action today</b><span>Found and explained by adapID, before anyone uses them</span></span> }),
      }} />
  );
}
