import Scene from './Scene.jsx';
import { Logo } from '../viz/kit.jsx';
import { TAU, seg, ease, lerp, hash, glow, rgba, clamp, text } from './engine.js';

/* A login page under a credential-stuffing wave. People arrive at their own
   uneven pace and pass the gate; bots arrive in perfectly regular bursts from
   rotating addresses and break on BotShield's intent check, named by the tool
   that sent them. Nothing asks a person to solve a puzzle. */
const HUMAN = '#4fd2ff', BOT = '#ff6b5d', GATE = '#34e0c3';
const T = { wave: 1.8, end: 10.2 }, LOOP = 12;
const HUM = Array.from({ length: 40 }, (_, i) => ({ y: 0.16 + hash(i, 81) * 0.68, e: hash(i, 82) * LOOP, sp: 0.1 + hash(i, 83) * 0.06, wob: hash(i, 84) * TAU }));
const WAVES = Array.from({ length: 22 }, (_, i) => ({ e: T.wave + i * 0.36 + hash(i, 85) * 0.15, y: 0.2 + hash(i, 86) * 0.6, n: 14 + Math.floor(hash(i, 87) * 9), kind: i % 3 }));
const KINDS = [['chrome', 'Headless Chrome'], ['selenium', 'Selenium'], ['puppeteer', 'Puppeteer']];

function draw(ctx, w, h, t, { narrow }) {
  const out = {};
  const fade = 1 - seg(t, LOOP - 0.6, LOOP);
  const gx = w * (narrow ? 0.6 : 0.58);
  const appear = ease(seg(t, 0, 0.7)) * fade;
  const atk = ease(seg(t, T.wave - 0.3, T.wave + 0.4)) * (1 - seg(t, T.end, T.end + 0.8));

  // the gate
  for (let k = 0; k < 3; k++) {
    const g = ctx.createLinearGradient(0, h * 0.06, 0, h * 0.94);
    g.addColorStop(0, rgba(GATE, 0)); g.addColorStop(0.5, rgba(GATE, (k === 1 ? 0.9 : 0.18 + 0.2 * atk) * appear)); g.addColorStop(1, rgba(GATE, 0));
    ctx.strokeStyle = g; ctx.lineWidth = k === 1 ? 2 : 10 + 8 * atk;
    ctx.beginPath(); ctx.moveTo(gx + (k - 1) * 3, h * 0.06); ctx.lineTo(gx + (k - 1) * 3, h * 0.94); ctx.stroke();
  }
  // the signed-in side
  const sg = ctx.createLinearGradient(gx, 0, w, 0);
  sg.addColorStop(0, rgba(HUMAN, 0.06 * appear)); sg.addColorStop(1, rgba(HUMAN, 0));
  ctx.fillStyle = sg; ctx.fillRect(gx, 0, w - gx, h);

  ctx.globalCompositeOperation = 'lighter';
  // people: their own pace, a slight wander, straight through
  for (const p of HUM) {
    const u = (((t - p.e) % LOOP) + LOOP) % LOOP * p.sp;
    if (u > 1.05) continue;
    const x = lerp(-0.02 * w, w * 1.02, u), y = (p.y + Math.sin(u * 9 + p.wob) * 0.018) * h;
    glow(ctx, x, y, 9, HUMAN, 0.85 * fade);
    ctx.fillStyle = rgba('#e6f8ff', 0.9 * fade); ctx.fillRect(x - 1.2, y - 1.2, 2.4, 2.4);
  }
  // bots: regular bursts, straight and fast, broken at the gate
  WAVES.forEach((wv, i) => {
    for (let j = 0; j < wv.n; j++) {
      const e = wv.e + j * 0.035, dur = 0.8;
      const u = (t - e) / dur;
      if (u < 0 || e > T.end) continue;
      const y = (wv.y + (j - wv.n / 2) * 0.009) * h;
      const hitU = gx / (w * 1.02);
      if (u < hitU) {
        const x = lerp(-0.02 * w, w * 1.02, u), x0 = lerp(-0.02 * w, w * 1.02, Math.max(0, u - 0.12));
        const g = ctx.createLinearGradient(x0, y, x, y); g.addColorStop(0, rgba(BOT, 0)); g.addColorStop(1, rgba('#ff9a8c', 0.95 * fade));
        ctx.strokeStyle = g; ctx.lineWidth = 1.8; ctx.beginPath(); ctx.moveTo(x0, y); ctx.lineTo(x, y); ctx.stroke();
      } else {
        const b = (u - hitU) / 0.5;
        if (b < 1) {
          glow(ctx, gx, y, 14 * (1 - b) + 4, BOT, (1 - b) * 0.85 * fade);
          for (let k = 0; k < 4; k++) { const a = Math.PI + (hash(i * 20 + j, k) - 0.5) * 2.2, r = b * 22; ctx.fillStyle = rgba('#ffc9c1', (1 - b) * fade); ctx.fillRect(gx + Math.cos(a) * r, y + Math.sin(a) * r, 1.6, 1.6); }
        }
      }
    }
    // name the tool behind the wave as it breaks
    const at = wv.e + (gx / (w * 1.02)) * 0.8;
    out[`w${i}`] = { x: gx - 14, y: wv.y * h, o: (i % 2 ? 0 : Math.min(seg(t, at, at + 0.2), 1 - seg(t, at + 0.8, at + 1.1))) * fade, ax: -100, ay: -50 };
  });
  ctx.globalCompositeOperation = 'source-over';

  // counters
  const blocked = Math.round(18204 * seg(t, T.wave + 0.6, T.end));
  const people = Math.round(2931 * seg(t, 0.2, LOOP - 1));
  const fmt = (n) => n.toLocaleString('en-IN');
  const cy = narrow ? h * 0.08 : h * 0.1;
  text(ctx, fmt(blocked), narrow ? 14 : 24, cy, { size: narrow ? 22 : 28, weight: 650, color: '#ff8b7e', align: 'left', alpha: appear });
  text(ctx, 'stopped by intent', narrow ? 14 : 24, cy + (narrow ? 19 : 24), { size: narrow ? 11 : 13, color: '#a4a7ad', align: 'left', alpha: appear });
  text(ctx, fmt(people), w - (narrow ? 14 : 24), cy, { size: narrow ? 22 : 28, weight: 650, color: '#7fdcff', align: 'right', alpha: appear });
  text(ctx, 'people signed in, no puzzle', w - (narrow ? 14 : 24), cy + (narrow ? 19 : 24), { size: narrow ? 11 : 13, color: '#a4a7ad', align: 'right', alpha: appear });
  out.gate = narrow ? { x: gx, y: h * 0.19, o: appear, ay: 0 } : { x: gx, y: h * 0.94, o: appear, ay: -100 };
  out.signin = { x: gx + (w - gx) / 2, y: h * 0.5, o: appear * (narrow ? 0 : 1) };
  out.foot = { x: narrow ? w / 2 : w * 0.29, y: h - (narrow ? 12 : 18), o: ease(seg(t, T.wave + 1.2, T.wave + 1.8)) * fade, ay: -100 };
  return out;
}

export const BOTS = { draw, loop: LOOP, still: 6, ratio: 1.75, narrowRatio: 0.9 };

export function BotStream({ t }) {
  const labels = {
    gate: <span className="scn-tag" style={{ color: '#5ff0d6' }}>POST /login · BotShield</span>,
    signin: <span className="scn-card" style={{ width: '11.5em', padding: '.9em 1em', background: 'rgb(16 18 22 / .9)' }}><b>Sign in · bank.in</b><span style={{ marginTop: '.6em', height: '1.6em', borderRadius: '.4em', background: 'rgb(255 255 255 / .07)' }} /><span style={{ marginTop: '.4em', height: '1.6em', borderRadius: '.4em', background: 'rgb(255 255 255 / .07)' }} /><span style={{ marginTop: '.6em', height: '1.8em', borderRadius: '.4em', background: '#0a6dbb', color: '#fff', textAlign: 'center', lineHeight: '1.8em', fontWeight: 600 }}>Continue</span></span>,
    foot: <span className="scn-card text-center"><b>6,410 rotating IPs, one intent</b><span>Caught by typing cadence, header order and retry timing</span></span>,
  };
  WAVES.forEach((wv, i) => { const [k, n] = KINDS[wv.kind]; labels[`w${i}`] = <span className="scn-tag" style={{ color: '#ffb1a8' }}><Logo k={k} size="1.1em" />{n}</span>; });
  return (
    <Scene scene={BOTS} t={t}
      label="Illustration: a login page under a credential-stuffing attack. People arrive at uneven, human pace and pass straight through. Bots arrive in regular bursts from 6,410 rotating IP addresses, driven by Headless Chrome, Selenium and Puppeteer, and are stopped at the gate by BotShield's intent check, using typing cadence, header order and retry timing. 18,204 attempts are stopped while 2,931 people sign in without a puzzle."
      labels={labels} />
  );
}
