import Scene from './Scene.jsx';
import { TAU, seg, ease, inout, lerp, hash, glow, rgba, clamp, rot, camera, drawIcon, preload, text } from './engine.js';

/* A scanner hands over 37 possible findings. BotShield's red-team agent
   replays each one: the beam sweeps the field, what cannot be exploited sinks
   and dims, and six rise. The blue-team agent then puts a virtual patch on
   each of the six and sends the fix to its owner. */
export const PROVEN = [[3, 'OTP endpoint without a rate limit', 'api.bank.in'], [9, 'Session token in a URL', 'm.bank.in'], [16, 'Debug route exposed', 'pay.bank.in'], [22, 'Card BIN check can be skipped', 'pay.bank.in'], [28, 'Weak CORS on the payments API', 'api.bank.in'], [33, 'Old TLS on a partner gateway', 'partners.bank.in']];
const IS = Object.fromEntries(PROVEN.map(([i], k) => [i, k]));
const COLS = 8, N = 37;
const SEV = (i) => (i * 7 + 3) % 5;
const T = { scan: 1.3, scanEnd: 4.1, patch: 4.9, done: 7.4 }, LOOP = 12;
const RED = '#ff6b5d', TEAL = '#34e0c3';
preload([['shieldok', '#0b1f1b', 2.2]]);

function draw(ctx, w, h, t, { narrow, mx, my }) {
  const out = {};
  const fade = 1 - seg(t, LOOP - 0.6, LOOP);
  const unit = narrow ? w * 0.43 : Math.min(w * 0.3, h * 0.62);
  const cx = narrow ? w / 2 : w * 0.33, cy = narrow ? h * 0.3 : h * 0.55;
  const cam = camera(cx, cy, unit, 4.5);
  const ax = -1.0 + my * 0.05, ay = -0.32 + mx * 0.12 + Math.sin(t * 0.3) * 0.03;
  const P = (p) => cam(rot(p, ax, ay, 0));
  const appear = ease(seg(t, 0, 0.7)) * fade;
  const bx = lerp(-1.25, 1.25, inout(seg(t, T.scan, T.scanEnd)));

  // the field
  const tiles = Array.from({ length: N }, (_, i) => {
    const c = i % COLS, r = Math.floor(i / COLS);
    const x = -1 + (c + 0.5) * (2 / COLS), z = -0.62 + (r + 0.5) * 0.25;
    const scanned = t >= T.scan && bx > x;
    const k = IS[i];
    const up = k !== undefined ? ease(clamp((bx - x) / 0.5)) : 0;
    const patched = k !== undefined && t >= T.patch + k * 0.35;
    return { i, x, z, scanned, k, up, patched };
  });
  const order = tiles.map((d) => ({ ...d, c: P([d.x, 0, d.z]) })).sort((a, b) => a.c.z - b.c.z);

  // grid floor
  ctx.strokeStyle = rgba('#7fb4d8', 0.08 * appear); ctx.lineWidth = 1;
  for (let gx = -1.2; gx <= 1.21; gx += 0.25) { const a = P([gx, 0.02, -0.75]), b = P([gx, 0.02, 0.75]); ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); }
  for (let gz = -0.75; gz <= 0.76; gz += 0.25) { const a = P([-1.2, 0.02, gz]), b = P([1.2, 0.02, gz]); ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); }

  for (const d of order) {
    const proven = d.k !== undefined;
    const sink = d.scanned && !proven ? ease(clamp((bx - d.x) / 0.4)) : 0;
    const y = proven ? -0.28 * d.up : 0.06 * sink;
    const s = 0.105;
    const q = [[-s, y, -s], [s, y, -s], [s, y, s], [-s, y, s]].map(([a, b, c]) => P([d.x + a, b, d.z + c]));
    const sev = SEV(d.i), sc = sev >= 3 ? '#ff8b7e' : sev >= 1 ? '#f6b955' : '#9aa0a9';
    const col = d.patched ? TEAL : proven && d.scanned ? RED : d.scanned ? '#5b6068' : sc;
    const a = (d.scanned && !proven ? 1 - 0.65 * sink : 1) * appear;
    if (proven && d.up > 0) {
      ctx.globalCompositeOperation = 'lighter';
      const m = P([d.x, y, d.z]); glow(ctx, m.x, m.y, unit * 0.22, col, 0.55 * d.up * fade);
      ctx.globalCompositeOperation = 'source-over';
      // a stem down to the floor
      const f = P([d.x, 0, d.z]); ctx.strokeStyle = rgba(col, 0.5 * d.up * fade); ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(f.x, f.y); ctx.lineTo(m.x, m.y); ctx.stroke();
    }
    ctx.fillStyle = rgba(d.patched ? '#0f2622' : proven && d.scanned ? '#2a1513' : '#16191e', 0.95 * a);
    ctx.strokeStyle = rgba(col, (proven && d.scanned ? 0.95 : 0.55) * a); ctx.lineWidth = proven && d.scanned ? 1.6 : 1;
    ctx.beginPath(); ctx.moveTo(q[0].x, q[0].y); for (let j = 1; j < 4; j++) ctx.lineTo(q[j].x, q[j].y); ctx.closePath(); ctx.fill(); ctx.stroke();
    const m = P([d.x, y, d.z]);
    if (d.patched) {
      const pa = ease(seg(t, T.patch + d.k * 0.35, T.patch + d.k * 0.35 + 0.4));
      ctx.fillStyle = rgba(TEAL, pa * fade); ctx.beginPath(); ctx.arc(m.x, m.y, unit * 0.05 * m.k, 0, TAU); ctx.fill();
      drawIcon(ctx, 'shieldok', m.x, m.y, unit * 0.07 * m.k, '#0b1f1b', pa * fade, 2.2);
    } else {
      text(ctx, `F-${String(d.i + 1).padStart(2, '0')}`, m.x, m.y, { size: Math.max(8, unit * 0.045 * m.k), weight: proven && d.scanned ? 650 : 500, color: proven && d.scanned ? '#ffd9d3' : '#c3c7cd', alpha: a, mono: true });
    }
    if (proven) {
      const lx = narrow ? null : w * 0.69, ly = narrow ? null : h * (0.17 + d.k * 0.125);
      out[`p${d.k}`] = narrow
        ? { x: d.k % 2 ? w * 0.52 : w * 0.04, y: h * (0.6 + Math.floor(d.k / 2) * 0.115), o: ease(seg(t, T.patch + d.k * 0.35, T.patch + d.k * 0.35 + 0.4)) * fade, ax: 0, ay: 0 }
        : { x: lx, y: ly, o: ease(seg(t, T.patch + d.k * 0.35, T.patch + d.k * 0.35 + 0.4)) * fade, ax: 0, ay: -50 };
      if (!narrow && d.patched) {
        const pa = ease(seg(t, T.patch + d.k * 0.35, T.patch + d.k * 0.35 + 0.5));
        ctx.strokeStyle = rgba(TEAL, 0.35 * pa * fade); ctx.lineWidth = 1; ctx.setLineDash([2, 4]);
        ctx.beginPath(); ctx.moveTo(m.x, m.y); ctx.bezierCurveTo(m.x + 60, m.y, lx - 60, ly, lx - 6, ly); ctx.stroke(); ctx.setLineDash([]);
      }
    }
  }

  // the red-team beam
  if (t > T.scan - 0.2 && t < T.scanEnd + 0.4) {
    const ba = Math.min(seg(t, T.scan - 0.2, T.scan + 0.2), 1 - seg(t, T.scanEnd, T.scanEnd + 0.4)) * fade;
    const a = P([bx, -0.35, -0.85]), b = P([bx, -0.35, 0.85]), c2 = P([bx, 0.05, 0.85]), d2 = P([bx, 0.05, -0.85]);
    const g = ctx.createLinearGradient(a.x, a.y, d2.x, d2.y);
    g.addColorStop(0, rgba(RED, 0)); g.addColorStop(1, rgba(RED, 0.28 * ba));
    ctx.globalCompositeOperation = 'lighter';
    ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.lineTo(c2.x, c2.y); ctx.lineTo(d2.x, d2.y); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = rgba('#ffb1a8', 0.9 * ba); ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(d2.x, d2.y); ctx.lineTo(c2.x, c2.y); ctx.stroke();
    ctx.globalCompositeOperation = 'source-over';
  }

  out.before = { x: narrow ? 12 : 22, y: narrow ? 12 : 20, o: appear * (1 - seg(t, T.scanEnd - 0.2, T.scanEnd + 0.3)), ax: 0, ay: 0 };
  out.after = { x: narrow ? 12 : 22, y: narrow ? 12 : 20, o: ease(seg(t, T.scanEnd - 0.2, T.scanEnd + 0.3)) * fade, ax: 0, ay: 0 };
  out.beam = { x: narrow ? w - 12 : w * 0.62, y: narrow ? 12 : 20, o: Math.min(seg(t, T.scan, T.scan + 0.3), 1 - seg(t, T.scanEnd, T.scanEnd + 0.3)) * fade, ax: -100, ay: 0 };
  return out;
}

export const PROOF = { draw, loop: LOOP, still: 9, ratio: 1.75, narrowRatio: 0.66 };

const Big = ({ k, v, c, sub }) => <span className="scn-card"><span style={{ textTransform: 'uppercase', letterSpacing: '.08em', fontSize: '.74em', fontWeight: 600 }}>{k}</span><b style={{ fontSize: '1.5em', color: c, letterSpacing: '-.02em' }}>{v}</b><span>{sub}</span></span>;

export function ProofField({ t }) {
  const labels = {
    before: <Big k="From the scanner" v="37 to triage" c="#ffb38a" sub="Unproven, each waiting for a developer" />,
    after: <Big k="After the red-team replay" v="6 that matter" c="#5ff0d6" sub="Proven exploitable, each patched in minutes" />,
    beam: <span className="scn-tag" style={{ color: '#ffb1a8' }}>Red-team agent replaying each finding</span>,
  };
  PROVEN.forEach(([i, name, host], k) => {
    labels[`p${k}`] = (
      <span className="scn-card pf-item" style={{ borderColor: 'rgb(52 224 195 / .35)' }}>
        <span style={{ display: 'inline', color: '#5ff0d6', fontFamily: 'var(--font-mono)', fontWeight: 600, whiteSpace: 'nowrap' }}>F-{String(i + 1).padStart(2, '0')}</span>
        <span style={{ display: 'inline' }}><b style={{ display: 'inline', fontSize: '.95em' }}>{name}</b><span className="pf-sub">{host} · virtual patch live · fix sent to owner</span></span>
      </span>
    );
  });
  return (
    <Scene scene={PROOF} t={t}
      label="Illustration: 37 possible findings from a scan lie on a field. BotShield's red-team agent replays each one; the 31 that cannot be exploited sink and dim, and six rise as proven exploitable: an OTP endpoint without a rate limit, a session token in a URL, an exposed debug route, a skippable card BIN check, weak CORS on the payments API and old TLS on a partner gateway. The blue-team agent puts a virtual patch on each and sends the fix to its owner."
      labels={labels} />
  );
}
