import { useEffect, useId, useRef, useState } from 'react';
import { Link } from 'react-router';
import { Icon } from './ui.jsx';
import ProductMark from './ProductMark.jsx';
import { cx, useInView, useReducedMotion } from '../lib/motion.js';
import { ZenGateway } from './viz/zenstra.jsx';
import { AdapRiskTimeline } from './viz/adapid.jsx';
import { CtemLoop } from './viz/botshield.jsx';
import { IcmsEvidence } from './viz/icms.jsx';

const ITEMS = [
  { key: 'zen', name: 'Zenstra AI', acc: 'var(--color-zen)', h: 'An agent tries to export CRM data. It never runs.', p: 'Each tool call is checked against the agent’s task and grant before it reaches your systems. Payments wait for a person.', to: '/agentic-ai/agentic-identity', V: ZenGateway },
  { key: 'adap', name: 'adapID AI', acc: 'var(--color-adap)', h: 'A valid login, an invalid person.', p: 'adapID learns how each identity normally works. When behaviour changes, the score rises with the reasons attached and the session is held.', to: '/adapid-ai', V: AdapRiskTimeline },
  { key: 'bot', name: 'BotShield AI', acc: 'var(--color-bot)', h: 'Thousands of findings. Six that matter.', p: 'Agents map your attack surface, prove what is exploitable and deploy virtual patches while fixes reach the team that owns them.', to: '/botshield-ai', V: CtemLoop },
  { key: 'icms', name: 'ICMS Compliance Suite', acc: 'var(--color-icms)', h: 'Evidence before the auditor asks.', p: 'Every access to personal data is checked against purpose and consent. Audit packages for DPDPA, RBI and SEBI assemble as you work.', to: '/dpdpa-compliance', V: IcmsEvidence },
];
const DUR = 11000;

export default function Spotlight() {
  const [i, setI] = useState(0);
  const [run, setRun] = useState(0);
  const [hover, setHover] = useState(false);
  const ref = useRef(null);
  const inView = useInView(ref, { threshold: 0.35 });
  const reduce = useReducedMotion();
  const id = useId();
  useEffect(() => {
    if (reduce || !inView || hover) return undefined;
    const t = setTimeout(() => setI((n) => (n + 1) % ITEMS.length), DUR);
    return () => clearTimeout(t);
  }, [i, run, inView, reduce, hover]);
  const go = (k) => { setI(k); setRun((r) => r + 1); };
  const it = ITEMS[i];
  return (
    <div ref={ref} className="grid gap-10 lg:grid-cols-[.9fr_1.3fr] lg:gap-16" onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}>
      <div role="tablist" aria-label="Products" aria-orientation="vertical" className="flex flex-col">
        {ITEMS.map((x, k) => (
          <div key={x.name} className={cx('relative border-l py-5 pl-6 transition-colors', k === i ? 'border-transparent' : 'border-line hover:border-line-2')}>
            <span aria-hidden="true" className="absolute -left-px top-0 h-full w-[2px] overflow-hidden rounded-full bg-line">
              {k === i && <span key={`${run}-${i}`} className="absolute inset-x-0 top-0 block h-full origin-top" style={{ background: x.acc, animation: reduce || hover ? 'none' : `spot-fill ${DUR}ms linear both` }} />}
            </span>
            <button id={`${id}-t${k}`} role="tab" type="button" aria-selected={k === i} aria-controls={`${id}-p`} tabIndex={k === i ? 0 : -1} onClick={() => go(k)}
              onKeyDown={(e) => { if (e.key === 'ArrowDown') { e.preventDefault(); go((i + 1) % ITEMS.length); } if (e.key === 'ArrowUp') { e.preventDefault(); go((i + ITEMS.length - 1) % ITEMS.length); } }}
              className="group block w-full text-left">
              <span className="flex items-center gap-2.5 text-[13px] font-semibold uppercase tracking-[.08em]" style={{ color: k === i ? x.acc : 'var(--color-ink-3)' }}><ProductMark p={x.key} size={22} className={cx('transition-[filter,opacity] duration-500', k !== i && 'opacity-60 grayscale')} />{x.name}</span>
              <span className={cx('mt-1.5 block text-[20px] font-semibold leading-snug tracking-[-0.02em] md:text-[22px]', k === i ? 'text-ink' : 'text-ink-3 group-hover:text-ink-2')}>{x.h}</span>
            </button>
            {k === i && (
              <div className="fadein">
                <p className="mt-3 max-w-[460px] text-[15.5px] leading-relaxed text-ink-2">{x.p}</p>
                <Link to={x.to} className="link mt-4 text-[15px]" style={{ '--acc': x.acc }}>Explore {x.name}<Icon name="ArrowRight" size={14} weight="bold" /></Link>
              </div>
            )}
          </div>
        ))}
      </div>
      <div id={`${id}-p`} role="tabpanel" aria-labelledby={`${id}-t${i}`} className="relative self-center">
        <div aria-hidden="true" className="absolute -inset-10 -z-10 rounded-full opacity-40 blur-3xl transition-colors duration-700" style={{ background: `radial-gradient(closest-side, color-mix(in oklab, ${it.acc} 33%, transparent), transparent)` }} />
        <div key={i} className="fadein"><it.V /></div>
      </div>
      <style>{'@keyframes spot-fill { from { transform: scaleY(0); } to { transform: scaleY(1); } }'}</style>
    </div>
  );
}
