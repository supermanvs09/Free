import { useId, useState } from 'react';
import { Link } from 'react-router';
import { Accordion, Breadcrumb, Button, Icon, Reveal, cx } from './ui.jsx';
import FlowRibbons from './FlowRibbons.jsx';

/* Accents are tokens, so the same accent reads well on a dark band and a light sheet. */
export const ACC = { zen: 'var(--color-zen)', adap: 'var(--color-adap)', bot: 'var(--color-bot)', icms: 'var(--color-icms)', brand: 'var(--color-sky)' };

/* Product hero frame: ribbons tinted by the product, crumbs, and two layouts:
   `split` (copy left, picture right) and `stack` (copy centred, picture below). */
export function Hero({ acc = 'brand', crumbs, eyebrow, title, lead, ctas, children, layout = 'split', ribbons = 'product', note }) {
  const color = ACC[acc] || ACC.brand;
  const stack = layout === 'stack';
  return (
    <section className="stage relative -mt-[72px] overflow-hidden pt-[72px]" style={{ '--acc': color }}>
      <FlowRibbons preset={ribbons} accent={acc} intensity={0.75} />
      <div aria-hidden="true" className="pointer-events-none absolute inset-0" style={{ background: stack ? 'radial-gradient(70% 60% at 50% 20%, rgb(4 6 11 / .6), transparent 70%)' : 'linear-gradient(90deg, rgb(4 6 11 / .78) 0%, rgb(4 6 11 / .3) 45%, transparent 70%)' }} />
      <div className={cx('hero-drift wrap relative pb-16 pt-10 md:pb-24 md:pt-14', !stack && 'grid items-center gap-12 lg:min-h-[min(88svh,900px)] lg:grid-cols-[1fr_1.1fr] lg:gap-8')}>
        <div className={cx(stack ? 'mx-auto max-w-[900px] text-center' : 'max-w-[620px]')}>
          {crumbs && <Breadcrumb items={crumbs} className={cx('rise mb-8', stack && 'flex justify-center')} />}
          {eyebrow && <p className="eyebrow rise" style={{ '--acc': color }}>{eyebrow}</p>}
          <h1 className={cx('t-h1 rise mt-6', stack && 'mx-auto max-w-[20ch]')} style={{ '--d': '80ms' }}>{title}</h1>
          {lead && <p className={cx('t-lead rise mt-6', stack ? 'mx-auto max-w-[680px]' : 'max-w-[560px]')} style={{ '--d': '160ms' }}>{lead}</p>}
          <div className={cx('rise mt-9 flex flex-wrap gap-3', stack && 'justify-center')} style={{ '--d': '240ms' }}>
            {ctas || <><Button to="/request-demo" size="lg" arrow>Book a demo</Button><Button to="/contact" variant="ghost" size="lg">Talk to an engineer</Button></>}
          </div>
          {note && <p className={cx('rise mt-7 text-[14px] text-ink-3', stack && 'text-center')} style={{ '--d': '300ms' }}>{note}</p>}
        </div>
        {children && <div className={cx('relative', stack ? 'mx-auto mt-16 max-w-[1080px]' : 'lg:-mr-6')}>{children}</div>}
      </div>
    </section>
  );
}

/* Figures with their sources; product figures say so. */
export function Stats({ items, acc = 'brand', title }) {
  const color = ACC[acc] || ACC.brand;
  return (
    <section className="sec-tight" aria-label={title || 'Key figures'}>
      <div className="wrap">
        {title && <Reveal><p className="kicker mb-8" style={{ '--acc': color }}>{title}</p></Reveal>}
        <div className="grid gap-px overflow-hidden rounded-[22px] border border-line bg-line md:grid-cols-3">
          {items.map((s, i) => (
            <Reveal key={s.l} delay={i * 80} className="bg-bg-1 p-7 md:p-9">
              <p className="font-semibold tracking-[-0.045em] num" style={{ fontSize: 'clamp(38px, 4vw, 58px)', lineHeight: 1, color: i === 0 ? color : 'var(--color-ink)' }}>{s.v}</p>
              <p className="mt-4 max-w-[300px] text-[15.5px] leading-relaxed text-ink-2">{s.l}</p>
              {s.s && <p className="mt-4 text-[12.5px] text-ink-3">Source: {s.s}</p>}
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Faq({ items, title = 'Questions teams ask us' }) {
  return (
    <section className="sec" aria-labelledby="faq-h">
      <div className="wrap grid gap-12 lg:grid-cols-[.8fr_1.2fr] lg:gap-20">
        <Reveal>
          <p className="eyebrow">FAQ</p>
          <h2 id="faq-h" className="t-h2 mt-6">{title}</h2>
          <p className="t-lead mt-5">Something else on your mind? <Link to="/contact" className="text-cyan-2 underline underline-offset-4 hover:text-fg">Ask an engineer</Link>.</p>
        </Reveal>
        <Reveal delay={100}><Accordion items={items} /></Reveal>
      </div>
    </section>
  );
}

/* A comparison table: rows of claims, columns of approaches; the last column is ours. */
export function Compare({ cols, rows, acc = 'brand', caption }) {
  const color = ACC[acc] || ACC.brand;
  return (
    <div className="overflow-x-auto rounded-[22px] border border-line" role="region" tabIndex={0} aria-label={caption}>
      <table className="w-full min-w-[640px] text-left">
        <caption className="sr-only">{caption}</caption>
        <thead>
          <tr className="border-b border-line">
            <th scope="col" className="p-5 text-[13px] font-semibold uppercase tracking-[.08em] text-ink-3">&nbsp;</th>
            {cols.map((c, i) => <th key={c} scope="col" className={cx('p-5 text-[15px] font-semibold', i === cols.length - 1 ? 'text-ink' : 'text-ink-2')} style={i === cols.length - 1 ? { background: `color-mix(in oklab, ${color} 12%, transparent)` } : undefined}>{c}</th>)}
          </tr>
        </thead>
        <tbody>
          {rows.map(([label, ...vals]) => (
            <tr key={label} className="border-b border-line last:border-0">
              <th scope="row" className="p-5 text-[15px] font-medium text-ink">{label}</th>
              {vals.map((v, i) => (
                <td key={i} className="p-5 align-top text-[14.5px] leading-snug text-ink-2" style={i === vals.length - 1 ? { background: `color-mix(in oklab, ${color} 7%, transparent)` } : undefined}>
                  {v === true ? <Icon name="CheckCircle" size={20} weight="fill" style={{ color }} /> : v === false ? <span className="text-ink-3">—</span> : v}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* Sibling products, as text cards. */
export function Related({ items, title = 'Works alongside' }) {
  return (
    <section className="sec-tight" aria-label={title}>
      <div className="wrap">
        <Reveal><p className="kicker mb-6">{title}</p></Reveal>
        <div className="grid gap-4 md:grid-cols-3">
          {items.map((p, i) => (
            <Reveal key={p.to} delay={i * 70}>
              <Link to={p.to} className="card card-hover group flex h-full flex-col p-6" style={{ '--acc': p.acc }}>
                <span className="flex items-center gap-2 text-[13px] font-semibold uppercase tracking-[.08em]" style={{ color: p.acc }}><span className="h-1.5 w-1.5 rounded-full" style={{ background: p.acc }} />{p.line}</span>
                <span className="mt-3 text-[19px] font-semibold tracking-[-0.015em]">{p.name}</span>
                <span className="mt-2 flex-1 text-[15px] leading-relaxed text-ink-2">{p.body}</span>
                <span className="link mt-5 text-[14.5px]">Learn more<Icon name="ArrowRight" size={14} weight="bold" /></span>
              </Link>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* Horizontal explorer: tabs on top, the picture and its copy below. */
export function Explorer({ items, acc = 'brand', label }) {
  const [i, setI] = useState(0);
  const id = useId();
  const color = ACC[acc] || ACC.brand;
  const it = items[i];
  return (
    <div>
      <div role="tablist" aria-label={label} className="no-scrollbar -mx-5 flex gap-2 overflow-x-auto px-5 md:mx-0 md:flex-wrap md:px-0">
        {items.map((x, k) => (
          <button key={x.tab} id={`${id}-t${k}`} role="tab" type="button" aria-selected={k === i} aria-controls={`${id}-p`} onClick={() => setI(k)}
            className={cx('inline-flex h-11 shrink-0 items-center gap-2 rounded-full border px-4 text-[14.5px] font-medium transition-colors', k === i ? 'border-transparent text-on-acc' : 'border-line-2 text-ink-2 hover:border-fg/30 hover:text-ink')}
            style={k === i ? { background: color } : undefined}>
            {x.icon && <Icon name={x.icon} size={16} />}{x.tab}
          </button>
        ))}
      </div>
      <div id={`${id}-p`} role="tabpanel" aria-labelledby={`${id}-t${i}`} key={i} className="fadein mt-10 grid items-center gap-10 lg:grid-cols-[.85fr_1.15fr] lg:gap-16">
        <div>
          <h3 className="text-[28px] font-semibold leading-tight tracking-[-0.03em] md:text-[34px]">{it.h}</h3>
          <p className="mt-4 text-[17px] leading-relaxed text-ink-2">{it.p}</p>
          {it.points && <ul className="mt-6 space-y-3">{it.points.map((t) => <li key={t} className="flex gap-3 text-[15.5px] text-ink-2"><Icon name="Check" size={18} weight="bold" className="mt-[3px] shrink-0" style={{ color }} />{t}</li>)}</ul>}
          {it.to && <Link to={it.to} className="link mt-7" style={{ '--acc': color }}>{it.cta || 'Learn more'}<Icon name="ArrowRight" size={14} weight="bold" /></Link>}
        </div>
        <div className="relative">
          <div aria-hidden="true" className="absolute -inset-8 -z-10 rounded-full opacity-30 blur-3xl" style={{ background: `radial-gradient(closest-side, color-mix(in oklab, ${color} 40%, transparent), transparent)` }} />
          <it.V {...(it.props || {})} />
        </div>
      </div>
    </div>
  );
}

/* Numbered steps in a row (onboarding, a loop, a lifecycle). */
export function Steps({ items, acc = 'brand', loop }) {
  const color = ACC[acc] || ACC.brand;
  return (
    <ol className={cx('grid gap-4', items.length === 4 ? 'md:grid-cols-2 lg:grid-cols-4' : 'md:grid-cols-3')}>
      {items.map((s, i) => (
        <Reveal as="li" key={s.h} delay={i * 80} className="card relative p-6 md:p-7">
          <span className="flex items-center gap-3">
            <span className="inline-flex h-9 w-9 items-center justify-center rounded-full text-[14px] font-bold text-on-acc num" style={{ background: color }}>{i + 1}</span>
            {loop && i === items.length - 1 && <span className="inline-flex items-center gap-1.5 text-[12.5px] text-ink-3"><Icon name="ArrowsClockwise" size={14} />then again</span>}
          </span>
          <h3 className="t-h3 mt-5">{s.h}</h3>
          <p className="mt-2 text-[15.5px] leading-relaxed text-ink-2">{s.p}</p>
        </Reveal>
      ))}
    </ol>
  );
}

export function Points({ items, acc = 'brand', cols = 3 }) {
  const color = ACC[acc] || ACC.brand;
  return (
    <div className={cx('grid gap-4', cols === 3 ? 'md:grid-cols-3' : cols === 4 ? 'sm:grid-cols-2 lg:grid-cols-4' : 'md:grid-cols-2')}>
      {items.map((x, i) => (
        <Reveal key={x.h} delay={i * 70} className="card p-6 md:p-7">
          {x.icon && <span className="inline-flex h-11 w-11 items-center justify-center rounded-[12px]" style={{ background: `color-mix(in oklab, ${color} 14%, transparent)`, color }}><Icon name={x.icon} size={22} /></span>}
          <h3 className={cx('t-h3', x.icon && 'mt-5')}>{x.h}</h3>
          <p className="mt-2 text-[15.5px] leading-relaxed text-ink-2">{x.p}</p>
        </Reveal>
      ))}
    </div>
  );
}

export function Split({ eyebrow, title, lead, children, visual, flip, acc = 'brand', id, className }) {
  const color = ACC[acc] || ACC.brand;
  return (
    <section id={id} className={cx('sec scroll-mt-20', className)}>
      <div className={cx('wrap grid items-center gap-12 lg:grid-cols-2 lg:gap-20')}>
        <Reveal className={cx(flip && 'lg:order-2')}>
          {eyebrow && <p className="eyebrow" style={{ '--acc': color }}>{eyebrow}</p>}
          <h2 className="t-h2 mt-6">{title}</h2>
          {lead && <p className="t-lead mt-5">{lead}</p>}
          {children}
        </Reveal>
        <Reveal delay={120} className="relative">
          <div aria-hidden="true" className="absolute -inset-8 -z-10 rounded-full opacity-25 blur-3xl" style={{ background: `radial-gradient(closest-side, color-mix(in oklab, ${color} 40%, transparent), transparent)` }} />
          {visual}
        </Reveal>
      </div>
    </section>
  );
}

export const LINKS = {
  zenstra: { line: 'Zenstra AI', name: 'Security for AI agents', body: 'Discover every agent, scope its access and check every action before it runs.', to: '/agentic-ai/agentic-identity', acc: ACC.zen },
  cirm: { line: 'adapID AI', name: 'Identity Risk Management', body: 'A live, explainable risk score for every person, acted on when behaviour changes.', to: '/adapid-ai', acc: ACC.adap },
  nhi: { line: 'adapID AI', name: 'NHI Security for AWS', body: 'Every role, key and workload identity found, scored and baselined.', to: '/adapid-ai/nhi-security', acc: ACC.adap },
  fraud: { line: 'adapID AI', name: 'Identity Fraud Prevention', body: 'Account takeover and mule accounts stopped before money moves.', to: '/adapid-ai/fraud-prevention', acc: ACC.adap },
  ad: { line: 'adapID AI', name: 'Active Directory Security', body: 'Attack paths to Domain Admins mapped and closed, live abuse contained.', to: '/ad-security', acc: ACC.adap },
  botshield: { line: 'BotShield AI', name: 'Exposure management and bot defence', body: 'Prove what is exploitable, patch it virtually and stop bots by intent.', to: '/botshield-ai', acc: ACC.bot },
  ddos: { line: 'BotShield AI', name: 'DDoS Protection', body: 'Inline L3 to L7 mitigation at the edge, with no traffic diversion.', to: '/botshield-ai/ddos-protection', acc: ACC.bot },
  icms: { line: 'ICMS Compliance Suite', name: 'DPDPA compliance', body: 'Every access to personal data checked, and evidence ready for audit.', to: '/dpdpa-compliance', acc: ACC.icms },
};
