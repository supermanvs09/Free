import { useEffect, useRef, useState } from 'react';
import { Icon, Reveal, cx } from './ui.jsx';
import { useInView, useReducedMotion } from '../lib/motion.js';

/* "What changes with …": one comparison per product, each in the form that suits
   its story. Zenstra flips a switch over an agent's five moments; adapID races
   two timelines of the same stolen password; BotShield drags across the
   findings queue; ICMS answers the auditor's questions. */

/* ---------- Zenstra: one switch, five moments ---------- */
const ZEN = [
  ['Discover', 'Agents found after an incident, one platform at a time', 'One inventory of every agent, each with a named owner'],
  ['Access', 'Standing keys and service accounts with broad scope', 'Grants scoped to the task that expire on their own'],
  ['Act', 'Logs that show what happened, after it happened', 'Every action decided inline, before it runs'],
  ['Stop', 'A separate switch in every vendor to stop one agent', 'One revocation stops an agent everywhere, in seconds'],
  ['Prove', 'Evidence pulled together by hand for every exam', 'A tamper-evident record, exported as evidence'],
];

export function ZenToggle() {
  const ref = useRef(null);
  const [on, setOn] = useState(false);
  const touched = useRef(false);
  const seen = useInView(ref, { threshold: 0.45, once: true });
  const reduce = useReducedMotion();
  // the first time it is seen, the switch turns itself on once, so the change is shown, not described
  useEffect(() => {
    if (!seen || touched.current) return undefined;
    const t = setTimeout(() => { if (!touched.current) setOn(true); }, reduce ? 0 : 1100);
    return () => clearTimeout(t);
  }, [seen, reduce]);
  const flip = () => { touched.current = true; setOn((v) => !v); };
  const acc = 'var(--color-zen)';
  return (
    <div ref={ref} className="card overflow-hidden">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-line px-6 py-5 md:px-8">
        <p className="text-[15px] text-ink-2">An AI agent’s life in your enterprise, <span className="font-semibold text-ink">{on ? 'with Zenstra' : 'without Zenstra'}</span></p>
        <button type="button" role="switch" aria-checked={on} onClick={flip} className="group inline-flex items-center gap-3 rounded-full border border-line-2 py-1.5 pl-4 pr-1.5 text-[14.5px] font-medium">
          Zenstra
          <span className="relative inline-flex h-7 w-12 items-center rounded-full transition-colors duration-500" style={{ background: on ? acc : 'color-mix(in oklab, var(--color-fg) 14%, transparent)' }}>
            <span className="absolute h-5 w-5 rounded-full bg-white shadow transition-transform duration-500" style={{ transform: `translateX(${on ? 24 : 4}px)` }} />
          </span>
        </button>
      </div>
      <ol>
        {ZEN.map(([moment, off, onText], i) => (
          <li key={moment} className="grid items-center gap-2 border-b border-line px-6 py-4 last:border-b-0 md:grid-cols-[150px_1fr] md:gap-6 md:px-8">
            <span className="text-[12.5px] font-semibold uppercase tracking-[.1em] text-ink-3"><span className="num mr-2">{String(i + 1).padStart(2, '0')}</span>{moment}</span>
            <span className="relative flex min-h-[28px] items-center gap-3">
              <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full transition-colors duration-500" style={{ background: on ? 'color-mix(in oklab, var(--color-zen) 16%, transparent)' : 'color-mix(in oklab, var(--color-crit) 12%, transparent)', color: on ? acc : 'var(--color-crit)', transitionDelay: `${i * 70}ms` }}>
                <Icon name={on ? 'Check' : 'X'} size={14} weight="bold" />
              </span>
              {/* both texts share one grid cell, so the row is as tall as the longer one */}
              <span className="grid flex-1 text-[16px]">
                <span className="text-ink-3 transition-all duration-500 [grid-area:1/1]" style={{ opacity: on ? 0 : 1, transform: `translateY(${on ? -6 : 0}px)`, transitionDelay: `${i * 70}ms` }} aria-hidden={on}>{off}</span>
                <span className="font-medium text-ink transition-all duration-500 [grid-area:1/1]" style={{ opacity: on ? 1 : 0, transform: `translateY(${on ? 0 : 6}px)`, transitionDelay: `${i * 70}ms` }} aria-hidden={!on}>{onText}</span>
              </span>
            </span>
          </li>
        ))}
      </ol>
    </div>
  );
}

/* ---------- adapID: the same stolen password, two endings ---------- */
const WITHOUT = [
  ['Day 0 · 02:14', 'Login from a new device. The password and MFA both pass.'],
  ['Day 3', 'A mailbox rule starts forwarding invoices outside.'],
  ['Day 12', 'Three years of finance files are exported.'],
  ['Day 47', 'Found during an audit. The data is long gone.'],
];
const WITH = [
  ['02:14:00', 'The same login. Risk jumps to 94: new device, Lagos, two hours after Mumbai.'],
  ['02:14:01', 'Session held. Kavya gets a step-up on her own phone.'],
  ['02:15', 'Kavya says it was not her. Sessions revoked, password reset.'],
  ['02:16', 'The SOC gets the case, with every reason attached.'],
];

function Lane({ title, items, tone, end, delay = 0 }) {
  const col = tone === 'crit' ? 'var(--color-crit)' : 'var(--color-adap)';
  return (
    <div className="card p-6 md:p-8">
      <div className="flex flex-wrap items-baseline justify-between gap-3">
        <p className="text-[13px] font-semibold uppercase tracking-[.1em]" style={{ color: col }}>{title}</p>
        <p className="text-[14px] text-ink-3">{end[0]} · <span className="font-semibold" style={{ color: col }}>{end[1]}</span></p>
      </div>
      <ol className="relative mt-7 grid gap-6 md:grid-cols-4 md:gap-5">
        <span aria-hidden="true" className="absolute left-[11px] top-3 bottom-3 w-px md:left-3 md:right-3 md:top-[11px] md:bottom-auto md:h-px md:w-auto" style={{ background: `color-mix(in oklab, ${col} 35%, transparent)` }} />
        {items.map(([when, what], i) => (
          <Reveal as="li" key={when} delay={delay + i * 140} className="relative pl-9 md:pl-0 md:pt-9">
            <span aria-hidden="true" className="absolute left-0 top-0 grid h-[23px] w-[23px] place-items-center rounded-full border-2" style={{ borderColor: col, background: 'var(--color-bg-1)' }}>
              <span className="h-2 w-2 rounded-full" style={{ background: col }} />
            </span>
            <span className="num block text-[13px] font-semibold" style={{ color: col }}>{when}</span>
            <span className="mt-1 block text-[15.5px] leading-snug text-ink-2">{what}</span>
          </Reveal>
        ))}
      </ol>
    </div>
  );
}

export function IdentityTimelines() {
  return (
    <div className="space-y-4">
      <Lane title="Without adapID" tone="crit" items={WITHOUT} end={['47 days inside', '0 alerts']} />
      <Lane title="With adapID" tone="adap" items={WITH} end={['2 minutes', 'nothing lost']} delay={300} />
      <p className="text-[13px] text-ink-3">An illustration of one session, with sample names and times.</p>
    </div>
  );
}

/* ---------- BotShield: drag across the findings queue ---------- */
const PROVEN = { 3: 'OTP endpoint lacks rate limit', 9: 'Session token in URL', 16: 'Debug route exposed', 22: 'Card BIN check skippable', 28: 'Weak CORS on payments API', 33: 'Old TLS on partner gateway' };
const SEV = (i) => (i * 7 + 3) % 5; // a fixed spread of scanner severities

function Queue({ after }) {
  return (
    <div className="grid grid-cols-5 gap-1.5 sm:grid-cols-8 md:gap-2">
      {Array.from({ length: 37 }, (_, i) => {
        const proven = PROVEN[i];
        if (!after) {
          const s = SEV(i);
          const c = s >= 3 ? '#ff6b5d' : s >= 1 ? '#f6b955' : '#9aa0a9';
          return <span key={i} className="flex h-9 items-center justify-center gap-1.5 rounded-[8px] border px-1 sm:justify-start sm:px-2 md:h-11" style={{ borderColor: `${c}55`, background: `${c}14` }}><i className="h-1.5 w-1.5 shrink-0 rounded-full max-sm:hidden" style={{ background: c }} /><span className="num truncate text-[11px] text-[#c9ccd2]">F-{String(i + 1).padStart(2, '0')}</span></span>;
        }
        return proven
          ? <span key={i} className="flex h-9 items-center justify-center gap-1.5 rounded-[8px] border px-1 sm:justify-start sm:px-2 md:h-11" style={{ borderColor: '#34e0c3aa', background: '#34e0c322' }}><Icon name="ShieldCheck" size={13} className="shrink-0 text-[#34e0c3] max-sm:hidden" /><span className="num truncate text-[11px] font-semibold text-[#c8fff2]">F-{String(i + 1).padStart(2, '0')}</span></span>
          : <span key={i} className="flex h-9 items-center justify-center rounded-[8px] border border-white/5 px-1 sm:justify-start sm:px-2 md:h-11" style={{ background: 'rgb(255 255 255 / .02)' }}><span className="num truncate text-[11px] text-[#5d6168] line-through">F-{String(i + 1).padStart(2, '0')}</span></span>;
      })}
    </div>
  );
}

export function QueueSlider() {
  const [x, setX] = useState(50);
  return (
    <div>
      <div className="tone-d relative select-none overflow-hidden rounded-[24px] border border-line-2 p-5 md:p-7" style={{ background: 'linear-gradient(180deg, #15171b, #0e1014)' }}>
        <div className="mb-5 flex justify-between gap-4 text-[13px] font-semibold uppercase tracking-[.08em]">
          <span className="text-[#ff8b7e]">Without<span className="max-sm:hidden"> BotShield</span> · 37 to triage</span>
          <span className="text-right text-[#34e0c3]">With<span className="max-sm:hidden"> BotShield</span> · 6 that matter</span>
        </div>
        <div className="relative">
          <Queue />
          <div className="absolute inset-0" style={{ clipPath: `inset(0 0 0 ${x}%)`, background: '#111317' }}><Queue after /></div>
          <span aria-hidden="true" className="pointer-events-none absolute -bottom-2 -top-2 w-[2px] bg-white" style={{ left: `${x}%` }}>
            <span className="absolute left-1/2 top-1/2 grid h-9 w-9 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-white text-[#0e1014] shadow-lg"><Icon name="ArrowsLeftRight" size={16} weight="bold" /></span>
          </span>
          <input type="range" min="0" max="100" value={x} onChange={(e) => setX(+e.target.value)} aria-label="Drag to compare the findings queue without and with BotShield"
            className="absolute inset-0 h-full w-full cursor-ew-resize opacity-0" />
        </div>
      </div>
      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <p className="text-[15.5px] leading-relaxed text-ink-2"><span className="font-semibold text-ink">Without:</span> 37 possible findings from a scan, unproven, each waiting for a developer and the next release.</p>
        <p className="text-[15.5px] leading-relaxed text-ink-2"><span className="font-semibold text-ink">With:</span> every finding replayed first. Six proven exploitable, each with a virtual patch live and the fix routed to its owner: an OTP endpoint without a rate limit, a session token in a URL, an exposed debug route, a skippable card BIN check, weak CORS on the payments API and old TLS on a partner gateway.</p>
      </div>
    </div>
  );
}

/* ---------- ICMS: the auditor's questions ---------- */
const ASKS = [
  ['Where does our customers’ personal data live?', 'A spreadsheet from last year’s data survey', 'Weeks', 'A live inventory by store, category and owner', 'Now'],
  ['Who opened this customer’s record, and why?', 'Logs in five systems, none of them with a purpose', 'Days', 'Every access tied to an identity and its declared purpose', 'Seconds'],
  ['Did we have consent when we used it?', 'Consent in one tool, processing in another', 'Days', 'A consent ledger per principal, checked on every access', 'Seconds'],
  ['Can you report this breach within 72 hours?', 'Records scoped by hand, against the clock', 'Unsure', 'Affected records and principals scoped, the report drafted from evidence', 'Hours'],
  ['Show us the evidence.', 'Collected from every team, one request at a time', 'Weeks', 'One audit package mapped to DPDPA, RBI and SEBI', 'Minutes'],
];

export function AuditorQuestions() {
  return (
    <ol className="space-y-3">
      {ASKS.map(([q, today, t1, icms, t2], i) => (
        <Reveal as="li" key={q} delay={i * 60} className="card grid gap-4 p-5 md:grid-cols-[1.05fr_1fr_1fr] md:items-center md:gap-8 md:p-6">
          <p className="flex items-start gap-3">
            <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full" style={{ background: 'color-mix(in oklab, var(--color-icms) 16%, transparent)', color: 'var(--color-icms)' }}><Icon name="ChatCircleText" size={16} /></span>
            <span><span className="block text-[12px] font-semibold uppercase tracking-[.1em] text-ink-3">The auditor asks</span><span className="mt-0.5 block text-[17px] font-semibold leading-snug tracking-[-0.015em]">“{q}”</span></span>
          </p>
          <p className="border-line md:border-l md:pl-6">
            <span className="flex items-center justify-between gap-3"><span className="text-[12px] font-semibold uppercase tracking-[.1em] text-ink-3">Today</span><span className="rounded-full px-2 py-0.5 text-[12px] font-semibold" style={{ background: 'color-mix(in oklab, var(--color-crit) 12%, transparent)', color: 'var(--color-crit)' }}>{t1}</span></span>
            <span className="mt-1 block text-[15px] leading-snug text-ink-3">{today}</span>
          </p>
          <p className="rounded-[14px] p-3 md:-my-2" style={{ background: 'color-mix(in oklab, var(--color-icms) 8%, transparent)' }}>
            <span className="flex items-center justify-between gap-3"><span className="text-[12px] font-semibold uppercase tracking-[.1em]" style={{ color: 'var(--color-icms)' }}>With ICMS</span><span className="rounded-full px-2 py-0.5 text-[12px] font-semibold" style={{ background: 'color-mix(in oklab, var(--color-ok) 14%, transparent)', color: 'var(--color-ok)' }}>{t2}</span></span>
            <span className="mt-1 block text-[15px] font-medium leading-snug">{icms}</span>
          </p>
        </Reveal>
      ))}
    </ol>
  );
}
