import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router';
import { Brain, Cloud, Cpu, Database, GearSix, HardDrives, Key, Plugs, Robot, Sparkle, Terminal, User } from '@phosphor-icons/react/dist/ssr';
import { cx, useReducedMotion } from '../lib/motion.js';
import { getTheme, onTheme } from '../lib/theme.js';
import ProductMark from './ProductMark.jsx';
import { Icon } from './ui.jsx';

/* The logo moment. Two parts on the page, one mark travelling between them.
   1. The plate: our mark rises in from below, a brand-blue plate opens around
      it and our line arrives word by word. The plate stays.
   2. The orbit: when the reader reaches it, the mark pops out of the plate,
      arcs down and lands at the centre of the identity orbit from the original
      site; the rings open out of it and people, machine identities and AI
      agents take their places. Then the calm loop: a pulse leaves the mark
      every five seconds and each risk dot it reaches becomes a fix.
   No scroll lock. The prerendered HTML and reduced motion show the finished
   state: the plate with its words, the mark in the orbit. Names are
   illustrative. */

const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
const P = (t, a, b) => clamp((t - a) / (b - a));
const ss = (x) => x * x * (3 - 2 * x);
const eo = (x) => 1 - (1 - x) ** 3;
const eio = (x) => (x < 0.5 ? 4 * x * x * x : 1 - (-2 * x + 2) ** 3 / 2);
const eb = (x) => (x <= 0 ? 0 : x >= 1 ? 1 : 1 + 2.70158 * (x - 1) ** 3 + 1.70158 * (x - 1) ** 2);
const f2 = (n) => (Math.round(n * 100) / 100).toFixed(2);
const BLUE = '#0068ac', CYAN = '#00aeef', CORAL = '#f0644d';

const RINGS = [
  { label: 'People', icons: [User, User, User, User], risky: [0, 2] },
  { label: 'Machine identities', icons: [Key, Cloud, Database, GearSix, Plugs, HardDrives, Terminal], risky: [0, 3, 4] },
  { label: 'AI agents', icons: [Robot, Sparkle, Robot, Brain, Robot, Sparkle, Cpu, Robot], risky: [0, 3, 6] },
];
const angles = (n, gap = 56) => Array.from({ length: n }, (_, i) => ((-90 + gap / 2 + ((i + 0.5) * (360 - gap)) / n) * Math.PI) / 180);

const GEO = {
  wide: { W: 1200, H: 500, cx: 600, cy: 250, rings: [[200, 104], [350, 152], [495, 200]], r: 26, half: 68 },
  compact: { W: 560, H: 560, cx: 280, cy: 280, rings: [[105, 105], [175, 175], [245, 245]], r: 22, half: 52 },
};
// the plate, in seconds from when it comes into view
const A = { rise: 0, riseEnd: 0.8, open: 0.9, openEnd: 1.6, words: 1.5, tag: 2.45, done: 3.2 };
// the orbit, in seconds from when the mark pops out of the plate
const T = { pop: 0, popEnd: 0.3, fly: 0.3, flyEnd: 1.15, landEnd: 1.45, rings: 1.3, nodes: 1.8, labels: 2.95, loop: 3.85 };
const CYCLE = 5, REACH = 2.2, DONE = 60;
const LINE = ['Identity', 'security', 'for', 'the', 'AI', 'era.'];
const TAG = 'The future is decided today.';

function Disc({ x, y, Icon: I, r, o = 1, s = 1, dark, warn = 0, ok = 0, glow = 0 }) {
  if (o <= 0.01) return null;
  return (
    <g transform={`translate(${f2(x)} ${f2(y)}) scale(${f2(s)})`} opacity={f2(o)}>
      {glow > 0.01 && <circle r={r + 9} fill="none" stroke={dark ? '#5cc2ff' : BLUE} strokeOpacity={f2(glow * 0.85)} strokeWidth="2" />}
      <circle r={r} fill={dark ? '#151a22' : '#fff'} stroke={dark ? 'rgba(255,255,255,.22)' : '#dbe3ec'} strokeWidth="1.5" filter="url(#lo-sh)" />
      <g transform={`translate(${f2(-r * 0.5)} ${f2(-r * 0.5)})`}><I size={r} color={dark ? '#dfe6ef' : '#3f4a5a'} weight="regular" /></g>
      {warn > 0.01 && <circle cx={f2(r * 0.74)} cy={f2(-r * 0.74)} r={f2(Math.max(0.01, 7.5 * warn))} fill={CORAL} stroke={dark ? '#0a0b0e' : '#fff'} strokeWidth="2.5" />}
      {ok > 0.01 && <g transform={`translate(${f2(r * 0.74)} ${f2(-r * 0.74)}) scale(${f2(ok)})`}><circle r="10" fill={dark ? CYAN : BLUE} stroke={dark ? '#0a0b0e' : '#fff'} strokeWidth="2.5" /><path d="M-4.5 0.5 l3 3.2 6-6.7" fill="none" stroke="#fff" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" /></g>}
    </g>
  );
}

function Scene({ t, compact, dark }) {
  const g = compact ? GEO.compact : GEO.wide, { W, H, cx, cy, r } = g;
  const rx3 = g.rings[2][0], ry3 = g.rings[2][1], r0 = g.half * 1.1;
  const live = t >= T.loop, tau = live ? (t - T.loop) % CYCLE : -1, s = tau / REACH;
  const landed = ss(P(t, T.flyEnd, T.landEnd));
  const nodes = [];
  RINGS.forEach((ring, i) => {
    const [rx, ry] = g.rings[i], ang = angles(ring.icons.length), ratio = (rx - r0) / (rx3 - r0);
    ring.icons.forEach((Ic, k) => {
      const at = T.nodes + i * 0.28 + k * 0.06, pop = P(t, at, at + 0.55);
      const tx = cx + rx * Math.cos(ang[k]), ty = cy + ry * Math.sin(ang[k]) + (live ? Math.sin(t * 0.9 + k * 1.7 + i) * 2.5 : 0);
      // each identity pops out of the mark and travels to its place on the ring
      const x = cx + (tx - cx) * eo(pop), y = cy + (ty - cy) * eo(pop);
      const risky = ring.risky.includes(k), flip = (ratio + 0.03 * k) * REACH, back = 3.5 + 0.12 * k;
      const okOn = live && risky && tau >= flip && tau < back;
      const warn = risky && !okOn ? (live && tau >= back ? eb(P(tau, back, back + 0.4)) : eb(P(t, at + 0.45, at + 0.8))) : 0;
      const ok = okOn ? eb(P(tau, flip, flip + 0.4)) : 0;
      const glow = live ? Math.sin(Math.PI * P(tau, flip - 0.2, flip + 0.55)) : 0;
      nodes.push(<Disc key={`${i}${k}`} x={x} y={y} Icon={Ic} r={r} o={ss(P(pop, 0, 0.3))} s={0.4 + 0.6 * eb(pop)} warn={warn} ok={ok} glow={glow} dark={dark} />);
    });
  });
  const lab = ss(P(t, T.labels, T.labels + 0.6));
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="h-full w-full font-sans" role="img"
      aria-label="Animation: the Deep Algorithms mark lands at the centre, three rings open out of it, and people, machine identities and AI agents take their places on them. A pulse then leaves the mark every few seconds, and each identity it reaches changes from a risk marker to a fix.">
      <defs>
        <filter id="lo-sh" x="-40%" y="-40%" width="180%" height="190%"><feDropShadow dx="0" dy="5" stdDeviation="6" floodColor="#062f57" floodOpacity={dark ? '.45' : '.12'} /></filter>
        <radialGradient id="lo-halo"><stop offset="0" stopColor={dark ? '#5cc2ff' : CYAN} stopOpacity={dark ? '.3' : '.2'} /><stop offset="1" stopColor={CYAN} stopOpacity="0" /></radialGradient>
      </defs>
      {g.rings.map(([rx, ry], i) => {
        const open = eo(P(t, T.rings + i * 0.16, T.rings + 0.7 + i * 0.16));
        return (
          <g key={i} opacity={f2(ss(P(t, T.rings + i * 0.16, T.rings + 0.3 + i * 0.16)))}>
            <ellipse cx={cx} cy={cy} rx={f2(r0 + (rx - r0) * open)} ry={f2(r0 + (ry - r0) * open)} fill="none" stroke={dark ? 'rgba(255,255,255,.18)' : '#dbe3ec'} strokeWidth="1.5" />
            {lab > 0.01 && <text x={cx} y={cy - ry + 5} textAnchor="middle" opacity={f2(lab)} fontSize={compact ? 13 : 14} fontWeight="500" fill={dark ? '#a8b0bb' : '#5c6777'} stroke={dark ? '#0f1114' : '#f6f7f9'} strokeWidth="7" paintOrder="stroke">{RINGS[i].label}</text>}
          </g>
        );
      })}
      {live && tau < REACH + 0.4 && <ellipse cx={cx} cy={cy} rx={f2(r0 + s * (rx3 - r0))} ry={f2(r0 + s * (ry3 - r0))} fill="none" stroke={dark ? '#5cc2ff' : BLUE} strokeWidth="2" strokeOpacity={f2(0.5 * (1 - ss(P(s, 0.9, 1.15))))} />}
      {nodes}
      {/* the halo the mark sits in once it lands; the mark itself is drawn on top as an image */}
      <circle cx={cx} cy={cy} r={f2(g.half * 2.3 * (1 + 0.015 * Math.sin(t * 1.3)))} fill="url(#lo-halo)" opacity={f2(0.9 * landed)} />
    </svg>
  );
}


const MarkTile = ({ size, className, style }) => (
  <span className={cx('lm-mark absolute flex items-center justify-center rounded-[23%] border border-[#e3e8ee] bg-white', className)} style={{ width: size, height: size, ...style }}>
    <img src="/brand/mark.webp" alt="" className="h-[58%] w-[58%]" />
  </span>
);

const PRODUCTS = [
  { key: 'zenstra', name: 'Zenstra AI', what: 'AI agents', to: '/agentic-ai/agentic-identity' },
  { key: 'adapid', name: 'adapID AI', what: 'People and machine identities', to: '/adapid-ai' },
  { key: 'botshield', name: 'BotShield AI', what: 'Apps, APIs and the edge', to: '/botshield-ai' },
  { key: 'icms', name: 'ICMS Compliance Suite', what: 'Personal data and DPDPA', to: '/dpdpa-compliance' },
];

export default function LogoOrbit() {
  const root = useRef(null);
  const plate = useRef(null);
  const frame = useRef(null);
  const reduce = useReducedMotion();
  const [ta, setTa] = useState(DONE);
  const [tb, setTb] = useState(DONE);
  const [compact, setCompact] = useState(false);
  const [dark, setDark] = useState(false);
  const [geo, setGeo] = useState(null); // measured: plate size, where the mark starts and where it lands

  useEffect(() => {
    const m = window.matchMedia('(max-width: 639px)');
    const on = () => setCompact(m.matches);
    on(); m.addEventListener('change', on);
    setDark(getTheme() === 'dark');
    const off = onTheme((x) => setDark(x === 'dark'));
    return () => { m.removeEventListener('change', on); off?.(); };
  }, []);

  // measure the plate and the orbit, relative to this block
  useEffect(() => {
    const r0 = root.current, pl = plate.current, fr = frame.current;
    const measure = () => {
      const R = r0.getBoundingClientRect(), Pp = pl.getBoundingClientRect(), F = fr.getBoundingClientRect();
      const g = window.matchMedia('(max-width: 639px)').matches ? GEO.compact : GEO.wide;
      const small = Pp.width < 640;
      setGeo({
        pw: Pp.width, ph: Pp.height, s0: small ? 76 : 104,
        sx: Pp.left - R.left + Pp.width / 2, sy: Pp.top - R.top + Pp.height / 2,
        ex: F.left - R.left + (g.cx / g.W) * F.width, ey: F.top - R.top + (g.cy / g.H) * F.height,
        s1: ((g.half * 2) / g.W) * F.width,
      });
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(r0);
    return () => ro.disconnect();
  }, [compact]);

  // two clocks: the plate plays when it is seen; the orbit plays when it is seen and the plate is done
  useEffect(() => {
    if (reduce) { setTa(DONE); setTb(DONE); return undefined; }
    let raf = 0, last = 0, a = -1, b = -1, acc = 0, seeP = false, seeF = false;
    setTa(0); setTb(-1);
    const tick = (now) => {
      const dt = Math.min(0.1, (now - last) / 1000); last = now; acc += dt;
      if (a < 0 && seeP) a = 0;
      if (a < 0 && seeF) a = A.done; // reached the orbit without seeing the plate play
      if (a >= 0 && a < DONE) a += dt;
      if (b < 0 && seeF && a >= A.done) b = 0;
      if (b >= 0 && (seeF || b < T.landEnd)) b += dt;
      if (acc >= 1 / 50) { acc = 0; setTa(Math.max(0, a)); setTb(b); }
      raf = (seeP || seeF || (b >= 0 && b < T.landEnd)) ? requestAnimationFrame(tick) : 0;
    };
    const wake = () => { if (!raf) { last = performance.now(); raf = requestAnimationFrame(tick); } };
    const io = new IntersectionObserver((es) => {
      for (const e of es) {
        if (e.target === plate.current) seeP = e.intersectionRatio >= 0.5;
        if (e.target === frame.current) seeF = e.intersectionRatio >= 0.4;
      }
      wake();
    }, { threshold: [0, 0.4, 0.5, 0.75] });
    io.observe(plate.current); io.observe(frame.current);
    return () => { io.disconnect(); cancelAnimationFrame(raf); };
  }, [reduce]);

  /* --- the plate --- */
  const open = eo(P(ta, A.open, A.openEnd));
  const pw = geo?.pw || 1000, ph = geo?.ph || 380, s0 = geo?.s0 || 104;
  const small = pw < 640;
  const fs = small ? Math.max(24, pw * 0.074) : Math.min(60, Math.max(30, pw * 0.046));
  const tsz = small ? 16 : Math.min(22, Math.max(17, pw * 0.019));
  const word = (i) => { const q = P(ta, A.words + i * 0.11, A.words + 0.55 + i * 0.11); return { opacity: ss(q), transform: `translateY(${f2((1 - eo(q)) * 0.45 * fs)}px)`, filter: `blur(${f2((1 - q) * 6)}px)` }; };
  const tag = P(ta, A.tag, A.tag + 0.7);

  /* --- the mark: in the plate, in flight, or landed --- */
  const flying = tb >= 0 && tb < T.landEnd && geo;
  const inPlate = tb < 0;
  const rise = P(ta, A.rise, A.riseEnd);
  const plateMark = { transform: `translate(-50%, -50%) translateY(${f2((1 - eo(rise)) * 90)}px) scale(${f2(0.82 + 0.18 * eb(rise))})`, opacity: f2(ss(P(ta, 0, 0.3))) };
  let flyStyle = null;
  if (flying) {
    const { sx, sy, ex, ey, s1 } = geo;
    const pop = eb(P(tb, T.pop, T.popEnd));
    const q = eio(P(tb, T.fly, T.flyEnd));
    const cxp = sx + (ex - sx) * 0.2, cyp = Math.min(sy, ey) - 110; // the arc's control point: up and out of the plate first
    const x = (1 - q) ** 2 * sx + 2 * (1 - q) * q * cxp + q * q * ex;
    const y = (1 - q) ** 2 * sy + 2 * (1 - q) * q * cyp + q * q * ey;
    const land = Math.sin(Math.PI * P(tb, T.flyEnd, T.landEnd));
    const sc = (1 + 0.14 * pop * (1 - q)) * (1 + (s1 / s0 - 1) * q) * (1 - 0.07 * land);
    flyStyle = { left: x, top: y, transform: `translate(-50%, -50%) scale(${f2(sc)})`, zIndex: 30 };
  }
  const gone = ss(P(tb, T.popEnd, T.popEnd + 0.4)); // the empty place the mark left in the plate

  const g = compact ? GEO.compact : GEO.wide;
  const row = (i) => ({ opacity: ss(P(tb, T.labels + 0.1 + i * 0.12, T.labels + 0.6 + i * 0.12)), transform: `translateY(${f2((1 - eo(P(tb, T.labels + 0.1 + i * 0.12, T.labels + 0.7 + i * 0.12))) * 18)}px)` });
  return (
    <div ref={root} className="relative">
      {/* 1. the plate */}
      <div ref={plate} className="relative mx-auto h-[300px] w-full sm:h-[360px] lg:h-[380px]">
        <div aria-hidden="true" className="plate absolute left-1/2 top-1/2" style={{ width: f2(s0 + (pw - s0) * open) + 'px', height: f2(s0 + (ph - s0) * open) + 'px', borderRadius: f2(s0 * 0.23 + (28 - s0 * 0.23) * open) + 'px', transform: 'translate(-50%, -50%)', opacity: open > 0.002 ? 1 : 0 }} />
        <h2 id="orbit-h" className="absolute inset-x-0 flex flex-wrap justify-center gap-x-[.26em] px-6 text-center font-semibold text-white" style={{ bottom: `calc(50% + ${f2(s0 / 2 + s0 * 0.22)}px)`, fontSize: f2(fs) + 'px', lineHeight: 1.06, letterSpacing: '-0.03em' }}>
          {LINE.map((x, i) => [<span key={x + i} className="inline-block" style={word(i)}>{x}</span>, small && i === 1 && <span key="br" className="basis-full" />])}
        </h2>
        <p className="absolute inset-x-0 px-6 text-center font-medium text-white/90" style={{ top: `calc(50% + ${f2(s0 / 2 + s0 * 0.22)}px)`, fontSize: f2(tsz) + 'px', opacity: f2(ss(tag)), transform: `translateY(${f2((1 - eo(tag)) * 10)}px)` }}>{TAG}</p>
        {/* the place the mark leaves behind */}
        <span aria-hidden="true" className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-[23%] border-2 border-dashed border-white/35" style={{ width: s0, height: s0, opacity: f2(gone) }} />
        {inPlate && <MarkTile size={s0} className="left-1/2 top-1/2 shadow-[0_18px_40px_-14px_rgb(6_47_87/.55)]" style={plateMark} />}
      </div>

      {/* the mark in flight, between the two */}
      {flying && <MarkTile size={s0} className="shadow-[0_26px_50px_-18px_rgb(6_47_87/.6)]" style={flyStyle} />}

      {/* 2. the orbit, smaller than before, with the four products under it */}
      <div ref={frame} className={cx('relative mx-auto mt-16 w-full md:mt-20', compact ? 'aspect-square max-w-[460px]' : 'aspect-[1200/500] max-w-[980px]')}>
        <Scene t={Math.max(0, tb)} compact={compact} dark={dark} />
        {tb >= T.landEnd && <MarkTile size={`${f2(((g.half * 2) / g.W) * 100)}%`} className="left-1/2 shadow-[0_14px_34px_-12px_rgb(6_47_87/.45)]" style={{ top: `${f2((g.cy / g.H) * 100)}%`, transform: 'translate(-50%, -50%)', height: 'auto', aspectRatio: '1' }} />}
      </div>
      <ul className="mx-auto mt-6 flex max-w-[860px] flex-wrap justify-center gap-x-8 gap-y-3 text-[15.5px] font-medium text-ink-2">
        {['Discover every identity', 'Fix risk before it is used', 'Prove it to every auditor'].map((x) => (
          <li key={x} className="inline-flex items-center gap-2"><Icon name="CheckCircle" size={20} weight="fill" className="text-[#0a6dbb]" />{x}</li>
        ))}
      </ul>
      <ul className="mx-auto mt-8 grid max-w-[1000px] grid-cols-2 gap-3 md:grid-cols-4 md:gap-4">
        {PRODUCTS.map((p, i) => (
          <li key={p.key} style={row(i)}>
            <Link to={p.to} className="card card-hover group flex h-full items-center gap-3.5 p-4 max-md:flex-col max-md:text-center md:p-5">
              <ProductMark p={p.key} size={40} className="transition-transform duration-300 group-hover:scale-[1.06]" />
              <span className="min-w-0">
                <span className="block text-[15.5px] font-semibold leading-tight">{p.name}</span>
                <span className="mt-0.5 block text-[13px] leading-snug text-ink-3">{p.what}</span>
              </span>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
