import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router';
import { Brain, Cloud, Cpu, Database, GearSix, HardDrives, Key, Plugs, Robot, Sparkle, Terminal, User } from '@phosphor-icons/react/dist/ssr';
import { cx, useReducedMotion } from '../lib/motion.js';
import { getTheme, onTheme } from '../lib/theme.js';
import ProductMark from './ProductMark.jsx';
import { Icon } from './ui.jsx';

/* The logo moment, with the identity orbit from the original site.
   When it comes into view, our mark rises in and opens into a brand-blue
   plate that carries our line, then folds back into the mark; the three rings
   open out of it and people, machine identities and AI agents pop onto them. Then the picture
   settles into its calm loop: a pulse leaves the mark every five seconds and
   each risk dot it reaches becomes a fix. Below, the four products in a line.
   It plays once on arrival (no scroll lock); the prerendered HTML and reduced
   motion show the finished picture. Icons are plain and monochrome; the mark
   is the only brand colour. Names are illustrative. */

const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
const P = (t, a, b) => clamp((t - a) / (b - a));
const ss = (x) => x * x * (3 - 2 * x);
const eo = (x) => 1 - (1 - x) ** 3;
const eb = (x) => (x <= 0 ? 0 : x >= 1 ? 1 : 1 + 2.70158 * (x - 1) ** 3 + 1.70158 * (x - 1) ** 2);
const f2 = (n) => (Math.round(n * 100) / 100).toFixed(2);
// how open the plate is: 0 is the mark alone, 1 is the full plate
const plateOpen = (t) => eo(P(t, T.open, T.openEnd)) * (1 - ss(P(t, T.fold, T.foldEnd)));
const BLUE = '#0068ac', CYAN = '#00aeef', NAVY = '#0a2a5e', CORAL = '#f0644d';

const RINGS = [
  { label: 'People', icons: [User, User, User, User], risky: [0, 2] },
  { label: 'Machine identities', icons: [Key, Cloud, Database, GearSix, Plugs, HardDrives, Terminal], risky: [0, 3, 4] },
  { label: 'AI agents', icons: [Robot, Sparkle, Robot, Brain, Robot, Sparkle, Cpu, Robot], risky: [0, 3, 6] },
];
const angles = (n, gap = 56) => Array.from({ length: n }, (_, i) => ((-90 + gap / 2 + ((i + 0.5) * (360 - gap)) / n) * Math.PI) / 180);

const GEO = {
  wide: { W: 1200, H: 500, cx: 600, cy: 250, rings: [[200, 104], [350, 152], [495, 200]], r: 26, half: 68 },
  compact: { W: 560, H: 560, cx: 280, cy: 280, rings: [[105, 105], [175, 175], [245, 245]], r: 22, half: 52 },
};
// the arrival, in seconds: rise, the plate (open, words, fold), rings, identities,
// labels; the loop starts after
const T = { rise: 0, riseEnd: 0.9, open: 1.0, openEnd: 1.7, words: 1.55, tag: 2.55, fold: 4.4, foldEnd: 5.05, rings: 5.0, nodes: 5.5, labels: 6.65, loop: 7.55 };
const CYCLE = 5, REACH = 2.2, DONE = 60;
const LINE = ['Identity', 'security', 'for', 'the', 'AI', 'era.'];
const TAG = 'Impact the future, today.';

function Disc({ x, y, Icon: I, r, o = 1, s = 1, dark, warn = 0, ok = 0, glow = 0 }) {
  if (o <= 0.01) return null;
  return (
    <g transform={`translate(${f2(x)} ${f2(y)}) scale(${f2(s)})`} opacity={f2(o)}>
      {glow > 0.01 && <circle r={r + 9} fill="none" stroke={dark ? '#5cc2ff' : BLUE} strokeOpacity={f2(glow * 0.85)} strokeWidth="2" />}
      <circle r={r} fill={dark ? '#151a22' : '#fff'} stroke={dark ? 'rgba(255,255,255,.22)' : '#dbe3ec'} strokeWidth="1.5" filter="url(#lo-sh)" />
      <g transform={`translate(${f2(-r * 0.5)} ${f2(-r * 0.5)})`}><I size={r} color={dark ? '#dfe6ef' : '#3f4a5a'} weight="regular" /></g>
      {warn > 0.01 && <circle cx={f2(r * 0.74)} cy={f2(-r * 0.74)} r={f2(Math.max(0.01, 7.5 * warn))} fill={CORAL} stroke={dark ? '#0a0b0e' : '#fff'} strokeWidth="2.5" />}
      {ok > 0.01 && <g transform={`translate(${f2(r * 0.74)} ${f2(-r * 0.74)}) scale(${f2(ok)})`}><circle r="10" fill={dark ? CYAN : BLUE} stroke={dark ? '#0a0b0e' : '#fff'} strokeWidth="2.5" /><path d="M-4.5 0.5 l3 3.2 6-6.7" fill="none" stroke="#fff" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" /></g>}
    </g>
  );
}

function Scene({ t, compact, dark }) {
  const g = compact ? GEO.compact : GEO.wide, { W, H, cx, cy, r } = g;
  const rx3 = g.rings[2][0], ry3 = g.rings[2][1], r0 = g.half * 1.1;
  const live = t >= T.loop, tau = live ? (t - T.loop) % CYCLE : -1, s = tau / REACH;
  // the mark rises from below and settles with a small overshoot, as it does in the line above
  const d = eo(P(t, T.rise, T.riseEnd)), grow = 0.82 + 0.18 * eb(P(t, T.rise, T.riseEnd));
  const markY = cy + (1 - d) * (H * 0.22), markO = ss(P(t, 0, 0.3));
  const nodes = [];
  RINGS.forEach((ring, i) => {
    const [rx, ry] = g.rings[i], ang = angles(ring.icons.length), ratio = (rx - r0) / (rx3 - r0);
    ring.icons.forEach((Ic, k) => {
      const at = T.nodes + i * 0.28 + k * 0.06, pop = P(t, at, at + 0.55);
      const tx = cx + rx * Math.cos(ang[k]), ty = cy + ry * Math.sin(ang[k]) + (live ? Math.sin(t * 0.9 + k * 1.7 + i) * 2.5 : 0);
      // each identity pops out of the mark and travels to its place on the ring
      const x = cx + (tx - cx) * eo(pop), y = cy + (ty - cy) * eo(pop);
      const risky = ring.risky.includes(k), flip = (ratio + 0.03 * k) * REACH, back = 3.5 + 0.12 * k;
      const okOn = live && risky && tau >= flip && tau < back;
      const warn = risky && !okOn ? (live && tau >= back ? eb(P(tau, back, back + 0.4)) : eb(P(t, at + 0.45, at + 0.8))) : 0;
      const ok = okOn ? eb(P(tau, flip, flip + 0.4)) : 0;
      const glow = live ? Math.sin(Math.PI * P(tau, flip - 0.2, flip + 0.55)) : 0;
      nodes.push(<Disc key={`${i}${k}`} x={x} y={y} Icon={Ic} r={r} o={ss(P(pop, 0, 0.3))} s={0.4 + 0.6 * eb(pop)} warn={warn} ok={ok} glow={glow} dark={dark} />);
    });
  });
  const lab = ss(P(t, T.labels, T.labels + 0.6));
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="h-full w-full font-sans" role="img"
      aria-label="Animation: the Deep Algorithms mark rises in and opens into a blue plate that reads: Identity security for the AI era. Impact the future, today. It folds back into the mark, three rings open out of it, and people, machine identities and AI agents take their places on them. A pulse then leaves the mark every few seconds, and each identity it reaches changes from a risk marker to a fix.">
      <defs>
        <filter id="lo-sh" x="-40%" y="-40%" width="180%" height="190%"><feDropShadow dx="0" dy="5" stdDeviation="6" floodColor="#062f57" floodOpacity={dark ? '.45' : '.12'} /></filter>
        <filter id="lo-sh-lg" x="-40%" y="-40%" width="180%" height="190%"><feDropShadow dx="0" dy="12" stdDeviation="14" floodColor="#062f57" floodOpacity={dark ? '.6' : '.22'} /></filter>
        <radialGradient id="lo-halo"><stop offset="0" stopColor={dark ? '#5cc2ff' : CYAN} stopOpacity={dark ? '.3' : '.2'} /><stop offset="1" stopColor={CYAN} stopOpacity="0" /></radialGradient>
      </defs>
      {g.rings.map(([rx, ry], i) => {
        const open = eo(P(t, T.rings + i * 0.16, T.rings + 0.7 + i * 0.16));
        return (
          <g key={i} opacity={f2(ss(P(t, T.rings + i * 0.16, T.rings + 0.3 + i * 0.16)))}>
            <ellipse cx={cx} cy={cy} rx={f2(r0 + (rx - r0) * open)} ry={f2(r0 + (ry - r0) * open)} fill="none" stroke={dark ? 'rgba(255,255,255,.18)' : '#dbe3ec'} strokeWidth="1.5" />
            {lab > 0.01 && <text x={cx} y={cy - ry + 5} textAnchor="middle" opacity={f2(lab)} fontSize={compact ? 13 : 14} fontWeight="500" fill={dark ? '#a8b0bb' : '#5c6777'} stroke={dark ? '#0f1114' : '#f6f7f9'} strokeWidth="7" paintOrder="stroke">{RINGS[i].label}</text>}
          </g>
        );
      })}
      {live && tau < REACH + 0.4 && <ellipse cx={cx} cy={cy} rx={f2(r0 + s * (rx3 - r0))} ry={f2(r0 + s * (ry3 - r0))} fill="none" stroke={dark ? '#5cc2ff' : BLUE} strokeWidth="2" strokeOpacity={f2(0.5 * (1 - ss(P(s, 0.9, 1.15))))} />}
      {nodes}
      <g transform={`translate(${cx} ${f2(markY)}) scale(${f2(grow)})`} opacity={f2(markO)}>
        <circle r={f2(g.half * 2.3 * (1 + 0.015 * Math.sin(t * 1.3)))} fill="url(#lo-halo)" opacity={f2(0.9 * d * (1 - plateOpen(t)))} />
        <g>
          <g filter="url(#lo-sh-lg)"><rect x={-g.half} y={-g.half} width={g.half * 2} height={g.half * 2} rx={g.half * 0.46} fill="#fff" stroke={dark ? 'none' : '#e3e8ee'} /></g>
          <image href="/brand/mark.webp" x={-g.half * 0.58} y={-g.half * 0.58} width={g.half * 1.16} height={g.half * 1.16} />
        </g>
      </g>
    </svg>
  );
}

/* The plate sits behind the mark in the same frame, so the mark never moves:
   it opens around it, carries the line above and the tagline below, and
   closes back into it. Sizes follow the frame, so it reads on a laptop. */
function Plate({ t, compact, w }) {
  const g = compact ? GEO.compact : GEO.wide;
  const k = plateOpen(t);
  if (k <= 0.002 || !w) return null;
  const px = w / g.W, mark = g.half * 2 * px, H = g.H * px;
  const top = (g.cy - g.half) * px, below = (g.cy + g.half) * px;
  const out = 1 - ss(P(t, T.fold - 0.25, T.fold + 0.1)); // the words leave just before it folds
  const fs = compact ? Math.max(22, w * 0.07) : Math.max(28, w * 0.044), ts = compact ? Math.max(15, w * 0.045) : Math.max(17, w * 0.021);
  const word = (i) => { const a = P(t, T.words + i * 0.11, T.words + 0.55 + i * 0.11); return { opacity: ss(a) * out, transform: `translateY(${f2((1 - eo(a)) * 0.45 * fs)}px)`, filter: `blur(${f2((1 - a) * 6)}px)` }; };
  const tag = P(t, T.tag, T.tag + 0.7);
  return (
    <div aria-hidden="true" className="pointer-events-none absolute inset-0">
      <div className="plate absolute left-1/2" style={{ top: g.cy * px, width: mark + (w - mark) * k, height: mark + (H * 0.94 - mark) * k, borderRadius: mark * 0.23 + (28 - mark * 0.23) * k, transform: 'translate(-50%, -50%)' }} />
      <p className="absolute inset-x-0 flex flex-wrap justify-center gap-x-[.26em] px-6 text-center font-semibold text-white" style={{ bottom: H - top + mark * 0.2, fontSize: fs, lineHeight: 1.06, letterSpacing: '-0.03em' }}>
        {LINE.map((x, i) => [<span key={x + i} className="inline-block" style={word(i)}>{x}</span>, compact && i === 1 && <span key="br" className="basis-full" />])}
      </p>
      <p className="absolute inset-x-0 px-6 text-center font-medium text-white/90" style={{ top: below + mark * 0.2, fontSize: ts, opacity: f2(ss(tag) * out), transform: `translateY(${f2((1 - eo(tag)) * 10)}px)` }}>
        {TAG}
      </p>
    </div>
  );
}

const PRODUCTS = [
  { key: 'zenstra', name: 'Zenstra AI', what: 'AI agents', to: '/agentic-ai/agentic-identity' },
  { key: 'adapid', name: 'adapID AI', what: 'People and machine identities', to: '/adapid-ai' },
  { key: 'botshield', name: 'BotShield AI', what: 'Apps, APIs and the edge', to: '/botshield-ai' },
  { key: 'icms', name: 'ICMS Compliance Suite', what: 'Personal data and DPDPA', to: '/dpdpa-compliance' },
];

export default function LogoOrbit() {
  const reduce = useReducedMotion();
  const [t, setT] = useState(DONE);
  const [compact, setCompact] = useState(false);
  const [dark, setDark] = useState(false);
  const frame = useRef(null);
  const [w, setW] = useState(0);

  useEffect(() => {
    const ro = new ResizeObserver(() => setW(frame.current.clientWidth));
    ro.observe(frame.current);
    const m = window.matchMedia('(max-width: 639px)');
    const on = () => setCompact(m.matches);
    on(); m.addEventListener('change', on);
    setDark(getTheme() === 'dark');
    const off = onTheme((x) => setDark(x === 'dark'));
    return () => { ro.disconnect(); m.removeEventListener('change', on); off?.(); };
  }, []);

  // arrive once when it comes into view, then loop while on screen
  useEffect(() => {
    if (reduce) { setT(DONE); return undefined; }
    const el = frame.current;
    let raf = 0, visible = false, acc = 0, last = 0, cur = 0;
    setT(0);
    const tick = (now) => {
      const dt = Math.min(0.1, (now - last) / 1000); last = now;
      cur += dt; acc += dt;
      if (acc >= 1 / 40) { acc = 0; setT(cur); }
      if (visible) raf = requestAnimationFrame(tick);
    };
    const io = new IntersectionObserver(([e]) => {
      visible = e.isIntersecting;
      if (visible && !raf) { last = performance.now(); raf = requestAnimationFrame(tick); }
      if (!visible) { cancelAnimationFrame(raf); raf = 0; }
    }, { threshold: 0.5 });
    io.observe(el);
    return () => { io.disconnect(); cancelAnimationFrame(raf); };
  }, [reduce]);

  const row = (i) => ({ opacity: ss(P(t, T.labels + 0.1 + i * 0.12, T.labels + 0.6 + i * 0.12)), transform: `translateY(${f2((1 - eo(P(t, T.labels + 0.1 + i * 0.12, T.labels + 0.7 + i * 0.12))) * 18)}px)` });
  return (
    <div>
      <ul className="mx-auto flex max-w-[860px] flex-wrap justify-center gap-x-8 gap-y-3 text-[15.5px] font-medium text-ink-2">
        {['Discover every identity', 'Fix risk before it is used', 'Prove it to every auditor'].map((x) => (
          <li key={x} className="inline-flex items-center gap-2"><Icon name="CheckCircle" size={20} weight="fill" className="text-[#0a6dbb]" />{x}</li>
        ))}
      </ul>
      <div ref={frame} className={cx('relative mx-auto mt-6 w-full max-w-[1200px]', compact ? 'aspect-square' : 'aspect-[1200/500]')}>
        <Plate t={t} compact={compact} w={w} />
        <div className="relative h-full w-full"><Scene t={t} compact={compact} dark={dark} /></div>
      </div>
      <ul className="mx-auto mt-4 grid max-w-[1100px] grid-cols-2 gap-3 md:grid-cols-4 md:gap-4">
        {PRODUCTS.map((p, i) => (
          <li key={p.key} style={row(i)}>
            <Link to={p.to} className="card card-hover group flex h-full items-center gap-3.5 p-4 max-md:flex-col max-md:text-center md:p-5">
              <ProductMark p={p.key} size={40} className="transition-transform duration-300 group-hover:scale-[1.06]" />
              <span className="min-w-0">
                <span className="block text-[15.5px] font-semibold leading-tight">{p.name}</span>
                <span className="mt-0.5 block text-[13px] leading-snug text-ink-3">{p.what}</span>
              </span>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
