import { cx } from '../lib/motion.js';

/* Research covers, drawn in SVG: a fan of light strands in the topic's colour,
   a motif for the subject and the one figure the article turns on. */
export const TOPIC = {
  'Identity Security': { hue: 196, motif: 'rings' },
  'AI Agent Security': { hue: 232, motif: 'graph' },
  'Threat Intelligence': { hue: 12, motif: 'radar' },
  'Financial Crime': { hue: 40, motif: 'mesh' },
  'Field Notes': { hue: 150, motif: 'terminal' },
  Compliance: { hue: 44, motif: 'docs' },
  'Bot Defence': { hue: 170, motif: 'streams' },
};

export const HOOK = {
  'identity-security': ['0', 'alerts raised'],
  'ai-security-intelligence': ['Authority', 'without identity'],
  'threat-intelligence': ['15 days', 'before containment'],
  'ai-agent-governance': ['12 s', 'three years of mail'],
  'ai-security': ['New', 'security boundary'],
  'india-mule-account-crisis': ['26.5 lakh', 'mule accounts'],
  'mythos-ai-banking-threat': ['Minutes', 'not months'],
  'confessions-entry-01': ['47 days', 'inside, unseen'],
  'ctem-dpdpa-india-2026': ['CTEM + DPDPA', 'one programme'],
  'ctem-bot-defence-fintech': ['Hours', 'for bots to adapt'],
  'ddos-mitigation-strategy-2026': ['L7', 'floods that look human'],
};

const rnd = (seed) => { let s = seed; return () => { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; }; };
const hash = (str) => [...str].reduce((a, c) => (a * 31 + c.charCodeAt(0)) % 2147483647, 7);

function Strands({ r, hue, id }) {
  const out = [];
  const kx = 900 + r() * 300, ky = 380 + r() * 260;
  for (let i = 0; i < 46; i++) {
    const a = r() * 2 - 1, b = r() * 2 - 1;
    const y0 = ky + a * 520, y1 = ky + b * 560;
    const d = `M-40 ${y0.toFixed(0)} C ${(kx * 0.45).toFixed(0)} ${(y0 * 0.6 + ky * 0.4).toFixed(0)}, ${(kx * 0.8).toFixed(0)} ${(ky + a * 16).toFixed(0)}, ${kx.toFixed(0)} ${(ky + a * 6).toFixed(0)} S ${(kx + 380).toFixed(0)} ${(y1 * 0.7 + ky * 0.3).toFixed(0)}, 1660 ${y1.toFixed(0)}`;
    out.push(<path key={i} d={d} fill="none" stroke={`hsl(${hue + (r() * 16 - 8)} 100% ${62 + r() * 22}%)`} strokeWidth={0.8 + r() * 1.6} opacity={0.12 + r() * 0.4} />);
  }
  return <g style={{ mixBlendMode: 'screen' }}>{out}<circle cx={kx} cy={ky} r="140" fill={`url(#knot-${id})`} /></g>;
}

function Motif({ m, r, hue }) {
  const c = `hsl(${hue} 100% 72%)`, c2 = `hsl(${hue} 90% 60% / .5)`;
  switch (m) {
    case 'rings': return <g transform="translate(1250 300)">{[60, 120, 180, 240].map((rr, i) => <circle key={rr} r={rr} fill="none" stroke={c} strokeOpacity={0.5 - i * 0.1} strokeDasharray={i % 2 ? '4 10' : undefined} />)}<circle r="16" fill={c} /><circle r="34" fill="none" stroke={c} strokeWidth="3" /></g>;
    case 'graph': {
      const pts = Array.from({ length: 9 }, () => [1050 + r() * 420, 120 + r() * 420]);
      return <g>{pts.map((p, i) => pts.slice(i + 1, i + 3).map((q, j) => <line key={`${i}${j}`} x1={p[0]} y1={p[1]} x2={q[0]} y2={q[1]} stroke={c2} strokeWidth="2" />))}{pts.map((p, i) => <g key={i} transform={`translate(${p[0]} ${p[1]})`}><rect x="-22" y="-22" width="44" height="44" rx="12" fill="#0d1428" stroke={c} strokeOpacity={i === 4 ? 1 : 0.5} strokeWidth="2" /><circle r="5" fill={c} opacity={i === 4 ? 1 : 0.6} /></g>)}</g>;
    }
    case 'radar': return <g transform="translate(1260 320)">{[80, 160, 240].map((rr) => <circle key={rr} r={rr} fill="none" stroke={c2} />)}<path d="M0 0 L240 0 A240 240 0 0 0 170 -170 Z" fill={c} opacity=".18" /><line x1="0" y1="0" x2="240" y2="0" stroke={c} strokeWidth="3" /><circle cx="120" cy="-60" r="9" fill={c} /><circle cx="-90" cy="110" r="6" fill={c} opacity=".6" /></g>;
    case 'mesh': {
      const pts = Array.from({ length: 14 }, (_, i) => { const a = (i / 14) * Math.PI * 2; return [1260 + Math.cos(a) * 220, 320 + Math.sin(a) * 200]; });
      return <g>{pts.map((p, i) => <line key={i} x1="1260" y1="320" x2={p[0]} y2={p[1]} stroke={c2} strokeWidth="2" />)}{pts.map((p, i) => <circle key={i} cx={p[0]} cy={p[1]} r="12" fill="#151221" stroke={c} strokeWidth="2" />)}<circle cx="1260" cy="320" r="30" fill={c} /></g>;
    }
    case 'terminal': return <g transform="translate(1000 170)"><rect width="520" height="300" rx="22" fill="#08130f" stroke={c2} strokeWidth="2" />{['#ff6b5d', '#f6b955', '#3fd98f'].map((f, i) => <circle key={f} cx={36 + i * 26} cy="32" r="8" fill={f} />)}<text x="36" y="120" fill={c} fontFamily="JetBrains Mono, monospace" fontSize="34">$ whoami</text><text x="36" y="175" fill="#fff" fontFamily="JetBrains Mono, monospace" fontSize="34">trusted-user</text><text x="36" y="230" fill={c} fontFamily="JetBrains Mono, monospace" fontSize="34">$ _</text></g>;
    case 'docs': return <g transform="translate(1080 130)">{[0, 1, 2].map((i) => <rect key={i} x={i * 40} y={i * 34} width="300" height="380" rx="18" fill="#141209" stroke={c} strokeOpacity={0.3 + i * 0.25} strokeWidth="2" />)}{[0, 1, 2, 3].map((i) => <rect key={i} x="120" y={140 + i * 46} width={150 - i * 20} height="12" rx="6" fill={c} opacity=".45" />)}<circle cx="330" cy="380" r="46" fill={c} /><path d="m308 380 15 15 30-30" fill="none" stroke="#141209" strokeWidth="9" strokeLinecap="round" strokeLinejoin="round" /></g>;
    case 'streams': return <g>{Array.from({ length: 12 }, (_, i) => <line key={i} x1={980 + (i % 3) * 30} y1={110 + i * 38} x2={1300} y2={110 + i * 38} stroke={i % 3 === 0 ? `hsl(200 100% 70%)` : c} strokeWidth="5" strokeLinecap="round" strokeDasharray="30 18" opacity={0.35 + (i % 4) * 0.15} />)}<rect x="1300" y="90" width="10" height="460" rx="5" fill={c} /><line x1="1320" y1="320" x2="1520" y2="320" stroke="hsl(200 100% 70%)" strokeWidth="5" strokeDasharray="30 18" /></g>;
    default: return null;
  }
}

export default function Cover({ post, className, showHook = true, style }) {
  const t = TOPIC[post.category] || TOPIC['Identity Security'];
  const r = rnd(hash(post.slug));
  const [big, small] = HOOK[post.slug] || ['', ''];
  const hue = t.hue;
  return (
    <div className={cx('relative overflow-hidden', className)} style={{ ...style, containerType: 'inline-size', background: `radial-gradient(120% 120% at 80% 30%, hsl(${hue} 70% 14%), #05070d 62%)` }}>
      <svg viewBox="0 0 1600 1000" preserveAspectRatio="xMidYMid slice" className="absolute inset-0 h-full w-full" aria-hidden="true">
        <defs>
          <radialGradient id={`knot-${post.slug}`}><stop offset="0" stopColor={`hsl(${hue} 100% 85%)`} stopOpacity=".5" /><stop offset="1" stopColor={`hsl(${hue} 100% 60%)`} stopOpacity="0" /></radialGradient>
          <pattern id={`grid-${post.slug}`} width="64" height="64" patternUnits="userSpaceOnUse"><path d="M64 0H0V64" fill="none" stroke="rgb(255 255 255 / .04)" /></pattern>
        </defs>
        <rect width="1600" height="1000" fill={`url(#grid-${post.slug})`} />
        <Strands r={r} hue={hue} id={post.slug} />
        <Motif m={t.motif} r={r} hue={hue} />
      </svg>
      {showHook && big && (
        <div className="absolute bottom-[9%] left-[7%] right-[40%]">
          <p className="font-semibold leading-none tracking-[-0.05em] text-white" style={{ fontSize: 'clamp(30px, 8cqw, 96px)' }}>{big}</p>
          <p className="mt-2 font-medium" style={{ color: `hsl(${hue} 100% 78%)`, fontSize: 'clamp(12px, 2.4cqw, 22px)' }}>{small}</p>
        </div>
      )}
    </div>
  );
}
