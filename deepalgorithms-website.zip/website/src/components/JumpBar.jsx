import { useEffect, useRef, useState } from 'react';
import { useLocation } from 'react-router';
import { cx } from './ui.jsx';

/* On a phone, long pages get a bar of their sections once the reader is past
   the hero: what is coming, where they are, one tap to any part. Sections are
   read from the page itself (each h2 with an id), named by their eyebrow. */
const LONG = /^\/(adapid-ai|agentic-ai|botshield-ai|dpdpa-compliance|ad-security|solutions|platform|about-us)/;

export default function JumpBar() {
  const { pathname } = useLocation();
  const [items, setItems] = useState([]);
  const [active, setActive] = useState(-1);
  const [on, setOn] = useState(false);
  const bar = useRef(null);

  useEffect(() => {
    setItems([]); setActive(-1); setOn(false);
    if (!LONG.test(pathname)) return undefined;
    let io, onScroll;
    const t = setTimeout(() => {
      const hs = [...document.querySelectorAll('main h2[id]')].filter((h) => !h.closest('[role=dialog]'));
      const list = hs.map((h) => {
        const eb = h.previousElementSibling?.classList.contains('eyebrow') ? h.previousElementSibling.textContent.trim() : '';
        const label = (eb || h.textContent.trim().split(/\s+/).slice(0, 3).join(' ')).replace(/[.,:]$/, '');
        return { id: h.id, label: label.length > 28 ? `${label.slice(0, 26)}…` : label, el: h };
      });
      if (list.length < 4) return;
      setItems(list.map(({ id, label }) => ({ id, label })));
      io = new IntersectionObserver((es) => {
        for (const e of es) if (e.isIntersecting) setActive(list.findIndex((x) => x.el === e.target));
      }, { rootMargin: '-30% 0px -60% 0px' });
      list.forEach((x) => io.observe(x.el));
      const first = list[0].el;
      onScroll = () => setOn(first.getBoundingClientRect().top < window.innerHeight * 0.6);
      onScroll();
      window.addEventListener('scroll', onScroll, { passive: true });
    }, 450);
    return () => { clearTimeout(t); io?.disconnect(); if (onScroll) window.removeEventListener('scroll', onScroll); };
  }, [pathname]);

  // keep the current chip in view
  useEffect(() => {
    const el = bar.current?.querySelector(`[data-i="${active}"]`);
    if (el) el.parentElement.scrollTo({ left: el.offsetLeft - 20, behavior: 'smooth' });
  }, [active]);

  if (!items.length) return null;
  const go = (id) => {
    const el = document.getElementById(id);
    if (!el) return;
    window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - 70, behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
  };
  return (
    <nav ref={bar} aria-label="On this page" className={cx('jumpbar noprint md:hidden', on && 'on')}>
      <div className="no-scrollbar flex gap-1.5 overflow-x-auto border-b border-line bg-[color-mix(in_oklab,var(--color-bg)_88%,transparent)] px-4 py-2.5 backdrop-blur-xl">
        {items.map((x, i) => (
          <button key={x.id} type="button" data-i={i} onClick={() => go(x.id)} aria-current={i === active ? 'true' : undefined}
            className={cx('shrink-0 rounded-full px-3.5 py-1.5 text-[13.5px] font-medium transition-colors', i === active ? 'bg-fg text-bg' : 'border border-line-2 text-ink-2')}>
            {x.label}
          </button>
        ))}
      </div>
    </nav>
  );
}
