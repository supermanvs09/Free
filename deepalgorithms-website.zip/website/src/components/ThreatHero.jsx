import { useEffect, useRef, useState } from 'react';
import { useInView, useReducedMotion, cx } from '../lib/motion.js';

/* The home hero, one frame, on a loop: an attacker in a hood and a rogue AI
   agent at the same desk, working one target together, your business, its
   systems on the screen above them. One signs in with a stolen password, the
   other pulls records its task does not allow. One scan reads both; both are
   stopped and blown away as dust; the business carries on; and the next
   attempt sits down. Illustrations are our own (flat vector); the dust is made
   from their own pixels. */

const VW = 640, VH = 560;
const FIGS = [
  { id: 'person', x: 186, claim: 'Right password. Wrong person.', verdict: 'Blocked before the first click.' },
  { id: 'agent', x: 454, claim: 'Approved agent. Wrong action.', verdict: 'Stopped before it ran.' },
];
const SCALE = 0.56, DESK = 470;
const place = (cx) => `translate(${cx - 300 * SCALE} ${DESK - 524 * SCALE}) scale(${SCALE})`;
/* where each laptop sits, for the data each one pulls */
const LAP = (cx) => ({ x: cx, y: DESK - (524 - 430) * SCALE });
const SCREEN = { x: 220, y: 30, w: 200, h: 156 };
/* one round, in ms; then the next attempt begins */
const T = { alert: 700, claim: 1000, scan: 2600, verdict: 3800, dust: 4600, sweep: 1800, calm: 7200, end: 9600 };
const FLY = 1300; // how long one grain is blown about

function phaseAt(t) {
  if (t >= T.calm) return 'calm';
  if (t >= T.dust) return 'dust';
  if (t >= T.verdict) return 'verdict';
  if (t >= T.scan) return 'scan';
  if (t >= T.claim) return 'claim';
  if (t >= T.alert) return 'alert';
  return 'in';
}

const RIM = { fill: 'none', stroke: '#7cc4ff', strokeWidth: 2, strokeOpacity: 0.55 };

/* the laptop both of them work at; the lid carries what they are after */
function Laptop({ children }) {
  return (
    <>
      <rect x="188" y="372" width="224" height="146" rx="14" fill="#e6ecf5" />
      <rect x="188" y="372" width="224" height="146" rx="14" fill="none" stroke="#c3cfe2" strokeWidth="2" />
      <g transform="translate(300 446)">{children}</g>
      <rect x="156" y="512" width="288" height="12" rx="6" fill="#b8c5da" />
    </>
  );
}

/* Plain fills (no classes) so the same markup can be drawn onto a canvas. */
function Attacker() {
  return (
    <>
      <path d="M150 468C158 390 214 350 300 348c86 2 142 42 150 120Z" fill="#24345f" />
      <path d="M300 348c-30 1-56 6-78 15l20 105h116l20-105c-22-9-48-14-78-15Z" fill="#2b3d6e" />
      <path d="M150 468C158 390 214 350 300 348c86 2 142 42 150 120" {...RIM} />
      <path d="M300 116c-66 0-108 54-112 122-3 46 4 78 16 102h192c12-24 19-56 16-102-4-68-46-122-112-122Z" fill="#2c3f72" />
      <path d="M300 116c-66 0-108 54-112 122-1 20 0 37 2 52 10-74 50-128 110-128s100 54 110 128c2-15 3-32 2-52-4-68-46-122-112-122Z" fill="#3a5291" />
      <path d="M204 340c-12-24-19-56-16-102 4-68 46-122 112-122s108 54 112 122c3 46-4 78-16 102" {...RIM} />
      <path d="M300 166c-42 0-70 36-72 82-1 36 16 70 40 86h64c24-16 41-50 40-86-2-46-30-82-72-82Z" fill="#060a16" />
      <path d="M300 194c-32 0-50 26-50 60 0 38 22 66 50 66s50-28 50-66c0-34-18-60-50-60Z" fill="#d39a76" />
      <path d="M250 254c0-34 18-60 50-60s50 26 50 60c-16-22-32-30-50-30s-34 8-50 30Z" fill="#060a16" opacity=".88" />
      <path d="M252 240c30-9 66-9 96 0l2 24c-32 9-68 9-100 0Z" fill="#05070f" />
      <g className="th-blink">
        <path d="M266 249l25 5-2 8-21-3Z" fill="#fff" />
        <path d="M334 249l-25 5 2 8 21-3Z" fill="#fff" />
      </g>
      <path d="M283 336l-4 52M317 336l4 52" stroke="#9fb1d1" strokeWidth="3.5" strokeLinecap="round" />
      <circle cx="279" cy="391" r="4.5" fill="#9fb1d1" />
      <circle cx="321" cy="391" r="4.5" fill="#9fb1d1" />
      <Laptop>
        <path d="M-38-30 38 30M38-30-38 30" stroke="#1b2747" strokeWidth="10" strokeLinecap="round" />
        {[[-41, -33], [-33, -41], [41, -33], [33, -41], [-41, 33], [-33, 41], [41, 33], [33, 41]].map(([x, y]) => <circle key={`${x}${y}`} cx={x} cy={y} r="7" fill="#1b2747" />)}
        <path d="M0-30c-18 0-28 12-28 27 0 9 4 15 10 19v9h36v-9c6-4 10-10 10-19 0-15-10-27-28-27Z" fill="#1b2747" />
        <circle cx="-10" cy="-4" r="7" fill="#e6ecf5" /><circle cx="10" cy="-4" r="7" fill="#e6ecf5" />
        <path d="M0 5l-4 7h8Z" fill="#e6ecf5" />
        <path d="M-8 18v7M0 18v7M8 18v7" stroke="#e6ecf5" strokeWidth="2.4" />
      </Laptop>
    </>
  );
}

function Agent() {
  return (
    <>
      <path d="M156 468C164 396 220 360 300 358c80 2 136 38 144 110Z" fill="#24345f" />
      <path d="M156 468C164 396 220 360 300 358c80 2 136 38 144 110" {...RIM} />
      <rect x="282" y="312" width="36" height="52" rx="8" fill="#3a5291" />
      <path d="M300 122v36" stroke="#8fa3c4" strokeWidth="6" strokeLinecap="round" />
      <circle className="th-led" cx="300" cy="114" r="11" fill="#ff5d5d" />
      <rect x="198" y="210" width="22" height="56" rx="9" fill="#8fa3c4" />
      <rect x="380" y="210" width="22" height="56" rx="9" fill="#8fa3c4" />
      <rect x="212" y="154" width="176" height="164" rx="44" fill="#c7d3e6" />
      <path d="M256 154h88c24 0 44 20 44 44v6c-26-22-62-30-88-30s-62 8-88 30v-6c0-24 20-44 44-44Z" fill="#e1e8f3" />
      <rect x="212" y="154" width="176" height="164" rx="44" {...RIM} />
      <rect x="234" y="196" width="132" height="64" rx="32" fill="#070b18" />
      <rect x="250" y="212" width="42" height="30" rx="15" fill="#ff5d5d" opacity=".28" />
      <rect x="308" y="212" width="42" height="30" rx="15" fill="#ff5d5d" opacity=".28" />
      <g className="th-blink">
        <rect x="258" y="218" width="26" height="18" rx="9" fill="#ff6b6b" />
        <rect x="316" y="218" width="26" height="18" rx="9" fill="#ff6b6b" />
      </g>
      <rect x="268" y="282" width="64" height="12" rx="6" fill="#8fa3c4" />
      <path d="M284 282v12M300 282v12M316 282v12" stroke="#c7d3e6" strokeWidth="2.5" />
      <Laptop>
        {/* records leaving */}
        <path d="M-40-30h30l12 12v40h-42Z" fill="#1b2747" />
        <path d="M-30-12h22M-30-2h22M-30 8h16" stroke="#e6ecf5" strokeWidth="3.5" strokeLinecap="round" />
        <path d="M8 2h30M28-10l12 12-12 12" fill="none" stroke="#e5484d" strokeWidth="7" strokeLinecap="round" strokeLinejoin="round" />
      </Laptop>
    </>
  );
}

/* the four systems on the target screen: mail, payments, records, cloud */
const TILES = [
  { x: 254, d: 'M-8-5h16v11h-16Z M-8-5 0 1 8-5' },
  { x: 298, d: 'M-9-6h18v12h-18Z M-9-2h18 M-5 3h4' },
  { x: 342, d: 'M-8-7c0-2 16-2 16 0v13c0 2-16 2-16 0Z M-8-7c0 2 16 2 16 0 M-8-1c0 2 16 2 16 0' },
  { x: 386, d: 'M-9 5h17a4.5 4.5 0 0 0-1-9 6 6 0 0 0-11.5 1.5A3.8 3.8 0 0 0-9 5Z' },
];

/* draw markup onto a canvas and read it back as grains of its own colours */
function rasterise(markup, w, h, step, done) {
  const img = new Image();
  img.onload = () => {
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    const g = c.getContext('2d');
    g.drawImage(img, 0, 0);
    const px = g.getImageData(0, 0, w, h).data;
    const byColour = new Map(); // grouped by colour, so each colour is one fillStyle
    for (let y = 0; y < h; y += step) {
      for (let x = 0; x < w; x += step) {
        // the most opaque pixel of the cell stands for it, so soft edges
        // become grains too and no outline stays behind
        let o = (y * w + x) * 4;
        for (const [dx, dy] of [[1, 0], [0, 1], [1, 1]]) {
          const q = (Math.min(h - 1, y + dy) * w + Math.min(w - 1, x + dx)) * 4;
          if (px[q + 3] > px[o + 3]) o = q;
        }
        if (px[o + 3] < 8) continue;
        const key = `${px[o] & 0xf8},${px[o + 1] & 0xf8},${px[o + 2] & 0xf8}`;
        if (!byColour.has(key)) byColour.set(key, []);
        byColour.get(key).push(x, y, Math.random(), Math.random(), Math.random(), Math.random());
      }
    }
    const sets = [...byColour].map(([k, list]) => ({ fill: `rgb(${k.split(',').join(' ')})`, g: new Float32Array(list) }));
    done({ sets, picture: c });
  };
  img.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${VW} ${VH}">${markup}</svg>`)}`;
}

export default function ThreatHero() {
  const ref = useRef(null);
  const svg = useRef(null);
  const figs = useRef(null);
  const canvas = useRef(null);
  const seen = useInView(ref, { threshold: 0.2 });
  const reduce = useReducedMotion();
  const [paused, setPaused] = useState(false);
  const [phase, setPhase] = useState('claim'); // without scripts and with reduced motion, the scene as the attempt is made
  const clock = useRef({ t: 0, last: 0 });
  const grains = useRef(null);
  const [ready, setReady] = useState(false);

  // the two figures become grains of their own colours, once
  useEffect(() => {
    if (reduce) return undefined;
    let live = true;
    const box = svg.current.getBoundingClientRect();
    const w = Math.max(320, Math.round(box.width)), h = Math.round(w * (VH / VW));
    const step = 2;
    rasterise(figs.current.innerHTML, w, h, step, (res) => {
      if (!live) return;
      grains.current = { ...res, w, h, step };
      setReady(true);
    });
    return () => { live = false; };
  }, [reduce]);

  useEffect(() => {
    if (reduce) { setPhase('verdict'); return undefined; }
    if (!seen || paused) return undefined;
    const c = clock.current;
    const cv = canvas.current;
    const ctx = cv.getContext('2d');
    let raf = 0;
    c.last = performance.now();
    const size = () => {
      const r = cv.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      cv.width = Math.round(r.width * dpr); cv.height = Math.round(r.height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    size();

    const draw = (t) => {
      const r = cv.getBoundingClientRect();
      ctx.clearRect(0, 0, r.width, r.height);
      const G = grains.current;
      if (!G || t < T.dust || t > T.dust + T.sweep + FLY + 100) return;
      const k = r.width / G.w;
      const sx = G.w / VW, sy = G.h / VH;
      const mid = G.w / 2;
      const s0 = G.step * 1.6;
      // a grain leaves when the wave reaches it: each figure comes apart from
      // its outer side inwards, with a little scatter
      const leaves = (x0, y0, r1) => T.dust + ((1 - Math.abs(x0 - mid) / mid) * 0.62 + (y0 / G.h) * 0.28 + r1 * 0.1) * T.sweep;
      if (t < T.dust + T.sweep + 100) {
        // what is still there stays the crisp picture; cut out what has left
        ctx.drawImage(G.picture, 0, 0, G.w * k, G.h * k);
        ctx.globalCompositeOperation = 'destination-out';
        ctx.fillStyle = '#000';
        for (const { g } of G.sets) {
          for (let o = 0; o < g.length; o += 6) {
            if (t >= leaves(g[o], g[o + 1], g[o + 2])) ctx.fillRect((g[o] - 0.3) * k, (g[o + 1] - 0.3) * k, s0 * k, s0 * k);
          }
        }
        ctx.globalCompositeOperation = 'source-over';
      }
      // and what has left blows away, outwards and up, shrinking as it goes
      for (const { fill, g } of G.sets) {
        ctx.fillStyle = fill;
        for (let o = 0; o < g.length; o += 6) {
          const x0 = g[o], y0 = g[o + 1], r2 = g[o + 3], r3 = g[o + 4];
          const v = (t - leaves(x0, y0, g[o + 2])) / FLY;
          if (v <= 0 || v >= 1) continue;
          const e = 0.3 * v + 0.7 * v * v; // a push at once, then the wind takes it
          const out = x0 < mid ? -1 : 1;
          const x = x0 - 0.3 + out * (60 + 220 * r2) * e * sx + Math.sin(v * 6 + r3 * 6) * 6 * v;
          const y = y0 - 0.3 - (40 + 160 * r3) * e * sy;
          const s = s0 * (1 - v * 0.8);
          ctx.fillRect(x * k, y * k, s * k, s * k);
        }
      }
    };

    const loop = (now) => {
      c.t += Math.min(64, now - c.last);
      c.last = now;
      if (c.t >= T.end) c.t = 0; // the next attempt
      setPhase(phaseAt(c.t));
      draw(c.t);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    const vis = () => {
      if (document.hidden) cancelAnimationFrame(raf);
      else { c.last = performance.now(); raf = requestAnimationFrame(loop); }
    };
    document.addEventListener('visibilitychange', vis);
    window.addEventListener('resize', size);
    return () => { cancelAnimationFrame(raf); document.removeEventListener('visibilitychange', vis); window.removeEventListener('resize', size); };
  }, [seen, paused, reduce]);

  const gone = ready && (phase === 'dust' || phase === 'calm');
  const showFigs = !gone && phase !== 'calm';
  const attack = ['alert', 'claim', 'scan'].includes(phase);
  const blocked = phase === 'verdict' || phase === 'dust';
  const safe = blocked || phase === 'calm';
  const status = (f) => (blocked ? f.verdict : phase === 'scan' ? 'Checking…' : phase === 'claim' ? f.claim : '');
  const pct = (v, of) => `${(v / of) * 100}%`;
  return (
    <figure ref={ref} data-phase={phase} className="th relative mx-auto w-full max-w-[640px] lg:mr-0" aria-label="Animation, on a loop: an attacker in a hood and a rogue AI agent sit at one desk, working against your business together. The attacker signs in with a stolen password; the agent pulls records its task does not allow. One scan reads both; both are stopped and blown away as dust, the business stays protected, and the next attempt begins.">
      <div className="relative">
      <svg ref={svg} viewBox={`0 0 ${VW} ${VH}`} className="relative block h-auto w-full overflow-visible" aria-hidden="true">
        <defs>
          <radialGradient id="th-floor" cx="50%" cy="50%" r="50%"><stop offset="0" stopColor="#4f9dff" stopOpacity=".22" /><stop offset="1" stopColor="#4f9dff" stopOpacity="0" /></radialGradient>
          <linearGradient id="th-beam" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#4f9dff" stopOpacity="0" /><stop offset="1" stopColor="#4f9dff" stopOpacity=".28" /></linearGradient>
          <linearGradient id="th-desk" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#2a3c6c" /><stop offset="1" stopColor="#17244a" /></linearGradient>
        </defs>

        {/* the target: your business, its systems on one screen */}
        <g className={cx('th-target', attack && 'hit', safe && 'safe')}>
          <rect x={SCREEN.x} y={SCREEN.y} width={SCREEN.w} height={SCREEN.h} rx="14" fill="#0b1a3a" stroke="rgb(124 196 255 / .35)" strokeWidth="1.5" />
          <path d={`M${SCREEN.x} ${SCREEN.y + 26}h${SCREEN.w}`} stroke="rgb(124 196 255 / .2)" />
          {[0, 1, 2].map((i) => <circle key={i} cx={SCREEN.x + 16 + i * 12} cy={SCREEN.y + 13} r="3.5" fill="rgb(124 196 255 / .35)" />)}
          <text x={SCREEN.x + SCREEN.w - 14} y={SCREEN.y + 17.5} textAnchor="end" fill="#9fb3d6" fontSize="11" fontWeight="600" letterSpacing=".06em">YOUR BUSINESS</text>
          {TILES.map((tl, i) => (
            <g key={i} transform={`translate(${tl.x} ${SCREEN.y + 66})`}>
              <rect x="-20" y="-20" width="40" height="40" rx="11" className="th-tile" style={{ animationDelay: `${i * 0.18}s` }} />
              <path d={tl.d} fill="none" stroke="#dbe6f7" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
            </g>
          ))}
          <g transform={`translate(${SCREEN.x + SCREEN.w / 2} ${SCREEN.y + 122})`}>
            <rect x="-62" y="-14" width="124" height="28" rx="14" className="th-state" />
            <text y="4.5" textAnchor="middle" fontSize="12.5" fontWeight="600" className="th-state-t">{safe ? 'Protected' : attack ? 'Under attack' : 'Online'}</text>
          </g>
        </g>

        {/* what each of them pulls from it */}
        {FIGS.map((f) => {
          const l = LAP(f.x);
          return <path key={f.id} d={`M${SCREEN.x + SCREEN.w / 2} ${SCREEN.y + SCREEN.h} C${SCREEN.x + SCREEN.w / 2} ${SCREEN.y + SCREEN.h + 70}, ${l.x} ${l.y - 150}, ${l.x} ${l.y - 64}`} className={cx('th-flow', attack && 'on', blocked && 'cut')} fill="none" strokeWidth="2.5" strokeLinecap="round" />;
        })}

        {/* one desk */}
        <g className="th-desk">
        <ellipse cx={VW / 2} cy={DESK + 12} rx="300" ry="50" fill="url(#th-floor)" />
        <rect x="40" y={DESK} width={VW - 80} height="14" rx="7" fill="url(#th-desk)" />
        <rect x="40" y={DESK} width={VW - 80} height="14" rx="7" fill="none" stroke="rgb(124 196 255 / .25)" />
        <path d={`M86 ${DESK + 14}v42M${VW - 86} ${DESK + 14}v42`} stroke="#17244a" strokeWidth="8" strokeLinecap="round" />
        </g>

        {/* the two of them, side by side */}
        <g ref={figs} className={cx('th-art', showFigs && 'on')}>
          <g transform={place(FIGS[0].x)}><Attacker /></g>
          <g transform={place(FIGS[1].x)}><Agent /></g>
        </g>

        {/* what each one is after */}
        <g className={cx('th-pop', attack && 'on')} style={{ transformOrigin: '84px 262px' }}>
          <path d="M60 240a34 34 0 1 1 22 61l-19 12 4-18a34 34 0 0 1-7-55Z" fill="#e5484d" />
          <g transform="translate(84 267) scale(.74)" fill="#fff">
            <path d="M0-24c-14 0-22 10-22 21 0 7 3 12 8 15v7h28v-7c5-3 8-8 8-15 0-11-8-21-22-21Z" />
            <circle cx="-8" cy="-3" r="5.5" fill="#e5484d" /><circle cx="8" cy="-3" r="5.5" fill="#e5484d" />
            <path d="M-30 26 30 40M30 26-30 40" stroke="#fff" strokeWidth="6" strokeLinecap="round" />
          </g>
        </g>
        <g className={cx('th-pop', attack && 'on')} style={{ transformOrigin: '556px 262px', transitionDelay: attack ? '.15s' : '0s' }}>
          <path d="M580 240a34 34 0 1 0-22 61l19 12-4-18a34 34 0 0 0 7-55Z" fill="#e5484d" />
          <g transform="translate(554 266) scale(.8)">
            <path d="M-22-26h22l10 10v36h-32Z" fill="#fff" />
            <path d="M-15-10h16M-15-1h16M-15 8h10" stroke="#e5484d" strokeWidth="3" strokeLinecap="round" />
            <path d="M14 0h14M21-8l8 8-8 8" fill="none" stroke="#fff" strokeWidth="4.5" strokeLinecap="round" strokeLinejoin="round" />
          </g>
        </g>

        {/* the check runs over both */}
        <g className={cx('th-scan', phase === 'scan' && 'on')}>
          <rect x="60" y="208" width="520" height="28" fill="url(#th-beam)" />
          <rect x="60" y="234" width="520" height="3" rx="1.5" fill="#7fd0ff" />
        </g>

        {/* both stopped */}
        {FIGS.map((f, i) => (
          <g key={f.id} className={cx('th-pop', blocked && 'on')} style={{ transformOrigin: `${f.x + 62}px 262px`, transitionDelay: blocked ? `${i * 0.18}s` : '0s' }}>
            <circle cx={f.x + 62} cy="262" r="22" fill="#1a0b14" />
            <circle cx={f.x + 62} cy="262" r="22" fill="none" stroke="#ff5d5d" strokeWidth="3" />
            <path d={`M${f.x + 54} 254l16 16M${f.x + 70} 254l-16 16`} stroke="#ff5d5d" strokeWidth="5" strokeLinecap="round" />
          </g>
        ))}

      </svg>
      <canvas ref={canvas} aria-hidden="true" className="pointer-events-none absolute inset-0 h-full w-full" />

      {/* under each figure, what is happening to it */}
      {FIGS.map((f) => {
        const s = status(f);
        return (
          <p key={f.id} aria-hidden="true" className={cx('th-status absolute bottom-[2%] flex w-max max-w-[48%] -translate-x-1/2 items-center gap-2 rounded-full border border-white/15 bg-[#081633]/90 py-1.5 pl-2.5 pr-3 text-[13px] font-medium text-white max-sm:text-[10.5px] max-sm:pl-2 max-sm:pr-2.5', !s && 'hide')} style={{ left: pct(f.x, VW) }}>
            <span className={cx('h-2 w-2 shrink-0 rounded-full', blocked ? 'bg-[#ff5d5d] shadow-[0_0_10px_#ff5d5d]' : phase === 'scan' ? 'animate-pulse bg-[#4fb3ff]' : 'bg-[#f5a524]')} />
            <span className="truncate">{s || ' '}</span>
          </p>
        );
      })}

      {/* between attempts: what it meant */}
      <p aria-hidden="true" className={cx('th-calm absolute bottom-[2%] left-1/2 flex w-max max-w-[94%] -translate-x-1/2 items-center gap-2 rounded-full border border-[#4be29a]/30 bg-[#08261f]/90 py-1.5 pl-2.5 pr-3.5 text-[13.5px] font-medium text-white max-sm:text-[11px]', phase === 'calm' && 'on')}>
        <span className="h-2 w-2 shrink-0 rounded-full bg-[#4be29a] shadow-[0_0_10px_#4be29a]" />Both stopped. Nothing lost. Business as usual.
      </p>
      </div>

      {!reduce && (
        <button type="button" onClick={() => setPaused(!paused)} className="th-ctl absolute right-0 top-0 inline-flex h-8 w-8 items-center justify-center rounded-full border border-white/20 bg-[#0b1d40] text-white/80 hover:text-white" aria-label={paused ? 'Play the animation' : 'Pause the animation'}>
          {paused ? <svg width="12" height="12" viewBox="0 0 12 12" aria-hidden="true"><path d="M3 1.5v9l7.5-4.5z" fill="currentColor" /></svg> : <svg width="12" height="12" viewBox="0 0 12 12" aria-hidden="true"><path d="M3 1.5h2v9H3zM7 1.5h2v9H7z" fill="currentColor" /></svg>}
        </button>
      )}
    </figure>
  );
}
