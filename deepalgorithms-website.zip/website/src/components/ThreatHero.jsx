import { useEffect, useRef, useState } from 'react';
import { useInView, useReducedMotion, cx } from '../lib/motion.js';

/* The home hero, one frame: an attacker in a hood signing in with someone
   else's password, and beside him an approved AI agent reaching for records
   its task does not allow. Both are read, both are stopped, and both turn to
   dust; the dust gathers into the Deep Algorithms mark, which stays, with what
   just happened floating beside it. Then it rests on that picture; the visitor
   can play it again. The illustrations are our own (flat vector, drawn for this
   page) and the dust is made from their own pixels. */

const VW = 640, VH = 560;
const FIGS = [
  { id: 'person', x: 172, claim: 'Right password. Wrong person.', verdict: 'Blocked before the first click.' },
  { id: 'agent', x: 468, claim: 'Approved agent. Wrong action.', verdict: 'Stopped before it ran.' },
];
const SCALE = 0.6;
const place = (cx) => `translate(${cx - 300 * SCALE} ${470 - 524 * SCALE}) scale(${SCALE})`;
/* what happened, once the mark has formed */
const NOTES = [
  { icon: 'user', h: 'Stolen password, wrong person', p: 'Blocked before the first click', at: 'left-[0%] top-[8%] max-sm:top-[2%]' },
  { icon: 'bot', h: 'AI agent off its task', p: 'Stopped before the action ran', at: 'right-[0%] top-[26%] max-sm:top-[58%]' },
  { icon: 'doc', h: 'Nothing lost', p: 'Every decision explained and on record', at: 'left-1/2 bottom-[6%] -translate-x-1/2 max-sm:left-0 max-sm:bottom-[1%] max-sm:translate-x-0' },
];

/* the whole scene, in ms; it plays once and rests on the last picture */
const T = { alert: 500, claim: 800, scan: 2300, verdict: 3500, dust: 4300, sweep: 1800, mark: 7900, notes: 8500, done: 10000 };
const FLY = 1100; // how long one grain is blown about before it turns home
const TURN = 0.5; // how far into its flight a gathering grain turns towards the mark
const GATHER = 1300;

function phaseAt(t) {
  if (t >= T.done) return 'done';
  if (t >= T.notes) return 'notes';
  if (t >= T.mark) return 'mark';
  if (t >= T.dust) return 'dust';
  if (t >= T.verdict) return 'verdict';
  if (t >= T.scan) return 'scan';
  if (t >= T.claim) return 'claim';
  if (t >= T.alert) return 'alert';
  return 'in';
}
const AFTER = ['mark', 'notes', 'done'];

/* the brand mark, traced from /brand/mark.webp so it stays sharp at any size */
const MARK = [
  ['#0067ab', 'M6 2.3 6.2 154.5H72.8L84 152.8 92.7 150.7 101.3 147.7 111.2 142.8 110.7 141 96.8 122.7H95.8L91.3 125 83.8 127.8 69.3 131 59 132 49.3 132.2 33.5 131.3 32.5 130.7 32.7 36.7 8.7 4.5 6.7 2.3ZM48 1.2V2.3L64.8 24.5 73.5 25 79.7 26 87.2 28 91.8 29.8 98 33 102.3 36 108 41.2 111.7 45.7 114.7 50.5 117.8 57.8 119.8 65.3 120.8 72.5 121 81.5 120 90.2 117.8 97.8 115.3 103.8 131.3 125H132L137.8 116.3 142.7 105.3 145.7 94.2 147.2 80.3V69L145.7 57.8 141.8 45.7 135.7 34.3 130.7 28 125.7 23 119.7 18.2 109.3 12 100.3 8.2 86.2 4.2 74 2.2 60.7 1.2Z'],
  ['#00aeef', 'M6.5 1.3V2L8.8 4.5 120.8 154.5 152.5 154.7 152.2 153.3 136.5 132.8 131.2 125 114.8 103.2 112.7 101 38.7 1.7Z'],
];
const MARK_C = { x: 320, y: 232 }, MARK_SIZE = 172;
const MARK_AT = { x: MARK_C.x - MARK_SIZE / 2, y: MARK_C.y - MARK_SIZE / 2, s: MARK_SIZE / 160 };

const RIM = { fill: 'none', stroke: '#7cc4ff', strokeWidth: 2, strokeOpacity: 0.55 };

/* the laptop both of them work at; the lid carries what they are after */
function Laptop({ children }) {
  return (
    <>
      <rect x="188" y="372" width="224" height="146" rx="14" fill="#e6ecf5" />
      <rect x="188" y="372" width="224" height="146" rx="14" fill="none" stroke="#c3cfe2" strokeWidth="2" />
      <g transform="translate(300 446)">{children}</g>
      <rect x="156" y="512" width="288" height="12" rx="6" fill="#b8c5da" />
    </>
  );
}

/* Plain fills (no classes) so the same markup can be drawn onto a canvas. */
function Attacker() {
  return (
    <>
      <path d="M150 468C158 390 214 350 300 348c86 2 142 42 150 120Z" fill="#24345f" />
      <path d="M300 348c-30 1-56 6-78 15l20 105h116l20-105c-22-9-48-14-78-15Z" fill="#2b3d6e" />
      <path d="M150 468C158 390 214 350 300 348c86 2 142 42 150 120" {...RIM} />
      <path d="M300 116c-66 0-108 54-112 122-3 46 4 78 16 102h192c12-24 19-56 16-102-4-68-46-122-112-122Z" fill="#2c3f72" />
      <path d="M300 116c-66 0-108 54-112 122-1 20 0 37 2 52 10-74 50-128 110-128s100 54 110 128c2-15 3-32 2-52-4-68-46-122-112-122Z" fill="#3a5291" />
      <path d="M204 340c-12-24-19-56-16-102 4-68 46-122 112-122s108 54 112 122c3 46-4 78-16 102" {...RIM} />
      <path d="M300 166c-42 0-70 36-72 82-1 36 16 70 40 86h64c24-16 41-50 40-86-2-46-30-82-72-82Z" fill="#060a16" />
      <path d="M300 194c-32 0-50 26-50 60 0 38 22 66 50 66s50-28 50-66c0-34-18-60-50-60Z" fill="#d39a76" />
      <path d="M250 254c0-34 18-60 50-60s50 26 50 60c-16-22-32-30-50-30s-34 8-50 30Z" fill="#060a16" opacity=".88" />
      <path d="M252 240c30-9 66-9 96 0l2 24c-32 9-68 9-100 0Z" fill="#05070f" />
      <g className="th-blink">
        <path d="M266 249l25 5-2 8-21-3Z" fill="#fff" />
        <path d="M334 249l-25 5 2 8 21-3Z" fill="#fff" />
      </g>
      <path d="M283 336l-4 52M317 336l4 52" stroke="#9fb1d1" strokeWidth="3.5" strokeLinecap="round" />
      <circle cx="279" cy="391" r="4.5" fill="#9fb1d1" />
      <circle cx="321" cy="391" r="4.5" fill="#9fb1d1" />
      <Laptop>
        <path d="M-38-30 38 30M38-30-38 30" stroke="#1b2747" strokeWidth="10" strokeLinecap="round" />
        {[[-41, -33], [-33, -41], [41, -33], [33, -41], [-41, 33], [-33, 41], [41, 33], [33, 41]].map(([x, y]) => <circle key={`${x}${y}`} cx={x} cy={y} r="7" fill="#1b2747" />)}
        <path d="M0-30c-18 0-28 12-28 27 0 9 4 15 10 19v9h36v-9c6-4 10-10 10-19 0-15-10-27-28-27Z" fill="#1b2747" />
        <circle cx="-10" cy="-4" r="7" fill="#e6ecf5" /><circle cx="10" cy="-4" r="7" fill="#e6ecf5" />
        <path d="M0 5l-4 7h8Z" fill="#e6ecf5" />
        <path d="M-8 18v7M0 18v7M8 18v7" stroke="#e6ecf5" strokeWidth="2.4" />
      </Laptop>
    </>
  );
}

function Agent() {
  return (
    <>
      <path d="M156 468C164 396 220 360 300 358c80 2 136 38 144 110Z" fill="#24345f" />
      <path d="M156 468C164 396 220 360 300 358c80 2 136 38 144 110" {...RIM} />
      <rect x="282" y="312" width="36" height="52" rx="8" fill="#3a5291" />
      <path d="M300 122v36" stroke="#8fa3c4" strokeWidth="6" strokeLinecap="round" />
      <circle className="th-led" cx="300" cy="114" r="11" fill="#ff5d5d" />
      <rect x="198" y="210" width="22" height="56" rx="9" fill="#8fa3c4" />
      <rect x="380" y="210" width="22" height="56" rx="9" fill="#8fa3c4" />
      <rect x="212" y="154" width="176" height="164" rx="44" fill="#c7d3e6" />
      <path d="M256 154h88c24 0 44 20 44 44v6c-26-22-62-30-88-30s-62 8-88 30v-6c0-24 20-44 44-44Z" fill="#e1e8f3" />
      <rect x="212" y="154" width="176" height="164" rx="44" {...RIM} />
      <rect x="234" y="196" width="132" height="64" rx="32" fill="#070b18" />
      <rect x="250" y="212" width="42" height="30" rx="15" fill="#ff5d5d" opacity=".28" />
      <rect x="308" y="212" width="42" height="30" rx="15" fill="#ff5d5d" opacity=".28" />
      <g className="th-blink">
        <rect x="258" y="218" width="26" height="18" rx="9" fill="#ff6b6b" />
        <rect x="316" y="218" width="26" height="18" rx="9" fill="#ff6b6b" />
      </g>
      <rect x="268" y="282" width="64" height="12" rx="6" fill="#8fa3c4" />
      <path d="M284 282v12M300 282v12M316 282v12" stroke="#c7d3e6" strokeWidth="2.5" />
      <Laptop>
        {/* records leaving */}
        <path d="M-40-30h30l12 12v40h-42Z" fill="#1b2747" />
        <path d="M-30-12h22M-30-2h22M-30 8h16" stroke="#e6ecf5" strokeWidth="3.5" strokeLinecap="round" />
        <path d="M8 2h30M28-10l12 12-12 12" fill="none" stroke="#e5484d" strokeWidth="7" strokeLinecap="round" strokeLinejoin="round" />
      </Laptop>
    </>
  );
}

const CODE = [
  [36, 70, 70, 1], [114, 70, 110, 0], [36, 94, 46, 2], [90, 94, 130, 0], [36, 118, 90, 0],
  [440, 70, 120, 0], [440, 94, 70, 1], [518, 94, 86, 0], [470, 118, 110, 0], [470, 142, 60, 3],
];
const CODE_FILL = ['rgb(124 160 230 / .22)', 'rgb(124 196 255 / .32)', 'rgb(255 107 107 / .45)', 'rgb(245 165 36 / .45)'];

const NoteIcon = ({ k }) => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    {k === 'user' ? <><circle cx="8" cy="5.5" r="2.6" /><path d="M3 14c.6-2.8 2.6-4.3 5-4.3s4.4 1.5 5 4.3" /></>
      : k === 'bot' ? <><rect x="3" y="5" width="10" height="8" rx="2.5" /><path d="M8 2.5V5M6 9h.01M10 9h.01" /></>
        : <><path d="M8 1.8 13 3.6v4c0 3.2-2.1 5.4-5 6.6-2.9-1.2-5-3.4-5-6.6v-4Z" /><path d="m5.7 8 1.6 1.6L10.5 6.4" /></>}
  </svg>
);

/* draw markup onto a canvas and read it back as grains of its own colours */
function rasterise(markup, w, h, step, done) {
  const img = new Image();
  img.onload = () => {
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    const g = c.getContext('2d');
    g.drawImage(img, 0, 0);
    const px = g.getImageData(0, 0, w, h).data;
    const byColour = new Map(); // grouped by colour, so each colour is one fillStyle
    const all = [];
    for (let y = 0; y < h; y += step) {
      for (let x = 0; x < w; x += step) {
        // the most opaque pixel of the cell stands for it, so soft edges
        // become grains too and no outline stays behind
        let o = (y * w + x) * 4;
        for (const [dx, dy] of [[1, 0], [0, 1], [1, 1]]) {
          const q = (Math.min(h - 1, y + dy) * w + Math.min(w - 1, x + dx)) * 4;
          if (px[q + 3] > px[o + 3]) o = q;
        }
        if (px[o + 3] < 8) continue;
        const key = `${px[o] & 0xf8},${px[o + 1] & 0xf8},${px[o + 2] & 0xf8}`;
        if (!byColour.has(key)) byColour.set(key, []);
        byColour.get(key).push(x, y, Math.random(), Math.random(), Math.random(), Math.random());
        all.push(x, y, key);
      }
    }
    const sets = [...byColour].map(([k, list]) => ({ fill: `rgb(${k.split(',').join(' ')})`, g: new Float32Array(list) }));
    done({ sets, picture: c, all });
  };
  img.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${VW} ${VH}">${markup}</svg>`)}`;
}

export default function ThreatHero() {
  const ref = useRef(null);
  const svg = useRef(null);
  const figs = useRef(null);
  const mark = useRef(null);
  const canvas = useRef(null);
  const seen = useInView(ref, { threshold: 0.2 });
  const reduce = useReducedMotion();
  const [paused, setPaused] = useState(false);
  const [run, setRun] = useState(0); // bumped to play it again
  const [phase, setPhase] = useState('in'); // without scripts, CSS shows the resting picture instead
  const clock = useRef({ t: 0, last: 0 });
  const grains = useRef(null);
  const [ready, setReady] = useState(false);

  // the two figures and the mark become grains, once
  useEffect(() => {
    if (reduce) return undefined;
    let live = true;
    const box = svg.current.getBoundingClientRect();
    const w = Math.max(320, Math.round(box.width)), h = Math.round(w * (VH / VW));
    const step = 2;
    const out = { w, h, step };
    let left = 2;
    const finish = () => {
      left -= 1;
      if (left || !live) return;
      // every grain that gathers gets a place in the mark; the rest blow out
      const targets = out.mark.all;
      const nT = targets.length / 3;
      const A = out.figs;
      const total = A.sets.reduce((n, s) => n + s.g.length / 6, 0);
      const every = Math.max(1, Math.round(total / (nT * 1.6)));
      let i = 0;
      A.homes = A.sets.map(({ g }) => {
        const home = new Float32Array((g.length / 6) * 3).fill(-1);
        for (let o = 0, j = 0; o < g.length; o += 6, j += 3) {
          i += 1;
          if (i % every) continue;
          const ti = Math.floor(g[o + 5] * nT) * 3;
          home[j] = targets[ti]; home[j + 1] = targets[ti + 1];
          home[j + 2] = +targets[ti + 2].split(',')[1] > 140 ? 1 : 0; // the bright stroke or the bowl
        }
        return home;
      });
      grains.current = out;
      setReady(true);
    };
    rasterise(figs.current.innerHTML, w, h, step, (res) => { out.figs = res; finish(); });
    rasterise(mark.current.outerHTML.replace(/class="[^"]*"/g, ''), w, h, step, (res) => { out.mark = res; finish(); });
    return () => { live = false; };
  }, [reduce]);

  useEffect(() => {
    if (reduce) { setPhase('done'); return undefined; }
    const c = clock.current;
    if (c.t >= T.done) { setPhase('done'); return undefined; } // it has played; rest
    if (!seen || paused) return undefined;
    const cv = canvas.current;
    const ctx = cv.getContext('2d');
    let raf = 0;
    c.last = performance.now();
    const size = () => {
      const r = cv.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      cv.width = Math.round(r.width * dpr); cv.height = Math.round(r.height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    size();

    const draw = (t) => {
      const r = cv.getBoundingClientRect();
      ctx.clearRect(0, 0, r.width, r.height);
      const G = grains.current;
      if (!G || t < T.dust || t > T.mark + 900) return;
      const A = G.figs;
      const k = r.width / G.w;
      const sx = G.w / VW, sy = G.h / VH;
      const mid = G.w / 2;
      const s0 = G.step * 1.6;
      // a grain leaves when the wave reaches it: each figure comes apart from
      // its outer side inwards, with a little scatter
      const leaves = (x0, y0, r1) => T.dust + ((1 - Math.abs(x0 - mid) / mid) * 0.62 + (y0 / G.h) * 0.28 + r1 * 0.1) * T.sweep;
      if (t < T.dust + T.sweep + 100) {
        ctx.drawImage(A.picture, 0, 0, G.w * k, G.h * k);
        ctx.globalCompositeOperation = 'destination-out';
        ctx.fillStyle = '#000';
        for (const { g } of A.sets) {
          for (let o = 0; o < g.length; o += 6) {
            if (t >= leaves(g[o], g[o + 1], g[o + 2])) ctx.fillRect((g[o] - 0.3) * k, (g[o + 1] - 0.3) * k, s0 * k, s0 * k);
          }
        }
        ctx.globalCompositeOperation = 'source-over';
      }
      // the grains fade as the sharp mark takes over
      ctx.globalAlpha = t > T.mark ? Math.max(0, 1 - (t - T.mark) / 700) : 1;
      const homeFill = ['#0067ab', '#2fbaf5'];
      const late = [[], []];
      A.sets.forEach(({ fill, g }, si) => {
        const home = A.homes[si];
        ctx.fillStyle = fill;
        for (let o = 0, j = 0; o < g.length; o += 6, j += 3) {
          const x0 = g[o], y0 = g[o + 1], r2 = g[o + 3], r3 = g[o + 4];
          const v = (t - leaves(x0, y0, g[o + 2])) / FLY;
          if (v <= 0) continue;
          const gathers = home[j] >= 0;
          if (!gathers && v >= 1) continue;
          const f = Math.min(v, 1);
          const e = 0.3 * f + 0.7 * f * f; // a push at once, then the wind takes it
          const out = x0 < mid ? -1 : 1; // away from the middle first
          let x = x0 - 0.3 + out * (40 + 150 * r2) * e * sx + Math.sin(f * 6 + r3 * 6) * 6 * f;
          let y = y0 - 0.3 - (40 + 150 * r3) * e * sy;
          let s = s0 * (1 - f * 0.8);
          if (gathers && v > TURN) {
            // turn home, into the mark
            const p = Math.min(1, ((v - TURN) * FLY) / GATHER);
            const q = p < 0.5 ? 2 * p * p : 1 - ((-2 * p + 2) ** 2) / 2;
            x += (home[j] - x) * q; y += (home[j + 1] - y) * q;
            s = s0 * (0.45 + 0.55 * q);
            if (q > 0.4) { late[home[j + 2]].push(x, y, s); continue; }
          }
          ctx.fillRect(x * k, y * k, s * k, s * k);
        }
      });
      late.forEach((l, li) => {
        ctx.fillStyle = homeFill[li];
        for (let o = 0; o < l.length; o += 3) ctx.fillRect(l[o] * k, l[o + 1] * k, l[o + 2] * k, l[o + 2] * k);
      });
      ctx.globalAlpha = 1;
    };

    const loop = (now) => {
      c.t += Math.min(64, now - c.last);
      c.last = now;
      setPhase(phaseAt(c.t));
      draw(c.t);
      if (c.t >= T.done) return; // rest on the last picture; the notes keep floating in CSS
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    const vis = () => {
      if (document.hidden) cancelAnimationFrame(raf);
      else if (c.t < T.done) { c.last = performance.now(); raf = requestAnimationFrame(loop); }
    };
    document.addEventListener('visibilitychange', vis);
    window.addEventListener('resize', size);
    return () => { cancelAnimationFrame(raf); document.removeEventListener('visibilitychange', vis); window.removeEventListener('resize', size); };
  }, [seen, paused, reduce, run]);

  const replay = () => { clock.current.t = 0; setPaused(false); setPhase('in'); setRun((n) => n + 1); };
  const after = AFTER.includes(phase);
  const showFigs = !after && !(ready && phase === 'dust');
  const threat = ['alert', 'claim', 'scan'].includes(phase);
  const blocked = phase === 'verdict' || phase === 'dust';
  const status = (f) => (blocked ? f.verdict : phase === 'scan' ? 'Checking…' : phase === 'claim' ? f.claim : '');
  return (
    <figure ref={ref} data-phase={phase} className="th relative mx-auto w-full max-w-[640px] lg:mr-0" aria-label="Animation: an attacker in a hood signs in with someone else's password, and an approved AI agent tries to send records outside its task. Both are checked and stopped, and both turn to dust that gathers into the Deep Algorithms mark. Beside it: a stolen password blocked before the first click; an AI agent stopped before the action ran; nothing lost, and every decision explained and on record.">
      <svg ref={svg} viewBox={`0 0 ${VW} ${VH}`} className="relative block h-auto w-full overflow-visible" aria-hidden="true">
        <defs>
          <radialGradient id="th-floor" cx="50%" cy="50%" r="50%"><stop offset="0" stopColor="#4f9dff" stopOpacity=".24" /><stop offset="1" stopColor="#4f9dff" stopOpacity="0" /></radialGradient>
          <linearGradient id="th-beam" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#4f9dff" stopOpacity="0" /><stop offset="1" stopColor="#4f9dff" stopOpacity=".28" /></linearGradient>
          <radialGradient id="th-halo" cx="50%" cy="50%" r="50%"><stop offset="0" stopColor="#2fbaf5" stopOpacity=".38" /><stop offset=".6" stopColor="#0067ab" stopOpacity=".12" /><stop offset="1" stopColor="#0067ab" stopOpacity="0" /></radialGradient>
        </defs>
        <g className={cx('th-code', after && 'dim')}>
          {CODE.map(([x, y, w, c], i) => <rect key={i} x={x} y={y} width={w} height="9" rx="4.5" fill={CODE_FILL[c]} style={{ animationDelay: `${i * 70}ms` }} />)}
        </g>
        <ellipse cx={VW / 2} cy="478" rx="290" ry="56" fill="url(#th-floor)" />
        <path d="M60 482h520" stroke="rgb(124 196 255 / .2)" strokeWidth="2" strokeLinecap="round" />

        {/* the two of them, side by side */}
        <g ref={figs} className={cx('th-art', showFigs && 'on')}>
          <g transform={place(FIGS[0].x)}><Attacker /></g>
          <g transform={place(FIGS[1].x)}><Agent /></g>
        </g>

        {/* what each one is after */}
        <g className={cx('th-pop', threat && 'on')} style={{ transformOrigin: '72px 150px' }}>
          <path d="M48 128a34 34 0 1 1 22 61l-19 12 4-18a34 34 0 0 1-7-55Z" fill="#e5484d" />
          <g transform="translate(72 155) scale(.74)" fill="#fff">
            <path d="M0-24c-14 0-22 10-22 21 0 7 3 12 8 15v7h28v-7c5-3 8-8 8-15 0-11-8-21-22-21Z" />
            <circle cx="-8" cy="-3" r="5.5" fill="#e5484d" /><circle cx="8" cy="-3" r="5.5" fill="#e5484d" />
            <path d="M-30 26 30 40M30 26-30 40" stroke="#fff" strokeWidth="6" strokeLinecap="round" />
          </g>
        </g>
        <g className={cx('th-pop', threat && 'on')} style={{ transformOrigin: '568px 150px', transitionDelay: threat ? '.15s' : '0s' }}>
          <path d="M592 128a34 34 0 1 0-22 61l19 12-4-18a34 34 0 0 0 7-55Z" fill="#e5484d" />
          <g transform="translate(566 154) scale(.8)">
            <path d="M-22-26h22l10 10v36h-32Z" fill="#fff" />
            <path d="M-15-10h16M-15-1h16M-15 8h10" stroke="#e5484d" strokeWidth="3" strokeLinecap="round" />
            <path d="M14 0h14M21-8l8 8-8 8" fill="none" stroke="#fff" strokeWidth="4.5" strokeLinecap="round" strokeLinejoin="round" />
          </g>
        </g>

        {/* the check runs over both */}
        <g className={cx('th-scan', phase === 'scan' && 'on')}>
          <rect x="70" y="122" width="500" height="28" fill="url(#th-beam)" />
          <rect x="70" y="148" width="500" height="3" rx="1.5" fill="#7fd0ff" />
        </g>

        {/* both stopped */}
        {FIGS.map((f, i) => (
          <g key={f.id} className={cx('th-pop', blocked && 'on')} style={{ transformOrigin: `${f.x + 66}px 152px`, transitionDelay: blocked ? `${i * 0.18}s` : '0s' }}>
            <circle cx={f.x + 66} cy="152" r="24" fill="#1a0b14" />
            <circle cx={f.x + 66} cy="152" r="24" fill="none" stroke="#ff5d5d" strokeWidth="3" />
            <path d={`M${f.x + 57} 143l18 18M${f.x + 75} 143l-18 18`} stroke="#ff5d5d" strokeWidth="5" strokeLinecap="round" />
          </g>
        ))}

        {/* what is left: the mark, which stays */}
        <g className={cx('th-float', after && 'on')}>
          <circle className="th-halo" cx={MARK_C.x} cy={MARK_C.y} r="150" fill="url(#th-halo)" />
          <g ref={mark} className="th-mark" transform={`translate(${MARK_AT.x} ${MARK_AT.y}) scale(${MARK_AT.s})`}>
            {MARK.map(([fill, d]) => <path key={fill} d={d} fill={fill} />)}
          </g>
        </g>
      </svg>
      <canvas ref={canvas} aria-hidden="true" className="pointer-events-none absolute inset-0 h-full w-full" />

      {/* under each figure, what is happening to it */}
      {FIGS.map((f) => {
        const s = status(f);
        return (
          <p key={f.id} aria-hidden="true" className={cx('th-status absolute bottom-[8%] flex w-max max-w-[48%] -translate-x-1/2 items-center gap-2 rounded-full border border-white/15 bg-[#081633]/90 py-1.5 pl-2.5 pr-3 text-[13px] font-medium text-white max-sm:text-[10.5px] max-sm:pl-2 max-sm:pr-2.5', (!s || after) && 'hide')} style={{ left: `${(f.x / VW) * 100}%` }}>
            <span className={cx('h-2 w-2 shrink-0 rounded-full', blocked ? 'bg-[#ff5d5d] shadow-[0_0_10px_#ff5d5d]' : phase === 'scan' ? 'animate-pulse bg-[#4fb3ff]' : 'bg-[#f5a524]')} />
            <span className="truncate">{s || ' '}</span>
          </p>
        );
      })}

      {/* what happened, floating beside the mark */}
      {NOTES.map((n, i) => (
        <div key={n.h} aria-hidden="true" className={cx('th-note absolute', n.at, (phase === 'notes' || phase === 'done') && 'on')} style={{ '--d': `${i * 0.35}s`, '--f': `${i * 1.3}s` }}>
          <div className="th-note-in flex items-center gap-3 rounded-[14px] border border-white/15 bg-[#0a1a3a]/90 py-2.5 pl-2.5 pr-4 shadow-[0_24px_50px_-24px_rgba(0,0,0,.9)] max-sm:gap-2 max-sm:py-2 max-sm:pr-3">
            <span className={cx('grid h-8 w-8 shrink-0 place-items-center rounded-[10px] max-sm:h-7 max-sm:w-7', i === 2 ? 'bg-[#1f9d63]/20 text-[#4be29a]' : 'bg-[#2f8bff]/18 text-[#8cc4ff]')}><NoteIcon k={n.icon} /></span>
            <span className="whitespace-nowrap leading-tight">
              <span className="block text-[14px] font-semibold text-white max-sm:text-[11.5px]">{n.h}</span>
              <span className="mt-0.5 block text-[12.5px] text-white/65 max-sm:text-[10.5px]">{n.p}</span>
            </span>
          </div>
        </div>
      ))}

      {!reduce && (phase === 'done'
        ? <button type="button" onClick={replay} className="th-ctl absolute right-0 top-0 inline-flex h-9 items-center gap-1.5 rounded-full border border-white/20 bg-[#0b1d40] px-3 text-[12.5px] font-medium text-white/80 hover:text-white" aria-label="Play the animation again">
            <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M2.5 8a5.5 5.5 0 1 0 1.7-4" /><path d="M2.5 2.5V6H6" /></svg>Replay
          </button>
        : <button type="button" onClick={() => setPaused(!paused)} className="th-ctl absolute right-0 top-0 inline-flex h-9 w-9 items-center justify-center rounded-full border border-white/20 bg-[#0b1d40] text-white/80 hover:text-white" aria-label={paused ? 'Play the animation' : 'Pause the animation'}>
            {paused ? <svg width="12" height="12" viewBox="0 0 12 12" aria-hidden="true"><path d="M3 1.5v9l7.5-4.5z" fill="currentColor" /></svg> : <svg width="12" height="12" viewBox="0 0 12 12" aria-hidden="true"><path d="M3 1.5h2v9H3zM7 1.5h2v9H7z" fill="currentColor" /></svg>}
          </button>)}
    </figure>
  );
}
