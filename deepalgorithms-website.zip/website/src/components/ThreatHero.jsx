import { useEffect, useRef, useState } from 'react';
import { useInView, useReducedMotion, cx } from '../lib/motion.js';

/* The home hero, one frame: an attacker in a hood and a rogue AI agent at the
   same desk, working one target together, your business, its systems on the
   screen above them. One signs in with a stolen password, the other pulls
   records its task does not allow. Both are read and stopped; both turn to
   dust, and the dust gathers into the Deep Algorithms mark, inside one shield
   with every kind of identity on it: people, machine identities, AI agents. Then it rests on that picture; the visitor can play it again.
   Illustrations are our own (flat vector); the dust is made from their pixels. */

const VW = 640, VH = 560;
const FIGS = [
  { id: 'person', x: 186, claim: 'Right password. Wrong person.', verdict: 'Blocked before the first click.' },
  { id: 'agent', x: 454, claim: 'Approved agent. Wrong action.', verdict: 'Stopped before it ran.' },
];
const SCALE = 0.56, DESK = 470;
const place = (cx) => `translate(${cx - 300 * SCALE} ${DESK - 524 * SCALE}) scale(${SCALE})`;
/* where each laptop sits, for the data each one pulls */
const LAP = (cx) => ({ x: cx, y: DESK - (524 - 430) * SCALE });
const SCREEN = { x: 220, y: 30, w: 200, h: 156 };
/* the ending: the mark inside a shield ring, the three kinds of identity on it */
const ORB = { x: 320, y: 236, r: 150 };
const MARK = [
  ['#0067ab', 'M6 2.3 6.2 154.5H72.8L84 152.8 92.7 150.7 101.3 147.7 111.2 142.8 110.7 141 96.8 122.7H95.8L91.3 125 83.8 127.8 69.3 131 59 132 49.3 132.2 33.5 131.3 32.5 130.7 32.7 36.7 8.7 4.5 6.7 2.3ZM48 1.2V2.3L64.8 24.5 73.5 25 79.7 26 87.2 28 91.8 29.8 98 33 102.3 36 108 41.2 111.7 45.7 114.7 50.5 117.8 57.8 119.8 65.3 120.8 72.5 121 81.5 120 90.2 117.8 97.8 115.3 103.8 131.3 125H132L137.8 116.3 142.7 105.3 145.7 94.2 147.2 80.3V69L145.7 57.8 141.8 45.7 135.7 34.3 130.7 28 125.7 23 119.7 18.2 109.3 12 100.3 8.2 86.2 4.2 74 2.2 60.7 1.2Z'],
  ['#00aeef', 'M6.5 1.3V2L8.8 4.5 120.8 154.5 152.5 154.7 152.2 153.3 136.5 132.8 131.2 125 114.8 103.2 112.7 101 38.7 1.7Z'],
];
const MARK_SIZE = 132;
const markAt = `translate(${ORB.x - MARK_SIZE / 2} ${ORB.y - MARK_SIZE / 2}) scale(${MARK_SIZE / 160})`;
const NODES = [
  { k: 'people', label: 'People', a: -90 },
  { k: 'machine', label: 'Machine identities', a: 30 },
  { k: 'agent', label: 'AI agents', a: 150 },
].map((n) => ({ ...n, x: ORB.x + ORB.r * Math.cos((n.a * Math.PI) / 180), y: ORB.y + ORB.r * Math.sin((n.a * Math.PI) / 180) }));

/* the whole scene, in ms; it plays once and rests on the last picture */
const T = { alert: 600, claim: 900, scan: 2400, verdict: 3600, dust: 4400, sweep: 1800, record: 8000, notes: 8900, done: 10400 };
const FLY = 1100; // how long one grain is blown about before it turns home
const TURN = 0.5; // how far into its flight a gathering grain turns towards the record
const GATHER = 1300;

function phaseAt(t) {
  if (t >= T.done) return 'done';
  if (t >= T.notes) return 'notes';
  if (t >= T.record) return 'record';
  if (t >= T.dust) return 'dust';
  if (t >= T.verdict) return 'verdict';
  if (t >= T.scan) return 'scan';
  if (t >= T.claim) return 'claim';
  if (t >= T.alert) return 'alert';
  return 'in';
}
const AFTER = ['record', 'notes', 'done'];

const RIM = { fill: 'none', stroke: '#7cc4ff', strokeWidth: 2, strokeOpacity: 0.55 };

/* the laptop both of them work at; the lid carries what they are after */
function Laptop({ children }) {
  return (
    <>
      <rect x="188" y="372" width="224" height="146" rx="14" fill="#e6ecf5" />
      <rect x="188" y="372" width="224" height="146" rx="14" fill="none" stroke="#c3cfe2" strokeWidth="2" />
      <g transform="translate(300 446)">{children}</g>
      <rect x="156" y="512" width="288" height="12" rx="6" fill="#b8c5da" />
    </>
  );
}

/* Plain fills (no classes) so the same markup can be drawn onto a canvas. */
function Attacker() {
  return (
    <>
      <path d="M150 468C158 390 214 350 300 348c86 2 142 42 150 120Z" fill="#24345f" />
      <path d="M300 348c-30 1-56 6-78 15l20 105h116l20-105c-22-9-48-14-78-15Z" fill="#2b3d6e" />
      <path d="M150 468C158 390 214 350 300 348c86 2 142 42 150 120" {...RIM} />
      <path d="M300 116c-66 0-108 54-112 122-3 46 4 78 16 102h192c12-24 19-56 16-102-4-68-46-122-112-122Z" fill="#2c3f72" />
      <path d="M300 116c-66 0-108 54-112 122-1 20 0 37 2 52 10-74 50-128 110-128s100 54 110 128c2-15 3-32 2-52-4-68-46-122-112-122Z" fill="#3a5291" />
      <path d="M204 340c-12-24-19-56-16-102 4-68 46-122 112-122s108 54 112 122c3 46-4 78-16 102" {...RIM} />
      <path d="M300 166c-42 0-70 36-72 82-1 36 16 70 40 86h64c24-16 41-50 40-86-2-46-30-82-72-82Z" fill="#060a16" />
      <path d="M300 194c-32 0-50 26-50 60 0 38 22 66 50 66s50-28 50-66c0-34-18-60-50-60Z" fill="#d39a76" />
      <path d="M250 254c0-34 18-60 50-60s50 26 50 60c-16-22-32-30-50-30s-34 8-50 30Z" fill="#060a16" opacity=".88" />
      <path d="M252 240c30-9 66-9 96 0l2 24c-32 9-68 9-100 0Z" fill="#05070f" />
      <g className="th-blink">
        <path d="M266 249l25 5-2 8-21-3Z" fill="#fff" />
        <path d="M334 249l-25 5 2 8 21-3Z" fill="#fff" />
      </g>
      <path d="M283 336l-4 52M317 336l4 52" stroke="#9fb1d1" strokeWidth="3.5" strokeLinecap="round" />
      <circle cx="279" cy="391" r="4.5" fill="#9fb1d1" />
      <circle cx="321" cy="391" r="4.5" fill="#9fb1d1" />
      <Laptop>
        <path d="M-38-30 38 30M38-30-38 30" stroke="#1b2747" strokeWidth="10" strokeLinecap="round" />
        {[[-41, -33], [-33, -41], [41, -33], [33, -41], [-41, 33], [-33, 41], [41, 33], [33, 41]].map(([x, y]) => <circle key={`${x}${y}`} cx={x} cy={y} r="7" fill="#1b2747" />)}
        <path d="M0-30c-18 0-28 12-28 27 0 9 4 15 10 19v9h36v-9c6-4 10-10 10-19 0-15-10-27-28-27Z" fill="#1b2747" />
        <circle cx="-10" cy="-4" r="7" fill="#e6ecf5" /><circle cx="10" cy="-4" r="7" fill="#e6ecf5" />
        <path d="M0 5l-4 7h8Z" fill="#e6ecf5" />
        <path d="M-8 18v7M0 18v7M8 18v7" stroke="#e6ecf5" strokeWidth="2.4" />
      </Laptop>
    </>
  );
}

function Agent() {
  return (
    <>
      <path d="M156 468C164 396 220 360 300 358c80 2 136 38 144 110Z" fill="#24345f" />
      <path d="M156 468C164 396 220 360 300 358c80 2 136 38 144 110" {...RIM} />
      <rect x="282" y="312" width="36" height="52" rx="8" fill="#3a5291" />
      <path d="M300 122v36" stroke="#8fa3c4" strokeWidth="6" strokeLinecap="round" />
      <circle className="th-led" cx="300" cy="114" r="11" fill="#ff5d5d" />
      <rect x="198" y="210" width="22" height="56" rx="9" fill="#8fa3c4" />
      <rect x="380" y="210" width="22" height="56" rx="9" fill="#8fa3c4" />
      <rect x="212" y="154" width="176" height="164" rx="44" fill="#c7d3e6" />
      <path d="M256 154h88c24 0 44 20 44 44v6c-26-22-62-30-88-30s-62 8-88 30v-6c0-24 20-44 44-44Z" fill="#e1e8f3" />
      <rect x="212" y="154" width="176" height="164" rx="44" {...RIM} />
      <rect x="234" y="196" width="132" height="64" rx="32" fill="#070b18" />
      <rect x="250" y="212" width="42" height="30" rx="15" fill="#ff5d5d" opacity=".28" />
      <rect x="308" y="212" width="42" height="30" rx="15" fill="#ff5d5d" opacity=".28" />
      <g className="th-blink">
        <rect x="258" y="218" width="26" height="18" rx="9" fill="#ff6b6b" />
        <rect x="316" y="218" width="26" height="18" rx="9" fill="#ff6b6b" />
      </g>
      <rect x="268" y="282" width="64" height="12" rx="6" fill="#8fa3c4" />
      <path d="M284 282v12M300 282v12M316 282v12" stroke="#c7d3e6" strokeWidth="2.5" />
      <Laptop>
        {/* records leaving */}
        <path d="M-40-30h30l12 12v40h-42Z" fill="#1b2747" />
        <path d="M-30-12h22M-30-2h22M-30 8h16" stroke="#e6ecf5" strokeWidth="3.5" strokeLinecap="round" />
        <path d="M8 2h30M28-10l12 12-12 12" fill="none" stroke="#e5484d" strokeWidth="7" strokeLinecap="round" strokeLinejoin="round" />
      </Laptop>
    </>
  );
}

/* the four systems on the target screen: mail, payments, records, cloud */
const TILES = [
  { x: 254, d: 'M-8-5h16v11h-16Z M-8-5 0 1 8-5' },
  { x: 298, d: 'M-9-6h18v12h-18Z M-9-2h18 M-5 3h4' },
  { x: 342, d: 'M-8-7c0-2 16-2 16 0v13c0 2-16 2-16 0Z M-8-7c0 2 16 2 16 0 M-8-1c0 2 16 2 16 0' },
  { x: 386, d: 'M-9 5h17a4.5 4.5 0 0 0-1-9 6 6 0 0 0-11.5 1.5A3.8 3.8 0 0 0-9 5Z' },
];

/* the mark and its ring, drawn for the dust to settle into */
function MarkShape() {
  return (
    <>
      <circle cx={ORB.x} cy={ORB.y} r="98" fill="none" stroke="#2fbaf5" strokeWidth="5" />
      <g transform={markAt}>{MARK.map(([fill, d]) => <path key={fill} d={d} fill={fill} />)}</g>
    </>
  );
}

const NODE_ICON = {
  people: <><circle cx="0" cy="-4" r="5.5" /><path d="M-10 10c1.2-5.5 5-8.5 10-8.5s8.8 3 10 8.5" /></>,
  machine: <><rect x="-10" y="-8" width="20" height="16" rx="3" /><path d="M-5-3h10M-5 2h6" /></>,
  agent: <><rect x="-9" y="-6" width="18" height="14" rx="4" /><path d="M0-6v-5M-4 1h.01M4 1h.01" /></>,
};

/* draw markup onto a canvas and read it back as grains of its own colours */
function rasterise(markup, w, h, step, done) {
  const img = new Image();
  img.onload = () => {
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    const g = c.getContext('2d');
    g.drawImage(img, 0, 0);
    const px = g.getImageData(0, 0, w, h).data;
    const byColour = new Map(); // grouped by colour, so each colour is one fillStyle
    const all = [];
    for (let y = 0; y < h; y += step) {
      for (let x = 0; x < w; x += step) {
        // the most opaque pixel of the cell stands for it, so soft edges
        // become grains too and no outline stays behind
        let o = (y * w + x) * 4;
        for (const [dx, dy] of [[1, 0], [0, 1], [1, 1]]) {
          const q = (Math.min(h - 1, y + dy) * w + Math.min(w - 1, x + dx)) * 4;
          if (px[q + 3] > px[o + 3]) o = q;
        }
        if (px[o + 3] < 8) continue;
        const key = `${px[o] & 0xf8},${px[o + 1] & 0xf8},${px[o + 2] & 0xf8}`;
        if (!byColour.has(key)) byColour.set(key, []);
        byColour.get(key).push(x, y, Math.random(), Math.random(), Math.random(), Math.random());
        all.push(x, y, key);
      }
    }
    const sets = [...byColour].map(([k, list]) => ({ fill: `rgb(${k.split(',').join(' ')})`, g: new Float32Array(list) }));
    done({ sets, picture: c, all });
  };
  img.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${VW} ${VH}">${markup}</svg>`)}`;
}

export default function ThreatHero() {
  const ref = useRef(null);
  const svg = useRef(null);
  const figs = useRef(null);
  const shape = useRef(null);
  const canvas = useRef(null);
  const seen = useInView(ref, { threshold: 0.2 });
  const reduce = useReducedMotion();
  const [paused, setPaused] = useState(false);
  const [run, setRun] = useState(0); // bumped to play it again
  const [phase, setPhase] = useState('in'); // without scripts, CSS shows the resting picture instead
  const clock = useRef({ t: 0, last: 0 });
  const grains = useRef(null);
  const [ready, setReady] = useState(false);

  // the two figures and the record become grains, once
  useEffect(() => {
    if (reduce) return undefined;
    let live = true;
    const box = svg.current.getBoundingClientRect();
    const w = Math.max(320, Math.round(box.width)), h = Math.round(w * (VH / VW));
    const step = 2;
    const out = { w, h, step };
    let left = 2;
    const finish = () => {
      left -= 1;
      if (left || !live) return;
      // every grain that gathers gets a place in the record; the rest blow out
      const targets = out.shape.all;
      const nT = targets.length / 3;
      const A = out.figs;
      const total = A.sets.reduce((n, s) => n + s.g.length / 6, 0);
      const every = Math.max(1, Math.round(total / (nT * 1.2)));
      let i = 0;
      A.homes = A.sets.map(({ g }) => {
        const home = new Float32Array((g.length / 6) * 3).fill(-1);
        for (let o = 0, j = 0; o < g.length; o += 6, j += 3) {
          i += 1;
          if (i % every) continue;
          const ti = Math.floor(g[o + 5] * nT) * 3;
          home[j] = targets[ti]; home[j + 1] = targets[ti + 1];
          const [r, gg, b] = targets[ti + 2].split(',').map(Number);
          home[j + 2] = (r << 16) | (gg << 8) | b; // the colour of the place it lands in
        }
        return home;
      });
      grains.current = out;
      setReady(true);
    };
    rasterise(figs.current.innerHTML, w, h, step, (res) => { out.figs = res; finish(); });
    rasterise(shape.current.innerHTML, w, h, step, (res) => { out.shape = res; finish(); });
    return () => { live = false; };
  }, [reduce]);

  useEffect(() => {
    if (reduce) { setPhase('done'); return undefined; }
    const c = clock.current;
    if (c.t >= T.done) { setPhase('done'); return undefined; } // it has played; rest
    if (!seen || paused) return undefined;
    const cv = canvas.current;
    const ctx = cv.getContext('2d');
    let raf = 0;
    c.last = performance.now();
    const size = () => {
      const r = cv.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      cv.width = Math.round(r.width * dpr); cv.height = Math.round(r.height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    size();
    const hex = (n) => `#${n.toString(16).padStart(6, '0')}`;

    const draw = (t) => {
      const r = cv.getBoundingClientRect();
      ctx.clearRect(0, 0, r.width, r.height);
      const G = grains.current;
      if (!G || t < T.dust || t > T.record + 900) return;
      const A = G.figs;
      const k = r.width / G.w;
      const sx = G.w / VW, sy = G.h / VH;
      const mid = G.w / 2;
      const s0 = G.step * 1.6;
      // a grain leaves when the wave reaches it: each figure comes apart from
      // its outer side inwards, with a little scatter
      const leaves = (x0, y0, r1) => T.dust + ((1 - Math.abs(x0 - mid) / mid) * 0.62 + (y0 / G.h) * 0.28 + r1 * 0.1) * T.sweep;
      if (t < T.dust + T.sweep + 100) {
        ctx.drawImage(A.picture, 0, 0, G.w * k, G.h * k);
        ctx.globalCompositeOperation = 'destination-out';
        ctx.fillStyle = '#000';
        for (const { g } of A.sets) {
          for (let o = 0; o < g.length; o += 6) {
            if (t >= leaves(g[o], g[o + 1], g[o + 2])) ctx.fillRect((g[o] - 0.3) * k, (g[o + 1] - 0.3) * k, s0 * k, s0 * k);
          }
        }
        ctx.globalCompositeOperation = 'source-over';
      }
      // the grains fade as the sharp record takes over
      ctx.globalAlpha = t > T.record ? Math.max(0, 1 - (t - T.record) / 700) : 1;
      const late = new Map();
      A.sets.forEach(({ fill, g }, si) => {
        const home = A.homes[si];
        ctx.fillStyle = fill;
        for (let o = 0, j = 0; o < g.length; o += 6, j += 3) {
          const x0 = g[o], y0 = g[o + 1], r2 = g[o + 3], r3 = g[o + 4];
          const v = (t - leaves(x0, y0, g[o + 2])) / FLY;
          if (v <= 0) continue;
          const gathers = home[j] >= 0;
          if (!gathers && v >= 1) continue;
          const f = Math.min(v, 1);
          const e = 0.3 * f + 0.7 * f * f; // a push at once, then the wind takes it
          const out = x0 < mid ? -1 : 1; // away from the middle first
          let x = x0 - 0.3 + out * (40 + 150 * r2) * e * sx + Math.sin(f * 6 + r3 * 6) * 6 * f;
          let y = y0 - 0.3 - (30 + 120 * r3) * e * sy;
          let s = s0 * (1 - f * 0.8);
          if (gathers && v > TURN) {
            // turn home, into the record
            const p = Math.min(1, ((v - TURN) * FLY) / GATHER);
            const q = p < 0.5 ? 2 * p * p : 1 - ((-2 * p + 2) ** 2) / 2;
            x += (home[j] - x) * q; y += (home[j + 1] - y) * q;
            s = s0 * (0.45 + 0.55 * q);
            if (q > 0.4) {
              const key = home[j + 2];
              if (!late.has(key)) late.set(key, []);
              late.get(key).push(x, y, s);
              continue;
            }
          }
          ctx.fillRect(x * k, y * k, s * k, s * k);
        }
      });
      late.forEach((l, key) => {
        ctx.fillStyle = hex(key);
        for (let o = 0; o < l.length; o += 3) ctx.fillRect(l[o] * k, l[o + 1] * k, l[o + 2] * k, l[o + 2] * k);
      });
      ctx.globalAlpha = 1;
    };

    const loop = (now) => {
      c.t += Math.min(64, now - c.last);
      c.last = now;
      setPhase(phaseAt(c.t));
      draw(c.t);
      if (c.t >= T.done) return; // rest on the last picture; the notes keep floating in CSS
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    const vis = () => {
      if (document.hidden) cancelAnimationFrame(raf);
      else if (c.t < T.done) { c.last = performance.now(); raf = requestAnimationFrame(loop); }
    };
    document.addEventListener('visibilitychange', vis);
    window.addEventListener('resize', size);
    return () => { cancelAnimationFrame(raf); document.removeEventListener('visibilitychange', vis); window.removeEventListener('resize', size); };
  }, [seen, paused, reduce, run]);

  const replay = () => { clock.current.t = 0; setPaused(false); setPhase('in'); setRun((n) => n + 1); };
  const after = AFTER.includes(phase);
  const showFigs = !after && !(ready && phase === 'dust');
  const attack = ['alert', 'claim', 'scan'].includes(phase);
  const blocked = phase === 'verdict' || phase === 'dust';
  const safe = blocked || after;
  const status = (f) => (blocked ? f.verdict : phase === 'scan' ? 'Checking…' : phase === 'claim' ? f.claim : '');
  const pct = (v, of) => `${(v / of) * 100}%`;
  return (
    <figure ref={ref} data-phase={phase} className="th relative mx-auto w-full max-w-[640px] lg:mr-0" aria-label="Animation: an attacker in a hood and a rogue AI agent sit at one desk, working against your business together. The attacker signs in with a stolen password; the agent pulls records its task does not allow. Both are checked and stopped, both turn to dust, and the dust gathers into the Deep Algorithms mark inside a shield ring that holds people, machine identities and AI agents, each checked. Two attacks stopped; business as usual.">
      <div className="relative">
      <svg ref={svg} viewBox={`0 0 ${VW} ${VH}`} className="relative block h-auto w-full overflow-visible" aria-hidden="true">
        <defs>
          <radialGradient id="th-halo" cx="50%" cy="50%" r="50%"><stop offset="0" stopColor="#2fbaf5" stopOpacity=".28" /><stop offset=".55" stopColor="#0067ab" stopOpacity=".12" /><stop offset="1" stopColor="#0067ab" stopOpacity="0" /></radialGradient>
          <radialGradient id="th-floor" cx="50%" cy="50%" r="50%"><stop offset="0" stopColor="#4f9dff" stopOpacity=".22" /><stop offset="1" stopColor="#4f9dff" stopOpacity="0" /></radialGradient>
          <linearGradient id="th-beam" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#4f9dff" stopOpacity="0" /><stop offset="1" stopColor="#4f9dff" stopOpacity=".28" /></linearGradient>
          <linearGradient id="th-desk" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#2a3c6c" /><stop offset="1" stopColor="#17244a" /></linearGradient>
        </defs>

        {/* the target: your business, its systems on one screen */}
        <g className={cx('th-target', attack && 'hit', safe && 'safe', after && 'gone')}>
          <rect x={SCREEN.x} y={SCREEN.y} width={SCREEN.w} height={SCREEN.h} rx="14" fill="#0b1a3a" stroke="rgb(124 196 255 / .35)" strokeWidth="1.5" />
          <path d={`M${SCREEN.x} ${SCREEN.y + 26}h${SCREEN.w}`} stroke="rgb(124 196 255 / .2)" />
          {[0, 1, 2].map((i) => <circle key={i} cx={SCREEN.x + 16 + i * 12} cy={SCREEN.y + 13} r="3.5" fill="rgb(124 196 255 / .35)" />)}
          <text x={SCREEN.x + SCREEN.w - 14} y={SCREEN.y + 17.5} textAnchor="end" fill="#9fb3d6" fontSize="11" fontWeight="600" letterSpacing=".06em">YOUR BUSINESS</text>
          {TILES.map((tl, i) => (
            <g key={i} transform={`translate(${tl.x} ${SCREEN.y + 66})`}>
              <rect x="-20" y="-20" width="40" height="40" rx="11" className="th-tile" style={{ animationDelay: `${i * 0.18}s` }} />
              <path d={tl.d} fill="none" stroke="#dbe6f7" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
            </g>
          ))}
          <g transform={`translate(${SCREEN.x + SCREEN.w / 2} ${SCREEN.y + 122})`}>
            <rect x="-62" y="-14" width="124" height="28" rx="14" className="th-state" />
            <text y="4.5" textAnchor="middle" fontSize="12.5" fontWeight="600" className="th-state-t">{safe ? 'Protected' : attack ? 'Under attack' : 'Online'}</text>
          </g>
        </g>

        {/* what each of them pulls from it */}
        {FIGS.map((f) => {
          const l = LAP(f.x);
          return <path key={f.id} d={`M${SCREEN.x + SCREEN.w / 2} ${SCREEN.y + SCREEN.h} C${SCREEN.x + SCREEN.w / 2} ${SCREEN.y + SCREEN.h + 70}, ${l.x} ${l.y - 150}, ${l.x} ${l.y - 64}`} className={cx('th-flow', attack && 'on', blocked && 'cut')} fill="none" strokeWidth="2.5" strokeLinecap="round" />;
        })}

        {/* one desk */}
        <g className={cx('th-desk', after && 'gone')}>
        <ellipse cx={VW / 2} cy={DESK + 12} rx="300" ry="50" fill="url(#th-floor)" />
        <rect x="40" y={DESK} width={VW - 80} height="14" rx="7" fill="url(#th-desk)" />
        <rect x="40" y={DESK} width={VW - 80} height="14" rx="7" fill="none" stroke="rgb(124 196 255 / .25)" />
        <path d={`M86 ${DESK + 14}v42M${VW - 86} ${DESK + 14}v42`} stroke="#17244a" strokeWidth="8" strokeLinecap="round" />
        </g>

        {/* the two of them, side by side */}
        <g ref={figs} className={cx('th-art', showFigs && 'on')}>
          <g transform={place(FIGS[0].x)}><Attacker /></g>
          <g transform={place(FIGS[1].x)}><Agent /></g>
        </g>

        {/* what each one is after */}
        <g className={cx('th-pop', attack && 'on')} style={{ transformOrigin: '84px 262px' }}>
          <path d="M60 240a34 34 0 1 1 22 61l-19 12 4-18a34 34 0 0 1-7-55Z" fill="#e5484d" />
          <g transform="translate(84 267) scale(.74)" fill="#fff">
            <path d="M0-24c-14 0-22 10-22 21 0 7 3 12 8 15v7h28v-7c5-3 8-8 8-15 0-11-8-21-22-21Z" />
            <circle cx="-8" cy="-3" r="5.5" fill="#e5484d" /><circle cx="8" cy="-3" r="5.5" fill="#e5484d" />
            <path d="M-30 26 30 40M30 26-30 40" stroke="#fff" strokeWidth="6" strokeLinecap="round" />
          </g>
        </g>
        <g className={cx('th-pop', attack && 'on')} style={{ transformOrigin: '556px 262px', transitionDelay: attack ? '.15s' : '0s' }}>
          <path d="M580 240a34 34 0 1 0-22 61l19 12-4-18a34 34 0 0 0 7-55Z" fill="#e5484d" />
          <g transform="translate(554 266) scale(.8)">
            <path d="M-22-26h22l10 10v36h-32Z" fill="#fff" />
            <path d="M-15-10h16M-15-1h16M-15 8h10" stroke="#e5484d" strokeWidth="3" strokeLinecap="round" />
            <path d="M14 0h14M21-8l8 8-8 8" fill="none" stroke="#fff" strokeWidth="4.5" strokeLinecap="round" strokeLinejoin="round" />
          </g>
        </g>

        {/* the check runs over both */}
        <g className={cx('th-scan', phase === 'scan' && 'on')}>
          <rect x="60" y="208" width="520" height="28" fill="url(#th-beam)" />
          <rect x="60" y="234" width="520" height="3" rx="1.5" fill="#7fd0ff" />
        </g>

        {/* both stopped */}
        {FIGS.map((f, i) => (
          <g key={f.id} className={cx('th-pop', blocked && 'on')} style={{ transformOrigin: `${f.x + 62}px 262px`, transitionDelay: blocked ? `${i * 0.18}s` : '0s' }}>
            <circle cx={f.x + 62} cy="262" r="22" fill="#1a0b14" />
            <circle cx={f.x + 62} cy="262" r="22" fill="none" stroke="#ff5d5d" strokeWidth="3" />
            <path d={`M${f.x + 54} 254l16 16M${f.x + 70} 254l-16 16`} stroke="#ff5d5d" strokeWidth="5" strokeLinecap="round" />
          </g>
        ))}

        {/* the ending: every kind of identity, inside one shield, around the mark */}
        <g className={cx('th-end', after && 'on')}>
          <circle cx={ORB.x} cy={ORB.y} r={ORB.r + 40} fill="url(#th-halo)" />
          <circle className="th-spin" cx={ORB.x} cy={ORB.y} r={ORB.r} fill="none" stroke="rgb(124 196 255 / .38)" strokeWidth="1.5" strokeDasharray="2 9" strokeLinecap="round" />
          <circle cx={ORB.x} cy={ORB.y} r="98" fill="rgb(10 32 72 / .55)" stroke="#2fbaf5" strokeOpacity=".75" strokeWidth="2" />
          <circle className="th-pulse" cx={ORB.x} cy={ORB.y} r="98" fill="none" stroke="#2fbaf5" strokeWidth="2" />
          <g transform={markAt}>{MARK.map(([fill, d]) => <path key={fill} d={d} fill={fill} />)}</g>
          {NODES.map((n, i) => (
            <g key={n.k} className="th-node" style={{ '--d': `${0.25 + i * 0.2}s`, transformOrigin: `${n.x}px ${n.y}px` }}>
              <path d={`M${ORB.x + 98 * Math.cos((n.a * Math.PI) / 180)} ${ORB.y + 98 * Math.sin((n.a * Math.PI) / 180)}L${n.x} ${n.y}`} stroke="rgb(124 196 255 / .35)" strokeWidth="1.5" />
              <circle cx={n.x} cy={n.y} r="27" fill="#0d2a5a" stroke="#4fb3ff" strokeWidth="2" />
              <g transform={`translate(${n.x} ${n.y})`} fill="none" stroke="#cfe6ff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">{NODE_ICON[n.k]}</g>
              <circle cx={n.x + 19} cy={n.y - 19} r="9" fill="#1f9d63" stroke="#071733" strokeWidth="2" />
              <path d={`M${n.x + 15} ${n.y - 19}l2.8 2.8 5-5`} fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </g>
          ))}
          <circle r="4.5" fill="#7fd0ff" className="th-orbit-dot"><animateMotion dur="9s" repeatCount="indefinite" path={`M${ORB.x} ${ORB.y - ORB.r}a${ORB.r} ${ORB.r} 0 1 1 -0.1 0`} /></circle>
        </g>

        {/* the shape the dust settles into (never shown; read once as pixels) */}
        <g ref={shape} className="th-sil"><MarkShape /></g>
      </svg>
      <canvas ref={canvas} aria-hidden="true" className="pointer-events-none absolute inset-0 h-full w-full" />

      {/* under each figure, what is happening to it */}
      {FIGS.map((f) => {
        const s = status(f);
        return (
          <p key={f.id} aria-hidden="true" className={cx('th-status absolute bottom-[2%] flex w-max max-w-[48%] -translate-x-1/2 items-center gap-2 rounded-full border border-white/15 bg-[#081633]/90 py-1.5 pl-2.5 pr-3 text-[13px] font-medium text-white max-sm:text-[10.5px] max-sm:pl-2 max-sm:pr-2.5', (!s || after) && 'hide')} style={{ left: pct(f.x, VW) }}>
            <span className={cx('h-2 w-2 shrink-0 rounded-full', blocked ? 'bg-[#ff5d5d] shadow-[0_0_10px_#ff5d5d]' : phase === 'scan' ? 'animate-pulse bg-[#4fb3ff]' : 'bg-[#f5a524]')} />
            <span className="truncate">{s || ' '}</span>
          </p>
        );
      })}

      {/* the three kinds of identity, named */}
      {NODES.map((n, i) => (
        <span key={n.k} aria-hidden="true" className={cx('th-label absolute -translate-x-1/2 whitespace-nowrap rounded-full border border-white/15 bg-[#0a1a3a]/90 px-3 py-1 text-[13px] font-semibold text-white max-sm:px-2 max-sm:text-[10px]', after && 'on')}
          style={{ left: pct(n.x, VW), top: pct(n.y + (n.a < 0 ? -58 : 34), VH), '--d': `${0.45 + i * 0.2}s` }}>{n.label}</span>
      ))}
      </div>

      {/* the line it ends on */}
      <div aria-hidden="true" className={cx('th-claim absolute inset-x-0 bottom-[3%] text-center max-sm:static max-sm:mt-2', (phase === 'notes' || phase === 'done') && 'on')}>
        <p className="font-semibold tracking-[-0.02em] text-white" style={{ fontSize: 'clamp(18px, 1.9vw, 26px)' }}>2 attacks stopped. <span className="text-[#7fe0ae]">Business as usual.</span></p>
        <p className="mt-1 text-[13.5px] text-white/60 max-sm:text-[12px]">Every person, machine identity and AI agent, with every decision explained.</p>
      </div>

      {!reduce && (phase === 'done'
        ? <button type="button" onClick={replay} className="th-ctl absolute right-0 top-0 inline-flex h-8 items-center gap-1.5 rounded-full border border-white/20 bg-[#0b1d40] px-3 text-[12.5px] font-medium text-white/80 hover:text-white" aria-label="Play the animation again">
            <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M2.5 8a5.5 5.5 0 1 0 1.7-4" /><path d="M2.5 2.5V6H6" /></svg>Replay
          </button>
        : <button type="button" onClick={() => setPaused(!paused)} className="th-ctl absolute right-0 top-0 inline-flex h-8 w-8 items-center justify-center rounded-full border border-white/20 bg-[#0b1d40] text-white/80 hover:text-white" aria-label={paused ? 'Play the animation' : 'Pause the animation'}>
            {paused ? <svg width="12" height="12" viewBox="0 0 12 12" aria-hidden="true"><path d="M3 1.5v9l7.5-4.5z" fill="currentColor" /></svg> : <svg width="12" height="12" viewBox="0 0 12 12" aria-hidden="true"><path d="M3 1.5h2v9H3zM7 1.5h2v9H7z" fill="currentColor" /></svg>}
          </button>)}
    </figure>
  );
}
