import { useEffect, useRef, useState } from 'react';
import { useReducedMotion } from '../lib/motion.js';

/* The answer to "why identity, why now", said by our mark. When it comes into
   view the mark rises to the middle of the page, opens into a brand-blue plate
   while the question types out across it, then folds back into the mark and
   the answer slides out from behind it. It plays once and stays (no scroll
   lock); the prerendered HTML and reduced motion show the finished line. */

const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
const P = (t, a, b) => clamp((t - a) / (b - a));
const ss = (x) => x * x * (3 - 2 * x);
const eo = (x) => 1 - (1 - x) ** 3;
const eb = (x) => (x <= 0 ? 0 : x >= 1 ? 1 : 1 + 2.70158 * (x - 1) ** 3 + 1.70158 * (x - 1) ** 2);
const lerp = (a, b, k) => a + (b - a) * k;

const ASK = 'So how do you stop an attacker who simply logs in?';
// in seconds: rise, open, type, fold (the plate goes back into the mark), home (the mark
// moves to its place in the line), answer, detail
const T = { rise: 0, riseEnd: 0.75, open: 0.9, openEnd: 1.6, type: 1.55, typeEnd: 2.9, fold: 3.3, foldEnd: 3.85, home: 3.8, homeEnd: 4.45, say: 3.95, sayEnd: 4.75, sub: 4.6, subEnd: 5.2 };
const DONE = 6;

export default function LogoStatement() {
  const stage = useRef(null);
  const tile = useRef(null);
  const reduce = useReducedMotion();
  const [t, setT] = useState(DONE);
  const [m, setM] = useState({ dx: 0, dy: 0, w: 1000, ts: 112, col: false });

  // where the mark sits in the finished line, so it can start from the middle
  useEffect(() => {
    const s = stage.current, k = tile.current;
    const measure = () => setM({
      dx: s.clientWidth / 2 - (k.offsetLeft + k.offsetWidth / 2),
      dy: s.clientHeight / 2 - (k.offsetTop + k.offsetHeight / 2),
      w: s.clientWidth, ts: k.offsetWidth, col: window.matchMedia('(max-width: 767px)').matches,
    });
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(s);
    return () => ro.disconnect();
  }, []);

  // play once, while on screen
  useEffect(() => {
    if (reduce) { setT(DONE); return undefined; }
    const el = stage.current;
    let raf = 0, visible = false, acc = 0, last = 0, cur = 0;
    setT(0);
    const tick = (now) => {
      const dt = Math.min(0.1, (now - last) / 1000); last = now;
      cur += dt; acc += dt;
      if (cur >= DONE) { setT(DONE); raf = 0; io.disconnect(); return; }
      if (acc >= 1 / 50) { acc = 0; setT(cur); }
      if (visible) raf = requestAnimationFrame(tick);
    };
    const io = new IntersectionObserver(([e]) => {
      visible = e.isIntersecting;
      if (visible && !raf) { last = performance.now(); raf = requestAnimationFrame(tick); }
      if (!visible) { cancelAnimationFrame(raf); raf = 0; }
    }, { threshold: 0.5 });
    io.observe(el);
    return () => { io.disconnect(); cancelAnimationFrame(raf); };
  }, [reduce]);

  const rise = P(t, T.rise, T.riseEnd);
  const open = eo(P(t, T.open, T.openEnd)), fold = ss(P(t, T.fold, T.foldEnd));
  const k = open * (1 - fold);
  // the mark: rises small, sits in the plate smaller still, then grows into its place
  const base = lerp(0.74, 0.6, open);
  const scale = (base + (1 - base) * fold) * lerp(0.82, 1, eb(rise));
  const home = ss(P(t, T.home, T.homeEnd));
  const tx = m.dx * (1 - home), ty = m.dy * (1 - home) + (1 - eo(rise)) * 90;
  const plateH = m.col ? 300 : 360, closed = m.ts * scale;
  const typed = Math.round(ASK.length * P(t, T.type, T.typeEnd));
  const say = eo(P(t, T.say, T.sayEnd)), sub = eo(P(t, T.sub, T.subEnd));

  return (
    <div ref={stage} className="relative mx-auto flex min-h-[400px] max-w-[1200px] items-center justify-center md:min-h-[420px]">
      {k > 0.002 && (
        <div aria-hidden="true" className="plate pointer-events-none absolute left-1/2 top-1/2 z-[1] overflow-hidden"
          style={{ width: lerp(closed, m.w, k), height: lerp(closed, plateH, k), borderRadius: lerp(closed * 0.23, 28, k), transform: 'translate(-50%, -50%)' }}>
          <p className="mono absolute inset-x-0 top-7 mx-auto max-w-[90%] text-center text-[13px] leading-relaxed text-white/80 md:text-[14px]" style={{ opacity: ss(P(k, 0.6, 1)) }}>
            {ASK.slice(0, typed)}<span className="caret" />
          </p>
        </div>
      )}
      <div className="flex items-center gap-8 max-md:flex-col max-md:gap-6 max-md:text-center md:gap-10">
        <div ref={tile} className="relative z-[2] h-[84px] w-[84px] shrink-0 md:h-[112px] md:w-[112px]"
          style={{ opacity: ss(P(t, 0, 0.3)), transform: `translate(${tx.toFixed(1)}px, ${ty.toFixed(1)}px) scale(${scale.toFixed(3)})` }}>
          <div className="flex h-full w-full items-center justify-center rounded-[23%] border border-[#e3e8ee] bg-white shadow-[0_14px_34px_-14px_rgb(6_47_87/.35)]">
            <img src="/brand/mark.webp" alt="" width="64" height="64" className="h-[58%] w-[58%] object-contain" />
          </div>
        </div>
        <div className="max-w-[880px]">
          <p className="mono text-[13.5px] text-ink-3 md:text-[14.5px]" style={{ opacity: say }}>{ASK}</p>
          <h2 id="say-h" className="mt-4 font-semibold text-ink"
            style={{ fontSize: 'clamp(34px, 4.6vw, 62px)', lineHeight: 1.04, letterSpacing: '-0.035em', opacity: say, clipPath: m.col ? undefined : `inset(-10% ${((1 - say) * 100).toFixed(1)}% -10% 0)`, transform: m.col ? `translateY(${((1 - say) * -24).toFixed(1)}px)` : `translateX(${((1 - say) * -48).toFixed(1)}px)` }}>
            <span className="md:block">A stolen login looks right. </span>It doesn’t <em className="pr-[.06em] font-semibold italic text-cyan-2">act</em> right.
          </h2>
          <p className="t-lead mt-5 max-w-[620px] max-md:mx-auto" style={{ opacity: sub, transform: `translateY(${((1 - sub) * 12).toFixed(1)}px)` }}>
            Deep Algorithms learns how every person, machine and AI agent behaves, and stops the impostor before it acts: at the login, the API, the agent’s next step and the data.
          </p>
        </div>
      </div>
    </div>
  );
}
