import { useEffect, useRef, useState } from 'react';
import { useInView, useReducedMotion, cx } from '../lib/motion.js';
import ProductMark from './ProductMark.jsx';

/* The home hero, in one picture: an attacker in a hood signs in with someone
   else's password. adapID AI reads him, blocks him, and he turns to dust and
   blows away. Then the desk is empty and the account is safe, and it plays
   again. The illustration is our own (flat vector, drawn for this page); the
   dust is made from its own pixels, so what blows away is the figure itself. */

const T = { code: 300, alert: 700, signin: 1100, scan: 3000, scanEnd: 4200, blocked: 4200, dust: 5000, dustEnd: 8300, safe: 8500, back: 10500, end: 11300 };
const DUST_MS = 1100; // how long one grain takes to blow away

function phaseAt(t) {
  if (t >= T.back) return 'back';
  if (t >= T.safe) return 'safe';
  if (t >= T.dust) return 'dust';
  if (t >= T.blocked) return 'blocked';
  if (t >= T.scan) return 'scan';
  if (t >= T.signin) return 'signin';
  return 'start';
}

/* The attacker and his laptop: everything that turns to dust. Plain fills (no
   classes) so the same markup can be drawn onto a canvas. */
function Attacker() {
  return (
    <>
      {/* hoodie */}
      <path d="M150 468C158 390 214 350 300 348c86 2 142 42 150 120Z" fill="#1d2747" />
      <path d="M300 348c-30 1-56 6-78 15l20 105h116l20-105c-22-9-48-14-78-15Z" fill="#232f55" />
      {/* hood */}
      <path d="M300 116c-66 0-108 54-112 122-3 46 4 78 16 102h192c12-24 19-56 16-102-4-68-46-122-112-122Z" fill="#263256" />
      <path d="M300 116c-66 0-108 54-112 122-1 20 0 37 2 52 10-74 50-128 110-128s100 54 110 128c2-15 3-32 2-52-4-68-46-122-112-122Z" fill="#2f3c66" />
      {/* the dark inside of the hood, and the face in it */}
      <path d="M300 166c-42 0-70 36-72 82-1 36 16 70 40 86h64c24-16 41-50 40-86-2-46-30-82-72-82Z" fill="#0c1124" />
      <path d="M300 194c-32 0-50 26-50 60 0 38 22 66 50 66s50-28 50-66c0-34-18-60-50-60Z" fill="#d79a74" />
      <path d="M250 254c0-34 18-60 50-60s50 26 50 60c-16-22-32-30-50-30s-34 8-50 30Z" fill="#0c1124" opacity=".88" />
      {/* the mask, and his eyes */}
      <path d="M252 240c30-9 66-9 96 0l2 24c-32 9-68 9-100 0Z" fill="#0b0f1c" />
      <g className="ah-eyes">
        <path d="M266 249l25 5-2 8-21-3Z" fill="#fff" />
        <path d="M334 249l-25 5 2 8 21-3Z" fill="#fff" />
      </g>
      {/* drawstrings */}
      <path d="M283 336l-4 52M317 336l4 52" stroke="#c6d1e4" strokeWidth="3.5" strokeLinecap="round" />
      <circle cx="279" cy="391" r="4.5" fill="#c6d1e4" />
      <circle cx="321" cy="391" r="4.5" fill="#c6d1e4" />
      {/* laptop, lid towards us, with a skull on it */}
      <rect x="188" y="372" width="224" height="146" rx="14" fill="#e9eef6" />
      <rect x="188" y="372" width="224" height="146" rx="14" fill="none" stroke="#cdd7e7" strokeWidth="2" />
      <g transform="translate(300 446)">
        <path d="M-38-30 38 30M38-30-38 30" stroke="#1d2747" strokeWidth="10" strokeLinecap="round" />
        <circle cx="-41" cy="-33" r="7" fill="#1d2747" /><circle cx="-33" cy="-41" r="7" fill="#1d2747" />
        <circle cx="41" cy="-33" r="7" fill="#1d2747" /><circle cx="33" cy="-41" r="7" fill="#1d2747" />
        <circle cx="-41" cy="33" r="7" fill="#1d2747" /><circle cx="-33" cy="41" r="7" fill="#1d2747" />
        <circle cx="41" cy="33" r="7" fill="#1d2747" /><circle cx="33" cy="41" r="7" fill="#1d2747" />
        <path d="M0-30c-18 0-28 12-28 27 0 9 4 15 10 19v9h36v-9c6-4 10-10 10-19 0-15-10-27-28-27Z" fill="#1d2747" />
        <circle cx="-10" cy="-4" r="7" fill="#e9eef6" /><circle cx="10" cy="-4" r="7" fill="#e9eef6" />
        <path d="M0 5l-4 7h8Z" fill="#e9eef6" />
        <path d="M-8 18v7M0 18v7M8 18v7" stroke="#e9eef6" strokeWidth="2.4" />
      </g>
      <rect x="156" y="512" width="288" height="12" rx="6" fill="#cdd7e7" />
    </>
  );
}

const CODE = [
  [70, 96, 70, '#a9bbf0'], [150, 96, 120, '#c9d5f6'], [70, 120, 46, '#ef8b86'], [126, 120, 150, '#c9d5f6'],
  [70, 144, 96, '#c9d5f6'], [176, 144, 54, '#a9bbf0'], [400, 110, 120, '#c9d5f6'], [400, 134, 70, '#a9bbf0'],
  [480, 134, 54, '#c9d5f6'], [430, 158, 100, '#c9d5f6'], [430, 182, 60, '#f3c27a'], [70, 300, 70, '#c9d5f6'],
  [470, 300, 64, '#c9d5f6'], [450, 324, 84, '#a9bbf0'],
];

export default function AttackerHero() {
  const ref = useRef(null);
  const svg = useRef(null);
  const art = useRef(null);
  const canvas = useRef(null);
  const seen = useInView(ref, { threshold: 0.2 });
  const reduce = useReducedMotion();
  const [paused, setPaused] = useState(false);
  const [phase, setPhase] = useState('blocked'); // the still picture, until the scene starts
  const clock = useRef({ t: 0, last: 0 });
  const grains = useRef(null);
  const [ready, setReady] = useState(false);

  // turn the drawn attacker into grains of his own colours, once
  useEffect(() => {
    if (reduce) return undefined;
    let live = true;
    const box = svg.current.getBoundingClientRect();
    const scale = box.width / 600;
    const w = Math.round(600 * scale), h = Math.round(560 * scale);
    const src = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 600 560">${art.current.outerHTML}</svg>`;
    const img = new Image();
    img.onload = () => {
      if (!live) return;
      const c = document.createElement('canvas');
      c.width = w; c.height = h;
      const g = c.getContext('2d');
      g.drawImage(img, 0, 0);
      const px = g.getImageData(0, 0, w, h).data;
      const step = 2;
      const byColour = new Map(); // grains grouped by colour, so each colour is one fillStyle
      for (let y = 0; y < h; y += step) {
        for (let x = 0; x < w; x += step) {
          // the most opaque pixel of the cell stands for it, so soft edges
          // become grains too and no outline stays behind
          let o = (y * w + x) * 4;
          for (const [dx, dy] of [[1, 0], [0, 1], [1, 1]]) {
            const q = (Math.min(h - 1, y + dy) * w + Math.min(w - 1, x + dx)) * 4;
            if (px[q + 3] > px[o + 3]) o = q;
          }
          if (px[o + 3] < 8) continue;
          const key = `${px[o] & 0xf8},${px[o + 1] & 0xf8},${px[o + 2] & 0xf8}`;
          if (!byColour.has(key)) byColour.set(key, []);
          byColour.get(key).push(x, y, Math.random(), Math.random(), Math.random());
        }
      }
      const sets = [...byColour].map(([k, list]) => ({ fill: `rgb(${k.split(',').map((v) => Math.min(255, +v + 4)).join(' ')})`, g: new Float32Array(list) }));
      grains.current = { sets, w, h, step, picture: c };
      setReady(true);
    };
    img.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(src)}`;
    return () => { live = false; };
  }, [reduce]);

  useEffect(() => {
    if (reduce) { setPhase('blocked'); return undefined; }
    if (!seen || paused) return undefined;
    const cv = canvas.current;
    const ctx = cv.getContext('2d');
    let raf = 0;
    const c = clock.current;
    c.last = performance.now();
    const size = () => {
      const r = cv.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      cv.width = Math.round(r.width * dpr); cv.height = Math.round(r.height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    size();

    const dust = (t) => {
      const r = cv.getBoundingClientRect();
      ctx.clearRect(0, 0, r.width, r.height);
      const G = grains.current;
      if (!G || t < T.dust || t > T.dustEnd + 200) return;
      const k = r.width / G.w;
      const { sets, step, picture } = G;
      // a grain leaves when the wave reaches it: it starts at his top right, the
      // side the wind blows to, and works across him, with some scatter
      const span = T.dustEnd - T.dust - DUST_MS;
      const leaves = (x0, y0, r1) => T.dust + ((1 - x0 / G.w) * 0.62 + (y0 / G.h) * 0.28 + r1 * 0.1) * span;
      const s0 = step * 1.6;
      // what is still there stays the crisp picture: draw it, then cut out
      // every grain that has already left
      ctx.drawImage(picture, 0, 0, G.w * k, G.h * k);
      ctx.globalCompositeOperation = 'destination-out';
      ctx.fillStyle = '#000';
      for (const { g } of sets) {
        for (let o = 0; o < g.length; o += 5) {
          if (t >= leaves(g[o], g[o + 1], g[o + 2])) ctx.fillRect((g[o] - 0.3) * k, (g[o + 1] - 0.3) * k, s0 * k, s0 * k);
        }
      }
      ctx.globalCompositeOperation = 'source-over';
      // and the grains that have left blow away, shrinking as they go
      for (const { fill, g } of sets) {
        ctx.fillStyle = fill;
        for (let o = 0; o < g.length; o += 5) {
          const x0 = g[o], y0 = g[o + 1], r2 = g[o + 3], r3 = g[o + 4];
          const v = (t - leaves(x0, y0, g[o + 2])) / DUST_MS;
          if (v <= 0 || v >= 1) continue;
          const e = 0.3 * v + 0.7 * v * v; // a push at once, then the wind takes it
          const x = x0 - 0.3 + (60 + 220 * r2) * e * (G.w / 600) + Math.sin(v * 6 + r3 * 6) * 6 * v;
          const y = y0 - 0.3 - (30 + 140 * r3) * e * (G.h / 560);
          const s = s0 * (1 - v * 0.8); // the same size as the hole it left, at first
          ctx.fillRect(x * k, y * k, s * k, s * k);
        }
      }
    };

    const loop = (now) => {
      c.t += Math.min(64, now - c.last);
      c.last = now;
      if (c.t >= T.end) c.t = 0;
      setPhase(phaseAt(c.t));
      dust(c.t);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    const vis = () => {
      if (document.hidden) cancelAnimationFrame(raf);
      else { c.last = performance.now(); raf = requestAnimationFrame(loop); }
    };
    document.addEventListener('visibilitychange', vis);
    window.addEventListener('resize', size);
    return () => { cancelAnimationFrame(raf); document.removeEventListener('visibilitychange', vis); window.removeEventListener('resize', size); };
  }, [seen, paused, reduce]);

  const gone = ready && (phase === 'dust' || phase === 'safe');
  const red = phase === 'blocked' || phase === 'dust';
  const threat = phase === 'start' || phase === 'signin' || phase === 'scan';
  return (
    <figure ref={ref} className={cx('ah relative mx-auto w-full max-w-[600px] lg:mr-0', `ah-${phase}`)} aria-label="Animation: an attacker in a hood signs in on his laptop with someone else's password and MFA. adapID AI checks how he behaves, finds it is not the account's owner and blocks him; he turns to dust and is gone, and the account is safe.">
      <div className="ah-card relative overflow-hidden rounded-[28px]">
        <svg ref={svg} viewBox="0 0 600 560" className="relative block h-auto w-full" aria-hidden="true">
          {/* code running behind him */}
          <g className="ah-code">
            {CODE.map(([x, y, w, c], i) => <rect key={i} x={x} y={y} width={w} height="10" rx="5" fill={c} style={{ animationDelay: `${i * 70}ms` }} />)}
          </g>
          <path d="M90 524h420" stroke="#cfd9ea" strokeWidth="3" strokeLinecap="round" />

          <g ref={art} className={cx('ah-art', gone && 'gone')}><Attacker /></g>

          {/* what he is: a skull alert and a warning */}
          <g className={cx('ah-pop', threat && 'on')} style={{ transformOrigin: '150px 178px' }}>
            <path d="M118 150a46 46 0 1 1 30 82l-26 16 6-24a46 46 0 0 1-10-74Z" fill="#e5484d" />
            <g transform="translate(150 182)" fill="#fff">
              <path d="M0-24c-14 0-22 10-22 21 0 7 3 12 8 15v7h28v-7c5-3 8-8 8-15 0-11-8-21-22-21Z" />
              <circle cx="-8" cy="-3" r="5.5" fill="#e5484d" /><circle cx="8" cy="-3" r="5.5" fill="#e5484d" />
              <path d="M-30 26 30 40M30 26-30 40" stroke="#fff" strokeWidth="6" strokeLinecap="round" />
            </g>
            <path d="M92 132l-12-10M104 120l-6-14M86 150l-15-4" stroke="#e5484d" strokeWidth="4" strokeLinecap="round" className="ah-ring" />
          </g>
          <g className={cx('ah-pop', threat && 'on')} style={{ transformOrigin: '456px 404px', transitionDelay: threat ? '.15s' : '0s' }}>
            <path d="M456 366c4 0 7 2 9 5l33 58c4 7-1 15-9 15h-66c-8 0-13-8-9-15l33-58c2-3 5-5 9-5Z" fill="#f5a524" />
            <rect x="452" y="386" width="8" height="30" rx="4" fill="#fff" />
            <circle cx="456" cy="428" r="5" fill="#fff" />
          </g>

          {/* adapID reads him */}
          <rect className={cx('ah-scan', phase === 'scan' && 'on')} x="150" y="110" width="300" height="4" rx="2" fill="#2f8bff" />

          {/* blocked, then safe */}
          <g className={cx('ah-pop', (phase === 'blocked' || phase === 'dust') && 'on')} style={{ transformOrigin: '440px 170px' }}>
            <circle cx="440" cy="170" r="44" fill="#fff" />
            <circle cx="440" cy="170" r="44" fill="none" stroke="#e5484d" strokeWidth="4" />
            <path d="M424 154l32 32M456 154l-32 32" stroke="#e5484d" strokeWidth="8" strokeLinecap="round" />
          </g>
          <g className={cx('ah-pop', phase === 'safe' && 'on')} style={{ transformOrigin: '300px 300px' }}>
            <path d="M300 214l70 26v52c0 46-30 80-70 96-40-16-70-50-70-96v-52Z" fill="#1f9d63" />
            <path d="M268 300l22 22 44-48" fill="none" stroke="#fff" strokeWidth="12" strokeLinecap="round" strokeLinejoin="round" />
          </g>
        </svg>
        <canvas ref={canvas} aria-hidden="true" className="pointer-events-none absolute inset-0 h-full w-full" />

        {/* one line of status, changing with the scene */}
        <p aria-hidden="true" className={cx('ah-toast absolute bottom-5 left-1/2 flex w-max max-w-[92%] -translate-x-1/2 items-center gap-2.5 rounded-full bg-white py-2 pl-2 pr-4 text-[14.5px] font-semibold text-[#0e1116] shadow-[0_18px_40px_-18px_rgba(10,30,70,.55)] max-sm:text-[12.5px]', (phase === 'start' || phase === 'back') && 'hide')}>
          <ProductMark p="adapid" size={26} />
          {red ? <span className="text-[#c4302b]">adapID AI: not the real user. Blocked.</span>
            : phase === 'safe' ? <span className="text-[#167a4c]">Attacker removed. The account is safe.</span>
              : phase === 'scan' ? <span>Password and MFA correct. Checking behaviour…</span>
                : <span>Sign-in as a finance analyst, 02:14</span>}
        </p>
      </div>

      {!reduce && (
        <button type="button" onClick={() => setPaused(!paused)} className="absolute right-4 top-4 inline-flex h-9 w-9 items-center justify-center rounded-full border border-[#0e1116]/10 bg-white/80 text-[#0e1116]/70 backdrop-blur hover:text-[#0e1116]" aria-label={paused ? 'Play the animation' : 'Pause the animation'}>
          {paused ? <svg width="12" height="12" viewBox="0 0 12 12" aria-hidden="true"><path d="M3 1.5v9l7.5-4.5z" fill="currentColor" /></svg> : <svg width="12" height="12" viewBox="0 0 12 12" aria-hidden="true"><path d="M3 1.5h2v9H3zM7 1.5h2v9H7z" fill="currentColor" /></svg>}
        </button>
      )}
    </figure>
  );
}
