import { useEffect, useRef, useState } from 'react';
import { useInView, useReducedMotion, cx } from '../lib/motion.js';
import { Logo } from './viz/kit.jsx';

/* The home hero picture: a real person at work, and what adapID AI checks
   about them, in one glance. Who they are (role, office, team) is confirmed,
   lines run to the apps they can reach, the two they use are kept and the one
   they have not opened in 90 days is removed. Photo: Pexels (free licence). */

const FACTS = ['Finance analyst', 'Hyderabad office', 'Treasury team'];
const APPS = [
  { k: 'aws', name: 'AWS', ok: true },
  { k: 'salesforce', name: 'Salesforce', ok: true },
  { k: 'github', name: 'GitHub', ok: false },
];
const STEPS = 7; // 0..2 facts, 3 lines, 4..5 apps kept, 6 one removed

export default function HeroPhoto() {
  const ref = useRef(null);
  const seen = useInView(ref, { threshold: 0.3, once: true });
  const reduce = useReducedMotion();
  const [k, setK] = useState(-1); // hidden until it plays; without scripts, CSS shows the finished picture
  useEffect(() => {
    if (reduce) { setK(STEPS); return undefined; }
    if (!seen) { setK(-1); return undefined; }
    setK(-1);
    const ts = Array.from({ length: STEPS + 1 }, (_, i) => setTimeout(() => setK(i), 500 + i * 420));
    return () => ts.forEach(clearTimeout);
  }, [seen, reduce]);
  return (
    <figure ref={ref} className="hp relative mx-auto w-full max-w-[640px]" aria-label="A finance analyst at work. adapID AI confirms his role, office and team, keeps his access to AWS and Salesforce, and removes GitHub access he has not used in 90 days.">
      <div className="relative overflow-hidden rounded-[24px] border border-white/15 shadow-[0_40px_90px_-40px_rgba(0,0,0,.8)]">
        <img src="/img/photos/analyst.webp" alt="" width="1800" height="1200" className="aspect-[5/4] w-full object-cover object-[62%_center]" fetchPriority="high" decoding="async" />
        <div aria-hidden="true" className="absolute inset-0" style={{ background: 'linear-gradient(90deg, rgb(4 25 58 / .55), rgb(4 25 58 / .08) 55%, transparent), linear-gradient(0deg, rgb(4 25 58 / .45), transparent 45%)' }} />
      </div>
      <div aria-hidden="true" className="absolute left-[-4%] top-[30%] w-[58%] max-w-[300px] max-sm:left-[3%] max-sm:w-[64%]">
        <ul className="space-y-2.5">
          {FACTS.map((f, i) => (
            <li key={f} className={cx('hp-chip flex items-center gap-2.5 rounded-[10px] bg-[#0b3a8c] px-3 py-2.5 text-[15px] font-medium text-white shadow-[0_14px_30px_-14px_rgba(0,0,0,.7)] max-sm:text-[13px]', k >= i && 'on')}>
              <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-white text-[#0b3a8c]"><svg width="13" height="13" viewBox="0 0 14 14"><path d="m3 7.3 2.6 2.5L11 4.3" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg></span>
              {f}
            </li>
          ))}
        </ul>
        {/* lines from the identity down to the apps it can reach */}
        <svg viewBox="0 0 300 56" className="h-[56px] w-full overflow-visible" preserveAspectRatio="none">
          {[50, 150, 250].map((x, i) => <path key={x} d={`M150 0 V20 Q150 28 ${x > 150 ? 158 : x < 150 ? 142 : 150} 28 H${x === 150 ? 150 : x + (x > 150 ? -8 : 8)} Q${x} 28 ${x} 36 V56`} className={cx('hp-line', k >= 3 && 'on')} style={{ transitionDelay: `${i * 90}ms` }} fill="none" stroke="#9cc8ff" strokeWidth="1.6" />)}
        </svg>
        <ul className="grid grid-cols-3 gap-[6%] px-[3%]">
          {APPS.map((a, i) => {
            const on = k >= (a.ok ? 4 + i : 6);
            return (
              <li key={a.k} className={cx('hp-app relative flex aspect-square items-center justify-center rounded-[14px] bg-white text-[#0e1014] shadow-[0_14px_30px_-12px_rgba(0,0,0,.6)]', k >= 3 && 'in', on && !a.ok && 'off')}>
                <Logo k={a.k} size="54%" />
                <span className={cx('hp-badge absolute -right-2 -top-2 grid h-6 w-6 place-items-center rounded-full border-2 border-white text-white', a.ok ? 'bg-[#0a6dbb]' : 'bg-[#e5484d]', on && 'on')}>
                  {a.ok ? <svg width="12" height="12" viewBox="0 0 14 14"><path d="m3 7.3 2.6 2.5L11 4.3" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" /></svg>
                    : <svg width="10" height="10" viewBox="0 0 12 12"><path d="M3 3l6 6M9 3l-6 6" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" /></svg>}
                </span>
              </li>
            );
          })}
        </ul>
      </div>
      <figcaption className={cx('hp-note absolute left-[4%] top-[5%] max-w-[54%] max-sm:max-w-[80%] rounded-[12px] border border-white/15 bg-[#04193a]/80 px-4 py-3 text-[14px] leading-snug text-white backdrop-blur-md max-sm:text-[12.5px]', k >= STEPS && 'on')}>
        <span className="block font-semibold">Access matches his role.</span>
        <span className="block text-white/75">GitHub, unused for 90 days, removed by adapID AI.</span>
      </figcaption>
    </figure>
  );
}
