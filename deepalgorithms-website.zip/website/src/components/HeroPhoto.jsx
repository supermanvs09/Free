import { useEffect, useRef, useState } from 'react';
import { useInView, useReducedMotion, cx } from '../lib/motion.js';
import ProductMark from './ProductMark.jsx';

/* The home hero picture, telling the headline in one glance: a real person
   at work, confirmed as himself; then someone else signs in with his
   password, and adapID AI stops them. Photo: Pexels (free licence). */

const FACTS = ['Finance analyst', 'His usual laptop', 'Hyderabad office'];
const STEPS = 5; // 0..2 confirmed, 3 the other sign-in, 4 blocked

const Tick = () => <svg width="13" height="13" viewBox="0 0 14 14" aria-hidden="true"><path d="m3 7.3 2.6 2.5L11 4.3" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>;

export default function HeroPhoto() {
  const ref = useRef(null);
  const seen = useInView(ref, { threshold: 0.3, once: true });
  const reduce = useReducedMotion();
  const [k, setK] = useState(-1); // hidden until it plays; without scripts, CSS shows the finished picture
  useEffect(() => {
    if (reduce) { setK(STEPS); return undefined; }
    if (!seen) return undefined;
    const at = [500, 900, 1300, 2300, 3500];
    const ts = at.map((ms, i) => setTimeout(() => setK(i), ms));
    return () => ts.forEach(clearTimeout);
  }, [seen, reduce]);
  const blocked = k >= 4;
  return (
    <figure ref={ref} className="hp relative mx-auto w-full max-w-[600px] lg:mr-0" aria-label="A finance analyst at his laptop. adapID AI confirms it is him: his role, his usual laptop, his office. Then someone signs in with his password from a new phone in Lagos, and adapID AI blocks it.">
      <div className="relative overflow-hidden rounded-[24px] border border-white/15 shadow-[0_40px_90px_-40px_rgba(0,0,0,.8)]">
        <img src="/img/photos/hero-person.webp" alt="" width="1800" height="1440" className="aspect-[5/4] w-full object-cover object-top" fetchPriority="high" decoding="async" />
        <div aria-hidden="true" className="absolute inset-0" style={{ background: 'linear-gradient(0deg, rgb(4 25 58 / .35), transparent 40%)' }} />
        {/* it is him */}
        <ul aria-hidden="true" className="absolute right-[4%] top-[7%] w-[44%] min-w-[180px] space-y-2 max-sm:bottom-[5%] max-sm:top-auto max-sm:min-w-0 max-sm:w-[52%] max-sm:space-y-1.5">
          {FACTS.map((f, i) => (
            <li key={f} className={cx('hp-chip flex items-center gap-2.5 rounded-[10px] bg-white/95 px-3 py-2 text-[14.5px] font-medium text-[#0e1116] shadow-[0_14px_30px_-14px_rgba(0,0,0,.55)] max-sm:gap-2 max-sm:px-2.5 max-sm:py-1.5 max-sm:text-[12.5px]', k >= i && 'on')}>
                <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-[#0a6dbb] text-white"><Tick /></span>{f}
            </li>
          ))}
        </ul>
      </div>
      {/* someone else, with his password */}
      <div aria-hidden="true" className={cx('hp-note absolute bottom-[6%] left-[-5%] w-[62%] min-w-[240px] rounded-[16px] bg-white p-4 text-left text-[#0e1116] shadow-[0_28px_60px_-22px_rgba(0,0,0,.7)] max-sm:relative max-sm:inset-auto max-sm:mt-3 max-sm:w-full max-sm:min-w-0', k >= 3 && 'on')}>
        <p className="flex items-center gap-2 text-[12px] font-semibold uppercase tracking-[.08em] text-[#5c6777]"><ProductMark p="adapid" size={18} />New sign-in · 02:14</p>
        <p className="mt-2 text-[15.5px] font-semibold leading-snug">His password, a new phone, in Lagos.</p>
        <p className={cx('mt-3 flex items-center justify-between gap-3 rounded-[10px] px-3 py-2 text-[14px] font-semibold transition-colors duration-500', blocked ? 'bg-[#fdecec] text-[#c4302b]' : 'bg-[#f1f4f8] text-[#5c6777]')}>
          <span>{blocked ? 'Blocked. Not him.' : 'Checking…'}</span>
          <span className={cx('grid h-6 w-6 place-items-center rounded-full text-white transition-colors duration-500', blocked ? 'bg-[#e5484d]' : 'bg-[#9aa5b4]')}>
            {blocked ? <svg width="11" height="11" viewBox="0 0 12 12" aria-hidden="true"><path d="M3 3l6 6M9 3l-6 6" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" /></svg> : <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" />}
          </span>
        </p>
      </div>
    </figure>
  );
}
