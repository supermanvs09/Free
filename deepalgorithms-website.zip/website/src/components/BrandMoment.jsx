import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router';
import ProductMark from './ProductMark.jsx';
import { cx, seg, ease, easeInOut, lerp } from '../lib/motion.js';

/* The brand moment, after the reference film: the logo tile rises, opens into
   a full-width statement, closes again and settles as the hub of the product
   map, where each product meets the problem it solves.
   Server HTML (and reduced motion) shows the statement and the map as two
   ordinary blocks; the scroll-driven version takes over once mounted. */

const STATEMENT = 'The best security is the incident nobody ever has to report.';
const WORDS = STATEMENT.split(' ');

const PRODUCTS = [
  { key: 'zenstra', name: 'Zenstra AI', acc: '#93a2ff', what: 'AI agents', line: 'Checks every agent action against its task before it runs.', to: '/agentic-ai/agentic-identity', pos: 'tl' },
  { key: 'adapid', name: 'adapID AI', acc: '#3cc8f6', what: 'People and machine identities', line: 'Scores every identity and stops the one that starts behaving differently.', to: '/adapid-ai', pos: 'tr' },
  { key: 'botshield', name: 'BotShield AI', acc: '#34e0c3', what: 'Apps, APIs and the edge', line: 'Proves which exposures are exploitable, and stops bots and floods.', to: '/botshield-ai', pos: 'bl' },
  { key: 'icms', name: 'ICMS Compliance Suite', acc: '#f4c76c', what: 'Personal data', line: 'Turns every access to personal data into DPDPA evidence.', to: '/dpdpa-compliance', pos: 'br' },
];

function Mark({ className, style }) {
  return <img src="/brand/mark.webp" alt="" width="64" height="64" className={className} style={style} />;
}

function Statement({ wordRefs, live }) {
  return (
    <p className="mx-auto max-w-[17ch] text-center font-semibold tracking-[-0.04em] text-white" style={{ fontSize: 'clamp(30px, 5.2vw, 76px)', lineHeight: 1.04 }}>
      {WORDS.map((w, i) => (
        <span key={i} ref={(el) => { if (wordRefs) wordRefs.current[i] = el; }} style={live ? { opacity: 0.18, transition: 'opacity .25s' } : undefined}>{w}{i < WORDS.length - 1 ? ' ' : ''}</span>
      ))}
    </p>
  );
}

/* The product map: hub in the middle, one card per product, light along the links. */
function ProductMap({ hubRef, cardRefs, lines, mapRef, live }) {
  return (
    <div ref={mapRef} className="relative h-full w-full">
      <svg className="pointer-events-none absolute inset-0 h-full w-full" aria-hidden="true">
        <defs>
          {PRODUCTS.map((p) => (
            <linearGradient key={p.key} id={`bm-${p.key}`} x1="0" y1="0" x2="1" y2="0"><stop offset="0" stopColor="#5fd0ff" stopOpacity=".7" /><stop offset="1" stopColor={p.acc} stopOpacity=".9" /></linearGradient>
          ))}
        </defs>
        {lines.map((l, i) => l && (
          <g key={PRODUCTS[i].key}>
            <path d={l.d} fill="none" stroke={`url(#bm-${PRODUCTS[i].key})`} strokeWidth="1.4" data-line={i} style={{ strokeDasharray: l.len, strokeDashoffset: live ? l.len : 0 }} />
            <circle r="3.2" fill={PRODUCTS[i].acc} style={{ filter: `drop-shadow(0 0 6px ${PRODUCTS[i].acc})` }} data-dot={i} opacity={live ? 0 : 1}>
              <animateMotion dur={`${2.6 + i * 0.35}s`} repeatCount="indefinite" path={l.d} />
            </circle>
          </g>
        ))}
      </svg>

      <div className="bm-grid relative h-full">
        <div className="bm-head text-center" data-head>
          <p className="eyebrow mx-auto">Our products</p>
          <h2 className="t-h2 mx-auto mt-5 max-w-[16ch]">Every way in. Already guarded.</h2>
        </div>
        <div className="bm-hub flex flex-col items-center" data-hub>
          <span aria-hidden="true" className="bm-orbit" data-orbit><i /><i /></span>
          <span ref={hubRef} className="relative block h-[84px] w-[84px] md:h-[104px] md:w-[104px]">
            {!live && <span className="flex h-full w-full items-center justify-center rounded-[30%] shadow-[0_0_40px_rgba(0,140,220,.25)]" style={{ background: 'linear-gradient(135deg, #0068ac, #169fe6)' }}><span className="block h-[46%] w-[46%] rounded-[24%] bg-white p-[14%]"><Mark className="h-full w-full" /></span></span>}
          </span>
          <span className="mt-3 text-[13px] font-medium text-ink-2" data-hublabel>Deep Algorithms</span>
        </div>
        {PRODUCTS.map((p, i) => (
          <Link key={p.key} to={p.to} ref={(el) => { cardRefs.current[i] = el; }} data-card={i}
            className={cx('bm-card group card card-hover glass flex items-start gap-4 p-4 md:p-5', `bm-${p.pos}`)} style={{ '--acc': p.acc }}>
            <span className="grid h-12 w-12 shrink-0 place-items-center rounded-[14px] border border-line-2 bg-white/[.05] transition-transform duration-500 group-hover:scale-[1.06] md:h-[58px] md:w-[58px]" style={{ boxShadow: `0 0 28px -8px ${p.acc}` }}>
              <ProductMark p={p.key} size={34} className="md:!h-[40px] md:!w-[40px]" />
            </span>
            <span className="min-w-0 flex-1">
              <span className="flex items-center justify-between gap-2"><span className="text-[16px] font-semibold tracking-[-0.01em] md:text-[17px]">{p.name}</span><span aria-hidden="true" className="hidden text-ink-3 transition-all duration-300 group-hover:translate-x-0.5 group-hover:text-ink sm:inline">→</span></span>
              <span className="mt-1 block text-[12px] font-semibold uppercase tracking-[.08em]" style={{ color: p.acc }}>{p.what}</span>
              <span className="mt-2 hidden text-[14.5px] leading-snug text-ink-2 sm:block">{p.line}</span>
            </span>
          </Link>
        ))}
      </div>
    </div>
  );
}

function useMapLines(mapRef, hubRef, cardRefs, setLines, dep) {
  useEffect(() => {
    const m = mapRef.current;
    if (!m) return undefined;
    const measure = () => {
      // a resize can be delivered after the page has started to unmount
      if (!m.isConnected || !hubRef.current || cardRefs.current.some((c) => !c)) return;
      const mr = m.getBoundingClientRect(), h = hubRef.current.getBoundingClientRect();
      const hx = h.left + h.width / 2 - mr.left, hy = h.top + h.height / 2 - mr.top;
      const firstRow = Math.min(...cardRefs.current.map((c) => c.getBoundingClientRect().top));
      setLines(cardRefs.current.map((c) => {
        const r = c.getBoundingClientRect();
        if (mr.width < 900 && r.top > firstRow + 4) return null; // stacked: only the first row has a clear path
        const cx0 = r.left + r.width / 2 - mr.left, cy0 = r.top + r.height / 2 - mr.top;
        const tx = cx0 < hx ? r.right - mr.left : r.left - mr.left;
        const wide = mr.width >= 900;
        const [ex, ey] = wide ? [tx, cy0] : [cx0, cy0 < hy ? r.bottom - mr.top : r.top - mr.top];
        const d = wide ? `M${hx} ${hy} C${(hx + ex) / 2} ${hy}, ${(hx + ex) / 2} ${ey}, ${ex} ${ey}` : `M${hx} ${hy} C${hx} ${(hy + ey) / 2}, ${ex} ${(hy + ey) / 2}, ${ex} ${ey}`;
        return { d, len: Math.hypot(ex - hx, ey - hy) * 1.35 };
      }));
    };
    measure();
    const ro = new ResizeObserver(measure); ro.observe(m);
    return () => ro.disconnect();
  }, [dep]); // eslint-disable-line react-hooks/exhaustive-deps
}

/* The product map on its own, for pages that explain how the products fit. */
export function ProductMapStatic({ className = 'relative md:h-[680px]' }) {
  const mapRef = useRef(null), hubRef = useRef(null), cardRefs = useRef([]);
  const [lines, setLines] = useState([]);
  useMapLines(mapRef, hubRef, cardRefs, setLines, 0);
  return <div className={className}><ProductMap hubRef={hubRef} cardRefs={cardRefs} lines={lines} mapRef={mapRef} /><style>{MAP_CSS}</style></div>;
}

export default function BrandMoment() {
  const [live, setLive] = useState(false);
  const outer = useRef(null), stage = useRef(null), tile = useRef(null), mark = useRef(null), words = useRef([]), text = useRef(null);
  const mapRef = useRef(null), hubRef = useRef(null), cardRefs = useRef([]);
  const [lines, setLines] = useState([]);

  useEffect(() => {
    if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) setLive(true);
  }, []);

  useMapLines(mapRef, hubRef, cardRefs, setLines, live);

  // scroll-driven choreography
  useEffect(() => {
    if (!live) return undefined;
    let raf = 0;
    const run = () => {
      const o = outer.current, st = stage.current, t = tile.current;
      if (!o || !st || !t || !hubRef.current || !mark.current || !text.current) return;
      const r = o.getBoundingClientRect();
      const total = r.height - window.innerHeight;
      const p = total > 0 ? Math.min(1, Math.max(0, -r.top / total)) : 0;
      const W = st.clientWidth, H = st.clientHeight;
      const small = W < 640 ? 64 : 84;
      const pw = Math.min(W - (W < 640 ? 24 : 64), 1280), ph = Math.min(H * (W < 640 ? 0.62 : 0.74), 660);
      const sr = st.getBoundingClientRect(), hr = hubRef.current.getBoundingClientRect();
      const hub = { x: hr.left - sr.left, y: hr.top - sr.top, w: hr.width };

      const a = ease(seg(p, 0, 0.1)), b = easeInOut(seg(p, 0.1, 0.26)), d = easeInOut(seg(p, 0.56, 0.68)), e = easeInOut(seg(p, 0.68, 0.82));
      let w = lerp(small, pw, b), h = lerp(small, ph, b);
      w = lerp(w, small, d); h = lerp(h, small, d);
      let x = W / 2 - w / 2, y = H / 2 - h / 2 + lerp(H * 0.32, 0, a);
      const hs = hub.w;
      x = lerp(x, hub.x, e); y = lerp(y, hub.y, e);
      w = lerp(w, hs, e); h = lerp(h, hs, e);
      const rad = lerp(lerp(small * 0.3, 34, b), small * 0.3, d) * (1 - e) + hs * 0.3 * e;
      t.style.transform = `translate3d(${x.toFixed(1)}px, ${y.toFixed(1)}px, 0)`;
      t.style.width = `${w.toFixed(1)}px`; t.style.height = `${h.toFixed(1)}px`;
      t.style.borderRadius = `${rad.toFixed(1)}px`;
      t.style.opacity = String(a);
      t.style.boxShadow = `0 0 ${(40 + 80 * b * (1 - d)).toFixed(0)}px rgb(0 160 240 / ${(0.35 + 0.25 * seg(p, 0.82, 1)).toFixed(2)})`;

      // the mark rides to the top of the open panel, then back to the centre
      const open = b * (1 - d);
      const ms = lerp(small * 0.5, 54, open);
      mark.current.style.width = `${ms}px`; mark.current.style.height = `${ms}px`;
      mark.current.style.transform = `translate(-50%, ${lerp(-50, -50 - (ph / 2 - 70) / ms * 100, open * seg(p, 0.2, 0.3))}%)`;

      // statement, word by word
      text.current.style.opacity = String(seg(p, 0.22, 0.28) * (1 - seg(p, 0.54, 0.6)));
      const n = WORDS.length;
      words.current.forEach((el, i) => {
        if (!el) return;
        const s0 = 0.28 + (i / n) * 0.22;
        el.style.opacity = String(0.18 + 0.82 * seg(p, s0, s0 + 0.03));
      });

      // the map arrives around the hub
      const m = mapRef.current;
      const mapIn = seg(p, 0.66, 0.8);
      m.style.opacity = String(mapIn);
      m.querySelector('[data-head]').style.transform = `translateY(${lerp(30, 0, ease(mapIn))}px)`;
      m.querySelector('[data-hublabel]').style.opacity = String(seg(p, 0.8, 0.86));
      m.querySelector('[data-orbit]').style.opacity = String(seg(p, 0.8, 0.92));
      cardRefs.current.forEach((c, i) => {
        const ci = ease(seg(p, 0.72 + i * 0.03, 0.84 + i * 0.03));
        c.style.opacity = String(ci); c.style.transform = `translateY(${lerp(24, 0, ci)}px)`;
      });
      m.querySelectorAll('[data-line]').forEach((l, i) => {
        const len = +l.style.strokeDasharray || 400;
        l.style.strokeDashoffset = String(len * (1 - easeInOut(seg(p, 0.82 + i * 0.02, 0.94 + i * 0.02))));
      });
      m.querySelectorAll('[data-dot]').forEach((dt) => dt.setAttribute('opacity', String(seg(p, 0.94, 0.98))));
    };
    const on = () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(run); };
    run();
    window.addEventListener('scroll', on, { passive: true });
    window.addEventListener('resize', on);
    return () => { window.removeEventListener('scroll', on); window.removeEventListener('resize', on); cancelAnimationFrame(raf); };
  }, [live, lines]);

  if (!live) {
    return (
      <section aria-label="Our products" className="stage sec">
        <div className="wrap">
          <div className="relative overflow-hidden rounded-[32px] px-6 py-20 md:py-28" style={{ background: 'linear-gradient(135deg, #0068ac 0%, #0a7fcf 55%, #169fe6 100%)' }}>
            <span className="mx-auto mb-10 block h-14 w-14 rounded-[16px] bg-white p-2.5"><Mark className="h-full w-full" /></span>
            <Statement />
          </div>
          <div className="relative mt-16 md:h-[680px]"><ProductMap hubRef={hubRef} cardRefs={cardRefs} lines={lines} mapRef={mapRef} /></div>
        </div>
        <style>{MAP_CSS}</style>
      </section>
    );
  }

  return (
    <section ref={outer} aria-label="Our products" className="stage relative" style={{ height: '300vh' }}>
      <div ref={stage} className="sticky top-0 h-[100svh] overflow-hidden">
        <div className="wrap relative h-full pt-[88px] pb-6 md:pb-10">
          <ProductMap hubRef={hubRef} cardRefs={cardRefs} lines={lines} mapRef={mapRef} live />
        </div>
        <div ref={tile} aria-hidden="true" className="absolute left-0 top-0 z-10 overflow-hidden will-change-transform"
          style={{ width: 84, height: 84, opacity: 0, background: 'linear-gradient(135deg, #0068ac 0%, #0a7fcf 55%, #169fe6 100%)' }}>
          <div className="absolute inset-0 opacity-[.18]" style={{ backgroundImage: 'radial-gradient(rgb(255 255 255 / .55) 1px, transparent 1px)', backgroundSize: '22px 22px' }} />
          <span ref={mark} className="absolute left-1/2 top-1/2 block" style={{ width: 42, height: 42, transform: 'translate(-50%, -50%)' }}>
            <span className="block h-full w-full rounded-[24%] bg-white p-[16%] shadow-[0_10px_30px_-8px_rgba(0,0,0,.45)]"><Mark className="h-full w-full" /></span>
          </span>
          <div ref={text} className="absolute inset-0 flex items-center justify-center px-6" style={{ opacity: 0 }}>
            <Statement wordRefs={words} live />
          </div>
        </div>
      </div>
      <p className="sr-only">{STATEMENT}</p>
      <style>{MAP_CSS}</style>
    </section>
  );
}

const MAP_CSS = `
.bm-grid { display: grid; grid-template-columns: 1fr 1fr; grid-template-rows: auto auto auto auto; gap: 14px; align-content: start; }
.bm-head { grid-column: 1 / -1; }
.bm-hub { grid-column: 1 / -1; padding-block: 18px 8px; position: relative; }
.bm-orbit { position: absolute; left: 50%; top: 60px; width: 0; height: 0; pointer-events: none; }
.bm-orbit i { position: absolute; left: 50%; top: 50%; border-radius: 50%; border: 1px dashed rgb(148 170 200 / .2); transform: translate(-50%, -50%); animation: bm-spin 80s linear infinite; }
.bm-orbit i:nth-child(1) { width: 190px; height: 190px; }
.bm-orbit i:nth-child(2) { width: 330px; height: 330px; border-style: solid; border-color: rgb(148 170 200 / .08); animation-direction: reverse; animation-duration: 120s; }
.bm-orbit i::after { content: ''; position: absolute; left: 50%; top: -3px; width: 6px; height: 6px; margin-left: -3px; border-radius: 50%; background: #5fd0ff; box-shadow: 0 0 10px #5fd0ff; }
@keyframes bm-spin { to { transform: translate(-50%, -50%) rotate(360deg); } }
@media (max-width: 899px) { .bm-orbit { display: none; } }
@media (min-width: 900px) { .bm-orbit { top: 52px; } }
@media (min-width: 900px) {
  .bm-grid { display: block; }
  .bm-head { position: absolute; left: 0; right: 0; top: 0; }
  .bm-hub { position: absolute; left: 50%; top: 60%; transform: translate(-50%, -50%); padding: 0; }
  .bm-card { position: absolute; width: min(31%, 380px); }
  .bm-tl { left: 0; top: 30%; } .bm-tr { right: 0; top: 30%; }
  .bm-bl { left: 0; top: 64%; } .bm-br { right: 0; top: 64%; }
}
@media (min-width: 900px) and (max-height: 760px) { .bm-tl, .bm-tr { top: 27%; } .bm-bl, .bm-br { top: 60%; } }
@media (prefers-reduced-motion: reduce) { .bm-orbit i { animation: none; } }
`;
