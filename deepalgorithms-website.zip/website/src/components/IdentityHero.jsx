import { useEffect, useRef, useState } from 'react';
import { useInView, useReducedMotion, cx } from '../lib/motion.js';
import ProductMark from './ProductMark.jsx';

/* The home hero, telling the headline as one scene. An identity, drawn in
   points of light, signs in: right password, MFA approved. adapID AI reads how
   it behaves; three things are not him. The face slips and shows who is really
   there, and the attacker comes apart into dust. Then the real analyst signs
   in, and it is him. Portraits: Pexels (free licence), see viz/faces.js. */

/* one loop, in ms; the first play starts at 0, every later play at LOOP */
const T = {
  form: 0, formEnd: 2400, card: 2700, pass: 3100, mfa: 3500,
  scan: 3900, scanEnd: 6700, tells: [4400, 5200, 6000],
  slip: 7000, slipEnd: 8200, verdict: 7600,
  vanish: 9000, vanishEnd: 11700, back: 12100, backEnd: 14300, real: 13300, end: 16800,
};
const LOOP = 2600;
const TELLS = ['Typing rhythm: not his', 'A phone he has never used', '02:14, and he is never online then'];

const clamp = (v) => (v < 0 ? 0 : v > 1 ? 1 : v);
const outCubic = (p) => 1 - (1 - p) ** 3;
const inOut = (p) => (p < 0.5 ? 4 * p * p * p : 1 - (-2 * p + 2) ** 3 / 2);

/* what the card and chips show at time t */
function stageAt(t) {
  if (t >= T.real) return 7;
  if (t >= T.verdict) return 6;
  if (t >= T.scan) return 5;
  if (t >= T.mfa) return 4;
  if (t >= T.pass) return 3;
  if (t >= T.card) return 2;
  return 0;
}
const tellsAt = (t) => (t >= T.vanish ? 0 : T.tells.filter((x) => t >= x).length);

function decode(b64, count) {
  const bin = atob(b64);
  const out = [new Float32Array(count * 3), new Float32Array(count * 3)];
  for (let f = 0; f < 2; f += 1) {
    for (let i = 0; i < count; i += 1) {
      const o = (f * count + i) * 3;
      const v = (bin.charCodeAt(o) << 16) | (bin.charCodeAt(o + 1) << 8) | bin.charCodeAt(o + 2);
      out[f][i * 3] = (v >> 14) / 1023;
      out[f][i * 3 + 1] = ((v >> 4) & 1023) / 1023;
      out[f][i * 3 + 2] = (v & 15) / 15;
    }
  }
  return out;
}

const BUCKETS = 8;

export default function IdentityHero() {
  const ref = useRef(null);
  const canvas = useRef(null);
  const seen = useInView(ref, { threshold: 0.15 });
  const reduce = useReducedMotion();
  const [paused, setPaused] = useState(false);
  const [stage, setStage] = useState(-1); // hidden until scripts run; without them, CSS shows the blocked card
  const [tells, setTells] = useState(0);
  const [red, setRed] = useState(false);
  const clock = useRef({ t: 0, last: 0, started: false });
  const data = useRef(null);

  // load the points once, after the page has painted
  const [ready, setReady] = useState(false);
  useEffect(() => {
    let live = true;
    import('./viz/faces.js').then(({ COUNT, DATA }) => {
      if (!live) return;
      const [A, B] = decode(DATA, COUNT);
      const n = COUNT;
      const rnd = new Float32Array(n * 4);
      for (let i = 0; i < rnd.length; i += 1) rnd[i] = Math.random();
      data.current = { A, B, n, rnd };
      setReady(true);
    });
    return () => { live = false; };
  }, []);

  useEffect(() => {
    const cv = canvas.current;
    if (!ready || !cv) return undefined;
    const ctx = cv.getContext('2d');
    const { A, B, n, rnd } = data.current;
    const small = window.matchMedia('(max-width: 640px)').matches;
    const stride = small ? 2 : 1;
    const bx = Array.from({ length: BUCKETS }, () => new Float32Array(n * 3));
    const bc = new Int32Array(BUCKETS);
    const glitch = new Float32Array(16);
    let W = 0, H = 0, dpr = 1, raf = 0, lastGlitch = 0;

    const size = () => {
      const r = cv.getBoundingClientRect();
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = r.width; H = r.height;
      cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
    };
    size();
    const ro = new ResizeObserver(size);
    ro.observe(cv);

    const draw = (t) => {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);
      ctx.globalCompositeOperation = 'lighter';
      // the face sits right of centre, looking left towards the words
      // on phones the card sits below the face instead of over it
      const fh = small ? Math.min(H * 0.72, (W * 0.94) / 0.918) : H, fw = fh * 0.918;
      const ox = small ? (W - fw) / 2 + W * 0.04 : W - fw + W * 0.02, oy = 0;
      const unit = fh / 600; // motion is set for a 600px face

      const slip = inOut(clamp((t - T.slip) / (T.slipEnd - T.slip)));
      const redness = t >= T.slip && t < T.back ? slip : 0;
      const scanP = (t - T.scan) / (T.scanEnd - T.scan);
      const scanY = scanP > 0 && scanP < 1 ? oy + fh * (0.02 + 0.96 * scanP) : -1e4;
      const glitchOn = t > T.slip && t < T.slip + 900;
      if (glitchOn && t - lastGlitch > 70) {
        lastGlitch = t;
        for (let g = 0; g < 16; g += 1) glitch[g] = Math.random() < 0.35 ? (Math.random() - 0.5) * 34 * unit : 0;
      }
      const firstForm = t < T.formEnd + 400;
      bc.fill(0);

      for (let i = 0; i < n; i += stride) {
        const r0 = rnd[i * 4], r1 = rnd[i * 4 + 1], r2 = rnd[i * 4 + 2], r3 = rnd[i * 4 + 3];
        const ax = ox + A[i * 3] * fw, ay = oy + A[i * 3 + 1] * fh, ab = A[i * 3 + 2];
        let x = ax, y = ay, b = ab, a = 1;

        if (firstForm) {
          // gather from a loose cloud
          const p = outCubic(clamp((t - T.form - r0 * 1000) / 1400));
          const sx = ox + fw * 0.5 + (r1 - 0.5) * W * 1.3, sy = oy + fh * 0.5 + (r2 - 0.5) * H * 1.2;
          x = sx + (ax - sx) * p; y = sy + (ay - sy) * p; a = p;
        } else if (t >= T.slip && t < T.back) {
          const p = inOut(clamp((t - T.slip - r0 * 450) / 750));
          const bxp = ox + B[i * 3] * fw, byp = oy + B[i * 3 + 1] * fh;
          x = ax + (bxp - ax) * p; y = ay + (byp - ay) * p; b = ab + (B[i * 3 + 2] - ab) * p;
          if (t >= T.vanish) {
            // the attacker comes apart, front of the face first, blown back and up
            const start = T.vanish + B[i * 3] * 1200 + r1 * 400;
            const v = clamp((t - start) / 1300);
            const e = v * v;
            x += (90 + 260 * r2) * unit * e + Math.sin(v * 5 + r3 * 6) * 9 * unit * v;
            y -= (30 + 150 * r3) * unit * e;
            a = 1 - v * v;
          }
        } else if (t >= T.back && t < T.backEnd + 200) {
          // the real analyst gathers back in
          const p = outCubic(clamp((t - T.back - r0 * 900) / 1300));
          const ang = r1 * Math.PI * 2, d = (90 + 160 * r2) * unit;
          const sx = ax + Math.cos(ang) * d, sy = ay + Math.sin(ang) * d;
          x = sx + (ax - sx) * p; y = sy + (ay - sy) * p; a = p;
        }

        // breathing, and a slow sway in depth: the lit side moves a little
        // more than the shadow, which reads as a head turning in light
        y += Math.sin(t / 950 + r3 * 6.28) * 0.6 * unit;
        x += (b - 0.45) * Math.sin(t / 2600) * 7 * unit;
        // the scan line lifts what it passes
        const dy = y - scanY;
        if (dy > -40 * unit && dy < 6 * unit) {
          const k = dy < 0 ? 1 + dy / (40 * unit) : 1 - dy / (6 * unit);
          b = Math.min(1, b + 0.55 * k);
          x += 2.5 * k * unit;
        }
        if (glitchOn) x += glitch[Math.min(15, Math.max(0, Math.floor((y - oy) / fh * 16)))];

        const alpha = a * (0.22 + 0.78 * b);
        if (alpha < 0.02) continue;
        const k = Math.min(BUCKETS - 1, Math.floor(alpha * BUCKETS));
        const o = bc[k] * 3;
        bx[k][o] = x; bx[k][o + 1] = y; bx[k][o + 2] = (0.7 + 1.7 * b) * Math.max(0.75, unit) * (small ? 1.35 : 1);
        bc[k] += 1;
      }

      // colour: cool blue for the analyst, red for the attacker
      const cr = Math.round(140 + 115 * redness), cg = Math.round(210 - 120 * redness), cb = Math.round(255 - 160 * redness);
      ctx.fillStyle = `rgb(${cr} ${cg} ${cb})`;
      for (let k = 0; k < BUCKETS; k += 1) {
        ctx.globalAlpha = (k + 0.5) / BUCKETS;
        const arr = bx[k];
        for (let j = 0; j < bc[k]; j += 1) {
          const s = arr[j * 3 + 2];
          ctx.fillRect(arr[j * 3] - s / 2, arr[j * 3 + 1] - s / 2, s, s);
        }
      }
      // white cores on the brightest points
      ctx.fillStyle = '#fff';
      ctx.globalAlpha = 0.55;
      for (let k = BUCKETS - 3; k < BUCKETS; k += 1) {
        const arr = bx[k];
        for (let j = 0; j < bc[k]; j += 2) {
          const s = arr[j * 3 + 2] * 0.5;
          ctx.fillRect(arr[j * 3] - s / 2, arr[j * 3 + 1] - s / 2, s, s);
        }
      }

      // the scan line
      if (scanY > 0) {
        ctx.globalAlpha = 1;
        const g = ctx.createLinearGradient(ox - 20, 0, ox + fw + 20, 0);
        g.addColorStop(0, 'rgb(127 220 255 / 0)');
        g.addColorStop(0.5, 'rgb(127 220 255 / .9)');
        g.addColorStop(1, 'rgb(127 220 255 / 0)');
        ctx.fillStyle = g;
        ctx.fillRect(ox - 20, scanY - 1, fw + 40, 2);
        const h = ctx.createLinearGradient(0, scanY - 46 * unit, 0, scanY);
        h.addColorStop(0, 'rgb(127 220 255 / 0)');
        h.addColorStop(1, 'rgb(127 220 255 / .12)');
        ctx.fillStyle = h;
        ctx.fillRect(ox, scanY - 46 * unit, fw, 46 * unit);
      }
      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = 'source-over';
    };

    const sync = (t) => {
      setStage(stageAt(t));
      setTells(tellsAt(t));
      setRed(t >= T.slip && t < T.back);
    };

    const c = clock.current;
    if (reduce) {
      // one still frame: the analyst, the three tells and the verdict
      c.t = T.verdict - 1;
      draw(T.formEnd + 400);
      setStage(6); setTells(3); setRed(false);
      return () => ro.disconnect();
    }
    if (!seen || paused) {
      // hold the frame it stopped on; before the first play, show nothing yet
      if (c.started) draw(c.t);
      return () => ro.disconnect();
    }
    c.started = true;
    c.last = performance.now();
    const loop = (now) => {
      c.t += Math.min(64, now - c.last);
      c.last = now;
      if (c.t >= T.end) c.t = LOOP;
      draw(c.t);
      sync(c.t);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    const vis = () => {
      if (document.hidden) cancelAnimationFrame(raf);
      else { c.last = performance.now(); raf = requestAnimationFrame(loop); }
    };
    document.addEventListener('visibilitychange', vis);
    return () => { cancelAnimationFrame(raf); ro.disconnect(); document.removeEventListener('visibilitychange', vis); };
  }, [ready, seen, paused, reduce]);

  const real = stage >= 7;
  const blocked = stage === 6;
  return (
    <figure ref={ref} className={cx('ih relative mx-auto aspect-[1/1.02] w-full max-sm:aspect-[1/1.32] max-w-[620px] lg:mr-0', red && 'is-red')} aria-label="Animation: a sign-in with the right password and an approved MFA prompt. adapID AI checks how the person behaves: the typing rhythm is not his, the phone is new, and it is 02:14, when he is never online. The face changes to show it is someone else, and the session is blocked. Then the real analyst signs in from his usual laptop, and is let in.">
      <div aria-hidden="true" className="ih-glow absolute inset-[-10%]" />
      <canvas ref={canvas} aria-hidden="true" className={cx('ih-canvas absolute inset-0 h-full w-full', ready && 'on')} />
      <noscript><img src="/img/hero/identity.webp" alt="" width="900" height="918" className="absolute inset-0 h-full w-full object-contain" /></noscript>

      {/* what adapID AI saw */}
      <ul aria-hidden="true" className="absolute right-[-1%] top-[10%] flex w-[52%] flex-col items-end gap-2.5 max-sm:top-[4%] max-sm:w-[86%] max-sm:gap-1.5">
        {TELLS.map((x, i) => (
          <li key={x} className={cx('ih-tell flex items-center gap-2 whitespace-nowrap rounded-full border border-[#ff8b7e]/30 bg-[#12070c]/70 py-1.5 pl-2.5 pr-3.5 text-[13px] font-medium text-white backdrop-blur-md max-sm:py-1 max-sm:text-[11.5px]', tells > i && 'on')} style={{ marginRight: `${[2, 9, 4][i]}%` }}>
            <span className="h-2 w-2 shrink-0 rounded-full bg-[#ff6b5e] shadow-[0_0_10px_#ff6b5e]" />{x}
          </li>
        ))}
      </ul>

      {/* the sign-in, as adapID AI scores it */}
      <div aria-hidden="true" className={cx('ih-card absolute bottom-[-2%] right-[-1%] w-[284px] rounded-[16px] bg-white/95 p-4 backdrop-blur text-left text-[#0e1116] shadow-[0_30px_70px_-24px_rgba(0,0,0,.8)] max-sm:inset-x-0 max-sm:bottom-0 max-sm:mx-auto max-sm:w-full max-sm:p-3.5', stage >= 2 && 'on')}>
        <p className="flex items-center gap-2 text-[11.5px] font-semibold uppercase tracking-[.08em] text-[#5c6777]"><ProductMark p="adapid" size={18} />{real ? 'Sign-in · 09:12 · Hyderabad' : 'Sign-in · 02:14 · Lagos'}</p>
        <ul className="mt-3 space-y-1.5 text-[14px] max-sm:text-[12.5px]">
          {[['Password', 'Correct', stage >= 3], ['MFA', 'Approved', stage >= 4]].map(([k, v, on]) => (
            <li key={k} className="flex items-center justify-between">
              <span className="text-[#5c6777]">{k}</span>
              <span className={cx('flex items-center gap-1.5 font-semibold transition-opacity duration-300', on ? 'opacity-100' : 'opacity-0')}>
                <svg width="14" height="14" viewBox="0 0 14 14" aria-hidden="true"><circle cx="7" cy="7" r="7" fill="#1f9d63" /><path d="m4 7.2 2 2 4-4.4" fill="none" stroke="#fff" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" /></svg>{v}
              </span>
            </li>
          ))}
          <li className="flex items-center justify-between gap-3">
            <span className="text-[#5c6777]">Behaviour</span>
            <span className="flex items-center gap-2 font-semibold">
              <span className="relative h-1.5 w-16 overflow-hidden rounded-full bg-[#e8ecf2]"><span className={cx('ih-bar absolute inset-y-0 left-0 rounded-full', stage === 5 && 'run', blocked && 'full', real && 'low')} /></span>
              <span className={cx(blocked ? 'text-[#c4302b]' : real ? 'text-[#1f9d63]' : 'text-[#5c6777]')}>{blocked ? 'Not him' : real ? 'Him' : stage >= 5 ? 'Reading…' : '—'}</span>
            </span>
          </li>
        </ul>
        <p className={cx('mt-3 flex items-center justify-between rounded-[10px] px-3 py-2 text-[14px] font-semibold transition-colors duration-500 max-sm:text-[13px]', blocked ? 'bg-[#fdecec] text-[#c4302b]' : real ? 'bg-[#e7f6ee] text-[#167a4c]' : 'bg-[#f1f4f8] text-[#5c6777]')}>
          <span>{blocked ? 'Blocked. Someone else.' : real ? 'Signed in. It’s him.' : 'Checking…'}</span>
          <span className={cx('grid h-6 w-6 place-items-center rounded-full text-white transition-colors duration-500', blocked ? 'bg-[#e5484d]' : real ? 'bg-[#1f9d63]' : 'bg-[#9aa5b4]')}>
            {blocked ? <svg width="11" height="11" viewBox="0 0 12 12" aria-hidden="true"><path d="M3 3l6 6M9 3l-6 6" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" /></svg>
              : real ? <svg width="12" height="12" viewBox="0 0 14 14" aria-hidden="true"><path d="m3 7.3 2.6 2.5L11 4.3" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" /></svg>
                : <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" />}
          </span>
        </p>
      </div>

      {!reduce && (
        <button type="button" onClick={() => setPaused(!paused)} className="absolute left-[8%] top-[3%] inline-flex h-9 w-9 items-center justify-center rounded-full border border-white/20 bg-white/5 text-white/80 backdrop-blur hover:text-white max-sm:bottom-auto max-sm:top-0" aria-label={paused ? 'Play the animation' : 'Pause the animation'}>
          {paused ? <svg width="12" height="12" viewBox="0 0 12 12" aria-hidden="true"><path d="M3 1.5v9l7.5-4.5z" fill="currentColor" /></svg> : <svg width="12" height="12" viewBox="0 0 12 12" aria-hidden="true"><path d="M3 1.5h2v9H3zM7 1.5h2v9H7z" fill="currentColor" /></svg>}
        </button>
      )}
    </figure>
  );
}
