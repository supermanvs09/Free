import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router';
import { Icon, Reveal, cx } from './ui.jsx';
import { AgentBoundary } from './scenes/agent.jsx';
import { MachineCrowd } from './scenes/crowd.jsx';
import { LoginGlobe } from './scenes/login.jsx';

/* The three identities attackers now use, told one at a time. On a desktop the
   scene stays pinned beside the text and changes as the reader scrolls (only the
   one showing is running); on a phone or tablet each step carries its own scene. */
const STEPS = [
  {
    V: AgentBoundary, acc: 'var(--color-zen)',
    kicker: 'AI agents', stat: '1 request. 3 systems.',
    title: 'An agent asked to summarise one contract reached for three years of mail.',
    body: 'Copilots and agents read data, call tools and move money with access nobody reviewed. Zenstra draws the task around each agent and stops every call that crosses it, before it runs.',
    to: '/agentic-ai/agentic-identity', cta: 'How Zenstra stops it',
  },
  {
    V: MachineCrowd, acc: 'var(--color-adap)',
    kicker: 'Machine identities', stat: 'Outnumbered by machines.',
    title: 'For every person who can log in, a crowd of keys, bots and AI agents can too.',
    body: 'Most hold more access than they ever use, and they multiply with every deploy. adapID finds each one, shows what it can reach and what it actually uses, and flags the few that need action today.',
    to: '/adapid-ai/nhi-security', cta: 'How adapID finds them',
  },
  {
    V: LoginGlobe, acc: 'var(--color-adap)',
    kicker: 'People', stat: 'MFA passed. Twice.',
    title: 'A stolen login passes every check and looks exactly like the real one.',
    body: 'Mumbai at 09:12, Lagos at 11:05, both with MFA. Rules stay quiet; adapID knows how each person normally works and holds the session the moment that changes.',
    to: '/adapid-ai', cta: 'How adapID catches it',
  },
];

function Copy({ s, i, dim }) {
  return (
    <div className={cx('transition-opacity duration-500', dim && 'lg:opacity-30')}>
      <p className="kicker" style={{ '--acc': s.acc }}><span className="num mr-2 opacity-60">{String(i + 1).padStart(2, '0')}</span>{s.kicker}</p>
      <p className="mt-5 text-[clamp(30px,3.2vw,44px)] font-semibold leading-[1.05] tracking-[-0.035em]" style={{ color: s.acc }}>{s.stat}</p>
      <h3 className="t-h3 mt-4 max-w-[30ch]">{s.title}</h3>
      <p className="mt-3 max-w-[46ch] text-[16.5px] leading-relaxed text-ink-2">{s.body}</p>
      <Link to={s.to} className="link mt-6" style={{ '--acc': s.acc }}>{s.cta}<Icon name="ArrowRight" size={14} weight="bold" /></Link>
    </div>
  );
}

export default function PerimeterStory() {
  const steps = useRef([]);
  const [active, setActive] = useState(0);

  useEffect(() => {
    const io = new IntersectionObserver((es) => {
      for (const e of es) if (e.isIntersecting) setActive(+e.target.dataset.i);
    }, { rootMargin: '-48% 0px -48% 0px' });
    steps.current.forEach((el) => el && io.observe(el));
    return () => io.disconnect();
  }, []);

  const go = (i) => steps.current[i]?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  const A = STEPS[active];

  return (
    <>
      {/* desktop: text scrolls, the scene stays */}
      <div className="hidden gap-14 lg:grid lg:grid-cols-[minmax(0,.78fr)_minmax(0,1.22fr)] xl:gap-20">
        <div>
          {STEPS.map((s, i) => (
            <div key={s.kicker} ref={(el) => { steps.current[i] = el; }} data-i={i} className="flex min-h-[78vh] items-center first:min-h-[60vh] last:min-h-[58vh]">
              <Copy s={s} i={i} dim={i !== active} />
            </div>
          ))}
        </div>
        <div>
          <div className="sticky top-[96px] flex h-[calc(100svh-120px)] max-h-[780px] items-center">
            <div className="scn-frame w-full">
              <div className="flex gap-2 px-5 pt-5 xl:px-6" role="tablist" aria-label="Three identities attackers use">
                {STEPS.map((s, i) => (
                  <button key={s.kicker} type="button" role="tab" aria-selected={i === active} onClick={() => go(i)} className="group flex-1 text-left">
                    <span className="block h-[3px] overflow-hidden rounded-full bg-white/10"><span className="block h-full rounded-full transition-all duration-500" style={{ width: i <= active ? '100%' : '0%', background: i === active ? s.acc : 'rgb(255 255 255 / .35)' }} /></span>
                    <span className={cx('mt-2 block text-[12.5px] font-semibold uppercase tracking-[.08em] transition-colors', i === active ? 'text-white' : 'text-white/45 group-hover:text-white/70')}>{s.kicker}</span>
                  </button>
                ))}
              </div>
              <div key={active} className="scn-swap"><A.V /></div>
            </div>
          </div>
        </div>
      </div>

      {/* phone and tablet: each step with its own scene */}
      <div className="space-y-16 lg:hidden">
        {STEPS.map((s, i) => (
          <Reveal key={s.kicker}>
            <Copy s={s} i={i} />
            <div className="scn-frame mt-8"><s.V /></div>
          </Reveal>
        ))}
      </div>
    </>
  );
}
