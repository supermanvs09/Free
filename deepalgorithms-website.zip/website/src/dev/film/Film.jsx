import { useLayoutEffect, useRef } from 'react';
import TIM from '../../../tools/film/timings.json';
import { buildScene, drawRibbons, PRESETS } from '../../components/FlowRibbons.jsx';
import { ZenGateway } from '../../components/viz/zenstra.jsx';
import { AdapRiskTimeline } from '../../components/viz/adapid.jsx';
import { CtemLoop } from '../../components/viz/botshield.jsx';
import { IcmsEvidence } from '../../components/viz/icms.jsx';
import { Gl } from '../../components/viz/kit.jsx';
import ProductMark from '../../components/ProductMark.jsx';
import { CUSTOMERS, CERTS } from '../../data/site.js';

/* The one-minute product film. Every frame is a pure function of time `t`
   (seconds): tools/film/render.mjs sets t, waits for React, steps CSS
   animations in virtual time and captures 1920x1080 frames. */

export const W = 1920, H = 1080, FPS = 30;
export const LENGTH = 61.5;
const C = Object.fromEntries(TIM.lines.map((l) => [l.id, l]));

const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const seg = (t, a, b) => clamp((t - a) / (b - a));
const ease = (x) => 1 - Math.pow(1 - x, 3);
const inout = (x) => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2);
const lerp = (a, b, x) => a + (b - a) * x;

/* ---------- shared pieces ---------- */
const SCN = {};
function Ribbons({ t, preset, accent = 'brand', intensity = 1, style }) {
  const cv = useRef(null);
  const key = `${preset}-${accent}`;
  SCN[key] ??= buildScene(PRESETS[preset], accent);
  useLayoutEffect(() => { drawRibbons(cv.current.getContext('2d'), W, H, t, SCN[key], { intensity, sat: 32 }); });
  return <canvas ref={cv} width={W} height={H} style={{ position: 'absolute', inset: 0, ...style }} />;
}

/* words light up as they are spoken, spread across the line's duration */
function Spoken({ line, t, size = 84, color = '#fff', dim = 0.16, width = 1500, align = 'center', weight = 600, words: override, part = [0, 1] }) {
  const words = (override || line.text).split(' ');
  const span = (line.end - line.start) * (part[1] - part[0]);
  const t0 = line.start + (line.end - line.start) * part[0];
  return (
    <p style={{ fontSize: size, fontWeight: weight, letterSpacing: '-0.045em', lineHeight: 1.04, maxWidth: width, textAlign: align, color, margin: align === 'center' ? '0 auto' : 0 }}>
      {words.map((w, i) => {
        const at = t0 + (i / words.length) * span * 0.92;
        const on = ease(seg(t, at - 0.05, at + 0.25));
        return <span key={i} style={{ opacity: dim + (1 - dim) * on, filter: `blur(${(1 - on) * 3}px)`, transition: 'none' }}>{w}{i < words.length - 1 ? ' ' : ''}</span>;
      })}
    </p>
  );
}

/* a picture in 3D: the camera drifts while the product works */
function Stage({ t, lt, d, children, from = [8, -20, -120], to = [5, -10, 0], width = 980, steps }) {
  const x = inout(seg(lt, 0, d));
  const rx = lerp(from[0], to[0], x), ry = lerp(from[1], to[1], x), tz = lerp(from[2], to[2], x);
  return (
    <div style={{ perspective: 2000, perspectiveOrigin: '50% 45%' }}>
      <div style={{ width, transformStyle: 'preserve-3d', transform: `translateZ(${tz}px) rotateX(${rx}deg) rotateY(${ry}deg)` }}>{children(stepAt(t, steps))}</div>
    </div>
  );
}
/* steps: array of times (s, local) when each step begins */
const stepAt = (t, steps) => (steps ? steps.filter((s) => t >= s).length : undefined);

function Pop({ t, at, z = 90, style, children }) {
  const x = ease(seg(t, at, at + 0.7));
  return <div style={{ position: 'absolute', transform: `translateZ(${z * x}px) translateY(${(1 - x) * 30}px) scale(${0.9 + 0.1 * x})`, opacity: x, ...style }}>{children}</div>;
}

const Mark = ({ size = 64, style }) => (
  <span style={{ display: 'inline-flex', width: size, height: size, borderRadius: size * 0.26, background: '#fff', padding: size * 0.16, boxShadow: '0 20px 50px -15px rgba(0,0,0,.6)', ...style }}><img src="/brand/mark.webp" alt="" style={{ width: '100%', height: '100%' }} /></span>
);

/* ---------- scenes ---------- */

/* 1. Most access no longer belongs to a person: a floor of identities turns from people to keys and agents */
function Hook({ t }) {
  const tiles = [];
  for (let r = 0; r < 7; r++) for (let c = 0; c < 14; c++) tiles.push([r, c]);
  const flip0 = C.hook.start + 1.6;
  return (
    <>
      <Ribbons t={t} preset="hero" intensity={0.55 * ease(seg(t, 0, 1.5))} style={{ opacity: 0.8 }} />
      <div style={{ position: 'absolute', left: 0, right: 0, bottom: -60, height: 620, perspective: 1200, perspectiveOrigin: '50% 0%' }}>
        <div style={{ position: 'absolute', left: '50%', top: 0, width: 2100, transformStyle: 'preserve-3d', transform: `translateX(-50%) rotateX(62deg) translateZ(${-40 + t * 14}px) translateY(${-t * 18}px)` }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(14, 1fr)', gap: 22 }}>
            {tiles.map(([r, c], i) => {
              const at = flip0 + ((c * 7 + r * 13) % 23) * 0.06;
              const f = inout(seg(t, at, at + 0.5));
              const human = (r * 3 + c) % 9 === 0;
              const g = human ? 'user' : (c + r) % 3 === 0 ? 'agent' : 'key';
              const col = f > 0.5 && !human ? (g === 'agent' ? '#aab6ff' : '#ffd27a') : '#7fd3ff';
              const show = ease(seg(t, 0.2 + r * 0.08, 1.0 + r * 0.08));
              return (
                <div key={i} style={{ height: 120, borderRadius: 22, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'linear-gradient(180deg, #181a1e, #101216)', border: `1px solid ${f > 0.5 && !human ? 'rgb(255 210 122 / .25)' : 'rgb(127 211 255 / .22)'}`, color: col, opacity: show * (0.35 + 0.65 * (1 - r / 9)), transform: `rotateY(${(human ? 0 : f) * 180}deg)` }}>
                  <span style={{ transform: `rotateY(${(human ? 0 : f) * 180}deg)` }}><Gl g={f > 0.5 ? g : 'user'} style={{ width: 52, height: 52 }} /></span>
                </div>
              );
            })}
          </div>
        </div>
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, #0a0b0e 0%, rgb(10 11 14 / .2) 45%, #0a0b0e 100%)' }} />
      </div>
      <div style={{ position: 'absolute', left: 0, right: 0, top: 250 }}>
        <Spoken line={C.hook} t={t} size={96} width={1500} />
      </div>
    </>
  );
}

/* 2. Keys and agents hold it now: one person among fifteen machine identities */
function Shift({ t }) {
  const n = 15;
  const L = C.shift;
  const groups = [['Service accounts', 'server', '#9fb4cf'], ['Cloud keys', 'key', '#ffd27a'], ['AI agents', 'agent', '#aab6ff']];
  const bad = ease(seg(t, L.start + 3.6, L.start + 4.2));
  return (
    <>
      <Ribbons t={t} preset="product" accent="brand" intensity={0.45} style={{ opacity: 0.7 }} />
      <div style={{ position: 'absolute', left: 140, top: 230, width: 760 }}>
        {groups.map(([label, g, c], i) => {
          const at = L.start + 0.2 + i * 0.75;
          const x = ease(seg(t, at, at + 0.5));
          return (
            <div key={label} style={{ display: 'flex', alignItems: 'center', gap: 22, marginBottom: 26, opacity: x, transform: `translateX(${(1 - x) * -40}px)` }}>
              <span style={{ width: 84, height: 84, borderRadius: 22, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', background: 'rgb(255 255 255 / .05)', border: '1px solid rgb(255 255 255 / .12)', color: c }}><Gl g={g} style={{ width: 44, height: 44 }} /></span>
              <span style={{ fontSize: 64, fontWeight: 600, letterSpacing: '-0.04em' }}>{label}</span>
            </div>
          );
        })}
        <p style={{ marginTop: 34, fontSize: 52, fontWeight: 600, letterSpacing: '-0.035em', color: '#ff8b7e', opacity: bad, transform: `translateY(${(1 - bad) * 20}px)` }}>And attackers have noticed.</p>
      </div>
      <div style={{ position: 'absolute', right: 150, top: 150, width: 780, height: 780, perspective: 1600 }}>
        <div style={{ position: 'absolute', inset: 0, transformStyle: 'preserve-3d', transform: `rotateX(${14 - t * 0.6}deg) rotateY(${-18 + t * 2.2}deg)` }}>
          {Array.from({ length: n }, (_, i) => {
            const a = (i / n) * Math.PI * 2, rr = i % 2 ? 250 : 320, z = ((i * 53) % 7 - 3) * 40;
            const at = L.start + 0.3 + i * 0.12;
            const x = ease(seg(t, at, at + 0.7));
            const g = i % 3 === 0 ? 'agent' : i % 3 === 1 ? 'key' : 'server';
            const red = bad > 0.5 && i % 4 === 1;
            return (
              <div key={i} style={{ position: 'absolute', left: 390 + Math.cos(a) * rr * x - 34, top: 390 + Math.sin(a) * rr * x - 34, width: 68, height: 68, borderRadius: 20, display: 'flex', alignItems: 'center', justifyContent: 'center', background: red ? 'rgb(255 107 93 / .18)' : '#15171b', border: `1px solid ${red ? 'rgb(255 107 93 / .6)' : 'rgb(160 190 230 / .2)'}`, color: red ? '#ff8b7e' : g === 'agent' ? '#aab6ff' : g === 'key' ? '#ffd27a' : '#9fb4cf', opacity: x, transform: `translateZ(${z}px)`, boxShadow: red ? '0 0 30px rgb(255 107 93 / .45)' : 'none' }}>
                <Gl g={g} style={{ width: 34, height: 34 }} />
              </div>
            );
          })}
          <div style={{ position: 'absolute', left: 390 - 70, top: 390 - 70, width: 140, height: 140, borderRadius: 140, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgb(0 174 239 / .14)', border: '2px solid rgb(0 174 239 / .55)', color: '#7fd3ff', boxShadow: '0 0 60px rgb(0 174 239 / .35)' }}><Gl g="user" style={{ width: 64, height: 64 }} /></div>
        </div>
        <p style={{ position: 'absolute', left: 0, right: 0, bottom: -20, textAlign: 'center', fontSize: 26, color: '#bdbfc3', opacity: ease(seg(t, L.start + 2, L.start + 2.6)) }}><b style={{ color: '#fff', fontSize: 40 }}>15</b> machine identities for every person</p>
      </div>
    </>
  );
}

/* 3. They log in: two sign-ins, both pass MFA, and the alert count stays at zero */
function Login({ t }) {
  const L = C.login;
  const card = (city, dev, time, at, bad) => {
    const x = ease(seg(t, at, at + 0.6));
    const flag = bad && t > L.start + 2.6;
    return (
      <div style={{ width: 560, padding: '26px 30px', borderRadius: 26, background: 'linear-gradient(180deg, #191b1f, #101216)', border: `1px solid ${flag ? 'rgb(255 107 93 / .45)' : 'rgb(160 190 230 / .16)'}`, boxShadow: '0 50px 100px -40px rgba(0,0,0,.9)', opacity: x, transform: `translateY(${(1 - x) * 40}px)` }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
          <span style={{ width: 64, height: 64, borderRadius: 64, background: '#ffd27a', color: '#0e1014', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 24 }}>KR</span>
          <span><span style={{ display: 'block', fontSize: 30, fontWeight: 600 }}>Kavya Reddy · {city}</span><span style={{ display: 'block', fontSize: 22, color: '#9ea0a4' }}>{dev}</span></span>
          <span style={{ marginLeft: 'auto', fontFamily: 'JetBrains Mono Variable, monospace', fontSize: 22, color: '#b2b4b8' }}>{time}</span>
        </div>
        <div style={{ display: 'flex', gap: 12, marginTop: 22 }}>
          <span style={{ padding: '8px 16px', borderRadius: 99, background: 'rgb(63 217 143 / .12)', color: '#4be29a', fontSize: 20, fontWeight: 600 }}>✓ MFA passed</span>
          <span style={{ padding: '8px 16px', borderRadius: 99, background: 'rgb(63 217 143 / .12)', color: '#4be29a', fontSize: 20, fontWeight: 600 }}>✓ Signed in</span>
        </div>
      </div>
    );
  };
  return (
    <>
      <Ribbons t={t} preset="band" intensity={0.35} style={{ opacity: 0.6 }} />
      <div style={{ position: 'absolute', left: 0, right: 0, top: 120 }}>
        <Spoken line={C.login} t={t} size={80} width={1500} words="They don’t break in anymore. They log in." part={[0, 8 / 13]} />
      </div>
      <div style={{ position: 'absolute', left: 0, right: 0, top: 470, display: 'flex', justifyContent: 'center', gap: 60, perspective: 1800 }}>
        <div style={{ transform: `rotateY(${16 - t * 0.6}deg) rotateX(6deg)` }}>{card('Mumbai', 'Managed laptop', '09:12', L.start + 1.0, false)}</div>
        <div style={{ transform: `rotateY(${-16 + t * 0.6}deg) rotateX(6deg)` }}>{card('Lagos', 'New device', '11:05', L.start + 1.6, true)}</div>
      </div>
      <div style={{ position: 'absolute', left: 0, right: 0, top: 820, textAlign: 'center', opacity: ease(seg(t, L.start + 2.6, L.start + 3.2)) }}>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 16, padding: '16px 30px', borderRadius: 99, border: '1px solid rgb(148 170 200 / .25)', background: 'rgb(255 255 255 / .04)', fontSize: 30, color: '#d5d7db' }}>
          <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="#94969a" strokeWidth="1.8" aria-hidden="true"><path d="M6 8a6 6 0 1 1 12 0c0 7 3 8 3 8H3s3-1 3-8M10 20a2 2 0 0 0 4 0" /><path d="M3 3l18 18" /></svg>
          Alerts raised: <b style={{ color: '#fff', fontSize: 38 }}>0</b>
        </span>
      </div>
    </>
  );
}

/* 4. Deep Algorithms catches them: the brand tile opens, then sends out four products */
function Brand({ t, d }) {
  const L = C.brand;
  const a = ease(seg(t, L.start - 0.6, L.start)), open = inout(seg(t, L.start - 0.1, L.start + 0.8)), close = inout(seg(t, L.end + 0.15, L.end + 0.75));
  const w = lerp(lerp(120, 1500, open), 140, close), h = lerp(lerp(120, 640, open), 140, close);
  const prods = [['Zenstra AI', '#93a2ff', -1, -1, 'zenstra'], ['adapID AI', '#3cc8f6', 1, -1, 'adapid'], ['BotShield AI', '#34e0c3', -1, 1, 'botshield'], ['ICMS Compliance Suite', '#f4c76c', 1, 1, 'icms']];
  const out = ease(seg(t, L.end + 0.5, L.end + 1.1));
  return (
    <>
      <Ribbons t={t} preset="band" intensity={0.6 * a} />
      <div style={{ position: 'absolute', left: W / 2 - w / 2, top: H / 2 - h / 2 + (1 - a) * 200, width: w, height: h, borderRadius: lerp(34, 40, open) * (1 - close) + 36 * close, overflow: 'hidden', opacity: a, background: 'linear-gradient(135deg, #0068ac 0%, #0a7fcf 55%, #169fe6 100%)', boxShadow: `0 0 ${60 + 80 * open}px rgb(0 140 220 / .28)` }}>
        <div style={{ position: 'absolute', inset: 0, opacity: 0.18, backgroundImage: 'radial-gradient(rgb(255 255 255 / .55) 1.5px, transparent 1.5px)', backgroundSize: '30px 30px' }} />
        <div style={{ position: 'absolute', left: '50%', top: lerp(h / 2, 90, open * (1 - close)), transform: 'translate(-50%, -50%)' }}><Mark size={lerp(70, 84, open)} /></div>
        <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', paddingTop: 70, opacity: open * (1 - seg(t, L.end + 0.05, L.end + 0.35)) }}>
          <p style={{ fontSize: 44, fontWeight: 600, letterSpacing: '-0.03em', color: 'rgb(255 255 255 / .85)' }}>Deep Algorithms</p>
          <div style={{ marginTop: 14 }}><Spoken line={L} t={t} size={92} width={1300} words="catches them before they act." dim={0.25} part={[2 / 7, 1]} /></div>
        </div>
      </div>
      {prods.map(([n, c, sx, sy, k], i) => (
        <div key={n} style={{ position: 'absolute', left: W / 2 + sx * 540 * out - 230, top: H / 2 + sy * 270 * out - 56, width: 460, height: 112, borderRadius: 26, display: 'flex', alignItems: 'center', gap: 20, padding: '0 26px', background: '#121418', border: `1px solid ${c}55`, opacity: out, boxShadow: `0 0 40px ${c}33` }}>
          <ProductMark p={k} size={68} loading="eager" />
          <span style={{ fontSize: 30, fontWeight: 600 }}>{n}</span>
        </div>
      ))}
    </>
  );
}

/* 5–8. Each product, at work */
function Product({ t, d, line, acc, accent, mark, name, head, children, popAt, pop }) {
  const L = line;
  const tIn = ease(seg(t, L.start - 0.5, L.start + 0.3));
  return (
    <>
      <Ribbons t={t} preset="product" accent={accent} intensity={0.75} />
      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(90deg, rgb(10 11 14 / .85) 0%, rgb(10 11 14 / .35) 45%, transparent 70%)' }} />
      <div style={{ position: 'absolute', left: 130, top: 330, width: 650, opacity: tIn, transform: `translateY(${(1 - tIn) * 30}px)` }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 22 }}>
          <span style={{ width: 104, height: 104, borderRadius: 28, display: 'grid', placeItems: 'center', background: 'rgb(255 255 255 / .06)', border: '1px solid rgb(148 170 200 / .25)', boxShadow: `0 0 60px -16px ${acc}` }}><ProductMark p={mark} size={72} loading="eager" /></span>
          <span><span style={{ display: 'block', fontSize: 36, fontWeight: 600, letterSpacing: '-0.02em' }}>{name[0]}</span><span style={{ display: 'block', marginTop: 4, fontSize: 23, color: '#b2b4b8' }}>{name[1]}</span></span>
        </div>
        <h2 style={{ marginTop: 40, fontSize: 70, fontWeight: 600, letterSpacing: '-0.045em', lineHeight: 1.04 }}>{head}</h2>
      </div>
      <div style={{ position: 'absolute', right: 110, top: 150 }}>{children}</div>
      {pop && <div style={{ position: 'absolute', right: 120, bottom: 120 }}>{pop}</div>}
    </>
  );
}

function Zen({ t, lt, d }) {
  const s = C.zenstra.start;
  return (
    <Product t={t} d={d} line={C.zenstra} acc="#93a2ff" accent="zen" mark="zenstra" name={['Zenstra AI', 'Security for AI agents']} head={<>Every agent action, <span style={{ color: '#aab6ff' }}>checked before it runs.</span></>}>
      <Stage t={t} lt={lt} d={d} width={960} steps={[s - 0.2, s + 0.6, s + 1.6, s + 2.6, s + 3.6, s + 4.8]}>
        {(k) => <div style={{ position: 'relative' }}><ZenGateway k={k} />
          <Pop t={t} at={s + 2.8} z={120} style={{ left: -170, bottom: -70, width: 420 }}>
            <div className="vz-pop" style={{ padding: '20px 24px', '--glow': 'rgb(255 107 93 / .55)' }}>
              <p style={{ fontSize: 17, fontWeight: 700, letterSpacing: '.08em', color: '#ff7d70' }}>BLOCKED · 4 MS</p>
              <p style={{ marginTop: 6, fontSize: 22, fontWeight: 600 }}>invoice-agent → salesforce.export</p>
              <p style={{ fontSize: 18, color: '#9ea0a4' }}>Outside its declared task</p>
            </div>
          </Pop>
        </div>}
      </Stage>
    </Product>
  );
}
function Adap({ t, lt, d }) {
  const s = C.adapid.start;
  return (
    <Product t={t} d={d} line={C.adapid} acc="#3cc8f6" accent="adap" mark="adapid" name={['adapID AI', 'People and machine identities']} head={<>A valid login. <span style={{ color: '#7fdcff' }}>The wrong person.</span></>}>
      <Stage t={t} lt={lt} d={d} width={940} from={[10, -18, -140]} to={[6, -9, 0]} steps={[s - 0.3, s + 0.5, s + 1.5, s + 2.5, s + 3.5, s + 4.5, s + 5.4]}>
        {(k) => <AdapRiskTimeline k={k} />}
      </Stage>
    </Product>
  );
}
function Bot({ t, lt, d }) {
  const s = C.botshield.start;
  return (
    <Product t={t} d={d} line={C.botshield} acc="#34e0c3" accent="bot" mark="botshield" name={['BotShield AI', 'Apps, APIs and the edge']} head={<>Thousands of findings. <span style={{ color: '#7ff0dc' }}>The six that matter.</span></>}>
      <Stage t={t} lt={lt} d={d} width={960} from={[12, -16, -120]} to={[7, -8, 0]} steps={[s - 0.3, s + 0.5, s + 1.4, s + 2.4, s + 3.4]}>
        {(k) => <CtemLoop k={k} />}
      </Stage>
    </Product>
  );
}
function Icms({ t, lt, d }) {
  const s = C.icms.start;
  return (
    <Product t={t} d={d} line={C.icms} acc="#f4c76c" accent="icms" mark="icms" name={['ICMS Compliance Suite', 'DPDPA compliance']} head={<>Every access to personal data, <span style={{ color: '#ffd98f' }}>turned into evidence.</span></>}>
      <Stage t={t} lt={lt} d={d} width={960} from={[9, -18, -120]} to={[6, -9, 0]} steps={[s - 0.3, s + 0.5, s + 1.3, s + 2.2, s + 3.4, s + 4.3, s + 5.2]}>
        {(k) => <IcmsEvidence k={k} />}
      </Stage>
    </Product>
  );
}

/* 9. Built in India, trusted by banks, government and enterprises */
function Trust({ t }) {
  const L = C.trust;
  return (
    <>
      <Ribbons t={t} preset="band" intensity={0.45} style={{ opacity: 0.7 }} />
      <div style={{ position: 'absolute', left: 0, right: 0, top: 150 }}><Spoken line={L} t={t} size={78} width={1500} /></div>
      <div style={{ position: 'absolute', left: 180, right: 180, top: 420, display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 22, perspective: 1600 }}>
        {CUSTOMERS.slice(0, 12).map(([k, n], i) => {
          const at = L.start + 0.4 + i * 0.12;
          const x = ease(seg(t, at, at + 0.6));
          return (
            <div key={k} style={{ height: 130, borderRadius: 22, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgb(255 255 255 / .035)', border: '1px solid rgb(160 190 230 / .12)', opacity: x, transform: `rotateX(${(1 - x) * -50}deg) translateY(${(1 - x) * 30}px)` }}>
              <img src={`/img/logos/${k}-white.webp`} alt={n} style={{ maxHeight: 56, maxWidth: 190, objectFit: 'contain', opacity: 0.85 }} />
            </div>
          );
        })}
      </div>
      <div style={{ position: 'absolute', left: 0, right: 0, top: 790, display: 'flex', justifyContent: 'center', gap: 16, opacity: ease(seg(t, L.start + 2.2, L.start + 2.8)) }}>
        {CERTS.map((c) => <span key={c.code} style={{ padding: '12px 22px', borderRadius: 99, border: '1px solid rgb(148 170 200 / .25)', fontSize: 24, color: '#d5d7db' }}>{c.name}</span>)}
      </div>
    </>
  );
}

/* 10. See it on your own identities */
function Cta({ t }) {
  const L = C.cta;
  const x = ease(seg(t, L.start - 0.3, L.start + 0.6));
  const fadeOut = 1 - seg(t, LENGTH - 1.4, LENGTH - 0.2);
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: fadeOut }}>
      <Ribbons t={t} preset="band" intensity={0.9} />
      <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(55% 60% at 50% 50%, rgb(10 11 14 / .55), transparent 75%)' }} />
      <div style={{ position: 'absolute', left: 0, right: 0, top: 250, textAlign: 'center', opacity: x, transform: `translateY(${(1 - x) * 30}px)` }}>
        <img src="/brand/logo-lockup-inverse.webp" alt="Deep Algorithms" style={{ height: 70, margin: '0 auto' }} />
        <div style={{ marginTop: 70 }}><Spoken line={L} t={t} size={96} width={1400} words="See it on your own identities." dim={0.2} part={[0, 6 / 11]} /></div>
        <div style={{ marginTop: 60, display: 'inline-flex', alignItems: 'center', gap: 22, opacity: ease(seg(t, L.start + 2.2, L.start + 2.8)) }}>
          <span style={{ height: 76, padding: '0 38px', display: 'inline-flex', alignItems: 'center', borderRadius: 99, background: '#0a6dbb', color: '#fff', fontSize: 30, fontWeight: 600 }}>Book a demo</span>
          <span style={{ fontSize: 34, color: '#d5d7db', fontWeight: 500 }}>deepalgorithms.io</span>
        </div>
      </div>
    </div>
  );
}

/* scene list: [component, start, end] with crossfades at the seams */
export const SCENES = [
  [Hook, 0, C.shift.start - 0.2],
  [Shift, C.shift.start - 0.35, C.login.start - 0.2],
  [Login, C.login.start - 0.35, C.brand.start - 0.55],
  [Brand, C.brand.start - 0.7, C.zenstra.start - 0.25],
  [Zen, C.zenstra.start - 0.4, C.adapid.start - 0.25],
  [Adap, C.adapid.start - 0.4, C.botshield.start - 0.25],
  [Bot, C.botshield.start - 0.4, C.icms.start - 0.25],
  [Icms, C.icms.start - 0.4, C.trust.start - 0.25],
  [Trust, C.trust.start - 0.4, C.cta.start - 0.25],
  [Cta, C.cta.start - 0.4, LENGTH],
];
const XF = 0.45;

export default function Film({ t }) {
  return (
    <div className="film" style={{ position: 'relative', width: W, height: H, overflow: 'hidden', background: 'radial-gradient(110% 70% at 50% -20%, #16181d 0%, #0a0b0e 60%)', color: '#f2f3f5', fontFamily: 'Inter Variable, sans-serif' }}>
      {SCENES.map(([S, a, b], i) => {
        if (t < a || t > b) return null;
        const o = Math.min(seg(t, a, a + XF), 1 - seg(t, b - XF, b));
        const z = i === 0 ? 1 : lerp(1.03, 1, ease(seg(t, a, a + 0.9)));
        return <div key={i} style={{ position: 'absolute', inset: 0, opacity: i === 0 ? Math.min(1, 1 - seg(t, b - XF, b)) : o, transform: `scale(${z})` }}><S t={t} lt={t - a} d={b - a} /></div>;
      })}
    </div>
  );
}
