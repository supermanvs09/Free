import { createRoot } from 'react-dom/client';
import '../styles.css';
import '../components/viz/viz.css';
import { HeroActivity } from '../components/viz/home.jsx';
import { ZenGateway, ZenInventory, ZenGrant, ZenMcp, ZenDetect, ZenRecord, ZenApproval } from '../components/viz/zenstra.jsx';
import { AdapRiskTimeline, NhiGraph, RiskScoreCard, AdPath, IdentityGraph, AdTierGraph } from '../components/viz/adapid.jsx';
import { CtemLoop } from '../components/viz/botshield.jsx';
import { IdentityUniverse } from '../components/scenes/identity.jsx';
import { LoginGlobe } from '../components/scenes/login.jsx';
import { EdgeShield } from '../components/scenes/ddos.jsx';
import { MoneyTrail } from '../components/scenes/money.jsx';
import { AgentBoundary } from '../components/scenes/agent.jsx';
import { ProofField } from '../components/scenes/proof.jsx';
import { BotStream } from '../components/scenes/bots.jsx';
import { IcmsEvidence, DataMap, BreachClock } from '../components/viz/icms.jsx';
const ALL = { BotStream, ProofField, AgentBoundary, IdentityUniverse, LoginGlobe, EdgeShield, MoneyTrail, IdentityGraph, AdTierGraph, HeroActivity, ZenGateway, ZenInventory, ZenGrant, ZenMcp, ZenDetect, ZenRecord, ZenApproval, AdapRiskTimeline, NhiGraph, RiskScoreCard, AdPath, CtemLoop, IcmsEvidence, DataMap, BreachClock };
const q = new URLSearchParams(location.search);
const only = q.get('v') ? q.get('v').split(',') : Object.keys(ALL);
const w = q.get('w') || '620';
createRoot(document.getElementById('root')).render(
  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 40, padding: 40 }}>
    {only.map((n) => { const C = ALL[n]; return <div key={n} style={{ width: +w }} data-v={n}><p style={{ color: '#8a97aa', fontSize: 12, marginBottom: 8 }}>{n}</p><C /></div>; })}
  </div>,
);
