import { createRoot } from 'react-dom/client';
import '../styles.css';
import '../components/viz/viz.css';
import { HeroActivity, AgentOverreach, KeySprawl, LegitLogin } from '../components/viz/home.jsx';
import { ZenGateway, ZenInventory, ZenGrant, ZenMcp, ZenDetect, ZenRecord } from '../components/viz/zenstra.jsx';
import { AdapRiskTimeline, NhiGraph, FraudDecision, MuleNetwork, AdPath } from '../components/viz/adapid.jsx';
import { CtemLoop, BotIntent, DdosEdge } from '../components/viz/botshield.jsx';
import { IcmsEvidence, DataMap, BreachClock } from '../components/viz/icms.jsx';
const ALL = { HeroActivity, AgentOverreach, KeySprawl, LegitLogin, ZenGateway, ZenInventory, ZenGrant, ZenMcp, ZenDetect, ZenRecord, AdapRiskTimeline, NhiGraph, FraudDecision, MuleNetwork, AdPath, CtemLoop, BotIntent, DdosEdge, IcmsEvidence, DataMap, BreachClock };
const q = new URLSearchParams(location.search);
const only = q.get('v') ? q.get('v').split(',') : Object.keys(ALL);
const w = q.get('w') || '620';
createRoot(document.getElementById('root')).render(
  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 40, padding: 40 }}>
    {only.map((n) => { const C = ALL[n]; return <div key={n} style={{ width: +w }} data-v={n}><p style={{ color: '#8a97aa', fontSize: 12, marginBottom: 8 }}>{n}</p><C /></div>; })}
  </div>,
);
