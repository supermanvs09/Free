import { test, expect } from '@playwright/test';

test('product menu: each product line with its own logo; adapID lists four products, the platforms list what they cover', async ({ page, isMobile }) => {
  test.skip(isMobile, 'desktop menu');
  await page.goto('/');
  await page.getByRole('button', { name: 'Products' }).click();
  const mega = page.locator('#mega');
  await expect(mega).toBeVisible();
  // the only pictures are the four product logos
  const logos = mega.locator('img');
  await expect(logos).toHaveCount(4);
  for (const src of await logos.evaluateAll((els) => els.map((e) => e.getAttribute('src')))) expect(src).toMatch(/^\/brand\/products\/(zenstra|adapid|botshield|icms)\.webp$/);
  for (const name of ['Identity Risk Management', 'NHI Security for AWS', 'Identity Fraud Prevention', 'Active Directory Security']) await expect(mega.getByRole('link', { name: new RegExp(name) })).toBeVisible();
  await expect(mega.getByText('What it covers')).toHaveCount(3);
  await expect(mega.getByText('4 products')).toHaveCount(0);
  await page.keyboard.press('Escape');
  await expect(mega).toBeHidden();
});

test('every menu opens and carries no pictures', async ({ page, isMobile }) => {
  test.skip(isMobile, 'desktop menu');
  await page.goto('/');
  for (const label of ['Solutions', 'Research', 'Company']) {
    await page.getByRole('button', { name: label }).hover();
    await expect(page.locator('#mega')).toBeVisible();
    await expect(page.locator('#mega img')).toHaveCount(0);
  }
});

test('the phone menu opens, navigates and closes', async ({ page, isMobile }) => {
  test.skip(!isMobile, 'phone menu');
  await page.goto('/');
  await page.getByRole('button', { name: 'Open menu' }).click();
  const menu = page.locator('#mobile-menu');
  await expect(menu).toBeVisible();
  await menu.getByRole('link', { name: 'NHI Security for AWS' }).click();
  await expect(page).toHaveURL(/nhi-security/);
  await expect(menu).toBeHidden();
});

test('research topics in the menu land on a filtered list', async ({ page }) => {
  await page.goto('/blogs?topic=bot-defence');
  await expect(page.getByRole('heading', { name: '2 results' })).toBeVisible();
  await page.getByLabel('Search the research').fill('mule');
  await page.getByRole('button', { name: 'Clear filters' }).click();
  await expect(page.getByRole('heading', { name: 'All research' })).toBeVisible();
});
