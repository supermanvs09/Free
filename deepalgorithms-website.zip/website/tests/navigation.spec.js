import { test, expect } from '@playwright/test';
import { hydrated } from './helpers.js';

test('product menu: the four platforms, the four adapID products and the tools they work with', async ({ page, isMobile }) => {
  test.skip(isMobile, 'desktop menu');
  await page.goto('/');
  await page.getByRole('button', { name: 'Products' }).click();
  const mega = page.locator('#mega');
  await expect(mega).toBeVisible();
  // the only images are the four product logos; the brand marks are drawn inline
  const logos = mega.locator('img');
  await expect(logos).toHaveCount(4);
  for (const src of await logos.evaluateAll((els) => els.map((e) => e.getAttribute('src')))) expect(src).toMatch(/^\/brand\/products\/(zenstra|adapid|botshield|icms)\.webp$/);
  for (const name of ['Zenstra AI', 'BotShield AI', 'ICMS Compliance Suite', 'Identity Risk Management', 'NHI Security for AWS', 'Identity Fraud Prevention', 'Active Directory Security']) await expect(mega.getByRole('link', { name: new RegExp(name) })).toBeVisible();
  await expect(mega.getByText('Works with')).toBeVisible();
  await expect(mega.getByRole('img', { name: 'AWS' })).toBeVisible();
  await page.keyboard.press('Escape');
  await expect(mega).toBeHidden();
});

test('only Products and Solutions open a menu, with no arrows; the rest are plain links', async ({ page, isMobile }) => {
  test.skip(isMobile, 'desktop menu');
  await page.goto('/');
  const nav = page.getByRole('navigation', { name: 'Primary' });
  await expect(nav.getByRole('button')).toHaveCount(2);
  await expect(nav.locator('svg')).toHaveCount(0);
  await nav.getByRole('button', { name: 'Solutions' }).hover();
  await expect(page.locator('#mega')).toBeVisible();
  await expect(page.locator('#mega img')).toHaveCount(0);
  for (const [name, href] of [['Why Deep Algorithms', '/why-deep-algorithms'], ['Research', '/blogs'], ['Trust center', '/trust']]) await expect(nav.getByRole('link', { name })).toHaveAttribute('href', href);
});

test('the phone menu rises from the bottom bar, navigates and closes', async ({ page, isMobile }) => {
  test.skip(!isMobile, 'phone menu');
  await page.goto('/');
  await hydrated(page);
  await page.getByRole('navigation', { name: 'Quick actions' }).getByRole('button', { name: 'Menu' }).click();
  const menu = page.locator('#mobile-menu');
  await expect(menu).toBeVisible();
  await menu.getByRole('link', { name: 'NHI Security for AWS' }).click();
  await expect(page).toHaveURL(/nhi-security/);
  await expect(menu).toBeHidden();
});

test('research topics in the menu land on a filtered list', async ({ page }) => {
  await page.goto('/blogs?topic=bot-defence');
  await expect(page.getByRole('heading', { name: '2 results' })).toBeVisible();
  await page.getByLabel('Search the research').fill('mule');
  await page.getByRole('button', { name: 'Clear filters' }).click();
  await expect(page.getByRole('heading', { name: 'All research' })).toBeVisible();
});

test('the old company and Why addresses lead to Why Deep Algorithms', async ({ page }) => {
  for (const old of ['/about-us', '/platform']) {
    await page.goto(old);
    await expect(page).toHaveURL(/\/why-deep-algorithms$/);
    await expect(page.getByRole('heading', { level: 1 })).toHaveText('The defence has to be as intelligent as the attack.');
  }
});
