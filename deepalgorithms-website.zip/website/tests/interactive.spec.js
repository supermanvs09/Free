import { test, expect } from '@playwright/test';
import { hydrated } from './helpers.js';

test('home: the platform lists the four products, each with its own page', async ({ page }) => {
  await page.goto('/');
  await hydrated(page);
  const section = page.locator('#platform');
  await section.scrollIntoViewIfNeeded();
  for (const name of ['adapID AI', 'Zenstra AI', 'BotShield AI', 'ICMS Compliance Suite']) await expect(section.getByRole('link', { name: `Explore ${name}` })).toHaveAttribute('href', /\//);
});

test('home: the role tabs switch by click and by arrow keys', async ({ page }) => {
  await page.goto('/');
  await hydrated(page);
  const tab = page.getByRole('tab', { name: 'Compliance and DPO' });
  await tab.scrollIntoViewIfNeeded();
  await tab.click();
  await expect(tab).toHaveAttribute('aria-selected', 'true');
  await expect(page.locator('#role-panel')).toContainText('DPDPA');
  await page.keyboard.press('ArrowRight');
  await expect(page.getByRole('tab', { name: 'Fraud and digital banking' })).toHaveAttribute('aria-selected', 'true');
});

test('reduced motion still shows every product card and figure', async ({ page }) => {
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.goto('/');
  await hydrated(page);
  await expect(page.locator('#platform').getByRole('link', { name: /^Explore / })).toHaveCount(4);
  await expect(page.getByText('₹25.5 Cr').first()).toBeVisible();
});

test('zenstra: the switch turns the agent’s life from without to with', async ({ page }) => {
  await page.goto('/agentic-ai/agentic-identity');
  await hydrated(page);
  const sw = page.getByRole('switch', { name: 'Zenstra' });
  await sw.scrollIntoViewIfNeeded();
  await expect(sw).toHaveAttribute('aria-checked', 'true', { timeout: 5000 }); // turns itself on once seen
  await sw.click();
  await expect(sw).toHaveAttribute('aria-checked', 'false');
  await expect(page.getByText('without Zenstra', { exact: true })).toBeVisible();
});

test('botshield: the red-team scene plays and names the six proven findings', async ({ page }) => {
  await page.goto('/botshield-ai');
  await hydrated(page);
  const scene = page.getByRole('img', { name: /37 possible findings/ });
  await scene.scrollIntoViewIfNeeded();
  await expect(scene.locator('canvas')).toBeVisible();
  // the names arrive as the blue-team agent patches each one
  await expect(scene.getByText('Old TLS on a partner gateway')).toBeVisible({ timeout: 12000 });
});

test('a hero takes the reader into the page instead of repeating Book a demo', async ({ page }) => {
  await page.goto('/adapid-ai/nhi-security');
  await hydrated(page);
  await expect(page.locator('main section').first().getByRole('link', { name: 'Book a demo' })).toHaveCount(0);
  await page.getByRole('button', { name: 'See how it works' }).click();
  await expect.poll(() => page.evaluate(() => window.scrollY)).toBeGreaterThan(300);
});

test('home: the pinned picture follows the story as you scroll', async ({ page, isMobile }) => {
  test.skip(isMobile, 'on a phone each step carries its own picture');
  await page.goto('/');
  await hydrated(page);
  const tab = (name) => page.getByRole('tab', { name });
  await page.locator('[data-i="1"]').evaluate((el) => el.scrollIntoView({ block: 'center', behavior: 'instant' }));
  await expect(tab('Machine identities')).toHaveAttribute('aria-selected', 'true');
  await page.locator('[data-i="2"]').evaluate((el) => el.scrollIntoView({ block: 'center', behavior: 'instant' }));
  await expect(tab('People')).toHaveAttribute('aria-selected', 'true');
  await expect(page.getByRole('link', { name: 'How adapID catches it' }).first()).toBeVisible();
});

test('home: the logo moment ends on the four products in a line, each linked', async ({ page }) => {
  await page.goto('/');
  await hydrated(page);
  const orbit = page.locator('#orbit');
  await orbit.scrollIntoViewIfNeeded();
  await expect(orbit.getByRole('img', { name: /mark rises in/ })).toBeVisible();
  for (const [name, href] of [['Zenstra AI', '/agentic-ai/agentic-identity'], ['adapID AI', '/adapid-ai'], ['BotShield AI', '/botshield-ai'], ['ICMS Compliance Suite', '/dpdpa-compliance']]) {
    await expect(orbit.getByRole('link', { name: new RegExp(name) })).toHaveAttribute('href', href);
  }
});
