import { test, expect } from '@playwright/test';
import { hydrated } from './helpers.js';

test('home: the platform explorer shows each of the four products, each with its own page', async ({ page, isMobile }) => {
  test.skip(isMobile, 'phones get the accordion');
  await page.goto('/');
  await hydrated(page);
  const section = page.locator('#platform');
  await section.scrollIntoViewIfNeeded();
  for (const name of ['adapID AI', 'Zenstra AI', 'BotShield AI', 'ICMS Compliance Suite']) {
    await section.getByRole('tab', { name: new RegExp(`^${name}`) }).click();
    await expect(section.getByRole('link', { name: `Explore ${name}` })).toHaveAttribute('href', /\//);
  }
  await section.getByRole('tab', { name: /^Zenstra AI/ }).focus();
  await page.keyboard.press('ArrowDown');
  await expect(section.getByRole('tab', { name: /^BotShield AI/ })).toHaveAttribute('aria-selected', 'true');
});

test('home: the role tabs switch by click and by arrow keys', async ({ page }) => {
  await page.goto('/');
  await hydrated(page);
  const tab = page.getByRole('tab', { name: 'Compliance and DPO' });
  await tab.scrollIntoViewIfNeeded();
  await tab.click();
  await expect(tab).toHaveAttribute('aria-selected', 'true');
  await expect(page.locator('#role-panel')).toContainText('DPDPA');
  await page.keyboard.press('ArrowRight');
  await expect(page.getByRole('tab', { name: 'Fraud and digital banking' })).toHaveAttribute('aria-selected', 'true');
});

test('reduced motion still shows every product card and figure', async ({ page }) => {
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.goto('/');
  await hydrated(page);
  await expect(page.locator('#platform').getByRole('tab')).toHaveCount(4);
  await expect(page.getByText('₹25.5 Cr').first()).toBeVisible();
});

test('zenstra: before and after sit side by side, five moments each', async ({ page }) => {
  await page.goto('/agentic-ai/agentic-identity');
  const sec = page.locator('section:has(#chg-h)');
  await expect(sec.getByText('Without Zenstra', { exact: true })).toBeVisible();
  await expect(sec.getByText('With Zenstra', { exact: true })).toBeVisible();
  await expect(sec.locator('.chg-with li')).toHaveCount(5);
  await expect(sec.locator('.chg-without li')).toHaveCount(5);
});

test('botshield: the red-team scene plays and names the six proven findings', async ({ page }) => {
  await page.goto('/botshield-ai');
  await hydrated(page);
  const scene = page.getByRole('img', { name: /37 possible findings/ });
  await scene.scrollIntoViewIfNeeded();
  await expect(scene.locator('canvas')).toBeVisible();
  // the names arrive as the blue-team agent patches each one
  await expect(scene.getByText('Old TLS on a partner gateway')).toBeVisible({ timeout: 12000 });
});

test('a hero takes the reader into the page instead of repeating Book a demo', async ({ page }) => {
  await page.goto('/adapid-ai/nhi-security');
  await hydrated(page);
  await expect(page.locator('main section').first().getByRole('link', { name: 'Book a demo' })).toHaveCount(0);
  await page.getByRole('button', { name: 'See how it works' }).click();
  await expect.poll(() => page.evaluate(() => window.scrollY)).toBeGreaterThan(300);
});

test('home: the pinned picture follows the story as you scroll', async ({ page, isMobile }) => {
  test.skip(isMobile, 'on a phone each step carries its own picture');
  await page.goto('/');
  await hydrated(page);
  const tab = (name) => page.getByRole('tab', { name, exact: true });
  await page.locator('[data-i="1"]').evaluate((el) => el.scrollIntoView({ block: 'center', behavior: 'instant' }));
  await expect(tab('Machine identities')).toHaveAttribute('aria-selected', 'true');
  await page.locator('[data-i="2"]').evaluate((el) => el.scrollIntoView({ block: 'center', behavior: 'instant' }));
  await expect(tab('People')).toHaveAttribute('aria-selected', 'true');
  await expect(page.getByRole('link', { name: 'How adapID catches it' }).first()).toBeVisible();
});

test('home: the logo moment ends on the four products in a line, each linked', async ({ page }) => {
  await page.goto('/');
  await hydrated(page);
  const orbit = page.locator('#orbit');
  await orbit.scrollIntoViewIfNeeded();
  await expect(orbit.getByRole('heading', { name: 'Identity security for the AI era.' })).toBeVisible();
  await expect(orbit.getByRole('img', { name: /mark lands at the centre/ })).toBeVisible();
  for (const [name, href] of [['Zenstra AI', '/agentic-ai/agentic-identity'], ['adapID AI', '/adapid-ai'], ['BotShield AI', '/botshield-ai'], ['ICMS Compliance Suite', '/dpdpa-compliance']]) {
    await expect(orbit.getByRole('link', { name: new RegExp(name) })).toHaveAttribute('href', href);
  }
});

test('home: the hero scene plays, can be paused, and tells the whole story to screen readers', async ({ page }) => {
  await page.goto('/');
  const hero = page.locator('figure.th');
  await expect(hero).toHaveAttribute('aria-label', /attacker.*AI agent.*blown away as dust.*next attempt/);
  await expect(hero).toHaveAttribute('data-phase', /alert|claim|scan|verdict|dust/, { timeout: 8000 });
  // no product names in the hero
  await expect(page.locator('section[aria-labelledby="hero-h"]')).not.toContainText(/adapID|Zenstra|BotShield|ICMS/);
  await hero.getByRole('button', { name: 'Pause the animation' }).click();
  await expect(hero.getByRole('button', { name: 'Play the animation' })).toBeVisible();
});

test('every hero rolls the customer logos, with a pause control', async ({ page }) => {
  for (const path of ['/', '/adapid-ai']) {
    await page.goto(path);
    const roll = page.locator('.marquee').first();
    await expect(roll).toBeAttached();
    expect(await roll.locator('img[alt]:not([alt=""])').count()).toBeGreaterThanOrEqual(17);
    await page.getByRole('button', { name: 'Pause customer logos' }).first().click();
    await expect(page.getByRole('button', { name: 'Play customer logos' }).first()).toBeVisible();
  }
});

test('product tour: steps by button, keyboard and link, and ends on a demo', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('link', { name: 'Take the product tour' }).first().click();
  await expect(page).toHaveURL(/\/product-tour/);
  const frame = page.locator('.tour-frame');
  await expect(frame).toContainText('Step 1 of 11');
  await frame.getByRole('button', { name: 'Next' }).click();
  await expect(frame).toContainText('Step 2 of 11');
  await page.keyboard.press('ArrowRight');
  await expect(page).toHaveURL(/#step-3$/);
  await page.goto('/product-tour#step-12');
  await expect(frame.getByRole('link', { name: 'Book a demo' })).toBeVisible();
});
