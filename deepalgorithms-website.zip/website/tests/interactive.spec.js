import { test, expect } from '@playwright/test';
import { hydrated } from './helpers.js';

test('home: the brand moment ends on the four products, each with its own page', async ({ page }) => {
  await page.goto('/');
  await hydrated(page);
  const section = page.locator('section[aria-label="Our products"]');
  await section.scrollIntoViewIfNeeded();
  const box = await section.boundingBox();
  await page.evaluate((y) => window.scrollTo(0, y), box.y + box.height - 900);
  await page.waitForTimeout(600);
  for (const name of ['Zenstra AI', 'adapID AI', 'BotShield AI', 'ICMS Compliance Suite']) await expect(section.getByRole('link', { name: new RegExp(name) })).toBeVisible();
});

test('home: the spotlight switches product on click', async ({ page }) => {
  await page.goto('/');
  await hydrated(page);
  const tab = page.getByRole('tab', { name: /A valid login, an invalid person/ });
  await tab.click();
  await expect(tab).toHaveAttribute('aria-selected', 'true');
  await expect(page.getByRole('tabpanel').getByText('Identity risk')).toBeVisible();
});

test('hero light is painted on a canvas', async ({ page }) => {
  await page.goto('/');
  await hydrated(page);
  await page.waitForTimeout(800);
  const lit = await page.locator('.flow canvas').first().evaluate((c) => { const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data; let n = 0; for (let i = 3; i < d.length; i += 4 * 97) if (d[i] > 0) n++; return n; });
  expect(lit).toBeGreaterThan(50);
});

test('fraud: each mobile capability shows its own gap and phone screen', async ({ page }) => {
  await page.goto('/adapid-ai/fraud-prevention');
  await hydrated(page);
  await page.getByRole('tab', { name: 'Silent TOTP' }).click();
  await expect(page.getByText('SMS OTPs are phished, forwarded by malware and stolen through SIM swaps.')).toBeVisible();
  await expect(page.getByText('This phone is verified')).toBeVisible();
  await page.getByRole('tab', { name: 'Device security' }).click();
  await expect(page.getByText('Your screen is being shared')).toBeVisible();
});

test('identity risk: the policy slider changes the response', async ({ page }) => {
  await page.goto('/adapid-ai');
  await hydrated(page);
  const slider = page.getByLabel('Drag to set a risk score');
  await slider.focus();
  await page.keyboard.press('Home');
  await expect(page.getByText('Normal work continues. Nothing is interrupted.')).toBeVisible();
  await page.keyboard.press('End');
  await expect(page.getByText('End sessions, revoke tokens and open a case with the evidence attached.')).toBeVisible();
});

test('ICMS: each DPDPA duty opens to show the evidence it leaves', async ({ page }) => {
  await page.goto('/dpdpa-compliance');
  await hydrated(page);
  await page.getByRole('button', { name: /Report a breach in time/ }).click();
  await expect(page.getByText('Breach file with timeline and scope')).toBeVisible();
});

test('products: the directory filters by what you protect', async ({ page }) => {
  await page.goto('/products');
  await hydrated(page);
  await page.getByRole('button', { name: 'Personal data' }).click();
  await expect(page.locator('a:has(h3)')).toHaveCount(1);
  await expect(page.getByRole('heading', { name: 'ICMS Compliance Suite' })).toBeVisible();
});

test('demo: choosing a product changes what the session covers', async ({ page }) => {
  await page.goto('/request-demo');
  await hydrated(page);
  await page.getByLabel('Product of interest').selectOption('nhi');
  await expect(page.getByText('Granted versus used permissions')).toBeVisible();
});

test('articles: contents, progress and related reads', async ({ page }) => {
  await page.goto('/blogs/ddos-mitigation-strategy-2026');
  await hydrated(page);
  await expect(page.getByRole('navigation', { name: 'On this page' })).toBeVisible();
  await expect(page.getByRole('heading', { name: 'Keep reading' })).toBeVisible();
});

test('reduced motion shows the statement and the map as plain blocks', async ({ page }) => {
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.goto('/');
  await hydrated(page);
  await expect(page.getByText('The best security is the incident nobody ever has to report.').first()).toBeVisible();
  await expect(page.locator('section[aria-label="Our products"] a')).toHaveCount(4);
});

test('zenstra: the switch turns the agent’s life from without to with', async ({ page }) => {
  await page.goto('/agentic-ai/agentic-identity');
  await hydrated(page);
  const sw = page.getByRole('switch', { name: 'Zenstra' });
  await sw.scrollIntoViewIfNeeded();
  await expect(sw).toHaveAttribute('aria-checked', 'true', { timeout: 5000 }); // turns itself on once seen
  await sw.click();
  await expect(sw).toHaveAttribute('aria-checked', 'false');
  await expect(page.getByText('without Zenstra', { exact: true })).toBeVisible();
});

test('botshield: the slider reveals the proven queue', async ({ page }) => {
  await page.goto('/botshield-ai');
  await hydrated(page);
  const slider = page.getByRole('slider', { name: /findings queue without and with BotShield/ });
  await slider.fill('0');
  await expect(slider).toHaveValue('0');
  // the "with" layer now covers the whole queue
  await expect(slider.locator('xpath=preceding-sibling::div[1]')).toHaveCSS('clip-path', 'inset(0px 0px 0px 0%)');
});
