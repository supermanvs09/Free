import { test, expect } from '@playwright/test';
import { watch } from './helpers.js';

const bg = (loc) => loc.evaluate((el) => getComputedStyle(el).backgroundColor);
const sheets = (page) => page.locator('.page > :not(.stage, .fixed)');

test('one theme: dark bands, and light sheets that alternate tinted and white', async ({ page }) => {
  const errors = watch(page);
  await page.goto('/');
  await expect(page.locator('html')).not.toHaveAttribute('data-theme', 'dark');
  expect(await bg(sheets(page).nth(0))).toBe('rgb(237, 242, 248)');
  expect(await bg(sheets(page).nth(1))).toBe('rgb(255, 255, 255)');
  // the hero is the brand band: white words on Deep Algorithms blue
  const hero = page.locator('.page > .stage').first();
  await expect(hero).toHaveClass(/band-brand/);
  expect(await hero.evaluate((el) => getComputedStyle(el).color)).toBe('rgb(255, 255, 255)');
  expect(errors).toEqual([]);
});

test('there is no theme switch, and an old saved dark choice is ignored', async ({ page }) => {
  await page.addInitScript(() => { try { localStorage.setItem('da-theme', 'dark'); } catch (e) { /* private mode */ } });
  await page.goto('/agentic-ai/agentic-identity');
  await expect(page.locator('.theme-btn')).toHaveCount(0);
  await expect(page.locator('html')).not.toHaveAttribute('data-theme', 'dark');
  expect(await page.evaluate(() => localStorage.getItem('da-theme'))).toBeNull();
});

test('the header turns light over a light sheet', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('header')).not.toHaveClass(/tone-l/);
  await page.evaluate(() => document.getElementById('perimeter-h').scrollIntoView({ behavior: 'instant' }));
  await expect(page.locator('header')).toHaveClass(/tone-l/);
});

test('product pictures are drawn light on a light sheet, the way identity vendors show them', async ({ page }) => {
  await page.goto('/adapid-ai/nhi-security');
  const ink = (sel) => page.locator(sel).first().evaluate((el) => getComputedStyle(el).getPropertyValue('--color-ink').trim().toLowerCase());
  expect(await ink('.page > :not(.stage) h2')).toBe('#0e1116');
  await expect(page.locator('section[aria-labelledby="wb-h"]')).not.toHaveClass(/stage/);
  const win = page.locator('section[aria-labelledby="wb-h"] .vz-win').first();
  expect(await win.evaluate((el) => getComputedStyle(el).backgroundColor)).toBe('rgb(255, 255, 255)');
});
