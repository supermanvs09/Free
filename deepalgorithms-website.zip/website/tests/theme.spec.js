import { test, expect } from '@playwright/test';
import { watch } from './helpers.js';

const bg = (loc) => loc.evaluate((el) => getComputedStyle(el).backgroundColor);
const firstSheet = (page) => page.locator('.page > :not(.stage, .fixed)').first();

test('the default theme mixes dark bands and light sheets', async ({ page }) => {
  const errors = watch(page);
  await page.goto('/');
  await expect(page.locator('html')).not.toHaveAttribute('data-theme', 'dark');
  expect(await bg(firstSheet(page))).toBe('rgb(246, 247, 249)');
  // the hero stays dark
  const hero = page.locator('.page > .stage').first();
  expect(await hero.evaluate((el) => getComputedStyle(el).color)).toBe('rgb(242, 243, 245)');
  expect(errors).toEqual([]);
});

test('the header turns light over a light sheet', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('header')).not.toHaveClass(/tone-l/);
  await page.evaluate(() => document.getElementById('perimeter-h').scrollIntoView({ behavior: 'instant' }));
  await expect(page.locator('header')).toHaveClass(/tone-l/);
});

test('the switch turns the whole site dark and remembers it', async ({ page }) => {
  const errors = watch(page);
  await page.goto('/agentic-ai/agentic-identity');
  const btn = page.locator('.theme-btn');
  await expect(btn).toHaveAttribute('aria-pressed', 'false');
  await btn.click();
  await expect(page.locator('html')).toHaveAttribute('data-theme', 'dark');
  await expect(btn).toHaveAttribute('aria-pressed', 'true');
  expect(await bg(firstSheet(page))).not.toBe('rgb(246, 247, 249)');
  expect(await page.evaluate(() => localStorage.getItem('da-theme'))).toBe('dark');

  // set before the first paint on the next load, so there is no light flash
  await page.reload({ waitUntil: 'commit' });
  expect(await page.evaluate(() => document.documentElement.getAttribute('data-theme'))).toBe('dark');
  await page.waitForLoadState('networkidle');

  await page.locator('.theme-btn').click();
  await expect(page.locator('html')).not.toHaveAttribute('data-theme', 'dark');
  expect(await bg(firstSheet(page))).toBe('rgb(246, 247, 249)');
  expect(errors).toEqual([]);
});

test('product pictures keep their dark tokens on a light sheet', async ({ page }) => {
  await page.goto('/');
  const ink = (sel) => page.locator(sel).first().evaluate((el) => getComputedStyle(el).getPropertyValue('--color-ink').trim().toLowerCase());
  expect(await ink('.page > :not(.stage) h2')).toBe('#0e1116');
  expect(await ink('.page > :not(.stage) .vz')).toBe('#f2f3f5');
});

test('navigating fades the next page in and keeps the theme', async ({ page }) => {
  const errors = watch(page);
  await page.goto('/');
  await page.locator('.theme-btn').click();
  await page.getByRole('link', { name: 'Why Deep Algorithms' }).first().click();
  await expect(page).toHaveURL(/\/platform$/);
  await expect(page.locator('.page.page-in')).toHaveCount(1);
  await expect(page.locator('html')).toHaveAttribute('data-theme', 'dark');
  expect(errors).toEqual([]);
});
