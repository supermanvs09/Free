import { test, expect } from '@playwright/test';
import { watch, hydrated } from './helpers.js';

test.describe('desktop details', () => {
  test.skip(({ isMobile }) => isMobile, 'keyboard shortcuts are a desktop detail');

  test('Ctrl K opens search, and a result opens its page', async ({ page }) => {
    const errors = watch(page);
    await page.goto('/');
    await hydrated(page);
    await page.keyboard.press('Control+k');
    const dialog = page.getByRole('dialog', { name: 'Search the site' });
    await expect(dialog).toBeVisible();
    await page.keyboard.type('mule');
    await expect(page.getByRole('option').first()).toContainText('Mule Account Crisis');
    await page.keyboard.press('Enter');
    await expect(page).toHaveURL(/\/blogs\/india-mule-account-crisis$/);
    await expect(dialog).toHaveCount(0);
    expect(errors).toEqual([]);
  });

  test('the header search button opens search and Escape closes it', async ({ page }) => {
    await page.goto('/platform');
    await hydrated(page);
    await page.getByRole('button', { name: 'Search the site' }).click();
    await expect(page.getByRole('dialog', { name: 'Search the site' })).toBeVisible();
    await page.keyboard.press('Escape');
    await expect(page.getByRole('dialog')).toHaveCount(0);
  });

  test('the ` key opens the terminal, which can open a page', async ({ page }) => {
    const errors = watch(page);
    await page.goto('/');
    await hydrated(page);
    await page.keyboard.press('Backquote');
    await expect(page.getByRole('dialog', { name: 'Deep Algorithms terminal' })).toBeVisible();
    await page.keyboard.type('whoami');
    await page.keyboard.press('Enter');
    await expect(page.getByText('nothing about you is stored')).toBeVisible();
    await page.keyboard.type('open icms');
    await page.keyboard.press('Enter');
    await expect(page).toHaveURL(/\/dpdpa-compliance$/);
    expect(errors).toEqual([]);
  });
});

test('the navbar has no separate Contact link; Contact stays under Company', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('header a[href="/contact"]:visible')).toHaveCount(0);
  await expect(page.locator('footer a[href="/contact"]').first()).toBeAttached();
});

test('a missing page names the address and offers search', async ({ page }) => {
  await page.goto('/no-such-page');
  // the 404 has no reveal animations, so wait for the address the browser fills in
  await expect(page.getByText('GET /no-such-page')).toBeVisible();
  await expect(page.getByRole('button', { name: 'Search the site' }).last()).toBeVisible();
});

test('the home headline is one line on desktop and reads as one sentence', async ({ page, isMobile }) => {
  test.skip(isMobile, 'on a phone the headline wraps rather than shrink');
  await page.goto('/');
  const h1 = page.getByRole('heading', { level: 1, name: 'Identity security for the AI era.' });
  await expect(h1).toBeVisible();
  const { height, size } = await h1.evaluate((el) => ({ height: el.getBoundingClientRect().height, size: parseFloat(getComputedStyle(el).fontSize) }));
  expect(height).toBeLessThan(size * 1.5);
  await expect(page.locator('h1 .tw-ch').last()).toBeVisible({ timeout: 6000 }); // every letter typed
});

test('a picture that leaves and comes straight back still plays its steps', async ({ page, isMobile }) => {
  test.skip(isMobile, 'one viewport is enough');
  await page.goto('/adapid-ai');
  await hydrated(page);
  const vz = page.locator('section:has(#blast-h) .vz');
  const to = (sel) => page.evaluate((s) => document.querySelector(s).scrollIntoView({ block: 'start', behavior: 'instant' }), sel);
  await to('#blast-h');
  await expect(vz).not.toHaveClass(/\bk1\b/); // rewound to step 0 on entering
  await to('#fam-h');                          // out of view before step 1…
  await page.waitForTimeout(150);
  await to('#blast-h');                        // …and straight back
  await expect(vz).toHaveClass(/\bk2\b/, { timeout: 5000 });
});
