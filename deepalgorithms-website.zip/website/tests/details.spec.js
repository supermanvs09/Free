import { test, expect } from '@playwright/test';
import { watch, hydrated } from './helpers.js';

test.describe('desktop details', () => {
  test.skip(({ isMobile }) => isMobile, 'keyboard shortcuts are a desktop detail');

  test('Ctrl K opens search, and a result opens its page', async ({ page }) => {
    const errors = watch(page);
    await page.goto('/');
    await hydrated(page);
    await page.keyboard.press('Control+k');
    const dialog = page.getByRole('dialog', { name: 'Search the site' });
    await expect(dialog).toBeVisible();
    await page.keyboard.type('mule');
    await expect(page.getByRole('option').first()).toContainText('Mule Account Crisis');
    await page.keyboard.press('Enter');
    await expect(page).toHaveURL(/\/blogs\/india-mule-account-crisis$/);
    await expect(dialog).toHaveCount(0);
    expect(errors).toEqual([]);
  });

  test('the header search button opens search and Escape closes it', async ({ page }) => {
    await page.goto('/platform');
    await hydrated(page);
    await page.getByRole('button', { name: 'Search the site' }).click();
    await expect(page.getByRole('dialog', { name: 'Search the site' })).toBeVisible();
    await page.keyboard.press('Escape');
    await expect(page.getByRole('dialog')).toHaveCount(0);
  });

  test('the ` key opens the terminal, which can open a page', async ({ page }) => {
    const errors = watch(page);
    await page.goto('/');
    await hydrated(page);
    await page.keyboard.press('Backquote');
    await expect(page.getByRole('dialog', { name: 'Deep Algorithms terminal' })).toBeVisible();
    await page.keyboard.type('whoami');
    await page.keyboard.press('Enter');
    await expect(page.getByText('nothing about you is stored')).toBeVisible();
    await page.keyboard.type('open icms');
    await page.keyboard.press('Enter');
    await expect(page).toHaveURL(/\/dpdpa-compliance$/);
    expect(errors).toEqual([]);
  });
});

test('the navbar has no separate Contact link; Contact stays under Company', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('header a[href="/contact"]:visible')).toHaveCount(0);
  await expect(page.locator('footer a[href="/contact"]').first()).toBeAttached();
});

test('a missing page names the address and offers search', async ({ page }) => {
  await page.goto('/no-such-page');
  // the 404 has no reveal animations, so wait for the address the browser fills in
  await expect(page.getByText('GET /no-such-page')).toBeVisible();
  await expect(page.getByRole('button', { name: 'Search the site' }).last()).toBeVisible();
});
