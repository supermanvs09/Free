import { test, expect } from '@playwright/test';
import { watch, hydrated } from './helpers.js';

test.describe('desktop details', () => {
  test.skip(({ isMobile }) => isMobile, 'keyboard shortcuts are a desktop detail');

  test('Ctrl K opens search, and a result opens its page', async ({ page }) => {
    const errors = watch(page);
    await page.goto('/');
    await hydrated(page);
    await page.keyboard.press('Control+k');
    const dialog = page.getByRole('dialog', { name: 'Search the site' });
    await expect(dialog).toBeVisible();
    await page.keyboard.type('mule');
    await expect(page.getByRole('option').first()).toContainText('Mule Account Crisis');
    await page.keyboard.press('Enter');
    await expect(page).toHaveURL(/\/blogs\/india-mule-account-crisis$/);
    await expect(dialog).toHaveCount(0);
    expect(errors).toEqual([]);
  });

  test('the header search button opens search and Escape closes it', async ({ page }) => {
    await page.goto('/why-deep-algorithms');
    await hydrated(page);
    await page.getByRole('button', { name: 'Search', exact: true }).click();
    await expect(page.getByRole('dialog', { name: 'Search the site' })).toBeVisible();
    await page.keyboard.press('Escape');
    await expect(page.getByRole('dialog')).toHaveCount(0);
  });

  test('the ` key opens the terminal, which can open a page', async ({ page }) => {
    const errors = watch(page);
    await page.goto('/');
    await hydrated(page);
    await page.keyboard.press('Backquote');
    await expect(page.getByRole('dialog', { name: 'Deep Algorithms terminal' })).toBeVisible();
    await page.keyboard.type('whoami');
    await page.keyboard.press('Enter');
    await expect(page.getByText('nothing about you is stored')).toBeVisible();
    await page.keyboard.type('open icms');
    await page.keyboard.press('Enter');
    await expect(page).toHaveURL(/\/dpdpa-compliance$/);
    expect(errors).toEqual([]);
  });
});

test('the main menu has no separate Contact link; Contact stays under Company', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('nav[aria-label="Primary"] a[href="/contact"]:visible')).toHaveCount(0);
  await expect(page.locator('footer a[href="/contact"]').first()).toBeAttached();
});

test('a missing page names the address and offers search', async ({ page }) => {
  await page.goto('/no-such-page');
  // the 404 has no reveal animations, so wait for the address the browser fills in
  await expect(page.getByText('GET /no-such-page')).toBeVisible();
  await expect(page.getByRole('button', { name: 'Search the site' }).last()).toBeVisible();
});

test('the home hero says what we stop, names who we secure and shows proof before any scroll', async ({ page, isMobile }) => {
  await page.goto('/');
  await expect(page.getByRole('heading', { level: 1, name: 'Stop identity attacks before the damage. Human, machine or AI.' })).toBeVisible();
  await expect(page.getByText('learns how every person, machine identity and AI agent should behave', { exact: false }).first()).toBeVisible();
  const certs = page.getByRole('list', { name: 'Certifications' }).first();
  await expect(certs.getByRole('listitem')).toHaveCount(4);
  if (!isMobile) {
    await expect(certs).toBeInViewport();
    await expect(page.getByRole('img', { name: 'Canara Bank' }).first()).toBeInViewport();
  }
});

test('the utility bar carries search and the language menu, and folds away on scroll', async ({ page, isMobile }) => {
  test.skip(isMobile, 'desktop only');
  await page.goto('/');
  const bar = page.locator('.ubar');
  await expect(bar.getByRole('button', { name: 'Search', exact: true })).toBeVisible();
  await expect(bar.getByRole('button', { name: /Language: English/ })).toBeVisible();
  await page.evaluate(() => window.scrollTo(0, 600));
  await expect(bar).toHaveClass(/away/);
});

test('a picture that leaves and comes straight back still plays its steps', async ({ page, isMobile }) => {
  test.skip(isMobile, 'one viewport is enough');
  await page.goto('/adapid-ai');
  await hydrated(page);
  const vz = page.locator('section:has(#blast-h) .vz');
  const to = (sel) => page.evaluate((s) => document.querySelector(s).scrollIntoView({ block: 'start', behavior: 'instant' }), sel);
  await to('#blast-h');
  await expect(vz).not.toHaveClass(/\bk1\b/); // rewound to step 0 on entering
  await to('#fam-h');                          // out of view before step 1…
  await page.waitForTimeout(150);
  await to('#blast-h');                        // …and straight back
  await expect(vz).toHaveClass(/\bk2\b/, { timeout: 5000 });
});

test('the Trust center lists the four certifications and how to get the documents', async ({ page }) => {
  await page.goto('/trust');
  await expect(page.getByRole('heading', { level: 1, name: 'Security you can verify before you sign.' })).toBeVisible();
  for (const c of ['ISO/IEC 27001', 'SOC 2 Type II', 'ISO/IEC 42001', 'ISO/IEC 27701']) await expect(page.getByRole('heading', { level: 3, name: c })).toBeVisible();
  await expect(page.getByRole('link', { name: /Request compliance documents/ })).toHaveAttribute('href', '/contact');
});

test('trust center: each certification carries its seal and what kind of evidence it is', async ({ page }) => {
  await page.goto('/trust');
  const certs = page.locator('section[aria-labelledby="cert-h"] li');
  await expect(certs).toHaveCount(4);
  await expect(certs.locator('svg.seal')).toHaveCount(4);
  await expect(certs.filter({ hasText: 'SOC 2 Type II' })).toContainText('Audit report');
});
