// Renders the product film frame by frame from the dev server's film.html.
// node tools/film/render.mjs <base-url> <frames-dir> [from] [to]
// Requires `npm run dev` (or any server for this repo) and Playwright's Chromium.
import { chromium } from 'playwright';
import { mkdirSync } from 'node:fs';
const [, , base = 'http://localhost:5173', out = 'frames', from, to] = process.argv;
mkdirSync(out, { recursive: true });
const b = await chromium.launch();
const p = await b.newPage({ viewport: { width: 1920, height: 1080 }, deviceScaleFactor: 1 });
const errs = []; p.on('pageerror', (e) => errs.push(String(e)));
await p.goto(`${base}/film.html`, { waitUntil: 'networkidle' });
await p.waitForTimeout(1000);
const { L, F } = await p.evaluate(() => ({ L: window.__LENGTH, F: window.__FPS }));
const n = Math.round(L * F), i0 = from ? +from : 0, i1 = to ? +to : n;
const t0 = Date.now();
for (let i = i0; i < i1; i++) {
  await p.evaluate((t) => window.__film(t), i / F);
  await p.screenshot({ path: `${out}/f${String(i).padStart(5, '0')}.jpg`, type: 'jpeg', quality: 93 });
  if (i % 150 === 0) console.log(`frame ${i}/${n}  ${((Date.now() - t0) / 1000).toFixed(0)} s`);
}
if (errs.length) console.log('ERRORS', errs.slice(0, 5));
await b.close();
