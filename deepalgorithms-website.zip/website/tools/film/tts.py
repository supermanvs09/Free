"""Narration for the product film: one Kokoro voice, one sentence at a time.
Writes <out>/vo.wav and <out>/timings.json (start and end of every line, seconds).
Usage: python tts.py <kokoro-model-dir> <out-dir> [voice] [speed]"""
import json, sys, os
import numpy as np, soundfile as sf
from kokoro_onnx import Kokoro

here = os.path.dirname(os.path.abspath(__file__))
spec = json.load(open(os.path.join(here, 'script.json')))
mdir, out = sys.argv[1], sys.argv[2]
voice = sys.argv[3] if len(sys.argv) > 3 else spec['voice']
speed = float(sys.argv[4]) if len(sys.argv) > 4 else spec['speed']
k = Kokoro(os.path.join(mdir, 'kokoro-v1.0.onnx'), os.path.join(mdir, 'voices-v1.0.bin'))

def trim(a, sr, thr=0.008):
    idx = np.where(np.abs(a) > thr)[0]
    if not len(idx): return a
    s, e = max(0, idx[0] - int(0.02 * sr)), min(len(a), idx[-1] + int(0.06 * sr))
    return a[s:e]

lead = 0.6
parts, t, cues, sr = [], lead, [], 24000
for ln in spec['lines']:
    a, sr = k.create(ln['say'], voice=voice, speed=speed, lang='en-us')
    a = trim(a.astype(np.float32), sr)
    fade = int(0.012 * sr); a[:fade] *= np.linspace(0, 1, fade); a[-fade:] *= np.linspace(1, 0, fade)
    d = len(a) / sr
    cues.append({'id': ln['id'], 'text': ln['text'], 'start': round(t, 3), 'end': round(t + d, 3)})
    parts.append(a); t += d
    gap = ln.get('after', 0.5); parts.append(np.zeros(int(gap * sr), np.float32)); t += gap
pcm = np.concatenate([np.zeros(int(lead * sr), np.float32)] + parts)
os.makedirs(out, exist_ok=True)
sf.write(os.path.join(out, 'vo.wav'), pcm, sr, subtype='PCM_16')
json.dump({'duration': round(t, 3), 'voice': voice, 'speed': speed, 'lines': cues}, open(os.path.join(out, 'timings.json'), 'w'), indent=1)
print(voice, speed, 'total', round(t, 2), 's,', sum(len(l['text'].split()) for l in spec['lines']), 'words')
