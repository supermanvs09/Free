# Product film

The one-minute film on the home page (`public/video/deep-algorithms-film.mp4`), made entirely from code so it can be re-cut when the products or the words change.

| File | What it does |
| --- | --- |
| `script.json` | The narration, line by line. `text` is what appears on screen and in captions; `say` is what the voice reads (spellings that help pronunciation, such as “Adapt I.D.”); `after` is the pause after each line. |
| `tts.py` | Synthesises the narration with [Kokoro](https://github.com/hexgrad/kokoro) (Apache-2.0), voice `af_heart`, one line at a time. Writes `vo.wav` and `timings.json`. |
| `mix.py` | Generates the score (soft pads, a pulse from the brand moment on, whooshes, a chime, a closing swell), ducks it under the voice and sets it 18 dB below speech. |
| `captions.py` | Writes the WebVTT captions from `timings.json`. |
| `render.mjs` | Opens `film.html` on the dev server and captures every frame at 1920×1080. |
| `src/dev/film/Film.jsx` | The film: ten scenes, each a pure function of time, cut to `timings.json`. It reuses the site’s product pictures with their steps driven by the film clock. |

## Remake it

```bash
# 1. voice (Python 3.11+): pip install kokoro-onnx soundfile
#    model files: kokoro-v1.0.onnx and voices-v1.0.bin from github.com/thewh1teagle/kokoro-onnx/releases
python tools/film/tts.py <model-dir> build/film            # vo.wav + timings.json
cp build/film/timings.json tools/film/timings.json

# 2. sound
python tools/film/mix.py build/film/vo.wav tools/film/timings.json build/film/mix.wav 62.9

# 3. captions
python tools/film/captions.py tools/film/timings.json public/video/deep-algorithms-film.vtt

# 4. picture (needs Playwright with Chromium: npm i -D playwright)
npm run dev &                                              # serves film.html
node tools/film/render.mjs http://localhost:5173 build/film/frames

# 5. encode (loudness to -16 LUFS, true peak -1.5 dB)
ffmpeg -framerate 30 -i build/film/frames/f%05d.jpg -i build/film/mix.wav -map 0:v -map 1:a \
  -af "loudnorm=I=-16:TP=-1.5:LRA=9" -ar 48000 -c:v libx264 -preset slow -crf 22 -pix_fmt yuv420p \
  -profile:v high -level 4.1 -tune animation -g 60 -movflags +faststart -c:a aac -b:a 160k -shortest \
  public/video/deep-algorithms-film.mp4
ffmpeg -ss 24.3 -i public/video/deep-algorithms-film.mp4 -frames:v 1 -c:v libwebp -quality 86 public/video/film-poster.webp
```

Check the narration by ear, or with a speech-to-text pass (for example faster-whisper `small.en`): every product name should come back spelled correctly. A professional voice recording can replace `vo.wav` one-for-one; re-run `timings.json` by hand so the scenes stay on the words.
