/* The walkthrough, as segments. Each starts from a fresh page load so it can be
   recorded (and re-recorded) on its own; make-video.sh joins them in ORDER.
   `phone` and `tablet` are recorded at their own sizes and shown side by side. */
export const ORDER = ['home', 'zenstra', 'adapid', 'botshield', 'icms', 'company', 'research', 'contact', 'dark', 'devices'];

const NAV = 'nav[aria-label="Primary"]';
const tab = (list, n) => `[role=tablist][aria-label="${list}"] [role=tab]:nth-of-type(${n})`;

/* Scroll through a page, stopping at each selector for `hold` seconds. */
async function tour(R, stops) {
  for (const [sel, hold = 1.6, off] of stops) {
    const to = sel === 'bottom' ? 'bottom' : sel;
    const y0 = await R.page.evaluate(() => scrollY);
    const y1 = to === 'bottom' ? await R.page.evaluate(() => document.documentElement.scrollHeight - innerHeight)
      : await R.page.evaluate(([s, o]) => { const el = document.querySelector(s); return el ? el.getBoundingClientRect().top + scrollY - o : null; }, [to, off ?? 110]);
    if (y1 == null) throw new Error('tour: no ' + sel);
    const d = Math.abs(y1 - y0);
    await R.scrollTo(to, Math.min(2.6, Math.max(0.9, d / 1100)), off);
    await R.wait(hold);
  }
}

export const SEGMENTS = {
  async home(R) {
    await R.open('/');
    R.label('Home', 'The headline types itself · graphite and white');
    await R.wait(3.6);
    await R.move(`text:${NAV}>>Products`, 1.1); await R.wait(2.6);
    await R.move(`text:${NAV}>>Solutions`, 0.6); await R.wait(1.6);
    await R.move(`text:${NAV}>>Research`, 0.6); await R.wait(1.4);
    await R.move(`text:${NAV}>>Company`, 0.5); await R.wait(1.4);
    await R.move({ x: 1500, y: 960 }, 0.8);
    await tour(R, [['#perimeter-h', 1.4, 140], ['[data-i="0"]', 8.6, 160], ['[data-i="1"]', 7.6, 160], ['[data-i="2"]', 8.4, 160], ['#film-h', 1.2, 120]]);
    await R.move('#film button[aria-label^="Play"]', 1); await R.wait(1.6);
    await R.move({ x: 1700, y: 980 }, 0.6);
    // the logo moment: a 300vh scroll scene
    const bm = await R.page.evaluate(() => { const el = document.querySelector('section[aria-label="Our products"]'); return { top: el.getBoundingClientRect().top + scrollY, h: el.offsetHeight }; });
    await R.scrollTo(bm.top, 1.2);
    await R.scrollTo(bm.top + (bm.h - R.H) * 0.55, 4.5);
    await R.scrollTo(bm.top + (bm.h - R.H), 3.2);
    await R.wait(1.6);
    await tour(R, [['#spot-h', 1.2, 90]]);
    await R.wait(2.5);
    await R.move('[role=tablist][aria-label="Products"] > div:nth-child(2) [role=tab]', 0.9); await R.click(2.4);
    await R.move('[role=tablist][aria-label="Products"] > div:nth-child(4) [role=tab]', 0.8); await R.click(2.4);
    await R.move({ x: 1780, y: 1000 }, 0.6);
    await tour(R, [['#why-h', 2.2, 160], ['#ind-h', 1.8, 140], ['#res-h', 1.8, 140], ['bottom', 2.2]]);
  },

  async zenstra(R) {
    await R.open('/');
    await R.move(`text:${NAV}>>Products`, 0.9); await R.wait(1.2);
    await R.move('text:#mega>>Explore Zenstra AI', 0.9); await R.click(0);
    await R.afterClickNav();
    R.label('Zenstra AI', 'Security for AI agents');
    await R.wait(3);
    await R.move({ x: 1500, y: 980 }, 0.6);
    await tour(R, [['#where-h', 2.2, 140], ['#caps-h', 1.2, 120]]);
    for (const n of [2, 3, 4]) { await R.move(`[aria-label="Zenstra capabilities"] [role=tab]:nth-of-type(${n})`, 0.7); await R.click(2.2); }
    await R.move({ x: 1600, y: 1000 }, 0.5);
    await tour(R, [['#chg-h', 3.4, 120], ['#dep-h', 2.2, 140], ['#cmp-h', 2.0, 140], ['#faq-h', 0.6, 140]]);
    await R.move('text:Where does Zenstra run?', 0.8); await R.click(2.2);
    await R.move({ x: 1700, y: 1000 }, 0.5);
    await tour(R, [['bottom', 1.6]]);
  },

  async adapid(R) {
    await R.open('/adapid-ai');
    R.label('adapID AI', 'Four identity products');
    await R.wait(3);
    await tour(R, [['#itdr-h', 2.0, 120], ['#blast-h', 9.5, 90], ['#chg-h', 3.6, 120], ['#fam-h', 2.2, 120], ['#pol-h', 0.8, 140]]);
    // drag the risk score
    const box = await R.page.evaluate(() => { const r = document.querySelector('input[type=range]').getBoundingClientRect(); return { x: r.left, y: r.top + r.height / 2, w: r.width }; });
    const v = await R.page.evaluate(() => +document.querySelector('input[type=range]').value);
    await R.move({ x: box.x + box.w * (v / 100), y: box.y }, 0.8);
    await R.page.mouse.down();
    for (const t of [0.35, 0.62, 0.95]) await R.move({ x: box.x + box.w * t, y: box.y }, 0.9);
    await R.page.mouse.up(); await R.wait(1);
    await R.move({ x: 1700, y: 1000 }, 0.5);
    await R.nav('/adapid-ai/fraud-prevention');
    R.label('Identity Fraud Prevention', 'A scam caught mid-payment, on the phone');
    await R.wait(8.4);
    await tour(R, [['#q-h', 2.2, 120], ['#gap-h', 2.0, 120], ['#mob-h', 1.0, 120]]);
    for (const n of [2, 4, 5]) { await R.move(tab('Mobile banking capabilities', n), 0.7); await R.click(2.0); }
    await R.move({ x: 1700, y: 1000 }, 0.5);
    await tour(R, [['#web-h', 4.2, 120], ['#txn-h', 1.2, 120], ['section:has(#txn-h) .scn-frame', 10.5, 150], ['#case-h', 2.0, 120]]);
    await R.nav('/adapid-ai/nhi-security');
    R.label('NHI Security for AWS', 'adapID AI');
    await R.wait(2.6);
    await tour(R, [['#on-h', 1.8, 140], ['#gu-h', 1.8, 140], ['#gen-h', 1.8, 140]]);
    await R.nav('/ad-security');
    R.label('Active Directory Security', 'adapID AI');
    await R.wait(2.2);
    await R.scrollTo(560, 1.4); await R.wait(9);
    await tour(R, [['#tech-h', 1.6, 140], ['#fix-h', 1.6, 140], ['#as-h', 7.5, 110]]);
  },

  async botshield(R) {
    await R.open('/botshield-ai');
    R.label('BotShield AI', 'Exposure, bots and DDoS');
    await R.wait(3);
    await tour(R, [['#loop-h', 2.0, 140], ['#chg-h', 0.8, 120], ['section:has(#chg-h) .scn-frame', 8.6, 130]]);
    await tour(R, [['#bots-h', 6.4, 140], ['#upi-h', 1.8, 160], ['#dd-h', 6.5, 140]]);
    await R.nav('/botshield-ai/ddos-protection');
    R.label('DDoS Protection', 'BotShield AI');
    await R.wait(6.5);
    await tour(R, [['#ln-h', 2.2, 140], ['#pt-h', 2.0, 140], ['#ops-h', 1.6, 140]]);
  },

  async icms(R) {
    await R.open('/dpdpa-compliance');
    R.label('ICMS Compliance Suite', 'DPDPA compliance');
    await R.wait(3);
    await tour(R, [['#duty-h', 1.0, 140]]);
    for (const n of [3, 5]) { await R.move(`section:has(#duty-h) .rounded-\\[22px\\] > div:nth-child(${n}) button[aria-expanded]`, 0.8); await R.click(2.0); }
    await R.move({ x: 1700, y: 1000 }, 0.5);
    await tour(R, [['#discover', 2.0, 40], ['#consent', 2.2, 40], ['#breach', 2.0, 40], ['#chg-h', 3.2, 120], ['#ev-h', 1.8, 140]]);
    await R.nav('/platform');
    R.label('Why Deep Algorithms', 'How the products fit together');
    await R.wait(3);
    await tour(R, [['section[aria-label="How the products fit together"]', 2.6, 90], ['#dep-h', 2.0, 140], ['#trust-h', 1.8, 140]]);
    await R.nav('/products');
    R.label('All products', 'Filter by what you need to protect');
    await R.wait(2.2);
    await tour(R, [['#dir-h', 1.0, 140]]);
    for (const t of ['AI agents', 'Payments', 'Personal data', 'Everything']) { await R.move(`text:${t}`, 0.6); await R.click(1.3); }
    await R.nav('/solutions/bfsi');
    R.label('Solutions · Banking and financial services');
    await R.wait(2.6);
    await tour(R, [['#help-h', 2.2, 140]]);
  },

  async company(R) {
    await R.open('/about-us');
    R.label('About us', 'Company');
    await R.wait(3);
    await tour(R, [['#story-h', 2.0, 140], ['#tl-h', 1.0, 140]]);
    for (const n of [1, 2, 3, 4]) { await R.move(tab('Years', n), 0.6); await R.click(1.5); }
    await R.move({ x: 1700, y: 1000 }, 0.5);
    await tour(R, [['#lead-h', 2.2, 140], ['#bel-h', 1.6, 140], ['#rec-h', 2.0, 140], ['#life-h', 2.0, 140], ['#car-h', 1.4, 140], ['#off-h', 1.6, 140]]);
  },

  async research(R) {
    await R.open('/blogs');
    R.label('Research', 'Search, topics and products');
    await R.wait(2.6);
    await R.move('#rs', 0.9); await R.click(0.3);
    await R.type('mule', 6); await R.wait(1.6);
    for (let i = 0; i < 4; i++) await R.key('Backspace', 0.08);
    await R.wait(0.6);
    await R.move({ x: 1700, y: 1000 }, 0.5);
    await tour(R, [['#all-h', 1.2, 140]]);
    await R.move('section:has(#all-h) button[aria-pressed]:nth-of-type(3)', 0.7).catch(() => {});
    await R.click(1.6);
    await R.move('section:has(#all-h) button[aria-pressed]:nth-of-type(1)', 0.7).catch(() => {});
    await R.click(1.2);
    await R.nav('/blogs/ai-agent-governance');
    R.label('A research report', 'Reading progress, contents and takeaways');
    await R.wait(2.6);
    const h = await R.page.evaluate(() => document.documentElement.scrollHeight);
    await R.scrollTo(Math.round(h * 0.18), 2.2); await R.wait(1.4);
    await R.scrollTo(Math.round(h * 0.42), 3.2); await R.wait(1.2);
    await R.scrollTo(Math.round(h * 0.66), 3.0); await R.wait(1.2);
  },

  async contact(R) {
    await R.open('/request-demo');
    R.label('Book a demo', 'The agenda follows the product you choose');
    await R.wait(2.6);
    await R.move('select', 0.9); await R.click(0.2);
    for (let i = 0; i < 3; i++) await R.key('ArrowDown', 1.1);
    await R.key('Escape', 0.6);
    await R.move('input[autocomplete="name"]', 0.8); await R.click(0.2); await R.type('Asha Rao', 14);
    await R.wait(1.2);
    await R.nav('/contact');
    R.label('Contact', 'Copy the email or phone in one click');
    await R.wait(2.4);
    await R.move('button[aria-label^="Copy email"]', 0.8); await R.click(1.2);
    R.label('Search', 'Ctrl K or ⌘ K, from any page');
    await R.move('header button[aria-label="Search the site"]', 0.9); await R.click(0.8);
    await R.type('mule', 8); await R.wait(1.4);
    await R.key('ArrowDown', 0.6); await R.key('ArrowDown', 0.6); await R.key('ArrowUp', 0.8);
    await R.key('Escape', 0.6);
    R.label('A hidden terminal', 'Press ` on any page');
    await R.move({ x: 1500, y: 980 }, 0.5);
    await R.key('Backquote', 1.0);
    await R.type('help', 9); await R.key('Enter', 2.4);
    await R.type('whoami', 9); await R.key('Enter', 2.0);
    await R.type('exit', 9); await R.key('Enter', 1.0);
  },

  async dark(R) {
    await R.open('/');
    R.label('Dark theme', 'Switch at any time; the choice is remembered');
    await R.wait(1.8);
    await R.move('.theme-btn', 1.0); await R.click(2.2);
    await R.move({ x: 1600, y: 980 }, 0.6);
    await tour(R, [['#perimeter-h', 2.0, 140], ['#spot-h', 2.0, 90], ['#why-h', 1.6, 160]]);
    await R.nav('/agentic-ai/agentic-identity');
    await R.wait(2.4);
    await tour(R, [['#where-h', 1.8, 140], ['#dep-h', 1.6, 140]]);
    await R.scrollTo(0, 1.6);
    await R.move('.theme-btn', 0.9); await R.click(2.2);
    await R.page.evaluate(() => { try { localStorage.removeItem('da-theme'); } catch {} });
  },

  async phone(R) {
    await R.open('/');
    await R.wait(2.5);
    await tour(R, [['#perimeter-h', 1.2, 90], ['#perimeter .space-y-16 .scn-frame', 6.5, 120]]);
    // the bottom bar: menu as a sheet
    await R.move('nav[aria-label="Quick actions"] button', 0.6); await R.click(2.6);
    await R.move('#mobile-menu button[aria-label="Close menu"]', 0.5); await R.click(1.0);
    // a rail you swipe
    await tour(R, [['#why-h', 1.0, 90]]);
    await R.page.evaluate(() => { const r = [...document.querySelectorAll('.m-rail')].find((el) => el.getBoundingClientRect().top > 0); r?.scrollBy({ left: r.clientWidth * 0.85, behavior: 'smooth' }); });
    await R.wait(1.6);
    await R.nav('/botshield-ai');
    await R.wait(2.2);
    await R.scrollBy(1500, 2.6); await R.wait(1.4);
    await tour(R, [['section:has(#chg-h) .scn-frame', 6.5, 140]]);
  },
  async tablet(R) {
    await R.open('/');
    await R.wait(2.5);
    await tour(R, [['#perimeter-h', 1.6, 110], ['#film-h', 1.2, 110]]);
    await R.scrollBy(1500, 2.6); await R.wait(0.8);
    await R.scrollBy(1400, 2.4); await R.wait(1.0);
    await R.scrollTo(0, 1.6); await R.wait(0.6);
    await R.move('button[aria-controls="mobile-menu"]', 0.6); await R.click(2.4);
    await R.scrollBy(0, 0.1);
    await R.move('button[aria-controls="mobile-menu"]', 0.4); await R.click(1.0);
    await R.nav('/agentic-ai/agentic-identity');
    await R.wait(2.2);
    await R.scrollBy(1400, 2.6); await R.wait(1.0);
    await R.scrollBy(1600, 2.6); await R.wait(1.2);
  },
};
